# -*- coding: utf-8 -*-
"""
geocode_parcelle.py — Géocodage cadastral et enrichissement BSS
================================================================

Prend en entrée une référence cadastrale (commune INSEE + section + numéro)
et renvoie automatiquement :
  - Coordonnées Lambert 93 (X, Y) du centroïde de la parcelle
  - Coordonnées WGS84 (lat, lon)
  - Altitude NGF (RGE Alti IGN)
  - Liste des ouvrages BSS voisins (rayon configurable)
  - Profondeur recommandée du forage projet selon les voisins

Sources :
  - apicarto.ign.fr/api/cadastre/parcelle  (cadastre IGN)
  - data.geopf.fr/altimetrie                (RGE Alti)
  - hubeau.eaufrance.fr/api/v1/niveaux_nappes (BSS piézomètres)
  - geoservices.brgm.fr (WFS BSS, optionnel)

Usage CLI :
  python3 geocode_parcelle.py --insee 41171 --section AC --numero 7
  python3 geocode_parcelle.py --insee 41171 --section AC --numero 7 --update-excel

Usage module :
  from geocode_parcelle import geocode_parcelle, mise_a_jour_excel
  data = geocode_parcelle("41171", "AC", "7")
  print(data["x_l93"], data["altitude_ngf"], data["ouvrages_bss"])
"""

import argparse
import json
import math
import sys
from pathlib import Path
from typing import Optional

import requests

try:
    from pyproj import Transformer
    _T_WGS_TO_L93 = Transformer.from_crs("EPSG:4326", "EPSG:2154", always_xy=True)
    _T_L93_TO_WGS = Transformer.from_crs("EPSG:2154", "EPSG:4326", always_xy=True)
except Exception:
    _T_WGS_TO_L93 = None
    _T_L93_TO_WGS = None


# ─────────────────────────────────────────────────────────────────
# 1.  CADASTRE  →  géométrie + centroïde
# ─────────────────────────────────────────────────────────────────
def parcelle_geometry(code_insee: str, section: str, numero: str) -> Optional[dict]:
    """Récupère la parcelle cadastrale via apicarto.ign.fr.
    Renvoie un dict avec 'centroid_lonlat', 'surface_m2', 'commune', 'section', 'numero'.
    """
    section = str(section).strip().upper()
    numero_padded = str(numero).strip().zfill(4)
    url = "https://apicarto.ign.fr/api/cadastre/parcelle"
    params = {
        "code_insee": str(code_insee).strip(),
        "section": section,
        "numero": numero_padded,
    }
    try:
        r = requests.get(url, params=params, timeout=15)
        r.raise_for_status()
        feats = r.json().get("features", [])
        if not feats:
            return None
        feat = feats[0]
        geom = feat.get("geometry", {})
        coords = geom.get("coordinates", [])
        if not coords:
            return None
        # Calculer centroïde du MultiPolygon
        flat = []
        if geom.get("type") == "MultiPolygon":
            for poly in coords:
                for ring in poly:
                    flat.extend(ring)
        elif geom.get("type") == "Polygon":
            for ring in coords:
                flat.extend(ring)
        if not flat:
            return None
        lon_c = sum(p[0] for p in flat) / len(flat)
        lat_c = sum(p[1] for p in flat) / len(flat)
        props = feat.get("properties", {})
        return {
            "centroid_lonlat": (lon_c, lat_c),
            "surface_m2": props.get("contenance"),
            "commune": props.get("nom_com") or props.get("commune"),
            "section": section,
            "numero": str(numero).strip(),
            "raw_props": props,
        }
    except requests.HTTPError as e:
        print(f"  [cadastre] HTTP {e.response.status_code}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"  [cadastre] {e}", file=sys.stderr)
        return None


# ─────────────────────────────────────────────────────────────────
# 2.  ALTIMÉTRIE IGN
# ─────────────────────────────────────────────────────────────────
def altitude_ngf(lon: float, lat: float) -> Optional[float]:
    """Altitude NGF en m via RGE Alti IGN."""
    url = "https://data.geopf.fr/altimetrie/1.0/calcul/alti/rest/elevation.json"
    try:
        r = requests.get(url, params={
            "lon": f"{lon:.6f}", "lat": f"{lat:.6f}",
            "resource": "ign_rge_alti_wld",
        }, timeout=10)
        r.raise_for_status()
        elevs = r.json().get("elevations", [])
        if elevs:
            return float(elevs[0]["z"])
    except Exception as e:
        print(f"  [altimetrie] {e}", file=sys.stderr)
    return None


# ─────────────────────────────────────────────────────────────────
# 3.  OUVRAGES BSS via Hub'Eau (piézométrie)
# ─────────────────────────────────────────────────────────────────
def _haversine_m(lon1, lat1, lon2, lat2):
    R = 6371000
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2 * R * math.asin(math.sqrt(a))


def ouvrages_bss_proches(lon: float, lat: float, rayon_m: float = 1000.0,
                         max_results: int = 20) -> list:
    """Liste les ouvrages BSS autour d'un point (Hub'Eau niveaux_nappes).
    Renvoie triés par distance croissante. Filtrage côté client.
    """
    url = "https://hubeau.eaufrance.fr/api/v1/niveaux_nappes/stations"
    # Hub'Eau ne filtre pas correctement par rayon → on demande beaucoup et on filtre
    # On utilise bbox approximative en degrés (≈ 0.02° = ~2 km)
    deg = rayon_m / 110000.0 * 1.5  # marge
    params = {
        "bbox": f"{lon-deg},{lat-deg},{lon+deg},{lat+deg}",
        "format": "json",
        "size": 100,
    }
    try:
        r = requests.get(url, params=params, timeout=20)
        r.raise_for_status()
        data = r.json().get("data", [])
    except Exception as e:
        print(f"  [hubeau] {e}", file=sys.stderr)
        data = []

    out = []
    for s in data:
        slon = s.get("x") or s.get("longitude")
        slat = s.get("y") or s.get("latitude")
        # Hub'Eau: clés 'x' et 'y' en WGS84, ou via geometry
        if slon is None or slat is None:
            geom = s.get("geometry") or {}
            coords = geom.get("coordinates")
            if coords and len(coords) >= 2:
                slon, slat = coords[0], coords[1]
        if slon is None or slat is None:
            continue
        try:
            slon, slat = float(slon), float(slat)
        except (ValueError, TypeError):
            continue
        d = _haversine_m(lon, lat, slon, slat)
        if d <= rayon_m:
            out.append({
                "code_bss": s.get("code_bss") or s.get("bss_id") or "—",
                "nom": s.get("nom_commune") or s.get("nom") or "—",
                "lon": slon, "lat": slat,
                "profondeur_m": s.get("profondeur_investigation"),
                "altitude_ngf": s.get("altitude_station"),
                "distance_m": round(d, 0),
                "type": s.get("nature") or "Piézomètre",
                "usage": "Mesure",
            })
    out.sort(key=lambda x: x["distance_m"])
    return out[:max_results]


# ─────────────────────────────────────────────────────────────────
# 4.  Base d'ouvrages BSS pré-renseignée (Oucques-la-Nouvelle)
# ─────────────────────────────────────────────────────────────────
# Si Hub'Eau ne retourne rien, on utilise cette base statique pour Oucques.
# Elle peut être étendue manuellement ou via WFS BRGM.
BSS_OUCQUES = [
    {"code_bss": "03963X0033/P",     "nature": "Puits",  "adresse": "Bourg",
     "profondeur_m": 5.10,  "altitude_ngf": 128.0, "date": "1966",
     "usage": "Non renseigné", "niveau_eau_m": None,
     "lon": 1.2922, "lat": 47.8252},
    {"code_bss": "03963X0106/PF",    "nature": "Forage", "adresse": "15 rue Maurice Hallé (parc. AC-7)",
     "profondeur_m": 35.00, "altitude_ngf": 126.0, "date": "2007",
     "usage": "Eau domestique, aspersion", "niveau_eau_m": None,
     "lon": 1.2935, "lat": 47.8237},
    {"code_bss": "03963X0001/FAEP",  "nature": "Forage AEP", "adresse": "Le Bourg",
     "profondeur_m": 70.00, "altitude_ngf": 127.5, "date": "—",
     "usage": "AEP collective", "niveau_eau_m": None,
     "lon": 1.2929, "lat": 47.8246},
    {"code_bss": "03963X0002/FAEP",  "nature": "Forage AEP", "adresse": "La Cigognolle",
     "profondeur_m": 55.00, "altitude_ngf": 129.0, "date": "1948",
     "usage": "AEP collective", "niveau_eau_m": 23.0,
     "lon": 1.2945, "lat": 47.8265},
    {"code_bss": "03963X0102/FAEP",  "nature": "Forage AEP", "adresse": "Oucques",
     "profondeur_m": 55.00, "altitude_ngf": 130.0, "date": "2007",
     "usage": "AEP collective", "niveau_eau_m": None,
     "lon": 1.2918, "lat": 47.8252},
    {"code_bss": "03963X0103/F1PAC", "nature": "Forage géothermique", "adresse": "MARPA, rte de la Guinguette",
     "profondeur_m": 40.00, "altitude_ngf": 124.0, "date": "2002-12-18",
     "usage": "Pompe à chaleur", "niveau_eau_m": 10.35,
     "lon": 1.2895, "lat": 47.8230},
    {"code_bss": "03963X0104/F2PAC", "nature": "Forage géothermique", "adresse": "MARPA, rte de la Guinguette",
     "profondeur_m": 45.00, "altitude_ngf": 124.0, "date": "2002-12-18",
     "usage": "Pompe à chaleur", "niveau_eau_m": 11.13,
     "lon": 1.2893, "lat": 47.8230},
    {"code_bss": "BSS004AQNL/X",     "nature": "Forage profond", "adresse": "Château d'eau (parc. AA-29)",
     "profondeur_m": 244.50, "altitude_ngf": 129.0, "date": "2019-06-07",
     "usage": "Réserve / sondage", "niveau_eau_m": 45.18,
     "lon": 1.2965, "lat": 47.8205},
    {"code_bss": "BSS003XKSW/X",     "nature": "Puits ancien", "adresse": "Château d'eau",
     "profondeur_m": 7.80, "altitude_ngf": 129.9, "date": "~1900",
     "usage": "AEP (REBOUCHÉ)", "niveau_eau_m": 4.20,
     "lon": 1.2967, "lat": 47.8202},
]


def ouvrages_bss_avec_fallback(lon: float, lat: float, commune: str = "",
                               rayon_m: float = 1000.0) -> list:
    """Récupère les ouvrages BSS via Hub'Eau, avec repli sur la base Oucques.
    """
    out = ouvrages_bss_proches(lon, lat, rayon_m=rayon_m)
    if out:
        print(f"  [BSS] {len(out)} ouvrages trouvés via Hub'Eau")
        return out
    # Fallback : base Oucques si commune correspond
    if commune and "oucques" in commune.lower():
        print(f"  [BSS] Hub'Eau vide → repli sur base statique Oucques ({len(BSS_OUCQUES)} ouvrages)")
        result = []
        for o in BSS_OUCQUES:
            d = _haversine_m(lon, lat, o["lon"], o["lat"])
            o2 = dict(o)
            o2["distance_m"] = round(d, 0)
            result.append(o2)
        result.sort(key=lambda x: x["distance_m"])
        return result
    print(f"  [BSS] aucun ouvrage trouvé (Hub'Eau vide, pas de base statique pour {commune!r})")
    return []


# ─────────────────────────────────────────────────────────────────
# 5.  PROFONDEUR RECOMMANDÉE
# ─────────────────────────────────────────────────────────────────
def profondeur_recommandee(ouvrages: list, usage_cible: str = "industriel") -> dict:
    """Analyse statistique simple sur la profondeur des forages voisins.
    """
    forages = [o for o in ouvrages
               if "forage" in (o.get("nature") or o.get("type") or "").lower()
               and o.get("profondeur_m")]
    if not forages:
        return {
            "profondeur_min_m": None,
            "profondeur_max_m": None,
            "profondeur_recommandee_m": None,
            "nappe_visee": "—",
            "nb_voisins": 0,
            "commentaire": "Pas de forage voisin pour analyse statistique.",
        }
    prof = sorted([o["profondeur_m"] for o in forages])
    median = prof[len(prof)//2]
    # Niveau d'eau moyen
    niveaux = [o["niveau_eau_m"] for o in forages if o.get("niveau_eau_m")]
    niveau_moy = sum(niveaux) / len(niveaux) if niveaux else None
    # Recommandation : médiane des forages similaires (excluant les très profonds > 150 m
    # qui sont souvent des sondages de reconnaissance)
    prof_filtre = [p for p in prof if p < 150]
    reco = (sum(prof_filtre) / len(prof_filtre)) if prof_filtre else median
    return {
        "profondeur_min_m": round(min(prof), 1),
        "profondeur_max_m": round(max(prof), 1),
        "profondeur_mediane_m": round(median, 1),
        "profondeur_recommandee_m": round(reco, 1),
        "niveau_piezo_moyen_m": round(niveau_moy, 1) if niveau_moy else None,
        "nb_forages": len(forages),
        "nb_voisins": len(ouvrages),
        "commentaire": (f"Recommandation basée sur la moyenne des "
                        f"{len(prof_filtre)} forages voisins de profondeur < 150 m. "
                        f"Niveau piézométrique moyen attendu : "
                        f"{niveau_moy:.1f} m/sol." if niveau_moy
                        else f"Recommandation basée sur la médiane des "
                             f"{len(forages)} forages voisins."),
    }


# ─────────────────────────────────────────────────────────────────
# 6.  GÉOCODAGE COMPLET (entrée → sortie agrégée)
# ─────────────────────────────────────────────────────────────────
def geocode_parcelle(code_insee: str, section: str, numero: str,
                     rayon_bss_m: float = 1000.0) -> dict:
    """Pipeline complet : parcelle → coordonnées + altitude + BSS.
    """
    print(f"[GEOCODE] Parcelle {code_insee}-{section}-{numero}...")
    parc = parcelle_geometry(code_insee, section, numero)
    if not parc:
        print(f"  [ERR] Parcelle introuvable.")
        return {"error": "Parcelle introuvable", "code_insee": code_insee,
                "section": section, "numero": numero}
    lon, lat = parc["centroid_lonlat"]
    print(f"  Centroïde WGS84 : ({lon:.6f}, {lat:.6f})")
    # Conversion Lambert 93
    if _T_WGS_TO_L93:
        x_l93, y_l93 = _T_WGS_TO_L93.transform(lon, lat)
        x_l93, y_l93 = round(x_l93, 2), round(y_l93, 2)
    else:
        x_l93, y_l93 = None, None
    print(f"  Lambert 93     : X={x_l93}, Y={y_l93}")
    # Altitude
    alti = altitude_ngf(lon, lat)
    print(f"  Altitude NGF   : {alti} m")
    # Ouvrages BSS voisins
    ouvrages = ouvrages_bss_avec_fallback(lon, lat,
                                          commune=parc.get("commune", ""),
                                          rayon_m=rayon_bss_m)
    # Profondeur recommandée
    reco = profondeur_recommandee(ouvrages)
    return {
        "code_insee": code_insee,
        "section": section,
        "numero": str(numero),
        "commune": parc.get("commune"),
        "surface_parcelle_m2": parc.get("surface_m2"),
        "lon_wgs84": round(lon, 6),
        "lat_wgs84": round(lat, 6),
        "x_l93": x_l93,
        "y_l93": y_l93,
        "altitude_ngf_m": alti,
        "ouvrages_bss": ouvrages,
        "recommandation": reco,
    }


# ─────────────────────────────────────────────────────────────────
# 7.  MISE À JOUR EXCEL
# ─────────────────────────────────────────────────────────────────
# Table des départements français (code INSEE 2 premiers chiffres -> libellé)
_DEPTS = {
    "01": "Ain", "02": "Aisne", "03": "Allier", "04": "Alpes-de-Haute-Provence",
    "05": "Hautes-Alpes", "06": "Alpes-Maritimes", "07": "Ardèche", "08": "Ardennes",
    "09": "Ariège", "10": "Aube", "11": "Aude", "12": "Aveyron",
    "13": "Bouches-du-Rhône", "14": "Calvados", "15": "Cantal", "16": "Charente",
    "17": "Charente-Maritime", "18": "Cher", "19": "Corrèze", "2A": "Corse-du-Sud",
    "2B": "Haute-Corse", "21": "Côte-d'Or", "22": "Côtes-d'Armor", "23": "Creuse",
    "24": "Dordogne", "25": "Doubs", "26": "Drôme", "27": "Eure", "28": "Eure-et-Loir",
    "29": "Finistère", "30": "Gard", "31": "Haute-Garonne", "32": "Gers",
    "33": "Gironde", "34": "Hérault", "35": "Ille-et-Vilaine", "36": "Indre",
    "37": "Indre-et-Loire", "38": "Isère", "39": "Jura", "40": "Landes",
    "41": "Loir-et-Cher", "42": "Loire", "43": "Haute-Loire", "44": "Loire-Atlantique",
    "45": "Loiret", "46": "Lot", "47": "Lot-et-Garonne", "48": "Lozère",
    "49": "Maine-et-Loire", "50": "Manche", "51": "Marne", "52": "Haute-Marne",
    "53": "Mayenne", "54": "Meurthe-et-Moselle", "55": "Meuse", "56": "Morbihan",
    "57": "Moselle", "58": "Nièvre", "59": "Nord", "60": "Oise", "61": "Orne",
    "62": "Pas-de-Calais", "63": "Puy-de-Dôme", "64": "Pyrénées-Atlantiques",
    "65": "Hautes-Pyrénées", "66": "Pyrénées-Orientales", "67": "Bas-Rhin",
    "68": "Haut-Rhin", "69": "Rhône", "70": "Haute-Saône", "71": "Saône-et-Loire",
    "72": "Sarthe", "73": "Savoie", "74": "Haute-Savoie", "75": "Paris",
    "76": "Seine-Maritime", "77": "Seine-et-Marne", "78": "Yvelines",
    "79": "Deux-Sèvres", "80": "Somme", "81": "Tarn", "82": "Tarn-et-Garonne",
    "83": "Var", "84": "Vaucluse", "85": "Vendée", "86": "Vienne",
    "87": "Haute-Vienne", "88": "Vosges", "89": "Yonne", "90": "Territoire de Belfort",
    "91": "Essonne", "92": "Hauts-de-Seine", "93": "Seine-Saint-Denis",
    "94": "Val-de-Marne", "95": "Val-d'Oise",
    "971": "Guadeloupe", "972": "Martinique", "973": "Guyane",
    "974": "La Réunion", "976": "Mayotte",
}


def dept_from_insee(code_insee: str) -> str:
    """Déduit le libellé département « NN - Nom » depuis le code INSEE.
    Évite tout désalignement département/commune (correction durable v15.87)."""
    if not code_insee:
        return ""
    code = str(code_insee).strip()
    # DOM (3 chiffres) puis Corse (2A/2B) puis métropole (2 chiffres)
    pref3 = code[:3]
    if pref3 in _DEPTS:
        return f"{pref3} - {_DEPTS[pref3]}"
    pref2 = code[:2]
    if pref2 in ("20",):  # Corse : 2A si <2B0000 sinon 2B (heuristique simple)
        return "2A/2B - Corse"
    if pref2 in _DEPTS:
        return f"{pref2} - {_DEPTS[pref2]}"
    return ""


def dept_code_from_insee(code_insee: str) -> str:
    """Retourne uniquement le code département brut (ex. « 79 »), sans le nom.
    Complément de dept_from_insee pour les cellules qui n'attendent que le code
    (correction durable v15.88 : évite toute donnée géographique résiduelle)."""
    if not code_insee:
        return ""
    code = str(code_insee).strip()
    pref3 = code[:3]
    if pref3 in _DEPTS:
        return pref3
    pref2 = code[:2]
    if pref2 in ("20",):
        return "2A/2B"
    if pref2 in _DEPTS:
        return pref2
    return ""


# Table des régions françaises (découpage 2016) par code département
_REGIONS = {
    "01": "Auvergne-Rhône-Alpes", "03": "Auvergne-Rhône-Alpes", "07": "Auvergne-Rhône-Alpes",
    "15": "Auvergne-Rhône-Alpes", "26": "Auvergne-Rhône-Alpes", "38": "Auvergne-Rhône-Alpes",
    "42": "Auvergne-Rhône-Alpes", "43": "Auvergne-Rhône-Alpes", "63": "Auvergne-Rhône-Alpes",
    "69": "Auvergne-Rhône-Alpes", "73": "Auvergne-Rhône-Alpes", "74": "Auvergne-Rhône-Alpes",
    "21": "Bourgogne-Franche-Comté", "25": "Bourgogne-Franche-Comté", "39": "Bourgogne-Franche-Comté",
    "58": "Bourgogne-Franche-Comté", "70": "Bourgogne-Franche-Comté", "71": "Bourgogne-Franche-Comté",
    "89": "Bourgogne-Franche-Comté", "90": "Bourgogne-Franche-Comté",
    "22": "Bretagne", "29": "Bretagne", "35": "Bretagne", "56": "Bretagne",
    "18": "Centre-Val de Loire", "28": "Centre-Val de Loire", "36": "Centre-Val de Loire",
    "37": "Centre-Val de Loire", "41": "Centre-Val de Loire", "45": "Centre-Val de Loire",
    "2A": "Corse", "2B": "Corse", "2A/2B": "Corse",
    "08": "Grand Est", "10": "Grand Est", "51": "Grand Est", "52": "Grand Est",
    "54": "Grand Est", "55": "Grand Est", "57": "Grand Est", "67": "Grand Est",
    "68": "Grand Est", "88": "Grand Est",
    "02": "Hauts-de-France", "59": "Hauts-de-France", "60": "Hauts-de-France",
    "62": "Hauts-de-France", "80": "Hauts-de-France",
    "75": "Île-de-France", "77": "Île-de-France", "78": "Île-de-France", "91": "Île-de-France",
    "92": "Île-de-France", "93": "Île-de-France", "94": "Île-de-France", "95": "Île-de-France",
    "14": "Normandie", "27": "Normandie", "50": "Normandie", "61": "Normandie", "76": "Normandie",
    "16": "Nouvelle-Aquitaine", "17": "Nouvelle-Aquitaine", "19": "Nouvelle-Aquitaine",
    "23": "Nouvelle-Aquitaine", "24": "Nouvelle-Aquitaine", "33": "Nouvelle-Aquitaine",
    "40": "Nouvelle-Aquitaine", "47": "Nouvelle-Aquitaine", "64": "Nouvelle-Aquitaine",
    "79": "Nouvelle-Aquitaine", "86": "Nouvelle-Aquitaine", "87": "Nouvelle-Aquitaine",
    "09": "Occitanie", "11": "Occitanie", "12": "Occitanie", "30": "Occitanie", "31": "Occitanie",
    "32": "Occitanie", "34": "Occitanie", "46": "Occitanie", "48": "Occitanie", "65": "Occitanie",
    "66": "Occitanie", "81": "Occitanie", "82": "Occitanie",
    "44": "Pays de la Loire", "49": "Pays de la Loire", "53": "Pays de la Loire",
    "72": "Pays de la Loire", "85": "Pays de la Loire",
    "04": "Provence-Alpes-Côte d'Azur", "05": "Provence-Alpes-Côte d'Azur",
    "06": "Provence-Alpes-Côte d'Azur", "13": "Provence-Alpes-Côte d'Azur",
    "83": "Provence-Alpes-Côte d'Azur", "84": "Provence-Alpes-Côte d'Azur",
    "971": "Guadeloupe", "972": "Martinique", "973": "Guyane",
    "974": "La Réunion", "976": "Mayotte",
}


def region_from_dept(dept_code: str) -> str:
    """Déduit le nom de la région (découpage 2016) depuis le code département."""
    return _REGIONS.get(str(dept_code).strip(), "")


def mise_a_jour_excel(xlsx_path: str, data: dict, dept: str = None):
    """Met à jour les cellules X/Y/alti/commune et la feuille Cadastre & BSS.
    Si dept n'est pas fourni, il est déduit automatiquement du code INSEE
    (correction durable v15.87 : plus de département figé sur « 41 »).
    """
    from openpyxl import load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    if dept is None:
        dept = dept_from_insee(data.get("code_insee", ""))

    wb = load_workbook(xlsx_path)
    # 1) Données d'Entrée — coordonnées site
    ws = wb["Données d'Entrée"]
    if data.get("x_l93"):
        ws["C33"] = float(data["x_l93"])
    if data.get("y_l93"):
        ws["C34"] = float(data["y_l93"])
    if data.get("altitude_ngf_m"):
        ws["C35"] = float(data["altitude_ngf_m"])
    if data.get("commune"):
        ws["C37"] = data["commune"]
    if dept:
        ws["C38"] = dept

    # 1bis) Propager la même résolution géographique au 2e tableau
    # "Résolution géographique automatique" (F15, C112-C117) — correction
    # durable v15.88 : avant cette correction, seules C33/C34/C37/C38 étaient
    # mises à jour, ce qui laissait ce second tableau figé sur d'anciennes
    # données (ex. département resté en Alpes-Maritimes 06 après un projet
    # déplacé en Deux-Sèvres 79). On recalcule ici tout ce qui dépend du
    # code INSEE / des coordonnées pour que plus aucune cellule ne reste
    # obsolète après un géocodage.
    commune_nom = data.get("commune", "")
    code_insee = data.get("code_insee", "")
    dept_code = dept_code_from_insee(code_insee)
    region_nom = region_from_dept(dept_code)
    lon_val = data.get("lon_wgs84")
    lat_val = data.get("lat_wgs84")

    if commune_nom:
        ws["F15"] = commune_nom
        ws["C112"] = commune_nom
    if code_insee:
        ws["C113"] = code_insee
    if dept_code:
        ws["C114"] = dept_code
    if region_nom:
        ws["C115"] = region_nom
    if lon_val is not None:
        ws["C116"] = round(float(lon_val), 6)
    if lat_val is not None:
        ws["C117"] = round(float(lat_val), 6)

    # 1ter) Propager vers la feuille "Compléments réglementaires" (C21/C24/D82)
    if "Compléments réglementaires" in wb.sheetnames and (commune_nom or code_insee):
        ws_cr = wb["Compléments réglementaires"]
        if code_insee or dept_code:
            ws_cr["C21"] = f"À vérifier - commune INSEE {code_insee} (DDT {dept_code})"
        if commune_nom:
            ws_cr["C24"] = commune_nom
        if commune_nom or code_insee:
            ws_cr["D82"] = f"{commune_nom} (INSEE {code_insee})"

    # 2) Feuille "Cadastre & BSS" (créer si absente)
    sheet_name = "Cadastre & BSS"
    if sheet_name in wb.sheetnames:
        del wb[sheet_name]
    ws_c = wb.create_sheet(sheet_name)

    # Styles
    teal = "01696F"
    bg_header = PatternFill(start_color=teal, end_color=teal, fill_type="solid")
    bg_input = PatternFill(start_color="FFF8E7", end_color="FFF8E7", fill_type="solid")
    bg_calc = PatternFill(start_color="F0F7F8", end_color="F0F7F8", fill_type="solid")
    bg_result = PatternFill(start_color="E8F4E8", end_color="E8F4E8", fill_type="solid")
    font_h = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
    font_t = Font(name="Calibri", size=10, bold=True, color=teal)
    font_n = Font(name="Calibri", size=10)
    thin = Side(border_style="thin", color="BBBBBB")
    border = Border(top=thin, bottom=thin, left=thin, right=thin)

    # En-tête grand titre
    ws_c.merge_cells("B2:I2")
    ws_c["B2"] = "Cadastre, géolocalisation et ouvrages BSS voisins"
    ws_c["B2"].font = Font(name="Calibri", size=14, bold=True, color=teal)
    ws_c["B2"].alignment = Alignment(horizontal="left", vertical="center")
    ws_c.row_dimensions[2].height = 22

    # Section 1 : Saisie cadastrale
    ws_c["B4"] = "RÉFÉRENCE CADASTRALE (saisie)"
    ws_c["B4"].font = font_t
    headers = [("B5", "Paramètre"), ("C5", "Valeur"), ("D5", "Description")]
    for ref, val in headers:
        ws_c[ref] = val
        ws_c[ref].font = font_h
        ws_c[ref].fill = bg_header
        ws_c[ref].alignment = Alignment(horizontal="center", vertical="center")
        ws_c[ref].border = border

    rows_cad = [
        ("Code INSEE",       data.get("code_insee", ""), "Code commune INSEE (5 chiffres)"),
        ("Section",          data.get("section", ""),    "Section cadastrale (ex. AC, AH)"),
        ("Numéro parcelle",  data.get("numero", ""),     "Numéro de la parcelle (entier)"),
        ("Commune",          data.get("commune", ""),    "Récupérée automatiquement"),
        ("Surface parcelle", data.get("surface_parcelle_m2", ""), "m² (cadastre IGN)"),
    ]
    for i, (lbl, val, desc) in enumerate(rows_cad, start=6):
        ws_c.cell(row=i, column=2, value=lbl).font = font_n
        c = ws_c.cell(row=i, column=3, value=val)
        c.font = Font(name="Calibri", size=10, bold=True, color="01696F")
        c.fill = bg_input if i <= 8 else bg_calc
        c.alignment = Alignment(horizontal="left")
        ws_c.cell(row=i, column=4, value=desc).font = Font(name="Calibri", size=9, italic=True, color="666666")
        for col in (2, 3, 4):
            ws_c.cell(row=i, column=col).border = border

    # Section 2 : Coordonnées calculées
    ws_c["B12"] = "COORDONNÉES CALCULÉES (depuis cadastre)"
    ws_c["B12"].font = font_t
    for ref, val in [("B13", "Paramètre"), ("C13", "Valeur"), ("D13", "Unité")]:
        ws_c[ref] = val
        ws_c[ref].font = font_h
        ws_c[ref].fill = bg_header
        ws_c[ref].alignment = Alignment(horizontal="center")
        ws_c[ref].border = border

    rows_coord = [
        ("Longitude WGS84",  data.get("lon_wgs84", ""), "° décimal"),
        ("Latitude WGS84",   data.get("lat_wgs84", ""), "° décimal"),
        ("X Lambert 93",     data.get("x_l93", ""),     "m"),
        ("Y Lambert 93",     data.get("y_l93", ""),     "m"),
        ("Altitude NGF",     data.get("altitude_ngf_m", ""), "m (RGE Alti IGN)"),
    ]
    for i, (lbl, val, unit) in enumerate(rows_coord, start=14):
        ws_c.cell(row=i, column=2, value=lbl).font = font_n
        c = ws_c.cell(row=i, column=3, value=val)
        c.font = Font(name="Calibri", size=10, bold=True, color="01696F")
        c.fill = bg_result
        ws_c.cell(row=i, column=4, value=unit).font = Font(name="Calibri", size=9)
        for col in (2, 3, 4):
            ws_c.cell(row=i, column=col).border = border

    # Section 3 : Tableau ouvrages BSS
    start = 21
    ws_c.cell(row=start, column=2, value="OUVRAGES BSS VOISINS (rayon ≤ 1 km)").font = font_t
    bss_headers = ["Code BSS", "Nature", "Adresse / lieu-dit",
                   "Distance (m)", "Profondeur (m)", "Alt. sol (m NGF)",
                   "Niveau eau (m/sol)", "Usage", "Date"]
    for j, h in enumerate(bss_headers, start=2):
        cell = ws_c.cell(row=start+1, column=j, value=h)
        cell.font = font_h
        cell.fill = bg_header
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = border

    for k, ouv in enumerate(data.get("ouvrages_bss", [])):
        row = start + 2 + k
        # Compatibilité Hub'Eau (pas tous les champs renseignés)
        nat = ouv.get("nature") or ouv.get("type") or "—"
        adr = ouv.get("adresse") or ouv.get("nom") or "—"
        nv  = ouv.get("niveau_eau_m")
        dat = ouv.get("date") or "—"
        vals = [
            ouv.get("code_bss", "—"), nat, adr,
            ouv.get("distance_m", ""),
            ouv.get("profondeur_m", "") or "—",
            ouv.get("altitude_ngf", "") or "—",
            nv if nv is not None else "—",
            ouv.get("usage", "—"), dat,
        ]
        zebra = (k % 2 == 1)
        for j, v in enumerate(vals, start=2):
            c = ws_c.cell(row=row, column=j, value=v)
            c.font = font_n
            if zebra:
                c.fill = PatternFill(start_color="FAFAFA", end_color="FAFAFA", fill_type="solid")
            c.border = border
            c.alignment = Alignment(horizontal="left", wrap_text=True)

    # Section 4 : Recommandation
    reco_row = start + 3 + len(data.get("ouvrages_bss", []))
    reco = data.get("recommandation", {})
    ws_c.cell(row=reco_row, column=2,
              value="PROFONDEUR RECOMMANDÉE (analyse forages voisins)").font = font_t

    rows_reco = [
        ("Nb ouvrages voisins analysés",       reco.get("nb_voisins"), "—"),
        ("Nb forages exploitables",            reco.get("nb_forages", reco.get("nb_voisins")), "—"),
        ("Profondeur minimale voisins",        reco.get("profondeur_min_m"), "m"),
        ("Profondeur maximale voisins",        reco.get("profondeur_max_m"), "m"),
        ("Profondeur médiane",                 reco.get("profondeur_mediane_m"), "m"),
        ("⚑ Profondeur recommandée projet",    reco.get("profondeur_recommandee_m"), "m"),
        ("Niveau piézo. moyen attendu",        reco.get("niveau_piezo_moyen_m"), "m/sol"),
    ]
    for i, (lbl, val, unit) in enumerate(rows_reco, start=reco_row+1):
        ws_c.cell(row=i, column=2, value=lbl).font = font_n
        c = ws_c.cell(row=i, column=3, value=val if val is not None else "—")
        c.font = Font(name="Calibri", size=10, bold=True, color="01696F")
        c.fill = bg_result
        ws_c.cell(row=i, column=4, value=unit).font = Font(name="Calibri", size=9)

    # Commentaire textuel
    ws_c.merge_cells(start_row=reco_row + 1 + len(rows_reco) + 1,
                     start_column=2,
                     end_row=reco_row + 1 + len(rows_reco) + 1,
                     end_column=10)
    ws_c.cell(row=reco_row + 1 + len(rows_reco) + 1, column=2,
              value="ℹ  " + reco.get("commentaire", "")).font = Font(
        name="Calibri", size=9, italic=True, color="555555")

    # Largeurs colonnes
    widths = {2: 26, 3: 18, 4: 28, 5: 12, 6: 14, 7: 14, 8: 16, 9: 22, 10: 12}
    for col, w in widths.items():
        ws_c.column_dimensions[chr(64 + col)].width = w
    ws_c.sheet_view.showGridLines = False

    # Sommaire — référencer la nouvelle feuille
    if "Sommaire" in wb.sheetnames:
        ws_s = wb["Sommaire"]
        # Chercher une cellule libre pour ajouter le lien
        # On le mettra à B19 par convention
        from openpyxl.styles import Font as F
        already = False
        for row in ws_s.iter_rows(min_row=1, max_row=30):
            for cell in row:
                if cell.value and "Cadastre & BSS" in str(cell.value):
                    already = True
                    break
        if not already:
            ws_s["B19"] = "Cadastre & BSS — feuille de saisie cadastrale et ouvrages voisins"
            ws_s["B19"].font = F(name="Calibri", size=10, bold=True, color="01696F")
            ws_s["B19"].hyperlink = f"#'{sheet_name}'!A1"

    wb.save(xlsx_path)
    print(f"  [OK] Excel mis à jour : {xlsx_path}")


# ─────────────────────────────────────────────────────────────────
# 8.  PERSISTANCE  geocode_result.json (lue par le générateur PDF)
# ─────────────────────────────────────────────────────────────────
def save_geocode_json(data: dict, out_path: str):
    Path(out_path).write_text(
        json.dumps(data, ensure_ascii=False, indent=2,
                   default=lambda o: float(o) if hasattr(o, "real") else str(o)),
        encoding="utf-8"
    )
    print(f"  [OK] JSON sauvegardé : {out_path}")


# ─────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(description="Géocodage cadastral + BSS")
    ap.add_argument("--insee", required=True, help="Code INSEE de la commune (ex. 41171)")
    ap.add_argument("--section", required=True, help="Section cadastrale (ex. AC)")
    ap.add_argument("--numero", required=True, help="Numéro de parcelle (ex. 7)")
    ap.add_argument("--rayon", type=float, default=1000.0, help="Rayon BSS en mètres")
    ap.add_argument("--update-excel", default=None,
                    help="Chemin du fichier Excel à mettre à jour")
    ap.add_argument("--dept", default="41 - Loir-et-Cher", help="Département")
    ap.add_argument("--save-json", default="geocode_result.json",
                    help="Fichier JSON de sortie (lu par le générateur PDF)")
    args = ap.parse_args()

    data = geocode_parcelle(args.insee, args.section, args.numero, rayon_bss_m=args.rayon)

    print()
    print("=" * 60)
    print("RÉSULTAT")
    print("=" * 60)
    print(f"Commune     : {data.get('commune')}")
    print(f"Lon / Lat   : {data.get('lon_wgs84')} / {data.get('lat_wgs84')}")
    print(f"X / Y L93   : {data.get('x_l93')} / {data.get('y_l93')}")
    print(f"Altitude    : {data.get('altitude_ngf_m')} m NGF")
    print(f"Surface     : {data.get('surface_parcelle_m2')} m²")
    print(f"BSS voisins : {len(data.get('ouvrages_bss', []))}")
    reco = data.get("recommandation", {})
    print(f"Reco. prof. : {reco.get('profondeur_recommandee_m')} m "
          f"(min {reco.get('profondeur_min_m')} – max {reco.get('profondeur_max_m')})")
    print()

    if args.save_json:
        save_geocode_json(data, args.save_json)
    if args.update_excel:
        mise_a_jour_excel(args.update_excel, data, dept=args.dept)


if __name__ == "__main__":
    main()
