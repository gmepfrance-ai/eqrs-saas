@echo off
REM ================================================================
REM  G.M.E.P -- Generer le PDF (Windows) - v15.87e PORTABLE
REM  Python 3.12 embarque -- aucune installation requise.
REM  Fonctionne directement depuis le dossier extrait.
REM ================================================================

setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
pushd "%~dp0" >nul

color 1F
title G.M.E.P - Generation du PDF v15.87e (Python portable)

set "LOG=%CD%\GMEP_DerniereExecution.log"
> "%LOG%" echo === GMEP Generation PDF - %DATE% %TIME% === 2>nul
>> "%LOG%" echo Dossier : %CD% 2>nul

echo.
echo ================================================================
echo   G.M.E.P  --  Generation du Dossier Loi sur l'Eau  (v15.87e)
echo   Python portable embarque -- aucune installation requise
echo ================================================================
echo.
echo   Dossier de travail : %CD%
echo.

REM ----------------------------------------------------------------
REM 1) Python portable embarque (prioritaire)
REM ----------------------------------------------------------------
set "PYTHON_EXE="

if exist "%~dp0python_portable\python.exe" (
    set "PYTHON_EXE=%~dp0python_portable\python.exe"
    echo   Python portable detecte : !PYTHON_EXE!
    goto :python_found
)

REM ----------------------------------------------------------------
REM 2) Fallback : Python installe sur le systeme
REM ----------------------------------------------------------------
echo   Python portable absent -- recherche Python systeme...

where py >nul 2>&1
if not errorlevel 1 ( set "PYTHON_EXE=py" & goto :python_found )

where python >nul 2>&1
if not errorlevel 1 (
    python --version >nul 2>&1
    if not errorlevel 1 ( set "PYTHON_EXE=python" & goto :python_found )
)

for %%V in (313 312 311 310 39 38) do (
    if not defined PYTHON_EXE (
        if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" (
            set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
        )
        if exist "C:\Program Files\Python%%V\python.exe" (
            set "PYTHON_EXE=C:\Program Files\Python%%V\python.exe"
        )
    )
)
if defined PYTHON_EXE goto :python_found

echo  [ERREUR] Python introuvable.
echo  Le dossier python_portable est absent et Python n'est pas installe.
echo  Verifiez que vous avez extrait TOUS les fichiers du ZIP dans le meme dossier.
>> "%LOG%" echo [ERREUR] Python introuvable 2>nul
echo.
pause & popd >nul & exit /b 1

:python_found
>> "%LOG%" echo Python : !PYTHON_EXE! 2>nul

REM ----------------------------------------------------------------
REM 3) Verifier le script Python
REM ----------------------------------------------------------------
if not exist "generate_rapport_loi_eau.py" (
    echo  [ERREUR] generate_rapport_loi_eau.py introuvable dans : %CD%
    echo  Verifiez que vous avez extrait TOUS les fichiers du ZIP.
    >> "%LOG%" echo [ERREUR] generate_rapport_loi_eau.py introuvable 2>nul
    echo.
    pause & popd >nul & exit /b 1
)

REM ----------------------------------------------------------------
REM 4) Fichier Excel -- priorite au fichier Souvigne
REM ----------------------------------------------------------------
set "EXCEL_FILE="
if exist "Modelisation_Rabattement_TSN_GMEP_-Souvigne.xlsm" set "EXCEL_FILE=Modelisation_Rabattement_TSN_GMEP_-Souvigne.xlsm"
if not defined EXCEL_FILE if exist "Modelisation_Rabattement_TSN_GMEP.xlsm" set "EXCEL_FILE=Modelisation_Rabattement_TSN_GMEP.xlsm"
if not defined EXCEL_FILE if exist "Modelisation_Rabattement_TSN_GMEP.xlsx" set "EXCEL_FILE=Modelisation_Rabattement_TSN_GMEP.xlsx"

if not defined EXCEL_FILE (
    echo  [ERREUR] Aucun fichier Excel Modelisation_Rabattement_TSN_GMEP.xls* trouve.
    >> "%LOG%" echo [ERREUR] Excel introuvable 2>nul
    echo.
    pause & popd >nul & exit /b 1
)

echo   Fichier Excel : !EXCEL_FILE!
>> "%LOG%" echo Fichier Excel : !EXCEL_FILE! 2>nul
echo.

REM ----------------------------------------------------------------
REM 5) Modules Python (seulement si Python systeme, pas portable)
REM ----------------------------------------------------------------
if not "!PYTHON_EXE!"=="%~dp0python_portable\python.exe" (
    echo   Verification des modules Python...
    "!PYTHON_EXE!" -c "import openpyxl, reportlab, PIL, matplotlib, requests, pyproj" >nul 2>&1
    if errorlevel 1 (
        echo   Installation des modules manquants (1-2 min)...
        "!PYTHON_EXE!" -m pip install --quiet openpyxl reportlab Pillow matplotlib requests pyproj
        if errorlevel 1 (
            echo  [ERREUR] Echec installation modules Python.
            >> "%LOG%" echo [ERREUR] pip install echoue 2>nul
            echo.
            pause & popd >nul & exit /b 1
        )
    )
    echo   Modules : OK
    echo.
)

REM ----------------------------------------------------------------
REM 6) UTF-8 + fermer Excel
REM ----------------------------------------------------------------
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8:replace

echo   Fermeture d'Excel si ouvert...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $xl = [Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application'); if ($xl) { foreach ($wb in @($xl.Workbooks)) { if ($wb.Name -match 'Rabattement|Modelisation') { $wb.Save(); $wb.Close($false) } }; if ($xl.Workbooks.Count -eq 0) { $xl.Quit() }; [Runtime.InteropServices.Marshal]::ReleaseComObject($xl) | Out-Null } } catch {}" >nul 2>&1
if exist "~$*.xls*" del /q "~$*.xls*" >nul 2>&1
ping -n 3 127.0.0.1 >nul 2>&1

REM ----------------------------------------------------------------
REM 7) Lancer la generation
REM ----------------------------------------------------------------
echo.
echo ================================================================
echo   Generation du PDF en cours...
echo   Duree estimee : 30 a 90 secondes. NE FERMEZ PAS cette fenetre.
echo ================================================================
echo.

>> "%LOG%" echo === SORTIE PYTHON === 2>nul

"!PYTHON_EXE!" -X utf8 -u "generate_rapport_loi_eau.py" "!EXCEL_FILE!" 2>&1
set "PYRET=!ERRORLEVEL!"

>> "%LOG%" echo === FIN PYTHON (code !PYRET!) === 2>nul
echo.
echo ================================================================

if not "!PYRET!"=="0" (
    echo  [ERREUR] Generation echouee (code !PYRET!).
    echo  Detail dans le log : %LOG%
    echo ================================================================
    >> "%LOG%" echo [ERREUR] code !PYRET! 2>nul
    echo.
    echo  Appuyez sur une touche pour fermer...
    pause
    popd >nul & exit /b !PYRET!
)

REM ----------------------------------------------------------------
REM 8) Ouvrir le PDF
REM ----------------------------------------------------------------
set "PDF_FILE=Dossier_Declaration_Loi_Eau_GMEP.pdf"
if not exist "!PDF_FILE!" (
    echo  [ERREUR] Le PDF n'a pas ete cree. Consultez : %LOG%
    echo.
    pause & popd >nul & exit /b 1
)

echo  PDF genere avec succes !
echo  Emplacement : %CD%\!PDF_FILE!
>> "%LOG%" echo [OK] PDF genere 2>nul
echo ================================================================
echo.

ping -n 3 127.0.0.1 >nul 2>&1
start "" "%CD%\!PDF_FILE!"

echo  Fermeture dans 5 secondes...
ping -n 6 127.0.0.1 >nul 2>&1
popd >nul
exit /b 0
