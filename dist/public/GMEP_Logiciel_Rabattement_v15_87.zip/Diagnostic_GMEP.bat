@echo off
REM ================================================================
REM  G.M.E.P -- DIAGNOSTIC complet (v15.87c)
REM  Compatible chemins avec apostrophes/espaces/accents.
REM ================================================================

setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1

pushd "%~dp0" >nul

REM Ecrit DANS LE DOSSIER DU SCRIPT (evite le bug OneDrive qui redirige
REM le Bureau vers un chemin casse pour %USERPROFILE%\Desktop).
set "RAPPORT=%CD%\GMEP_Diagnostic.txt"

color 1F
title G.M.E.P - Diagnostic v15.87c

echo ================================================================
echo   G.M.E.P  --  Diagnostic complet
echo ================================================================
echo.
echo   Rapport sera ecrit dans : %RAPPORT%
echo   Dossier teste           : %CD%
echo.

> "%RAPPORT%" echo ================================================================ 2>nul
>> "%RAPPORT%" echo  G.M.E.P  --  DIAGNOSTIC - %DATE% %TIME% 2>nul
>> "%RAPPORT%" echo ================================================================ 2>nul
>> "%RAPPORT%" echo. 2>nul
>> "%RAPPORT%" echo Dossier de travail : %CD% 2>nul
>> "%RAPPORT%" echo Utilisateur        : %USERNAME% 2>nul
>> "%RAPPORT%" echo Ordinateur         : %COMPUTERNAME% 2>nul
>> "%RAPPORT%" echo. 2>nul

REM === Test 1 : fichiers essentiels ===
echo [1/6] Verification des fichiers essentiels...
>> "%RAPPORT%" echo [TEST 1] FICHIERS ESSENTIELS 2>nul
>> "%RAPPORT%" echo ---------------------------------------- 2>nul

set "MISSING=0"
if exist "generate_rapport_loi_eau.py" (
    >> "%RAPPORT%" echo   [OK]    generate_rapport_loi_eau.py 2>nul
    echo    [OK] generate_rapport_loi_eau.py
) else (
    >> "%RAPPORT%" echo   [MANQUE] generate_rapport_loi_eau.py 2>nul
    echo    [MANQUE] generate_rapport_loi_eau.py
    set /a MISSING+=1
)

if exist "update_excel_geo.py" (
    >> "%RAPPORT%" echo   [OK]    update_excel_geo.py 2>nul
    echo    [OK] update_excel_geo.py
) else (
    >> "%RAPPORT%" echo   [MANQUE] update_excel_geo.py 2>nul
    echo    [MANQUE] update_excel_geo.py
    set /a MISSING+=1
)

if exist "Generer_PDF.bat" (
    >> "%RAPPORT%" echo   [OK]    Generer_PDF.bat 2>nul
    echo    [OK] Generer_PDF.bat
) else (
    >> "%RAPPORT%" echo   [MANQUE] Generer_PDF.bat 2>nul
    echo    [MANQUE] Generer_PDF.bat
    set /a MISSING+=1
)

set "EXCEL_FILE="
if exist "Modelisation_Rabattement_TSN_GMEP.xlsm" set "EXCEL_FILE=Modelisation_Rabattement_TSN_GMEP.xlsm"
if not defined EXCEL_FILE if exist "Modelisation_Rabattement_TSN_GMEP.xlsx" set "EXCEL_FILE=Modelisation_Rabattement_TSN_GMEP.xlsx"

if defined EXCEL_FILE (
    >> "%RAPPORT%" echo   [OK]    Fichier Excel : !EXCEL_FILE! 2>nul
    echo    [OK] Fichier Excel : !EXCEL_FILE!
) else (
    >> "%RAPPORT%" echo   [MANQUE] Aucun fichier Excel 2>nul
    echo    [MANQUE] Aucun fichier Excel
    set /a MISSING+=1
)
>> "%RAPPORT%" echo. 2>nul
echo.

REM === Test 2 : Python ===
echo [2/6] Recherche de Python...
>> "%RAPPORT%" echo [TEST 2] PYTHON 2>nul
>> "%RAPPORT%" echo ---------------------------------------- 2>nul

set "PYTHON_EXE="
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYTHON_EXE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYTHON_EXE if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PYTHON_EXE if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
if not defined PYTHON_EXE if exist "C:\Program Files\Python313\python.exe" set "PYTHON_EXE=C:\Program Files\Python313\python.exe"
if not defined PYTHON_EXE if exist "C:\Program Files\Python312\python.exe" set "PYTHON_EXE=C:\Program Files\Python312\python.exe"
if not defined PYTHON_EXE if exist "C:\Program Files\Python311\python.exe" set "PYTHON_EXE=C:\Program Files\Python311\python.exe"

if defined PYTHON_EXE (
    >> "%RAPPORT%" echo   [OK]    Python trouve : !PYTHON_EXE! 2>nul
    echo    [OK] Python : !PYTHON_EXE!
    "!PYTHON_EXE!" --version >> "%RAPPORT%" 2>&1
    "!PYTHON_EXE!" --version
) else (
    >> "%RAPPORT%" echo   [ERREUR] Python NON INSTALLE. 2>nul
    >> "%RAPPORT%" echo            Telechargez Python 3.11+ depuis https://www.python.org/downloads/ 2>nul
    >> "%RAPPORT%" echo            ATTENTION : cocher "Add Python to PATH" pendant l'installation. 2>nul
    echo    [ERREUR] Python NON INSTALLE.
)
>> "%RAPPORT%" echo. 2>nul
echo.

REM === Test 3 : Modules ===
if defined PYTHON_EXE (
    echo [3/6] Verification des modules Python...
    >> "%RAPPORT%" echo [TEST 3] MODULES PYTHON 2>nul
    >> "%RAPPORT%" echo ---------------------------------------- 2>nul
    "!PYTHON_EXE!" -c "import openpyxl" >nul 2>&1
    if errorlevel 1 ( >> "%RAPPORT%" echo   [MANQUE] openpyxl & echo    [MANQUE] openpyxl ) else ( >> "%RAPPORT%" echo   [OK]    openpyxl & echo    [OK] openpyxl )
    "!PYTHON_EXE!" -c "import reportlab" >nul 2>&1
    if errorlevel 1 ( >> "%RAPPORT%" echo   [MANQUE] reportlab & echo    [MANQUE] reportlab ) else ( >> "%RAPPORT%" echo   [OK]    reportlab & echo    [OK] reportlab )
    "!PYTHON_EXE!" -c "import PIL" >nul 2>&1
    if errorlevel 1 ( >> "%RAPPORT%" echo   [MANQUE] PIL & echo    [MANQUE] PIL ) else ( >> "%RAPPORT%" echo   [OK]    PIL & echo    [OK] PIL )
    "!PYTHON_EXE!" -c "import matplotlib" >nul 2>&1
    if errorlevel 1 ( >> "%RAPPORT%" echo   [MANQUE] matplotlib & echo    [MANQUE] matplotlib ) else ( >> "%RAPPORT%" echo   [OK]    matplotlib & echo    [OK] matplotlib )
    "!PYTHON_EXE!" -c "import requests" >nul 2>&1
    if errorlevel 1 ( >> "%RAPPORT%" echo   [MANQUE] requests & echo    [MANQUE] requests ) else ( >> "%RAPPORT%" echo   [OK]    requests & echo    [OK] requests )
    >> "%RAPPORT%" echo. 2>nul
    echo.
)

REM === Test 4 : Verrous Excel ===
echo [4/6] Verification verrous Excel...
>> "%RAPPORT%" echo [TEST 4] VERROUS EXCEL 2>nul
>> "%RAPPORT%" echo ---------------------------------------- 2>nul
if exist "~$*.xls*" (
    >> "%RAPPORT%" echo   [VERROU] Fichier ~$ present 2>nul
    echo    [VERROU] Fichier ~$ present
    dir /b "~$*.xls*" >> "%RAPPORT%"
) else (
    >> "%RAPPORT%" echo   [OK]    Aucun verrou Office 2>nul
    echo    [OK] Aucun verrou Office
)
>> "%RAPPORT%" echo. 2>nul
echo.

REM === Test 5 : Droits ecriture ===
echo [5/6] Test d'ecriture dans le dossier...
>> "%RAPPORT%" echo [TEST 5] DROITS D'ECRITURE 2>nul
>> "%RAPPORT%" echo ---------------------------------------- 2>nul
set "TESTFILE=_gmep_writetest.tmp"
> "%TESTFILE%" echo test 2>nul
if exist "%TESTFILE%" (
    del "%TESTFILE%" >nul 2>&1
    >> "%RAPPORT%" echo   [OK]    Ecriture autorisee 2>nul
    echo    [OK] Ecriture autorisee
) else (
    >> "%RAPPORT%" echo   [ERREUR] Impossible d'ecrire dans le dossier 2>nul
    >> "%RAPPORT%" echo            OneDrive synchronise ? Lecture seule ? 2>nul
    echo    [ERREUR] Ecriture impossible
)
>> "%RAPPORT%" echo. 2>nul
echo.

REM === Test 6 : Chemin ===
echo [6/6] Verification du chemin...
>> "%RAPPORT%" echo [TEST 6] CHEMIN 2>nul
>> "%RAPPORT%" echo ---------------------------------------- 2>nul
>> "%RAPPORT%" echo   Chemin : %CD% 2>nul

echo %CD% | findstr /C:"'" >nul
if not errorlevel 1 (
    >> "%RAPPORT%" echo   [INFO]  Apostrophe presente dans le chemin 2>nul
    >> "%RAPPORT%" echo           v15.87c traite ce cas correctement. 2>nul
    echo    [INFO] Apostrophe presente dans le chemin
    echo           v15.87c traite ce cas correctement.
)

echo %CD% | findstr /C:"OneDrive" >nul
if not errorlevel 1 (
    >> "%RAPPORT%" echo   [INFO]  Dossier sur OneDrive ^(synchronisation cloud^) 2>nul
    echo    [INFO] OneDrive
)

>> "%RAPPORT%" echo. 2>nul

REM === Synthese ===
echo ================================================================
echo   DIAGNOSTIC TERMINE
echo ================================================================
echo.
echo   Rapport sauvegarde : %RAPPORT%
echo.
>> "%RAPPORT%" echo ================================================================ 2>nul
>> "%RAPPORT%" echo  FIN DU DIAGNOSTIC 2>nul
>> "%RAPPORT%" echo ================================================================ 2>nul

REM Ouvrir le rapport
start "" notepad "%RAPPORT%"

echo Appuyez sur une touche pour fermer cette fenetre...
pause >nul
popd >nul
exit /b 0
