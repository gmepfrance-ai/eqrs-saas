#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generateur de dossier de declaration Loi sur l'Eau -- Rubriques 1.1.1.0 + 1.1.2.0
G.M.E.P -- Rabattement d'une nappe souterraine
"""

import os
import json
import sys
from datetime import datetime
from pathlib import Path
import urllib.request

# ─────────────────────────────────────────────
# TEE LOGGER : affiche ET ecrit dans le log
# ─────────────────────────────────────────────
class _Tee:
    """Redirige stdout vers la console ET vers un fichier log."""
    def __init__(self, log_path):
        self._console = sys.__stdout__
        try:
            self._log = open(log_path, "a", encoding="utf-8", errors="replace", buffering=1)
        except Exception:
            self._log = None
    def write(self, data):
        self._console.write(data)
        self._console.flush()
        if self._log:
            try:
                self._log.write(data)
            except Exception:
                pass
    def flush(self):
        self._console.flush()
        if self._log:
            try: self._log.flush()
            except Exception: pass
    def fileno(self):
        return self._console.fileno()

_gmep_log = os.environ.get("GMEP_LOG_FILE", "")
if _gmep_log:
    sys.stdout = _Tee(_gmep_log)
    sys.stderr = _Tee(_gmep_log)

from openpyxl import load_workbook
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.colors import HexColor
from reportlab.lib.units import cm, mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable, KeepTogether
)
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics
from reportlab.platypus import Image as RLImage

# ─────────────────────────────────────────────
# COULEURS GMEP
# ─────────────────────────────────────────────
C_TEAL_DARK   = HexColor("#1B474D")   # En-têtes principaux
C_TEAL_MED    = HexColor("#2A6B73")   # En-têtes secondaires
C_TEAL_LIGHT  = HexColor("#E8F4F6")   # Fond alternance tableau
C_TEAL_XLIGHT = HexColor("#F2FAFB")   # Fond très clair
C_ORANGE      = HexColor("#C8641A")   # Paramètres géologiques
C_BLUE_DARK   = HexColor("#003399")   # Données saisies
C_GREEN_DARK  = HexColor("#1A5C2A")   # Résultats calculés
C_GOLD        = HexColor("#F5A623")   # Mise en évidence
C_RED         = HexColor("#C0392B")   # Alerte / Dépassement
C_GREY_LIGHT  = HexColor("#F5F5F5")
C_GREY_MED    = HexColor("#D0D0D0")
C_GREY_DARK   = HexColor("#666666")
C_WHITE       = colors.white
C_BLACK       = colors.black

W, H = A4  # 595.27 x 841.89 pts

# ─────────────────────────────────────────────
# POLICES
# ─────────────────────────────────────────────
import tempfile
FONT_DIR = Path(tempfile.gettempdir()) / "fonts_gmep"
FONT_DIR.mkdir(exist_ok=True)

def download_font(name, url, filename):
    path = FONT_DIR / filename
    if not path.exists():
        try:
            urllib.request.urlretrieve(url, path)
        except Exception:
            return False
    try:
        pdfmetrics.registerFont(TTFont(name, str(path)))
        return True
    except Exception:
        return False

# Polices Open Sans
fonts_ok = all([
    download_font("OpenSans",        "https://github.com/google/fonts/raw/main/apache/opensans/OpenSans%5Bwdth%2Cwght%5D.ttf", "OpenSans.ttf"),
    download_font("OpenSans-Bold",   "https://github.com/google/fonts/raw/main/apache/opensans/OpenSans%5Bwdth%2Cwght%5D.ttf", "OpenSans.ttf"),
])
# Fallback fiable : Helvetica
FONT_BODY = "Helvetica"
FONT_BOLD = "Helvetica-Bold"
FONT_ITALIC = "Helvetica-Oblique"

# ─────────────────────────────────────────────
# LECTURE DU FICHIER EXCEL + RECALCUL PYTHON
# ─────────────────────────────────────────────
import math

# ── Résolution robuste du chemin Excel ──
# Priorité 1 : argument passé en ligne de commande (depuis VBS/BAT)
# Priorité 2 : même dossier que le script
# Priorité 3 : dossier courant
# Supporte .xlsx et .xlsm, et les noms avec accents sous Windows

import sys, glob as _glob

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

def _find_excel(base_dir):
    """Cherche le fichier Excel GMEP dans base_dir.

    Ordre de priorite :
      1) Nom canonique sans accent  (Modelisation_Rabattement_TSN_GMEP)
      2) Nom avec accent             (Modélisation_Rabattement_TSN_GMEP)
      3) Glob generique *Rabattement_TSN_GMEP  -- mais on trie pour
         mettre le nom sans accent en premier.
    """
    import unicodedata as _ud

    for ext in (".xlsx", ".xlsm"):
        # Priorite 1 : sans accent (version courante)
        p = os.path.join(base_dir, "Modelisation_Rabattement_TSN_GMEP" + ext)
        if os.path.exists(p) and not os.path.basename(p).startswith("~$"):
            return p
        # Priorite 2 : avec accent (ancienne version)
        p = os.path.join(base_dir, "Modélisation_Rabattement_TSN_GMEP" + ext)
        if os.path.exists(p) and not os.path.basename(p).startswith("~$"):
            return p
        # Priorite 3 : glob generique -- IGNORE les fichiers temporaires ~$
        matches = _glob.glob(os.path.join(base_dir, f"*Rabattement_TSN_GMEP{ext}"))
        matches = [m for m in matches if not os.path.basename(m).startswith("~$")]
        if matches:
            matches.sort(key=lambda f: _ud.normalize("NFKD", os.path.basename(f)))
            return matches[0]
    return None

XLSX_PATH = None

# Priorité 1 : argument ligne de commande
if len(sys.argv) > 1:
    arg = sys.argv[1]
    # REJET STRICT : ne jamais utiliser un fichier verrou Excel ~$...
    if os.path.basename(arg).startswith("~$"):
        print(f"  [AVERT] Argument ignoré (fichier verrou Excel) : {arg}")
        arg = ""
    if arg and os.path.exists(arg):
        XLSX_PATH = arg
        SCRIPT_DIR = os.path.dirname(os.path.abspath(arg))
    else:
        # L'arg peut être un dossier
        if os.path.isdir(arg):
            XLSX_PATH = _find_excel(arg)
            if XLSX_PATH:
                SCRIPT_DIR = arg

# Priorité 2 : dossier du script
if not XLSX_PATH:
    XLSX_PATH = _find_excel(SCRIPT_DIR)

# Priorité 3 : dossier courant
if not XLSX_PATH:
    XLSX_PATH = _find_excel(os.getcwd())

# Erreur explicite si pas trouvé
if not XLSX_PATH:
    print(f"[ERREUR FATAL] Fichier Excel introuvable dans : {SCRIPT_DIR}")
    print(f"  Fichiers présents : {os.listdir(SCRIPT_DIR)}")
    sys.exit(1)

print(f"  Fichier Excel lu : {XLSX_PATH}")

# === V15.56 : Tentative de lecture du fichier avec retry (OneDrive peut prendre du temps)
# La vérification stricte du verrou (r+b) est trop agressive sur OneDrive.
# On essaie d'ouvrir le fichier en LECTURE SEULE avec plusieurs tentatives.
import time as _time
_read_ok = False
for _attempt in range(15):  # 15 secondes max
    try:
        with open(XLSX_PATH, "rb") as _fh:
            _fh.read(1024)  # lire au moins un bloc
        _read_ok = True
        break
    except (PermissionError, OSError):
        _time.sleep(1)

if not _read_ok:
    print("")
    print("  =====================================================================")
    print("  *** ERREUR : impossible de lire le fichier Excel ***")
    print("  =====================================================================")
    print("")
    print(f"  Fichier : {XLSX_PATH}")
    print("")
    print("  Causes possibles :")
    print("    - Le fichier est encore ouvert dans Microsoft Excel")
    print("    - OneDrive est en cours de synchronisation")
    print("    - Le fichier est sur un emplacement reseau lent")
    print("")
    print("  SOLUTION :")
    print("    1) Fermer Excel completement (clic sur la croix X)")
    print("    2) Attendre 10 secondes (synchronisation OneDrive)")
    print("    3) Relancer la generation")
    print("")
    print("  =====================================================================")
    sys.exit(2)

# Base géologique intégrée (42 formations) — v15.78 : Pack France entier (11 régionales)
# Colonnes: famille, type_nappe, K, T, S_captif, S_libre, porosite(%), ep(m)
GEO_DB = {
    "Argile compacte":           {"famille":"Argile",          "type_nappe":"Captif", "K":1e-10,  "T":1e-10,    "S_captif":1e-6,   "S_libre":0.02, "porosite":2,   "ep":5},
    "Argile sableuse":           {"famille":"Argile",          "type_nappe":"Captif", "K":5e-9,   "T":2e-8,    "S_captif":5e-6,   "S_libre":0.03, "porosite":5,   "ep":4},
    "Marne argileuse":           {"famille":"Argile",          "type_nappe":"Captif", "K":1e-9,   "T":8e-9,    "S_captif":2e-6,   "S_libre":0.02, "porosite":3,   "ep":8},
    "Marne calcaire":            {"famille":"Marne",           "type_nappe":"Captif", "K":5e-8,   "T":3e-7,    "S_captif":8e-6,   "S_libre":0.03, "porosite":8,   "ep":15},
    "Marno-calcaire fissuré":    {"famille":"Marne",           "type_nappe":"Libre",  "K":1e-6,   "T":3e-5,    "S_captif":2e-5,   "S_libre":0.04, "porosite":10,  "ep":20},
    "Limon éolien (lœss)":       {"famille":"Limon",           "type_nappe":"Libre",  "K":1e-7,   "T":1e-6,    "S_captif":1e-5,   "S_libre":0.05, "porosite":10,  "ep":10},
    "Limon alluvial":            {"famille":"Limon",           "type_nappe":"Libre",  "K":5e-7,   "T":2.5e-6,  "S_captif":5e-5,   "S_libre":0.06, "porosite":8,   "ep":5},
    "Sable fin argileux":        {"famille":"Sable fin",       "type_nappe":"Libre",  "K":1e-6,   "T":1e-5,    "S_captif":1e-4,   "S_libre":0.05, "porosite":15,  "ep":10},
    "Sable fin quaternaire":     {"famille":"Sable fin",       "type_nappe":"Libre",  "K":5e-6,   "T":7.5e-5,  "S_captif":5e-4,   "S_libre":0.08, "porosite":20,  "ep":15},
    "Sable fin à moyen":         {"famille":"Sable fin",       "type_nappe":"Libre",  "K":1e-5,   "T":1.5e-4,  "S_captif":1e-4,   "S_libre":0.10, "porosite":22,  "ep":15},
    "Sable moyen propre":        {"famille":"Sable moyen",     "type_nappe":"Libre",  "K":5e-5,   "T":1e-3,    "S_captif":5e-4,   "S_libre":0.12, "porosite":25,  "ep":20},
    "Sable grossier propre":     {"famille":"Sable grossier",  "type_nappe":"Libre",  "K":1e-4,   "T":2e-3,    "S_captif":1e-3,   "S_libre":0.15, "porosite":28,  "ep":20},
    "Sable grossier argileux":   {"famille":"Sable grossier",  "type_nappe":"Libre",  "K":5e-5,   "T":9e-4,    "S_captif":5e-4,   "S_libre":0.10, "porosite":22,  "ep":18},
    "Gravier sableux":           {"famille":"Gravier",         "type_nappe":"Libre",  "K":1e-3,   "T":1.5e-2,  "S_captif":1e-3,   "S_libre":0.18, "porosite":28,  "ep":15},
    "Gravier propre":            {"famille":"Gravier",         "type_nappe":"Libre",  "K":1e-2,   "T":1.2e-1,  "S_captif":2e-3,   "S_libre":0.20, "porosite":30,  "ep":12},
    "Alluvions grossières":      {"famille":"Gravier",         "type_nappe":"Libre",  "K":5e-3,   "T":1e-1,    "S_captif":2e-3,   "S_libre":0.22, "porosite":30,  "ep":20},
    "Gravier argileux":          {"famille":"Gravier",         "type_nappe":"Libre",  "K":1e-4,   "T":1e-3,    "S_captif":5e-4,   "S_libre":0.12, "porosite":22,  "ep":10},
    "Calcaire compact fissuré":  {"famille":"Calcaire",        "type_nappe":"Captif", "K":1e-6,   "T":3e-5,    "S_captif":1e-5,   "S_libre":0.02, "porosite":5,   "ep":30},
    "Calcaire karstifié":        {"famille":"Calcaire",        "type_nappe":"Libre",  "K":1e-3,   "T":5e-2,    "S_captif":1e-4,   "S_libre":0.05, "porosite":8,   "ep":50},
    "Craie":                     {"famille":"Craie",           "type_nappe":"Libre",  "K":1e-6,   "T":5e-5,    "S_captif":5e-5,   "S_libre":0.03, "porosite":15,  "ep":50},
    "Tuffeau (Val de Loire)":    {"famille":"Calcaire",        "type_nappe":"Libre",  "K":5e-6,   "T":1.5e-4,  "S_captif":2e-5,   "S_libre":0.04, "porosite":30,  "ep":30},
    "Calcaire gréseux":          {"famille":"Calcaire",        "type_nappe":"Captif", "K":1e-5,   "T":2.5e-4,  "S_captif":1e-5,   "S_libre":0.03, "porosite":8,   "ep":25},
    "Grès fin consolidé":        {"famille":"Grès",            "type_nappe":"Captif", "K":1e-7,   "T":3e-6,    "S_captif":1e-5,   "S_libre":0.04, "porosite":12,  "ep":30},
    "Grès poreux peu consolidé": {"famille":"Grès",            "type_nappe":"Libre",  "K":1e-5,   "T":2.5e-4,  "S_captif":5e-5,   "S_libre":0.10, "porosite":20,  "ep":25},
    "Grès argileux":             {"famille":"Grès",            "type_nappe":"Captif", "K":1e-8,   "T":2e-7,    "S_captif":1e-6,   "S_libre":0.03, "porosite":8,   "ep":20},
    "Arène granitique":          {"famille":"Altérite",        "type_nappe":"Libre",  "K":1e-5,   "T":1.5e-4,  "S_captif":5e-4,   "S_libre":0.10, "porosite":15,  "ep":15},
    "Altérite de schiste":       {"famille":"Altérite",        "type_nappe":"Libre",  "K":5e-7,   "T":5e-6,    "S_captif":1e-4,   "S_libre":0.05, "porosite":10,  "ep":10},
    "Granite fissuré":           {"famille":"Socle",           "type_nappe":"Captif", "K":1e-7,   "T":2e-6,    "S_captif":5e-6,   "S_libre":0.01, "porosite":2,   "ep":20},
    "Basalte fissuré":           {"famille":"Socle",           "type_nappe":"Captif", "K":1e-6,   "T":1.5e-5,  "S_captif":5e-6,   "S_libre":0.02, "porosite":5,   "ep":15},
    "Remblai hétérogène":        {"famille":"Remblai",         "type_nappe":"Libre",  "K":1e-5,   "T":3e-5,    "S_captif":1e-3,   "S_libre":0.15, "porosite":20,  "ep":3},
    "Grave de route / concassé": {"famille":"Remblai",         "type_nappe":"Libre",  "K":1e-3,   "T":2e-3,    "S_captif":2e-3,   "S_libre":0.20, "porosite":30,  "ep":2},
    # ── v15.78 : Pack France entier — 11 formations régionales ──
    "Marnes à meulières":         {"famille":"Marne",           "type_nappe":"Captif", "K":5e-7,   "T":1e-5,    "S_captif":1e-5,   "S_libre":0.02, "porosite":12,  "ep":20},
    "Calcaire de Beauce":        {"famille":"Calcaire",        "type_nappe":"Libre",  "K":5e-4,   "T":1.5e-2,  "S_captif":1e-4,   "S_libre":0.04, "porosite":10,  "ep":50},
    "Calcaire de Saint-Ouen":    {"famille":"Calcaire",        "type_nappe":"Captif", "K":1e-5,   "T":3e-4,    "S_captif":5e-5,   "S_libre":0.03, "porosite":8,   "ep":20},
    "Calcaire grossier du Lutétien":{"famille":"Calcaire",     "type_nappe":"Captif", "K":5e-5,   "T":1.5e-3,  "S_captif":5e-5,   "S_libre":0.04, "porosite":10,  "ep":30},
    "Sables de Fontainebleau":   {"famille":"Sable moyen",     "type_nappe":"Libre",  "K":5e-4,   "T":1.5e-2,  "S_captif":1e-4,   "S_libre":0.15, "porosite":28,  "ep":40},
    "Sables du Sparnacien":      {"famille":"Sable fin",       "type_nappe":"Captif", "K":1e-5,   "T":2e-4,    "S_captif":5e-5,   "S_libre":0.10, "porosite":22,  "ep":15},
    "Argile à silex":            {"famille":"Argile",          "type_nappe":"Libre",  "K":1e-8,   "T":3e-7,    "S_captif":1e-5,   "S_libre":0.01, "porosite":5,   "ep":15},
    "Schistes altérés":          {"famille":"Altérite",        "type_nappe":"Libre",  "K":1e-6,   "T":2e-5,    "S_captif":5e-5,   "S_libre":0.01, "porosite":8,   "ep":20},
    "Conglomérat (poudingue)":   {"famille":"Grès",            "type_nappe":"Captif", "K":5e-6,   "T":1e-4,    "S_captif":5e-5,   "S_libre":0.03, "porosite":10,  "ep":25},
    "Molasse miocène":           {"famille":"Grès",            "type_nappe":"Captif", "K":5e-5,   "T":1.5e-3,  "S_captif":5e-5,   "S_libre":0.05, "porosite":15,  "ep":40},
    "Calcaire urgonien":         {"famille":"Calcaire",        "type_nappe":"Libre",  "K":5e-3,   "T":1.5e-1,  "S_captif":1e-4,   "S_libre":0.06, "porosite":10,  "ep":100},
}

def fmt_sci(v):
    """Formatte une valeur scientifique de façon lisible."""
    try:
        fv = float(v)
        if fv == 0:
            return "0"
        exp = math.floor(math.log10(abs(fv)))
        mant = fv / (10 ** exp)
        if abs(mant - round(mant)) < 1e-9:
            mant_str = str(int(round(mant)))
        else:
            mant_str = f"{mant:.2g}"
        if exp == 0:
            return mant_str
        return f"{mant_str}×10<super>{exp}</super>"
    except Exception:
        return str(v)

def Wu_func(u):
    """Approximation polynomiale de la fonction de puits de Theis W(u)."""
    if u <= 0:
        return 99.0
    if u < 0.01:
        return (-0.57721566 - math.log(u) + u
                - u**2/4 + u**3/18 - u**4/96 + u**5/600)
    else:
        return -0.57721566 - math.log(u)

def safe(v, default="—"):
    if v is None or str(v).strip() in ("", "—", "None"):
        return default
    return str(v).strip()

def safe_float(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default

def _force_excel_recalc(xlsx_path):
    """Force le recalcul des formules Excel avant lecture.

    openpyxl ne sait PAS évaluer les formules : il lit uniquement les valeurs
    en cache laissées par Excel lors du dernier enregistrement. Si l'utilisateur
    modifie une valeur dans Excel SANS sauvegarder, ou si le cache est obsolète,
    les valeurs lues seront fausses.

    Cette fonction force le recalcul via 3 stratégies en cascade :
      1. LibreOffice (Mac/Linux) en mode headless
      2. Microsoft Excel COM (Windows) via pywin32 si disponible
      3. Marquage du workbook pour recalcul à l'ouverture (fallback)

    L'objectif est qu'après cette fonction, le fichier .xlsx contienne
    DES VALEURS CACHE À JOUR pour toutes les formules.
    """
    import os, sys, shutil, subprocess, platform, time

    if not os.path.exists(xlsx_path):
        return False

    # ---- Stratégie 1 : LibreOffice headless (le plus universel) ----
    soffice_candidates = [
        "soffice", "libreoffice",
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ]
    soffice = None
    for cand in soffice_candidates:
        p = shutil.which(cand) if not os.path.isabs(cand) else (cand if os.path.exists(cand) else None)
        if p:
            soffice = p
            break

    if soffice:
        try:
            outdir = os.path.dirname(os.path.abspath(xlsx_path)) or "."
            tmp_profile = os.path.join(outdir, ".lo_profile_tmp")
            res = subprocess.run(
                [soffice, "--headless",
                 f"-env:UserInstallation=file://{tmp_profile}",
                 "--calc", "--convert-to", "xlsx",
                 "--outdir", outdir, xlsx_path],
                capture_output=True, text=True, timeout=120
            )
            # LibreOffice écrit le même nom dans outdir : si c'est le même chemin, OK
            if res.returncode == 0:
                # Nettoyage du profil temp
                try:
                    shutil.rmtree(tmp_profile, ignore_errors=True)
                except Exception:
                    pass
                return True
        except Exception:
            pass

    # ---- Stratégie 2 : Microsoft Excel COM (Windows) ----
    if platform.system() == "Windows":
        try:
            import win32com.client  # type: ignore
            excel = win32com.client.DispatchEx("Excel.Application")
            excel.Visible = False
            excel.DisplayAlerts = False
            wb = excel.Workbooks.Open(os.path.abspath(xlsx_path))
            wb.Application.CalculateFullRebuild()
            wb.Save()
            wb.Close(SaveChanges=True)
            excel.Quit()
            return True
        except Exception:
            pass

    # ---- Stratégie 3 : marquer le workbook pour recalcul forcé ----
    # On positionne le flag fullCalcOnLoad pour qu'Excel recalcule à la prochaine
    # ouverture, ET on évalue en Python les cellules clés (NS, FF, C15) qui
    # alimentent toutes les autres formules. Ça garantit que même sans LibreOffice
    # ni Excel COM, les valeurs cache des cellules pivot seront correctes.
    try:
        from openpyxl import load_workbook as _lw
        _keep_vba = xlsx_path.lower().endswith(".xlsm")
        wb_w = _lw(xlsx_path, data_only=False, keep_vba=_keep_vba)
        # Activer fullCalcOnLoad au niveau workbook
        try:
            wb_w.calculation.calcMode = "auto"
            wb_w.calculation.fullCalcOnLoad = True
        except Exception:
            pass

        # Évaluation Python directe des cellules pivot ----
        # NS = Données d'Entrée!C63, FF = C64
        de_w = wb_w["Données d'Entrée"]
        calc_w = wb_w["Calculs"]
        try:
            ns = float(de_w["C63"].value) if de_w["C63"].value is not None else None
            ff = float(de_w["C64"].value) if de_w["C64"].value is not None else None
        except (TypeError, ValueError):
            ns, ff = None, None

        if ns is not None and ff is not None:
            # C15 = rabattement = FF - NS  (formule Calculs!C15 = =Données!C64 - Données!C63)
            s_rab = ff - ns
            # On écrit la valeur en cache pour C15 en résolvant la formule en Python
            # (openpyxl ne peut pas modifier le cache directement, mais on écrit le
            # résultat à côté dans une cellule miroir lue par read_excel_data en repli)
            try:
                # cellule miroir dédiée au repli Python (n'écrase pas la formule C15)
                if "_recalc_pivot" not in [n.name for n in wb_w.defined_names.definedName]:
                    pass
                # On stocke les valeurs pivots en zone non utilisée pour repli Python
                calc_w["AZ1"] = ns
                calc_w["AZ2"] = ff
                calc_w["AZ3"] = s_rab
                calc_w["AZ4"] = 1 if s_rab > 0 else 0  # flag nappe interceptée
            except Exception:
                pass

        # ── PROTECTION HYPERLIEN PDF (v15.59) ──
        # Le bouton vert ÉDITER LE PDF est placé en B25 avec un target EXTERNE
        # (vers le PDF) — c'est obligatoire pour déclencher Worksheet_FollowHyperlink
        # dans Excel (un hyperlien purement interne ne le déclenche PAS).
        # Le handler VBA Sheet2 reconnaît cellRef="b25" → appelle Lancer_Generation_PDF.
        try:
            if "Sommaire" in wb_w.sheetnames:
                _som = wb_w["Sommaire"]
                from openpyxl.styles import Font as _F, PatternFill as _P, Alignment as _A
                from openpyxl.worksheet.hyperlink import Hyperlink as _HL
                # B22 : VIDE (ancien emplacement du bouton — handler VBA y appelle Ouvrir_PDF_Dossier)
                _b22 = _som["B22"]
                if _b22.hyperlink is not None:
                    _b22.hyperlink = None
                if _b22.value is not None:
                    _b22.value = None
                    _b22.fill = _P(fill_type=None)
                    _b22.font = _F(name="Calibri", size=11)
                    _b22.alignment = _A()
                    _som.row_dimensions[22].height = 15
                # B23 : sous-titre explicatif (au-dessus du bouton B25)
                _b23 = _som["B23"]
                if _b23.hyperlink is not None:
                    _b23.hyperlink = None
                _msg23 = "> Cliquer sur le bouton vert ci-dessous suffit. Les calculs se mettent \u00e0 jour, le PDF se g\u00e9n\u00e8re et s'ouvre (30\u201390 sec)."
                if _b23.value != _msg23:
                    _b23.value = _msg23
                    _b23.font = _F(name="Calibri", size=10, italic=True, color="FF1F4E78")
                    _b23.alignment = _A(horizontal="left", vertical="center", wrap_text=True)
                # B24 : nettoyer
                _b24 = _som["B24"]
                if _b24.hyperlink is not None:
                    _b24.hyperlink = None
                if _b24.value is not None:
                    _b24.value = None
                    _b24.fill = _P(fill_type=None)
                    _b24.font = _F(name="Calibri", size=11)
                    _b24.alignment = _A()
                    _som.row_dimensions[24].height = 15
                # B25 = BOUTON CLIQUABLE
                # Target = le xlsm lui-même : Excel essaie de l'ouvrir, voit qu'il est
                # déjà ouvert et le réactive (aucun message). Cela déclenche
                # Worksheet_FollowHyperlink → le handler VBA appelle
                # GMEP_Geo.Lancer_Generation_PDF (recalcul + génération + ouverture).
                _b25 = _som["B25"]
                _msg25 = "\U0001F4C4  \u00c9DITER LE PDF  (1 clic \u2014 calculs + g\u00e9n\u00e9ration + ouverture automatiques)"
                _target_xlsm = "Modelisation_Rabattement_TSN_GMEP.xlsm"
                _need_hl = True
                if _b25.hyperlink is not None:
                    _tgt = str(_b25.hyperlink.target or "")
                    if _target_xlsm in _tgt:
                        _need_hl = False
                if _need_hl or _b25.value != _msg25:
                    _b25.value = _msg25
                    _b25.hyperlink = _HL(
                        ref="B25",
                        target=_target_xlsm,
                        display=_msg25,
                        tooltip="generer_pdf",
                    )
                    _b25.font = _F(name="Calibri", size=14, bold=True, color="FFFFFFFF", underline="single")
                    _b25.fill = _P("solid", fgColor="FF2E7D32")
                    _b25.alignment = _A(horizontal="center", vertical="center", wrap_text=True)
                    _som.row_dimensions[25].height = 48
                # B26 : nettoyer
                _b26 = _som["B26"]
                if _b26.hyperlink is not None:
                    _b26.hyperlink = None
                if _b26.value is not None:
                    _b26.value = None
                    _b26.fill = _P(fill_type=None)
                    _b26.font = _F(name="Calibri", size=11)
                    _b26.alignment = _A()
                    _som.row_dimensions[26].height = 15
        except Exception as _e_link:
            print(f"  (avertissement) refonte bouton \u00c9DITER : {_e_link}")

        wb_w.save(xlsx_path)
        return True
    except Exception:
        return False


def _repair_pdf_hyperlink(xlsx_path):
    """Normalise le bouton ÉDITER LE PDF en B25 (v15.59).
    Target EXTERNE vers Dossier_Declaration_Loi_Eau_GMEP.pdf (obligatoire
    pour déclencher Worksheet_FollowHyperlink). Le handler VBA Sheet2 matche
    cellRef="b25" → appelle GMEP_Geo.Lancer_Generation_PDF.
    Nettoie B22, B24, B26 (anciens emplacements)."""
    try:
        from openpyxl import load_workbook as _lw
        from openpyxl.styles import Font as _F2, PatternFill as _P2, Alignment as _A2
        from openpyxl.worksheet.hyperlink import Hyperlink as _HL2
        _keep_vba = xlsx_path.lower().endswith(".xlsm")
        _wb = _lw(xlsx_path, keep_vba=_keep_vba)
        if "Sommaire" not in _wb.sheetnames:
            return
        _som = _wb["Sommaire"]
        _changed = False
        # B22 : VIDE (ancien emplacement — handler VBA y appellerait Ouvrir_PDF_Dossier)
        _b22 = _som["B22"]
        if _b22.hyperlink is not None:
            _b22.hyperlink = None
            _changed = True
        if _b22.value is not None:
            _b22.value = None
            _b22.fill = _P2(fill_type=None)
            _b22.font = _F2(name="Calibri", size=11)
            _b22.alignment = _A2()
            _som.row_dimensions[22].height = 15
            _changed = True
        # B23 : sous-titre explicatif au-dessus du bouton B25
        _b23 = _som["B23"]
        if _b23.hyperlink is not None:
            _b23.hyperlink = None
            _changed = True
        _msg23 = "> Cliquer sur le bouton vert ci-dessous suffit. Les calculs se mettent \u00e0 jour, le PDF se g\u00e9n\u00e8re et s'ouvre (30\u201390 sec)."
        if _b23.value != _msg23:
            _b23.value = _msg23
            _b23.font = _F2(name="Calibri", size=10, italic=True, color="FF1F4E78")
            _b23.alignment = _A2(horizontal="left", vertical="center", wrap_text=True)
            _changed = True
        # B24 : nettoyer
        _b24 = _som["B24"]
        if _b24.hyperlink is not None:
            _b24.hyperlink = None
            _changed = True
        if _b24.value is not None:
            _b24.value = None
            _b24.fill = _P2(fill_type=None)
            _b24.font = _F2(name="Calibri", size=11)
            _b24.alignment = _A2()
            _som.row_dimensions[24].height = 15
            _changed = True
        # B25 : BOUTON CLIQUABLE (target = xlsm lui-même, déclenche FollowHyperlink)
        _b25 = _som["B25"]
        _msg25 = "\U0001F4C4  \u00c9DITER LE PDF  (1 clic \u2014 calculs + g\u00e9n\u00e9ration + ouverture automatiques)"
        _target_xlsm = "Modelisation_Rabattement_TSN_GMEP.xlsm"
        _need_hl25 = True
        if _b25.hyperlink is not None:
            _tgt = str(_b25.hyperlink.target or "")
            if _target_xlsm in _tgt:
                _need_hl25 = False
        if _need_hl25 or _b25.value != _msg25:
            _b25.value = _msg25
            _b25.hyperlink = _HL2(
                ref="B25",
                target=_target_xlsm,
                display=_msg25,
                tooltip="generer_pdf",
            )
            _b25.font = _F2(name="Calibri", size=14, bold=True, color="FFFFFFFF", underline="single")
            _b25.fill = _P2("solid", fgColor="FF2E7D32")
            _b25.alignment = _A2(horizontal="center", vertical="center", wrap_text=True)
            _som.row_dimensions[25].height = 48
            _changed = True
        # B26 : nettoyer
        _b26 = _som["B26"]
        if _b26.hyperlink is not None:
            _b26.hyperlink = None
            _changed = True
        if _b26.value is not None:
            _b26.value = None
            _b26.fill = _P2(fill_type=None)
            _b26.font = _F2(name="Calibri", size=11)
            _b26.alignment = _A2()
            _som.row_dimensions[26].height = 15
            _changed = True
        if _changed:
            _wb.save(xlsx_path)
            print(f"  Bouton \u00c9DITER LE PDF (Sommaire!B25) normalis\u00e9.", flush=True)
    except Exception as _e:
        print(f"  (avertissement) refonte bouton \u00c9DITER : {_e}", flush=True)


def _ensure_altitude_formulas(xlsx_path):
    """Garantit que les altitudes fond puits (C29, C36) sont des FORMULES dynamiques
    liées à C27 (profondeur du puits) et C28 (altitude tête). Restaure les formules
    si elles ont été écrasées par une valeur figée."""
    try:
        from openpyxl import load_workbook as _lw
        _keep_vba = xlsx_path.lower().endswith(".xlsm")
        _wb = _lw(xlsx_path, keep_vba=_keep_vba)
        _de = _wb["Données d'Entrée"]
        _changes = []
        # C29 = C28 - C27
        _v29 = _de["C29"].value
        if not (isinstance(_v29, str) and _v29.startswith("=")):
            _de["C29"] = "=C28-C27"
            _changes.append("C29=C28-C27")
        # C35 = C28 (recopie de l'altitude tête)
        _v35 = _de["C35"].value
        if not (isinstance(_v35, str) and _v35.startswith("=")):
            _de["C35"] = "=C28"
            _changes.append("C35=C28")
        # C36 = C35 - C27
        _v36 = _de["C36"].value
        if not (isinstance(_v36, str) and _v36.startswith("=")):
            _de["C36"] = "=C35-C27"
            _changes.append("C36=C35-C27")
        if _changes:
            _wb.save(xlsx_path)
            print(f"  Formules altitudes restaurées : {', '.join(_changes)}", flush=True)
    except Exception as _e:
        print(f"  (avertissement) restauration formules altitudes : {_e}", flush=True)


def _sync_selectors_top_bottom(xlsx_path):
    """Synchronise les sélecteurs du haut (C60/F60) avec le récapitulatif du bas (C137/C138).
    La cellule modifiée en dernier (haut OU bas) fait foi. Si une seule des deux a une valeur
    valide dans la liste, on propage cette valeur dans l'autre. Évite la désynchronisation
    quand l'utilisateur modifie C60 mais oublie C137 (ou inversement)."""
    try:
        from openpyxl import load_workbook as _lw
        _keep_vba = xlsx_path.lower().endswith(".xlsm")
        _wb = _lw(xlsx_path, keep_vba=_keep_vba)
        _de = _wb["Données d'Entrée"]
        _changes = []
        _liste_type = [
            "Pompage AEP / industriel (forage de production)",
            "Rabattement de fouille (chantier temporaire)",
            "Essai de pompage / piézométrie",
        ]
        _liste_mode = [
            "Niveau dynamique cible → débit Q calculé",
            "Débit Q imposé → rabattement s calculé",
        ]
        def _norm(v):
            return (v or "").strip() if isinstance(v, str) else ""
        c60, c137 = _norm(_de["C60"].value), _norm(_de["C137"].value)
        # Synchro type d'opération : si c60 et c137 différent, c60 (haut) prime
        if c60 in _liste_type and c60 != c137:
            _de["C137"] = c60
            _changes.append(f"C137←C60 ({c60[:30]}...)")
        elif c137 in _liste_type and not c60:
            _de["C60"] = c137
            _changes.append(f"C60←C137 ({c137[:30]}...)")
        f60, c138 = _norm(_de["F60"].value), _norm(_de["C138"].value)
        if f60 in _liste_mode and f60 != c138:
            _de["C138"] = f60
            _changes.append(f"C138←F60 ({f60[:30]}...)")
        elif c138 in _liste_mode and not f60:
            _de["F60"] = c138
            _changes.append(f"F60←C138 ({c138[:30]}...)")
        if _changes:
            _wb.save(xlsx_path)
            print(f"  Sélecteurs synchronisés : {' ; '.join(_changes)}", flush=True)
    except Exception as _e:
        print(f"  (avertissement) synchro sélecteurs : {_e}", flush=True)


def read_excel_data():
    # === Réparation automatique du lien hypertexte "OUVRIR LE PDF" ===
    _repair_pdf_hyperlink(XLSX_PATH)
    # === Garantir formules dynamiques altitudes (C29/C35/C36) ===
    _ensure_altitude_formulas(XLSX_PATH)
    # === Synchroniser les sélecteurs haut/bas (C60↔C137, F60↔C138) ===
    _sync_selectors_top_bottom(XLSX_PATH)

    # === Recalcul forcé du tableur AVANT lecture ===
    # Garantit que les modifications utilisateur (FF, NS, etc.) sont prises en compte
    # même si Excel n'a pas été sauvegardé avec recalcul automatique.
    print("  Recalcul des formules Excel...", flush=True)
    _ok = _force_excel_recalc(XLSX_PATH)
    if _ok:
        print("  Recalcul OK : valeurs synchronisées avec le tableur.", flush=True)
    else:
        print("  Avertissement : recalcul automatique indisponible (LibreOffice/Excel "
              "non trouvés). Les valeurs lues correspondent au dernier enregistrement Excel.",
              flush=True)

    wb = load_workbook(XLSX_PATH, data_only=True)

    # ===== REPLI PYTHON : vérification de cohérence valeurs pivot NS/FF/C15 =====
    # Si le recalcul automatique a échoué et que les valeurs cache sont obsolètes,
    # on recalcule en Python les cellules pivot à partir des entrées brutes
    # (NS=C63, FF=C64) et on les force dans les variables qui pilotent le PDF.
    try:
        _de_chk = wb["Données d'Entrée"]
        _calc_chk = wb["Calculs"]
        _ns_in = _de_chk["C63"].value
        _ff_in = _de_chk["C64"].value
        _c15_cache = _calc_chk["C15"].value
        if _ns_in is not None and _ff_in is not None:
            _ns_f = float(_ns_in); _ff_f = float(_ff_in)
            _c15_expected = _ff_f - _ns_f
            _c15_actual = float(_c15_cache) if _c15_cache is not None else None
            if _c15_actual is None or abs(_c15_actual - _c15_expected) > 1e-3:
                print(f"  Resynchronisation pivot : C15 cache={_c15_actual} → attendu={_c15_expected:.3f}")
                # On marque dans data un override qui sera utilisé plus loin
                wb._gmep_override_c15 = _c15_expected
                wb._gmep_override_ns = _ns_f
                wb._gmep_override_ff = _ff_f
    except Exception as _e:
        print(f"  Vérification pivot ignorée : {_e}")

    # ── Données d'Entrée ──
    de = wb["Données d'Entrée"]
    data = {}

    # Intervenants — v15.38 : 4 blocs distincts MO / ET / BE / SF
    # === MAÎTRE D'OUVRAGE (B5:C11) ===
    data["mo_nom"]       = safe(de["C6"].value, "—")
    data["mo_adresse"]   = safe(de["C7"].value, "—")
    data["mo_cp_ville"]  = safe(de["C8"].value, "—")
    data["mo_tel"]       = safe(de["C9"].value, "—")
    data["mo_email"]     = safe(de["C10"].value, "—")
    data["mo_siret"]     = safe(de["C11"].value, "—")

    # === ENTREPRISE DE TRAVAUX (E5:F11) ===
    data["et_nom"]       = safe(de["F6"].value, "—")
    data["et_adresse"]   = safe(de["F7"].value, "—")
    data["et_cp_ville"]  = safe(de["F8"].value, "—")
    data["et_tel"]       = safe(de["F9"].value, "—")
    data["et_email"]     = safe(de["F10"].value, "—")
    data["et_siret"]     = safe(de["F11"].value, "—")

    # === BUREAU D'ÉTUDES (B13:C19) ===
    data["be_nom"]       = safe(de["C14"].value, "G.M.E.P")
    data["be_adresse"]   = safe(de["C15"].value, "9 rue de la Marne")
    data["be_cp_ville"]  = safe(de["C16"].value, "79400 Saint-Maixent-l'École")
    data["be_tel"]       = safe(de["C17"].value, "06.97.73.72.33")
    data["be_email"]     = safe(de["C18"].value, "gmep.france@gmail.com")
    data["be_agrement"]  = safe(de["C19"].value, "—")

    # === SOCIÉTÉ DE FORAGE (E13:F19) ===
    data["forage_nom"]      = safe(de["F14"].value, "—")
    data["forage_adresse"]  = safe(de["F15"].value, "—")
    data["forage_cp_ville"] = safe(de["F16"].value, "—")
    data["forage_tel"]      = safe(de["F17"].value, "—")
    data["forage_siret"]    = safe(de["F18"].value, "—")
    data["forage_cert"]     = safe(de["F19"].value, "—")

    # === INFORMATIONS CHANTIER (B130:F134) ===
    data["ref_dossier"]  = safe(de["C131"].value, "—")
    data["date_debut"]   = safe(de["C132"].value, "—")
    data["date_fin"]     = safe(de["C133"].value, "—")
    data["num_bss"]      = safe(de["C134"].value, "—")
    data["ref_dreal"]    = safe(de["F131"].value, "—")
    data["version"]      = safe(de["F132"].value, "1.0")
    data["statut_doc"]   = safe(de["F133"].value, "Pour validation")
    # Commune / département : depuis géolocalisation automatique (C37/C38)
    data["commune"]      = safe(de["C37"].value, "—")
    data["departement"]  = safe(de["C38"].value, "—")

    # Puits — structure réelle : B22=Param, C22=Val, E22=Param équip, F22=Val équip
    data["diam_int"]     = safe(de["C23"].value, "0.30")
    data["diam_ext"]     = safe(de["C24"].value, "0.40")
    data["prof_puits"]   = safe(de["C27"].value, "6.00")
    data["alti_tete"]    = safe(de["C28"].value, "124.63")
    # alti_fond : cellule C27 est vide (formule), calculée
    alti_tete_v = safe_float(de["C28"].value, 124.63)
    prof_v      = safe_float(de["C27"].value, 6.0)
    data["alti_fond"]    = f"{alti_tete_v - prof_v:.2f}"

    # Équipements (v15.34 — nouveau schéma E23:F29)
    data["type_ouvrage"]     = safe(de["F23"].value, "Puits")
    data["margelle"]         = safe(de["F24"].value, "0,25 × 0,25 m — ép. 0,10 m")
    data["tete_protection"]  = safe(de["F25"].value, "Capot de protection cadenassé (h = 0,50 m)")
    data["mat_crepine"]      = safe(de["F26"].value, "PVC")
    data["mat_tubage"]       = safe(de["F27"].value, "PVC")
    data["gravier"]          = safe(de["F28"].value, "Silice 2-4 mm")
    data["cimentage"]        = safe(de["F29"].value, "Bentonite ≥ 2 m")
    # Rétro-compat
    # Profondeur totale du forage (C27) → fixe les côtes de crépine, massif filtrant, cimentation
    # Si C27 < FF (C64), prend la valeur max pour rester cohérent (forage doit être ≥ fond de fouille)
    _c27 = safe_float(de["C27"].value, 3.0)
    _c64 = safe_float(de["C64"].value, 3.0)
    _prof_forage = max(_c27, _c64)
    # Crépine : 1/3 sup du forage à protection bentonite, 2/3 inf ouverte
    _crep_top    = max(1.0, round(_prof_forage * 0.3, 2))
    _crep_bot    = round(_prof_forage, 2)
    _gravier_top = round(max(0.5, _crep_top - 0.5), 2)
    _gravier_bot = _crep_bot
    _ciment_bot  = round(_gravier_top - 0.1, 2)
    data["prof_forage_m"]    = _prof_forage
    data["crepine_top_m"]    = _crep_top
    data["crepine_bot_m"]    = _crep_bot
    data["gravier_top_m"]    = _gravier_top
    data["gravier_bot_m"]    = _gravier_bot
    data["ciment_bot_m"]     = _ciment_bot
    data["crepine"]          = f"{data['mat_crepine']} — fentes calibrées (-{_crep_top:.2f} m à -{_crep_bot:.2f} m)"
    data["type_captage"]     = "Nappe phréatique perchée"

    # Substrat géologique (décalé de +10 lignes après insertion coordonnées)
    data["substrat"]     = safe(de["C44"].value, "Alluvions grossières")

    # Coordonnées Lambert 93 (nouvelles lignes 28-37)
    data["lambert_x"]    = safe_float(de["C33"].value, 572272.0)
    data["lambert_y"]    = safe_float(de["C34"].value, 6748510.0)
    data["alti_ngf"]     = safe_float(de["C35"].value, 124.63)
    data["commune_geo"]  = safe(de["C37"].value, "—")
    data["dept_geo"]     = safe(de["C38"].value, "—")

    # ===== RÉSOLUTION GÉOGRAPHIQUE AUTOMATIQUE à partir de X/Y Lambert 93 =====
    # Module geo_resolver : commune + INSEE + département + bassin DCE + agence d'eau
    #                       + SDAGE + masse d'eau souterraine SANDRE + statut ZRE
    # Toutes les sections du PDF (5.3 ZRE, 5.5 masse d'eau, 8 conclusion) reposent désormais
    # sur cette résolution automatique — plus aucune valeur codée en dur.
    try:
        import geo_resolver as _geo
        _geo_data = _geo.resolve_geo(data["lambert_x"], data["lambert_y"], use_cache=True)
        data["geo_resolution_ok"] = _geo_data.get("resolution_ok", False)
        # Commune / INSEE / département / région (auto-résolus)
        if _geo_data.get("commune_nom", "—") not in ("—", ""):
            data["commune"]     = _geo_data["commune_nom"]
            data["commune_geo"] = _geo_data["commune_nom"]
        data["code_insee"]      = _geo_data.get("code_insee", "—")
        if _geo_data.get("code_dpt", "—") != "—":
            data["departement"] = _geo_data["code_dpt"]
            data["dept_geo"]    = _geo_data["code_dpt"]
        data["code_region"]     = _geo_data.get("code_region", "—")
        data["lon_wgs84"]       = _geo_data.get("lon_wgs84", 0.0)
        data["lat_wgs84"]       = _geo_data.get("lat_wgs84", 0.0)
        # Bassin DCE / agence d'eau / SDAGE / SAGE
        data["bassin_dce"]      = _geo_data.get("bassin_dce", "—")
        data["agence_eau"]      = _geo_data.get("agence_eau", "—")
        data["sdage"]           = _geo_data.get("sdage", "—")
        data["sage"]            = _geo_data.get("sage", "—")
        # Masse d'eau souterraine SANDRE
        data["meso_code"]       = _geo_data.get("meso_code", "—")
        data["meso_libelle"]    = _geo_data.get("meso_libelle", "—")
        data["meso_urn"]        = _geo_data.get("meso_urn", "—")
        data["bdlisa_codes"]    = _geo_data.get("bdlisa_codes", []) or []
        data["bdlisa_noms"]     = _geo_data.get("bdlisa_noms", []) or []
        # Statut ZRE
        data["zre_statut"]      = _geo_data.get("zre_statut", "NON ZRE")
        data["zre_nappe"]       = _geo_data.get("zre_nappe", "—")
        data["zre_arrete"]      = _geo_data.get("zre_arrete", "—")
        data["zre_date_maj"]    = _geo_data.get("zre_date_maj", "—")
        data["zre_source"]      = _geo_data.get("zre_source", "—")
        data["zre_communes_deleguees"] = _geo_data.get("zre_communes_deleguees", []) or []
        # Drapeaux dérivés utiles aux sections aval
        data["zre_confirme"]    = (data["zre_statut"] == "CONFIRMÉ")
        data["zre_presomption"] = data["zre_statut"].startswith("PRÉSOMPTION")
        data["zre_actif"]       = data["zre_confirme"] or data["zre_presomption"]
        print(f"  Géo-résolution OK : {data['commune']} (INSEE {data['code_insee']}) "
              f"— ZRE: {data['zre_statut']} — MESO: {data['meso_code']}")
    except Exception as _e:
        # Repli : si le module n'est pas disponible ou pas de réseau, on garde les valeurs Excel
        # et on signale l'échec pour que les sections puissent afficher "à vérifier"
        print(f"  Avertissement géo-résolution : {_e}")
        data["geo_resolution_ok"] = False
        data.setdefault("code_insee", "—")
        data.setdefault("code_region", "—")
        data.setdefault("lon_wgs84", 0.0)
        data.setdefault("lat_wgs84", 0.0)
        data.setdefault("bassin_dce", "—")
        data.setdefault("agence_eau", "—")
        data.setdefault("sdage", "—")
        data.setdefault("sage", "—")
        data.setdefault("meso_code", "—")
        data.setdefault("meso_libelle", "—")
        data.setdefault("meso_urn", "—")
        data.setdefault("bdlisa_codes", [])
        data.setdefault("bdlisa_noms", [])
        data.setdefault("zre_statut", "À VÉRIFIER")
        data.setdefault("zre_nappe", "—")
        data.setdefault("zre_arrete", "—")
        data.setdefault("zre_date_maj", "—")
        data.setdefault("zre_source", "Résolution géo indisponible — vérification manuelle requise")
        data.setdefault("zre_communes_deleguees", [])
        data.setdefault("zre_confirme", False)
        data.setdefault("zre_presomption", False)
        data.setdefault("zre_actif", False)

    # Données terrain (décalées de +10 lignes)
    data["NS"]           = safe_float(de["C63"].value, 2.8)
    data["fond_fouille"] = safe_float(de["C64"].value, 6.0)
    data["rayon_inf"]    = safe_float(de["C65"].value, 10.0)
    data["tps_pompage"]  = safe_float(de["C66"].value, 24.0)
    data["t_recharge_min"]= safe_float(de["C67"].value, 0.0)   # 0 = pompage continu
    data["t_pc_min"]     = safe_float(de["C68"].value, 60.0)   # durée pompage/cycle (min)
    data["t_exploit_h"]  = safe_float(de["C69"].value, 8.0)    # durée exploitation/jour (h)
    data["diam_int_v"]   = safe_float(de["C23"].value, 0.30)

    # === v15.46 : Type d'opération + Mode de calcul ===
    # PRIORITÉ : C60 (haut, visible) puis C137 (bloc bas, fallback)
    # F60 / C138 pour le mode de calcul
    # C139 = Débit Q imposé (Mode 2)
    # C140 = Marge de sécurité crépine (m)
    _type_op_raw = safe(de["C60"].value or de["C137"].value, "Pompage AEP / industriel (forage de production)")
    _mode_raw    = safe(de["F60"].value or de["C138"].value, "Niveau dynamique cible → débit Q calculé")
    # Si la valeur est une formule miroir non encore évaluée, fallback sur le bloc bas
    if isinstance(_type_op_raw, str) and _type_op_raw.startswith("="):
        _type_op_raw = safe(de["C137"].value, "Pompage AEP / industriel (forage de production)")
    if isinstance(_mode_raw, str) and _mode_raw.startswith("="):
        _mode_raw = safe(de["C138"].value, "Niveau dynamique cible → débit Q calculé")
    data["type_operation"] = _type_op_raw
    data["mode_calcul"]    = _mode_raw
    data["is_rabattement_fouille"] = ("rabattement" in _type_op_raw.lower() or "fouille" in _type_op_raw.lower())
    data["is_pompage_aep"]         = not data["is_rabattement_fouille"]
    data["mode_Q_impose"]          = ("q imposé" in _mode_raw.lower() or "débit q imposé" in _mode_raw.lower() or "s calculé" in _mode_raw.lower())
    data["Q_impose_m3h"]           = safe_float(de["C139"].value, 50.0)  # M³/h en Mode 2
    data["marge_crepine_m"]        = safe_float(de["C140"].value, 0.50)  # marge sécurité crépine immergée
    # Profondeur fond du puits (peut différer du fond de fouille)
    data["prof_puits"]             = safe_float(de["C27"].value, data["fond_fouille"] + 1.0)

    # Données climatiques locales (pluviométrie, ETP, recharge BRGM)
    data["P_mm"]   = safe_float(de["C77"].value, 700.0)   # pluviométrie annuelle (mm/an)
    data["ETP_mm"] = safe_float(de["C78"].value, 720.0)   # évapotranspiration (mm/an)
    data["R_mm"]   = safe_float(de["C79"].value, 150.0)   # recharge effective BRGM (mm/an)
    data["dept_code"]   = safe(de["C74"].value, "41")
    data["dept_nom"]    = safe(de["C75"].value, "—")
    data["station_meteo"]= safe(de["C76"].value, "—")

    # Override f_P / f_K manuels si renseignés dans Excel
    data["f_P_manuel"] = de["C105"].value
    data["f_K_manuel"] = de["C90"].value
    # Cache Ø forage (C25 dans structure actuelle)
    de_cache = {"diam_forage": safe_float(de["C25"].value, 0.22)}

    wb.close()

    # ── Paramètres géologiques depuis la base intégrée ──
    substrat = data["substrat"]
    geo = GEO_DB.get(substrat, GEO_DB["Sable fin à moyen"])

    data["geo_famille"]   = geo["famille"]
    data["geo_type_nappe"]= geo["type_nappe"]
    data["geo_K_v"]       = geo["K"]
    data["geo_T_v"]       = geo["T"]
    data["geo_S_captif_v"]= geo["S_captif"]
    data["geo_S_libre_v"] = geo["S_libre"]
    data["geo_porosite_v"]= geo["porosite"]
    data["geo_ep_v"]      = geo["ep"]

    # Formatage lisible
    data["geo_K"]        = fmt_sci(geo["K"]) + " m/s"
    data["geo_T"]        = fmt_sci(geo["T"]) + " m²/s"
    data["geo_S_captif"] = fmt_sci(geo["S_captif"])
    data["geo_S_libre"]  = fmt_sci(geo["S_libre"])
    data["geo_porosite"] = f"{geo['porosite']} %"
    data["geo_ep"]       = f"{geo['ep']} m"

    # ── Recalcul hydraulique complet en Python ──
    NS      = data["NS"]
    FF      = data["fond_fouille"]
    r       = data["diam_int_v"] / 2
    # Rayon d'influence : priorité à la valeur calculée par Sichardt (formule xlsm C65)
    # Si la valeur lue est <= 0 ou égale à la valeur figee 10m/15m (v15.82),
    # on recalcule en Python : R = 3000 * s * sqrt(K)
    _s_rab_pour_R = max(FF - NS, 0.0)
    t_h     = data["tps_pompage"]
    K       = geo["K"]
    # Calcul Sichardt de sécurité (Python fallback si xlsm pas recalculé)
    _R_sichardt_py = 3000 * _s_rab_pour_R * math.sqrt(max(K, 1e-12)) if _s_rab_pour_R > 0 else 0
    _R_xlsm = data["rayon_inf"]  # valeur lue du xlsm (C65, formule ou cache)
    # Si C65 est encore une valeur figee (<= 0) ou non actualisée, utiliser Sichardt Python
    if _R_xlsm is None or _R_xlsm <= 0:
        R_inf = _R_sichardt_py if _R_sichardt_py > 0 else 30.0
        data["R_inf_mode"] = "Sichardt (Python fallback)"
    else:
        R_inf = _R_xlsm
        # Détecter si c'est vraisemblablement la valeur Sichardt auto (via formule xlsm)
        # ou une saisie manuelle
        if abs(R_inf - _R_sichardt_py) < 0.5 * _R_sichardt_py:
            data["R_inf_mode"] = f"Sichardt automatique (R = {R_inf:.0f} m)"
        else:
            data["R_inf_mode"] = f"Saisi manuellement (R = {R_inf:.0f} m)"
    data["R_sichardt_calcule"] = _R_sichardt_py
    # T effective = K * epaisseur saturee captee (FF - NS)
    # et non T de la base geologique (K * epaisseur totale aquifere)
    e_captee = max(FF - NS, 0.1)   # epaisseur saturee captee (m), min 0.1m
    T       = K * e_captee
    # S retenu selon type de nappe
    S = geo["S_libre"] if geo["type_nappe"] == "Libre" else geo["S_captif"]

    s_rab   = FF - NS
    # GARDE-FOU PHYSIQUE : si la fouille est au-dessus du niveau d'eau (s <= 0),
    # aucun pompage gravitaire n'est possible. Tous les debits et volumes = 0.
    fouille_hors_eau = (s_rab <= 0)
    t_s     = t_h * 3600
    u       = (r**2 * S) / (4 * T * t_s)
    wu      = Wu_func(u)

    # === v15.46 : 2 MODES DE CALCUL ===
    if data.get("mode_Q_impose", False) and not fouille_hors_eau:
        # MODE 2 : Q imposé (m³/h) → s rabattement induit calculé
        Q_impose_ms = data["Q_impose_m3h"] / 3600.0  # conversion m³/h → m³/s
        # Inversion Theis : s = Q × W(u) / (4πT)
        s_theis_calc = (Q_impose_ms * wu) / (4 * math.pi * T) if (T > 0 and wu > 0) else 0
        # Inversion Dupuit : s = Q × ln(R/r) / (2πT)
        s_dupuit_calc = (Q_impose_ms * math.log(R_inf / r)) / (2 * math.pi * T) if (T > 0 and R_inf > r) else 0
        # On retient le rabattement moyen des deux méthodes pour pilotage du PDF
        s_calc = (s_theis_calc + s_dupuit_calc) / 2.0
        # Q_theis = Q_dupuit = Q_impose (par définition)
        Q_theis_ms  = Q_impose_ms
        Q_dupuit_ms = Q_impose_ms
        data["s_theis_calcule"]  = s_theis_calc
        data["s_dupuit_calcule"] = s_dupuit_calc
        data["s_rab_calcule"]    = s_calc
        # Niveau dynamique effectif = NS + s
        data["niveau_dyn_calcule"] = NS + s_calc
    else:
        # MODE 1 (par défaut) : Niveau dynamique cible → Q calculé
        s_calc = max(s_rab, 0.0)
        Q_theis_ms  = (4 * math.pi * T * s_calc) / wu if (wu > 0 and not fouille_hors_eau) else 0
        Q_dupuit_ms = (2 * math.pi * T * s_calc) / math.log(R_inf / r) if (R_inf > r and not fouille_hors_eau) else 0
        data["s_rab_calcule"]      = s_calc
        data["niveau_dyn_calcule"] = NS + s_calc

    Q_theis_h   = Q_theis_ms * 3600
    Q_theis_j   = Q_theis_ms * 86400
    Q_dupuit_h  = Q_dupuit_ms * 3600
    Q_dupuit_j  = Q_dupuit_ms * 86400

    # === VÉRIFICATION COHÉRENCE PUITS / FOUILLE / NIVEAU CIBLE ===
    # Le fond du puits doit être plus profond que le niveau dynamique + marge crépine
    _prof_puits   = data["prof_puits"]
    _marge        = data["marge_crepine_m"]
    _ndc_effectif = NS + s_calc  # niveau dynamique effectif (m/TN)
    data["coherence_puits"] = (_prof_puits >= _ndc_effectif + _marge)
    data["ecart_securite_m"] = _prof_puits - _ndc_effectif - _marge
    if not data["coherence_puits"] and not fouille_hors_eau:
        print(f"  [ATTENTION] Cohérence puits/niveau cible : fond puits ({_prof_puits:.2f} m) < niveau dynamique ({_ndc_effectif:.2f} m) + marge ({_marge:.2f} m). Risque de dénoyage de pompe.", flush=True)

    # Rendement hydraulique η (pertes de charge puits réel)
    # Typiquement 0.5 (dégradé) à 0.85 (neuf) -- valeur par défaut 0.70
    eta = 0.70

    Q_theis_corr  = Q_theis_h  * eta    # Débit Theis corrigé par rendement
    Q_dupuit_corr = Q_dupuit_h * eta    # Débit Dupuit corrigé par rendement

    # ── Correction par cycle pompage / recharge piézométrique ──
    import math as _m
    t_rec_min   = data.get("t_recharge_min", 0.0)
    t_rec_s     = t_rec_min * 60.0          # conversion minutes → secondes
    t_pc_min    = data.get("t_pc_min",  60.0)  # durée pompage par cycle (min)
    t_pc_s      = t_pc_min  * 60.0          # conversion minutes → secondes
    t_exploit_h = data.get("t_exploit_h", 8.0) # durée exploitation par jour (h)

    # η_recharge = fraction de récupération de la nappe avant reprise du pompage
    # Formule : 1 - exp(-T * t_rec / (S * r²))
    # Si t_rec = 0 (pompage continu) → η_rec = 1, facteur_cycle = 1
    if t_rec_s > 0 and T > 0 and S > 0 and r > 0:
        eta_rec       = 1.0 - _m.exp(-T * t_rec_s / (S * r**2))
        eta_rec       = min(max(eta_rec, 0.0), 1.0)
        # facteur_cycle : si t_pc=0 → pompage continu → facteur=1
        if t_pc_s > 0:
            facteur_cycle = t_pc_s / (t_pc_s + t_rec_s)
        else:
            facteur_cycle = 1.0
    else:
        eta_rec       = 1.0
        facteur_cycle = 1.0

    # ── Facteur f_P : correction pluviométrique du débit durable ──
    # Loi : f_P = MIN(1.5 ; MAX(0.3 ; pluie_eff_locale / 200))
    P_mm   = data["P_mm"]
    ETP_mm = data["ETP_mm"]
    R_mm   = data["R_mm"]
    pluie_eff_locale = max(max(P_mm - ETP_mm, 0.0), R_mm)  # mm/an
    f_P_auto = min(1.5, max(0.3, pluie_eff_locale / 200.0)) if pluie_eff_locale > 0 else 1.0
    f_P_manuel = data.get("f_P_manuel")
    if isinstance(f_P_manuel, (int, float)) and f_P_manuel and f_P_manuel > 0:
        f_P = min(1.5, max(0.2, float(f_P_manuel)))
    else:
        f_P = f_P_auto

    # ── Facteur f_K : correction perméabilité de la recharge effective ──
    # Loi : f_K = MIN(1.15 ; MAX(0.10 ; 0.20 + 0.15 × (log10(K) + 8)))
    f_K_auto = min(1.15, max(0.1, 0.2 + 0.15 * (_m.log10(max(K, 1e-12)) + 8)))
    f_K_manuel = data.get("f_K_manuel")
    if isinstance(f_K_manuel, (int, float)) and f_K_manuel and f_K_manuel > 0:
        f_K = min(1.3, max(0.05, float(f_K_manuel)))
    else:
        f_K = f_K_auto

    # Q_cycle inclut désormais f_P (cohérent avec Calculs!C39 dans l'Excel)
    # Et intègre le facteur de concentration topographique f_C si IPL ≥ 1
    # Lecture IPL et Q_lent_durable depuis le tableur Topographie & Lenticulaire
    # Si le cache Excel est vide (formules non évaluées), on recalcule en Python
    # à partir des inputs bruts pour garantir la cohérence du PDF.
    ipl_pdf = 0
    q_lent_durable_h = 0.0  # m³/h
    f_C_topo = 1.0
    try:
        import openpyxl as _opx
        _wb_t = _opx.load_workbook(
            "/home/user/workspace/rabattement_logiciel/Modelisation_Rabattement_TSN_GMEP.xlsx",
            data_only=True,
        )
        _topo = _wb_t["Topographie & Lenticulaire"]
        _ipl_raw = _topo["C42"].value
        ipl_pdf = int(_ipl_raw) if isinstance(_ipl_raw, (int, float)) else 0
        _q_raw = _topo["C51"].value
        if isinstance(_q_raw, (int, float)):
            q_lent_durable_h = float(_q_raw)
        _fc_raw = _topo["C50"].value
        if isinstance(_fc_raw, (int, float)):
            f_C_topo = float(_fc_raw)
    except Exception:
        pass

    # Fallback Python si le cache Excel n'est pas disponible (ex. après passage LibreOffice).
    # Formules identiques au tableur 'Topographie & Lenticulaire' :
    #   C45 = IF(IPL≥2, 2356194×0.5, 0)   — surface lenticulaire estimée (m²)
    #   C48 = R_mm / 1000                  — recharge annuelle effective (m/an)
    #   C51 = C45 × C48 / 8760             — débit cuvette durable (m³/h)
    #   C50 = 1 + 0.15 × IPL              — facteur de concentration f_C
    if q_lent_durable_h == 0.0 and ipl_pdf >= 2:
        _surf_lent = 2356194.0 * 0.5
        _R_m_an   = R_mm / 1000.0
        q_lent_durable_h = _surf_lent * _R_m_an / 8760.0
    if f_C_topo == 1.0 and ipl_pdf > 0:
        f_C_topo = 1.0 + 0.15 * ipl_pdf

    Q_cycle = Q_theis_corr * facteur_cycle * eta_rec * f_P * f_C_topo  # débit moyen exploitable

    # DÉBIT POMPE DIMENSIONNANT — cohérent avec Calculs!H33
    # Q_pompe = MAX(Q_aquifère corrigé, Q_lent_durable si IPL ≥ 2)
    # Garde-fou physique : si fouille hors d'eau, Q = 0 quelle que soit la signature lenticulaire
    if fouille_hors_eau:
        Q_pompe_dim = 0.0
        Q_cycle = 0.0
    else:
        # Q_pompe_dim = débit physique de la pompe (capacité réelle de prélèvement)
        # NB : on n'ajoute PAS l'apport cuvette lenticulaire ici car ce n'est pas un débit
        # de pompage mais une ressource stockée. Le seuil ZRE 8 m³/h porte sur la
        # CAPACITÉ DE PRÉLÈVEMENT physique, pas sur la ressource théoriquement mobilisable.
        Q_pompe_dim = Q_theis_corr

    # Fourchette ±15 % — sur le débit pompe dimensionnant (et non Theis brut)
    Q_min   = Q_pompe_dim * 0.85
    Q_max   = Q_pompe_dim * 1.15
    # Volumes calculés sur la durée d'exploitation effective (t_exploit_h)
    # V_aquif inclut f_K (correction perméabilité) — cohérent avec Calculs!C48
    vol_j_aquif = Q_cycle * t_exploit_h * f_K   # m3/j apport aquifère
    # Apport pluvial sur la fouille : pluie efficace × surface × α / 365
    surf_fouille = math.pi * R_inf**2
    alpha_ruiss  = 0.85
    vol_j_pluie  = surf_fouille * pluie_eff_locale * alpha_ruiss / 365.0 / 1000.0  # m3/j
    # v15.75 — SUPPRESSION du plancher arbitraire (chantier 5 m³/j / cuvette lenticulaire)
    # Motif : le plancher imposait un volume non atteignable physiquement quand le substrat
    # est peu perméable (lœss, argile), créant une incohérence Q × 24h << V_jour.
    # Le volume journalier est désormais piloté UNIQUEMENT par la physique Theis/Dupuit.
    plancher_j = 0.0
    # Garde-fou physique : si fouille hors d'eau, aucun volume pompé
    if fouille_hors_eau:
        vol_j_aquif = 0.0
        vol_j_pluie = 0.0
        vol_j       = 0.0
    else:
        vol_j   = vol_j_aquif + vol_j_pluie
    vol_m   = vol_j * 30
    vol_a   = vol_j * 365

    # Statut IOTA combiné 1.1.1.0 + 1.1.2.0 + 1.3.1.0
    # 1.1.1.0 : déclaration systématique (création d'ouvrage, sans seuil de volume)
    # 1.1.2.0 : déclaration si 10 000 ≤ V < 200 000 m³/an, autorisation si V ≥ 200 000 m³/an
    # 1.3.1.0 : ne s'applique QUE si la commune est en ZRE — AUTORISATION si Q≥8, sinon déclaration
    # Le statut ZRE est résolu automatiquement à partir de X/Y (geo_resolver)
    Q_theis_h_corr = Q_pompe_dim
    zre_actif = data.get("zre_actif", False)
    zre_nappe = data.get("zre_nappe", "—")
    zre_label = "ZRE " + zre_nappe if zre_actif and zre_nappe != "—" else (
                "ZRE confirmée" if zre_actif else "hors ZRE")

    # Garde-fou physique : fouille hors d'eau -> hors nomenclature, aucun pompage requis
    if fouille_hors_eau:
        ipl_mention = " (cuvette lenticulaire IPL\u2009≥\u20092 — surveiller fluctuations saisonnières)" if ipl_pdf >= 2 else ""
        statut_iota = (
            f"HORS NOMENCLATURE — Fond de fouille ({FF:.2f} m/TN) au-dessus du niveau d'eau "
            f"({NS:.2f} m/TN). Aucun pompage gravitaire requis{ipl_mention}."
        )
    elif zre_actif and Q_theis_h_corr >= 8.0:
        # ZRE + Q ≥ 8 m³/h → 1.3.1.0 prime, autorisation environnementale unique
        statut_iota = (
            f"AUTORISATION ENVIRONNEMENTALE — Rubriques 1.1.1.0 + 1.1.2.0 + 1.3.1.0 "
            f"({zre_label}, Q ≥ 8 m³/h — R.181-13)"
        )
    elif vol_a >= 200000:
        # V ≥ 200 000 m³/an : autorisation 1.1.2.0 (même hors ZRE)
        rubr_zre = " + 1.3.1.0" if zre_actif else ""
        statut_iota = f"AUTORISATION REQUISE — Rubrique 1.1.2.0{rubr_zre} (V ≥ 200 000 m³/an)"
    elif vol_a >= 10000:
        rubr_zre = " + 1.3.1.0" if zre_actif else ""
        zre_part = f" ({zre_label}, Q < 8 m³/h)" if zre_actif else ""
        statut_iota = f"DÉCLARATION — Rubriques 1.1.1.0 + 1.1.2.0{rubr_zre}{zre_part}"
    else:
        rubr_zre = " + 1.3.1.0" if zre_actif else ""
        zre_part = f" ({zre_label})" if zre_actif else ""
        statut_iota = f"DÉCLARATION — Rubrique 1.1.1.0{rubr_zre} (V < 10 000 m³/an{', ' + zre_part.strip(' ()') if zre_part else ''})"

    # Stockage
    data["rayon_r"]       = f"{r:.3f} m"
    data["rabattement_s"] = f"{s_rab:.2f} m"
    data["t_s"]           = f"{int(t_s):,} s".replace(",", " ")
    data["u"]             = f"{u:.4e}"
    data["Wu"]            = f"{wu:.4f}"
    # T_calc = K × épaisseur saturée réellement captée (peut différer de T_aquifère régional)
    data["T_calc"]        = fmt_sci(T) + f" m²/s  (= K × e_captée ; e_captée = {e_captee:.2f} m)"
    data["T_num"]         = T       # Transmissivité numérique pour schémas
    data["S_num"]         = S       # Coefficient emmagasinement numérique
    data["diam_forage"]   = safe_float(de_cache.get("diam_forage"), 0.22)
    data["eta"]           = f"{eta:.0%}"
    data["Q_theis_brut"]  = f"{Q_theis_h:.2f}"
    data["Q_dupuit_brut"] = f"{Q_dupuit_h:.2f}"
    data["Q_theis_corr"]  = f"{Q_theis_corr:.2f}"
    data["Q_dupuit_corr"] = f"{Q_dupuit_corr:.2f}"
    data["S_calc"]        = fmt_sci(S)
    data["Q_theis"]       = f"{Q_theis_corr:.2f}"   # valeur corrigee par eta
    data["Q_theis_jour"]  = f"{Q_theis_corr*24:.0f}"
    data["fouille_hors_eau"] = fouille_hors_eau  # Drapeau garde-fou physique
    data["Q_pompe_dim"]   = f"{Q_pompe_dim:.2f}"   # Débit pompe dimensionnant = MAX(Q_aquif, Q_lent_durable si IPL≥2)
    data["Q_pompe_dim_val"] = Q_pompe_dim
    data["Q_lent_durable"] = f"{q_lent_durable_h:.2f}"
    data["ipl_value"]     = ipl_pdf
    data["f_C_topo"]      = f"{f_C_topo:.3f}"
    data["Q_dupuit"]      = f"{Q_dupuit_corr:.2f}"  # valeur corrigee par eta
    data["Q_dupuit_jour"] = f"{Q_dupuit_j:.0f}"
    data["Q_min"]         = f"{Q_min:.2f}"
    data["Q_max"]         = f"{Q_max:.2f}"
    data["vol_jour"]      = f"{vol_j:.0f}"
    data["vol_mois"]      = f"{vol_m:.0f}"
    data["vol_an"]        = f"{vol_a:.0f}"
    data["vol_an_float"]  = vol_a
    data["statut_iota"]   = statut_iota
    data["t_rec_min"]     = t_rec_min
    data["t_rec_s"]       = t_rec_s
    data["t_pc_min_val"]  = t_pc_min
    data["t_exploit_h_val"]= t_exploit_h
    data["eta_rec"]       = eta_rec
    data["facteur_cycle"] = facteur_cycle
    data["Q_cycle"]       = f"{Q_cycle:.2f}"
    data["t_rec_str"]     = f"{t_rec_min:.0f} min ({t_rec_s:.0f} s)" if t_rec_min > 0 else "Non renseigné (pompage continu)"
    data["t_pc_str"]      = ("Continu (0 min)" if t_pc_min == 0 else f"{t_pc_min:.0f} min")
    data["t_exploit_str"] = f"{t_exploit_h:.1f} h/jour"
    data["eta_rec_str"]   = f"{eta_rec:.3f}  ({eta_rec*100:.1f} %)"
    data["facteur_cycle_str"] = f"{facteur_cycle:.3f}  ({facteur_cycle*100:.1f} %)"
    # Facteurs de correction pluvio + perméabilité
    data["pluie_eff_locale"] = f"{pluie_eff_locale:.0f} mm/an"
    data["f_P_auto"]   = f"{f_P_auto:.3f}"
    data["f_P"]        = f"{f_P:.3f}"
    data["f_P_val"]    = f_P
    data["f_K_auto"]   = f"{f_K_auto:.3f}"
    data["f_K"]        = f"{f_K:.3f}"
    data["f_K_val"]    = f_K
    data["vol_j_aquif"] = f"{vol_j_aquif:.1f}"
    data["vol_j_pluie"] = f"{vol_j_pluie:.2f}"
    # Diagnostic régime de calcul (toujours aquifère depuis v15.75 — plancher supprimé)
    vol_j_phys = vol_j_aquif + vol_j_pluie
    data["vol_j_phys"] = f"{vol_j_phys:.2f}"
    data["vol_j_phys_val"] = vol_j_phys
    data["plancher_j_val"] = 0.0
    if False:  # v15.75 — plancher supprimé, ce bloc n'est jamais activé
        data["regime_calcul"] = "PLANCHER CHANTIER"
        data["regime_alerte"] = (
            f"[!] Régime PLANCHER CHANTIER actif — le débit aquifère+pluvial cumulé "
            f"({vol_j_phys:.2f} m³/j) est inférieur au plancher minimum chantier ({plancher_j:.0f} m³/j). "
            f"Le volume annuel est figué à {plancher_j*365:.0f} m³/an et NE VARIE PAS avec t_rec / t_pc / cycle. "
            f"Cause typique : substratum peu perméable (ici {substrat}, K = {fmt_sci(K)} m/s). "
            f"Pour rendre le cycle visible, il faut un aquifère plus productif."
        )
    else:
        data["regime_calcul"] = "AQUIFÈRE"
        data["regime_alerte"] = (
            f"[OK] Régime AQUIFÈRE normal — V_jour = V_aquif ({vol_j_aquif:.1f}) + V_pluie ({vol_j_pluie:.2f}) "
            f"= {vol_j_phys:.1f} m³/j. Le facteur cycle = t_pc/(t_pc+t_rec) = {facteur_cycle:.3f} "
            f"module directement le volume journalier et annuel."
        )
    # Versions numériques pour calculs
    data["NS_str"]        = f"{NS:.2f}"
    data["FF_str"]        = f"{FF:.2f}"
    data["rayon_inf_str"] = f"{R_inf:.2f}"
    data["rayon_inf_final"] = R_inf          # valeur R finale utilisée (Sichardt ou manuelle)
    data["tps_pompage_str"]= f"{t_h:.0f}"
    data["geo_S_retenu"]  = fmt_sci(S)

    return data


# ─────────────────────────────────────────────
# STYLES
# ─────────────────────────────────────────────
def build_styles():
    styles = getSampleStyleSheet()
    s = {}

    s["cover_title"] = ParagraphStyle("cover_title",
        fontName=FONT_BOLD, fontSize=22, leading=28,
        textColor=C_WHITE, alignment=TA_CENTER, spaceAfter=6)

    s["cover_subtitle"] = ParagraphStyle("cover_subtitle",
        fontName=FONT_BODY, fontSize=12, leading=16,
        textColor=HexColor("#D0E8EC"), alignment=TA_CENTER, spaceAfter=4)

    s["cover_ref"] = ParagraphStyle("cover_ref",
        fontName=FONT_BOLD, fontSize=10, leading=14,
        textColor=C_WHITE, alignment=TA_CENTER, spaceAfter=3)

    s["section_title"] = ParagraphStyle("section_title",
        fontName=FONT_BOLD, fontSize=13, leading=18,
        textColor=C_WHITE, alignment=TA_LEFT,
        spaceBefore=10, spaceAfter=6,
        leftIndent=0, borderPadding=(6, 8, 6, 8))

    s["subsection_title"] = ParagraphStyle("subsection_title",
        fontName=FONT_BOLD, fontSize=11, leading=15,
        textColor=C_TEAL_DARK, alignment=TA_LEFT,
        spaceBefore=8, spaceAfter=4, leftIndent=0)

    s["body"] = ParagraphStyle("body",
        fontName=FONT_BODY, fontSize=9.5, leading=14,
        textColor=HexColor("#1A1A1A"), alignment=TA_JUSTIFY,
        spaceBefore=2, spaceAfter=4)

    s["body_bold"] = ParagraphStyle("body_bold",
        fontName=FONT_BOLD, fontSize=9.5, leading=14,
        textColor=HexColor("#1A1A1A"), alignment=TA_LEFT,
        spaceBefore=2, spaceAfter=4)

    s["small"] = ParagraphStyle("small",
        fontName=FONT_BODY, fontSize=8.5, leading=12,
        textColor=C_GREY_DARK, alignment=TA_LEFT,
        spaceBefore=1, spaceAfter=2)

    s["footer"] = ParagraphStyle("footer",
        fontName=FONT_BODY, fontSize=7.5, leading=10,
        textColor=C_GREY_DARK, alignment=TA_CENTER)

    s["formula"] = ParagraphStyle("formula",
        fontName=FONT_BOLD, fontSize=10, leading=14,
        textColor=C_TEAL_DARK, alignment=TA_CENTER,
        spaceBefore=4, spaceAfter=4,
        backColor=C_TEAL_XLIGHT, leftIndent=20, rightIndent=20,
        borderPadding=6)

    s["highlight"] = ParagraphStyle("highlight",
        fontName=FONT_BOLD, fontSize=11, leading=15,
        textColor=C_TEAL_DARK, alignment=TA_CENTER,
        spaceBefore=4, spaceAfter=4)

    s["result_box"] = ParagraphStyle("result_box",
        fontName=FONT_BOLD, fontSize=12, leading=16,
        textColor=C_GREEN_DARK, alignment=TA_CENTER,
        spaceBefore=2, spaceAfter=2)

    s["iota_ok"] = ParagraphStyle("iota_ok",
        fontName=FONT_BOLD, fontSize=11, leading=15,
        textColor=C_GREEN_DARK, alignment=TA_CENTER)

    s["iota_alert"] = ParagraphStyle("iota_alert",
        fontName=FONT_BOLD, fontSize=11, leading=15,
        textColor=C_RED, alignment=TA_CENTER)

    s["note"] = ParagraphStyle("note",
        fontName=FONT_ITALIC, fontSize=8.5, leading=12,
        textColor=C_GREY_DARK, alignment=TA_LEFT,
        leftIndent=10, spaceBefore=2, spaceAfter=4)

    return s


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────
def section_header(title, s):
    """Retourne une table pleine largeur avec fond teal pour les titres de section."""
    tbl = Table([[Paragraph(title, s["section_title"])]],
                colWidths=[17*cm])
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), C_TEAL_DARK),
        ("LEFTPADDING",  (0,0), (-1,-1), 8),
        ("RIGHTPADDING", (0,0), (-1,-1), 8),
        ("TOPPADDING",   (0,0), (-1,-1), 6),
        ("BOTTOMPADDING",(0,0), (-1,-1), 6),
        ("ROUNDEDCORNERS", [3]),
    ]))
    return tbl

def subsection_header(title, s):
    """Titre de sous-section avec ligne de soulignement teal."""
    return Paragraph(title, s["subsection_title"])

def two_col_table(rows, s, col1=7*cm, col2=10*cm):
    """Table à 2 colonnes : libellé | valeur."""
    data = []
    for label, value in rows:
        data.append([
            Paragraph(f"<b>{label}</b>", s["small"]),
            Paragraph(str(value), s["small"])
        ])
    tbl = Table(data, colWidths=[col1, col2])
    tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
        ("TOPPADDING",    (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("FONTNAME",      (0,0), (0,-1), FONT_BOLD),
        ("TEXTCOLOR",     (0,0), (0,-1), C_TEAL_DARK),
    ]))
    return tbl

def result_table(headers, rows, s, col_widths=None):
    """Table de résultats avec en-tête coloré."""
    data = [[Paragraph(f"<b>{h}</b>", ParagraphStyle("th",
                fontName=FONT_BOLD, fontSize=9, textColor=C_WHITE,
                alignment=TA_CENTER, leading=12)) for h in headers]]
    for row in rows:
        data.append([Paragraph(str(c), ParagraphStyle("td",
                fontName=FONT_BODY, fontSize=9, textColor=C_BLACK,
                alignment=TA_CENTER, leading=12)) for c in row])
    if col_widths is None:
        col_widths = [17*cm / len(headers)] * len(headers)
    tbl = Table(data, colWidths=col_widths)
    tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), C_TEAL_DARK),
        ("TEXTCOLOR",     (0,0), (-1,0), C_WHITE),
        ("ALIGN",         (0,0), (-1,-1), "CENTER"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("FONTNAME",      (0,0), (-1,0), FONT_BOLD),
        ("FONTSIZE",      (0,0), (-1,-1), 9),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.4, C_GREY_MED),
        ("LINEBELOW",     (0,0), (-1,0), 1.0, C_TEAL_DARK),
    ]))
    return tbl


# ─────────────────────────────────────────────
# PAGE DE GARDE
# ─────────────────────────────────────────────
def build_cover(story, data, s):
    # Titre + sous-titre dynamiques selon statut IOTA réel
    _statut_full = str(data.get("statut_iota", ""))
    _statut_up = _statut_full.upper()
    if _statut_up.startswith("AUTORISATION"):
        _cover_title = "DOSSIER D'AUTORISATION ENVIRONNEMENTALE"
    elif _statut_up.startswith("HORS NOMENCLATURE"):
        _cover_title = "DOSSIER TECHNIQUE \u2014 HORS NOMENCLATURE IOTA"
    else:
        _cover_title = "DOSSIER DE D\u00c9CLARATION LOI SUR L'EAU"
    # Sous-titre : reprendre les rubriques applicables
    _zre_actif_cov = bool(data.get("zre_actif", False))
    _zre_nappe_cov = data.get("zre_nappe", "")
    if _statut_up.startswith("HORS NOMENCLATURE"):
        _cover_sub_rub = "Fond de fouille au-dessus du niveau d'eau \u2014 aucun pompage gravitaire requis"
    elif _zre_actif_cov:
        _zre_txt = f" (ZRE {_zre_nappe_cov})" if _zre_nappe_cov and _zre_nappe_cov != "\u2014" else " (ZRE)"
        _cover_sub_rub = f"Loi sur l'Eau \u2014 Rubriques 1.1.1.0 + 1.1.2.0 + 1.3.1.0{_zre_txt}"
    else:
        _cover_sub_rub = "Loi sur l'Eau \u2014 Rubriques 1.1.1.0 + 1.1.2.0"
    # Bande titre principale
    cover_bg = Table(
        [[Paragraph("G.M.E.P", s["cover_title"])],
         [Paragraph("Rabattement d'une nappe souterraine", s["cover_subtitle"])],
         [Spacer(1, 0.3*cm)],
         [Paragraph(_cover_title, s["cover_title"])],
         [Paragraph(_cover_sub_rub, s["cover_subtitle"])],
         [Paragraph("Articles L.214-1 \u00e0 L.214-6 du Code de l'Environnement", s["cover_ref"])],
         [Paragraph("Nomenclature IOTA R.214-1", s["cover_ref"])],
        ],
        colWidths=[17*cm]
    )
    cover_bg.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,-1), C_TEAL_DARK),
        ("LEFTPADDING",   (0,0), (-1,-1), 20),
        ("RIGHTPADDING",  (0,0), (-1,-1), 20),
        ("TOPPADDING",    (0,0), (0,0), 30),
        ("TOPPADDING",    (0,1), (-1,-1), 4),
        ("BOTTOMPADDING", (0,-1),(-1,-1), 30),
        ("BOTTOMPADDING", (0,0), (-1,-2), 4),
    ]))
    story.append(cover_bg)
    story.append(Spacer(1, 0.8*cm))

    # Informations projet
    date_str = datetime.now().strftime("%d/%m/%Y")
    ref = data.get("ref_dossier", "—")
    commune = data.get("commune", "—")
    dept = data.get("departement", "—")

    info_data = [
        ["Référence dossier :", ref],
        ["Commune / Site :", commune],
        ["Département :", dept],
        ["Date d'édition :", date_str],
        ["Version :", "1.0"],
    ]
    info_tbl = Table(info_data, colWidths=[6*cm, 11*cm])
    info_tbl.setStyle(TableStyle([
        ("FONTNAME",      (0,0), (0,-1), FONT_BOLD),
        ("FONTSIZE",      (0,0), (-1,-1), 9.5),
        ("TEXTCOLOR",     (0,0), (0,-1), C_TEAL_DARK),
        ("TEXTCOLOR",     (1,0), (1,-1), C_BLACK),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
    ]))
    story.append(info_tbl)
    story.append(Spacer(1, 0.8*cm))

    # Intervenants — 3 colonnes
    story.append(Paragraph("Intervenants au projet", s["subsection_title"]))
    story.append(HRFlowable(width=17*cm, thickness=1, color=C_TEAL_DARK, spaceAfter=6))

    def intervenant_block(titre, nom, adresse, cp_ville, tel=None, email=None, siret=None, extra=None, col_w=4.2):
        """Bloc intervenant compact — v15.39 : tous les champs des 4 blocs identités."""
        lines = [
            [Paragraph(f"<b>{titre}</b>", ParagraphStyle("ih",
                fontName=FONT_BOLD, fontSize=8.5, textColor=C_WHITE,
                alignment=TA_CENTER, leading=11))],
            [Paragraph(nom or "—", ParagraphStyle("in",
                fontName=FONT_BOLD, fontSize=9, textColor=C_TEAL_DARK,
                alignment=TA_CENTER, leading=12))],
            [Paragraph(adresse or "—", ParagraphStyle("ia",
                fontName=FONT_BODY, fontSize=8, textColor=C_BLACK,
                alignment=TA_CENTER, leading=11))],
            [Paragraph(cp_ville or "—", ParagraphStyle("ic",
                fontName=FONT_BODY, fontSize=8, textColor=C_BLACK,
                alignment=TA_CENTER, leading=11))],
        ]
        if tel and tel != "—":
            lines.append([Paragraph(f"T\u00e9l. : {tel}", ParagraphStyle("it",
                fontName=FONT_BODY, fontSize=7.5, textColor=C_BLACK,
                alignment=TA_CENTER, leading=10))])
        if email and email != "—":
            lines.append([Paragraph(email, ParagraphStyle("iem",
                fontName=FONT_ITALIC, fontSize=7.5, textColor=C_GREY_DARK,
                alignment=TA_CENTER, leading=10))])
        if siret and siret != "—":
            lines.append([Paragraph(f"SIRET : {siret}", ParagraphStyle("is",
                fontName=FONT_BODY, fontSize=7, textColor=C_GREY_DARK,
                alignment=TA_CENTER, leading=10))])
        if extra and extra != "—":
            lines.append([Paragraph(extra, ParagraphStyle("ie",
                fontName=FONT_ITALIC, fontSize=7, textColor=C_GREY_DARK,
                alignment=TA_CENTER, leading=10))])
        t = Table(lines, colWidths=[col_w*cm])
        t.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,0), C_TEAL_MED),
            ("BACKGROUND",    (0,1), (-1,-1), C_TEAL_XLIGHT),
            ("LEFTPADDING",   (0,0), (-1,-1), 4),
            ("RIGHTPADDING",  (0,0), (-1,-1), 4),
            ("TOPPADDING",    (0,0), (0,0), 5),
            ("TOPPADDING",    (0,1), (-1,-1), 3),
            ("BOTTOMPADDING", (0,0), (-1,-1), 3),
            ("BOX",           (0,0), (-1,-1), 0.5, C_TEAL_DARK),
            ("INNERGRID",     (0,0), (-1,-1), 0.2, C_GREY_MED),
        ]))
        return t

    mo_bloc  = intervenant_block("MAÎTRE D'OUVRAGE",
        data["mo_nom"], data["mo_adresse"], data["mo_cp_ville"],
        tel=data.get("mo_tel"), email=data.get("mo_email"), siret=data.get("mo_siret"))
    et_bloc  = intervenant_block("ENTREPRISE DE TRAVAUX",
        data.get("et_nom", "—"), data.get("et_adresse", "—"), data.get("et_cp_ville", "—"),
        tel=data.get("et_tel"), email=data.get("et_email"), siret=data.get("et_siret"))
    be_bloc  = intervenant_block("BUREAU D'ÉTUDES",
        data["be_nom"], data["be_adresse"], data["be_cp_ville"],
        tel=data.get("be_tel"), email=data.get("be_email"),
        siret=data.get("be_agrement"))
    for_bloc = intervenant_block("SOCIÉTÉ DE FORAGE",
        data["forage_nom"], data["forage_adresse"], data["forage_cp_ville"],
        tel=data.get("forage_tel"), siret=data.get("forage_siret"),
        extra=data.get("forage_cert"))

    interv_tbl = Table([[mo_bloc, et_bloc, be_bloc, for_bloc]],
                       colWidths=[4.3*cm, 4.3*cm, 4.3*cm, 4.3*cm],
                       hAlign="CENTER")
    interv_tbl.setStyle(TableStyle([
        ("LEFTPADDING",  (0,0), (-1,-1), 3),
        ("RIGHTPADDING", (0,0), (-1,-1), 3),
        ("VALIGN",       (0,0), (-1,-1), "TOP"),
    ]))
    story.append(interv_tbl)
    story.append(Spacer(1, 0.5*cm))

    # Cadre réglementaire
    reg_text = (
        "Ce dossier est établi conformément aux dispositions du Code de l'Environnement, "
        "notamment les articles L.214-1 à L.214-6 et R.214-1 à R.214-56, relatifs à la "
        "nomenclature des installations, ouvrages, travaux et activités (IOTA) soumis à "
        "déclaration ou autorisation."
    )
    reg_tbl = Table([[Paragraph(reg_text, s["small"])]],
                    colWidths=[17*cm])
    reg_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), HexColor("#EAF4F6")),
        ("BOX",          (0,0), (-1,-1), 0.8, C_TEAL_DARK),
        ("LEFTPADDING",  (0,0), (-1,-1), 12),
        ("RIGHTPADDING", (0,0), (-1,-1), 12),
        ("TOPPADDING",   (0,0), (-1,-1), 8),
        ("BOTTOMPADDING",(0,0), (-1,-1), 8),
    ]))
    story.append(reg_tbl)
    story.append(PageBreak())


# ─────────────────────────────────────────────
# SOMMAIRE
# ─────────────────────────────────────────────
def build_sommaire(story, s, data=None):
    story.append(section_header("SOMMAIRE", s))
    story.append(Spacer(1, 0.4*cm))

    # Sommaire de base — sections 1 à 5 communes à tous les dossiers
    sections = [
        ("1", "Objet de l'étude"),
        ("2", "Données du projet et paramètres hydrogéologiques"),
        ("   2.1", "Caractéristiques de l'ouvrage de captage"),
        ("   2.2", "Paramètres hydrogéologiques"),
        ("3", "Méthodes de calcul"),
        ("   3.1", "Méthode de Theis — Régime transitoire"),
        ("   3.2", "Méthode de Dupuit-Thiem — Régime permanent"),
        ("4", "Résultats des calculs"),
        ("   4.1", "Paramètres intermédiaires de calcul"),
        ("   4.2", "Débits calculés et fourchette recommandée"),
        ("   4.3", "Analyse de sensibilité — Débit / Transmissivité"),
        ("   4.4", "Topographie & formations lenticulaires (IPL)"),
        ("5", "Vérification réglementaire — Nomenclature IOTA"),
        ("   5.1", "Rubrique 1.1.1.0 — Sondage, forage, ouvrage souterrain"),
        ("   5.2", "Rubrique 1.1.2.0 — Prélèvements en eau souterraine"),
        ("   5.3", "Rubrique 1.3.1.0 — Zone de Répartition des Eaux (ZRE)"),
        ("   5.4", "Rejet des eaux d'exhaure — Rubriques 2.x.x.0"),
        ("   5.5", "Masse d'eau souterraine — Référentiel SANDRE"),
        ("   5.6", "Régime cumulé & délais d'instruction prévisionnels"),
    ]
    # Section 6 : ZNIEFF/Natura 2000 — spécifique au site (Oucques) ou générique
    _is_oucques_som = (str((data or {}).get("code_insee", "")).strip() == "41171")
    if _is_oucques_som:
        sections += [
            ("6", "Sensibilité environnementale — ZNIEFF et Natura 2000"),
            ("   6.1", "ZNIEFF de Type I — Pelouses du Champ Noir"),
            ("   6.2", "ZNIEFF de Type II — Forêt de Marchenoir (proximité)"),
            ("   6.3", "Zone Natura 2000 ZPS — Petite Beauce (FR2410010)"),
            ("   6.4", "Évaluation des incidences"),
            ("7", "Préconisations techniques"),
        ]
    else:
        sections += [
            ("6", "Zones écologiquement sensibles — à compléter (spécifique au site)"),
        ]
    sections.append(("8", "Conclusion — Synthèse"))

    som_data = [[Paragraph(f"<b>{num}</b>", s["small"]),
                 Paragraph(titre, s["small"])]
                for num, titre in sections]
    som_tbl = Table(som_data, colWidths=[1.5*cm, 15.5*cm])
    som_tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (0,-1), "RIGHT"),
        ("ALIGN",         (1,0), (1,-1), "LEFT"),
        ("FONTNAME",      (0,0), (-1,-1), FONT_BODY),
        ("FONTSIZE",      (0,0), (-1,-1), 9.5),
        ("LEFTPADDING",   (0,0), (-1,-1), 4),
        ("RIGHTPADDING",  (0,0), (-1,-1), 4),
        ("TOPPADDING",    (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_GREY_LIGHT]),
        ("LINEBELOW",     (0,-1), (-1,-1), 0.5, C_GREY_MED),
    ]))
    story.append(som_tbl)
    story.append(PageBreak())


# ─────────────────────────────────────────────
# 1. OBJET DE L'ÉTUDE
# ─────────────────────────────────────────────
def build_objet(story, data, s):
    story.append(section_header("1. OBJET DE L'ÉTUDE", s))
    story.append(Spacer(1, 0.3*cm))

    mo = data["mo_nom"]
    commune = data["commune"] if data["commune"] != "—" else "la commune concernée"
    dept = data["departement"] if data["departement"] != "—" else ""
    dept_str = f" ({dept})" if dept and dept != "—" else ""

    # Suffixe rubriques IOTA — ajusté dynamiquement selon statut ZRE résolu
    if data.get("fouille_hors_eau"):
        _suffix_rubriques = (
            "(projet hors nomenclature IOTA — fond de fouille au-dessus du niveau d'eau, "
            "aucun prélèvement gravitaire requis)."
        )
    elif data.get("zre_actif"):
        _zre_qual = "confirmée" if data.get("zre_confirme") else "en présomption"
        _suffix_rubriques = (
            f"(Rubriques 1.1.1.0 + 1.1.2.0 + 1.3.1.0 — ZRE \"{data.get('zre_nappe', '—')}\" {_zre_qual})."
        )
    else:
        _suffix_rubriques = (
            "(Rubriques 1.1.1.0 + 1.1.2.0 — hors ZRE selon résolution géographique automatique)."
        )

    texte = (
        f"Le présent dossier est établi à la demande de <b>{mo}</b>. "
        f"Il concerne la réalisation d'un ouvrage de captage d'eaux souterraines "
        f"sur la commune de {commune}{dept_str}."
        f"<br/><br/>"
        f"Ce dossier a pour objet de démontrer, sur la base de calculs hydrogéologiques, "
        f"que l'exploitation de l'ouvrage de captage projeté est compatible avec les ressources "
        f"en eau du milieu récepteur et les usages en place. Il vise à satisfaire aux exigences "
        f"réglementaires du dossier au titre de la Loi sur l'Eau "
        f"{_suffix_rubriques}"
        f"<br/><br/>"
        f"Les calculs de rabattement sont réalisés selon deux méthodes complémentaires :"
        f"<br/>— la méthode de <b>Theis</b> (régime transitoire), applicable en début de pompage ;"
        f"<br/>— la méthode de <b>Dupuit-Thiem</b> (régime permanent), applicable à l'équilibre hydraulique."
        f"<br/><br/>"
        f"Les paramètres hydrogéologiques sont déterminés à partir de la nature géologique "
        f"du substrat identifié sur le site : <b>{data['substrat']}</b>."
    )
    story.append(Paragraph(texte, s["body"]))

    # Cadre référence réglementaire (Paragraph pour activer le retour à la ligne)
    story.append(Spacer(1, 0.4*cm))
    # Test ZRE 1.3.1.0 : on compare le DÉBIT POMPE DIMENSIONNANT (incluant cuvette si IPL≥2)
    q_h_reg = safe_float(data.get("Q_pompe_dim", data.get("Q_theis", 0)))
    _zre_actif_obj = bool(data.get("zre_actif", False))
    _zre_nappe_obj = data.get("zre_nappe", "—")
    if data.get("fouille_hors_eau"):
        regime_label = (
            "HORS NOMENCLATURE — fond de fouille au-dessus du niveau d'eau, "
            "aucun prélèvement gravitaire (Q = 0 m³/h)"
        )
        nomenclature_label = (
            "Sans objet — le projet ne sollicite pas la ressource en eau souterraine "
            "(rubriques 1.1.1.0, 1.1.2.0 et 1.3.1.0 non activées)"
        )
    elif _zre_actif_obj and q_h_reg >= 8.0:
        regime_label = (
            f"Autorisation environnementale (R.181-13) — ZRE \"{_zre_nappe_obj}\" "
            f"{'confirmée' if data.get('zre_confirme') else 'en présomption'}, "
            f"Q ≥ 8 m³/h (rubrique 1.3.1.0 alinéa 1°)"
        )
        nomenclature_label = (
            f"Rubriques 1.1.1.0 (sondage / ouvrage) + 1.1.2.0 (prélèvements) + "
            f"1.3.1.0 (ZRE \"{_zre_nappe_obj}\")"
        )
    elif data.get("vol_an_float", 0) >= 200000:
        regime_label = "Autorisation environnementale (volume annuel ≥ 200 000 m³/an)"
        nomenclature_label = "Rubriques 1.1.1.0 (sondage / ouvrage) + 1.1.2.0 (prélèvements)"
    elif _zre_actif_obj:
        regime_label = (
            f"Déclaration cumulée 1.1.1.0 + 1.1.2.0 + 1.3.1.0 (ZRE \"{_zre_nappe_obj}\", Q &lt; 8 m³/h)"
        )
        nomenclature_label = (
            f"Rubriques 1.1.1.0 (sondage / ouvrage) + 1.1.2.0 (prélèvements) + "
            f"1.3.1.0 (ZRE \"{_zre_nappe_obj}\")"
        )
    else:
        regime_label = (
            "Déclaration cumulée 1.1.1.0 + 1.1.2.0 (hors ZRE selon résolution géographique)"
        )
        nomenclature_label = "Rubriques 1.1.1.0 (sondage / ouvrage) + 1.1.2.0 (prélèvements)"

    reg_rows = [
        ["Code de l'Environnement", "Articles L.214-1 à L.214-6 et R.214-1 à R.214-56"],
        ["Nomenclature applicable", nomenclature_label],
        ["Régime", regime_label],
        ["Référence IOTA", "R.214-1 — Tableau annexé"],
    ]

    reg_key_style = ParagraphStyle(
        "reg_key", fontName=FONT_BOLD, fontSize=9, textColor=C_TEAL_DARK, leading=12
    )
    reg_val_style = ParagraphStyle(
        "reg_val", fontName=FONT_BODY, fontSize=9, textColor=C_BLACK, leading=12
    )
    reg_rows_para = [
        [Paragraph(k, reg_key_style), Paragraph(v, reg_val_style)] for k, v in reg_rows
    ]
    reg_tbl = Table(reg_rows_para, colWidths=[5.5*cm, 11.5*cm])
    reg_tbl.setStyle(TableStyle([
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 0.8, C_TEAL_DARK),
    ]))
    story.append(reg_tbl)
    story.append(Spacer(1, 0.4*cm))


# ─────────────────────────────────────────────
# 2. DONNÉES DU PROJET
# ─────────────────────────────────────────────
def build_donnees(story, data, s):
    story.append(section_header("2. DONNÉES DU PROJET ET PARAMÈTRES HYDROGÉOLOGIQUES", s))
    story.append(Spacer(1, 0.3*cm))

    # 2.1 Caractéristiques de l'ouvrage
    story.append(subsection_header("2.1  Caractéristiques de l'ouvrage de captage", s))

    ouvrage_rows = [
        ("Diamètre intérieur (Ø int.)", f"{data['diam_int']} m"),
        ("Diamètre extérieur (Ø ext.)", f"{data['diam_ext']} m"),
        ("Profondeur totale", f"{data['prof_puits']} m/TN"),
        ("Altimétrie tête d'ouvrage (NGF)", f"{data['alti_tete']} m NGF"),
        ("Altimétrie fond d'ouvrage (NGF)", f"{data['alti_fond']} m NGF"),
        ("Rayon du puits (r)", f"{data['rayon_r']}"),
        ("Type de captage", data["type_captage"]),
    ]
    story.append(two_col_table(ouvrage_rows, s))
    story.append(Spacer(1, 0.3*cm))

    # Équipements (v15.34)
    type_ouv = data.get("type_ouvrage", "Puits")
    story.append(Paragraph(f"Équipements de l'ouvrage (<b>{type_ouv}</b>) :", s["body_bold"]))
    equip_rows = [
        ("Type d'ouvrage",                 type_ouv),
        ("Margelle béton",                 data["margelle"]),
        ("Tête de puits — protection",     data["tete_protection"]),
        ("Matériau crépine",                f"{data['mat_crepine']} (fentes calibrées, -{data['crepine_top_m']:.2f} m à -{data['crepine_bot_m']:.2f} m)"),
        ("Matériau tubage",                 f"{data['mat_tubage']} (sur toute la hauteur)"),
        ("Massif filtrant",                 f"{data['gravier']} (-{data['gravier_top_m']:.2f} m à -{data['gravier_bot_m']:.2f} m)"),
        ("Cimentage annulaire",             f"{data['cimentage']} (0,00 à -{data['ciment_bot_m']:.2f} m)"),
    ]
    story.append(two_col_table(equip_rows, s))
    story.append(Spacer(1, 0.5*cm))

    # 2.2 Paramètres hydrogéologiques
    story.append(subsection_header("2.2  Paramètres hydrogéologiques", s))

    texte_geo = (
        f"Les paramètres hydrogéologiques retenus pour le présent dossier reposent sur "
        f"des valeurs de référence établies à l'échelle nationale (BRGM — BDLISA, SIGES) pour "
        f"chaque grande famille lithologique. Le substrat identifié sur le site est : "
        f"<b>{data['substrat']}</b>."
    )
    story.append(Paragraph(texte_geo, s["body"]))
    story.append(Spacer(1, 0.2*cm))

    geo_rows = [
        ("Substrat géologique", data["substrat"]),
        ("Famille lithologique", data["geo_famille"]),
        ("Type de nappe", data["geo_type_nappe"]),
        ("Conductivité hydraulique (K)", f"{data['geo_K']}"),
        ("Transmissivité (T)", f"{data['geo_T']}"),
        ("Coefficient d'emmagasinement — captive (S)", data["geo_S_captif"]),
        ("Coefficient d'emmagasinement — libre (S)", data["geo_S_libre"]),
        ("Porosité efficace (n)", f"{data['geo_porosite']}"),
        ("Épaisseur typique de l'aquifère", f"{data['geo_ep']}"),
    ]

    data_rows = [[Paragraph(f"<b>{k}</b>", ParagraphStyle("gk",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_TEAL_DARK, leading=12)),
                  Paragraph(str(v), ParagraphStyle("gv",
                    fontName=FONT_BODY, fontSize=9, textColor=C_ORANGE, leading=12))]
                 for k, v in geo_rows]
    geo_tbl = Table(data_rows, colWidths=[9*cm, 8*cm])
    geo_tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, HexColor("#FFF8F0")]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 0.8, C_ORANGE),
        ("LINEBELOW",     (0,0), (0,-1), 0.3, C_GREY_MED),
    ]))
    story.append(geo_tbl)
    story.append(Spacer(1, 0.3*cm))

    # Données terrain
    story.append(Paragraph("Données de terrain et conditions d'essai :", s["body_bold"]))
    terrain_rows = [
        ("Niveau statique (NS)", f"{data['NS_str']} m/TN"),
        ("Fond de fouille / Profondeur pompée", f"{data['FF_str']} m/TN"),
        ("Rabattement visé (s = fond − NS)", f"{data['rabattement_s']}"),
        ("Rayon d'influence (R)", f"{data['rayon_inf_str']} m"),
        ("Durée de pompage retenue", f"{data['tps_pompage_str']} h"),
    ]
    story.append(two_col_table(terrain_rows, s))
    story.append(Spacer(1, 0.4*cm))


# ─────────────────────────────────────────────
# 2bis. SCHÉMAS TECHNIQUES
# ─────────────────────────────────────────────
def build_schemas_techniques(story, data, s):
    """Insère les deux schémas : coupe piézomètre + cône de rabattement."""
    import sys, os, tempfile
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, SCRIPT_DIR)

    # === Nettoyage préventif des anciens schémas temporaires ===
    # Garantit que les schémas sont toujours régénérés avec les valeurs actuelles du tableur
    # et qu'aucun PNG périmé (ex. profondeur ancienne) ne traine en cache.
    _tmp = tempfile.gettempdir()
    for _old_png in ["gmep_schema_piezometre.png", "gmep_schema_cone.png", "gmep_schema_piezometres_ctrl.png"]:
        _p = os.path.join(_tmp, _old_png)
        try:
            if os.path.exists(_p):
                os.remove(_p)
        except Exception:
            pass

    try:
        from schemas_techniques import draw_piezometre, draw_cone_rabattement, draw_schema_piezometres
    except ImportError as e:
        story.append(Paragraph(f"[Schémas non disponibles : {e}]", s["body"]))
        story.append(PageBreak())
        return

    def _f(val, default):
        """Convertit en float en supprimant les unités éventuelles."""
        try:
            if val is None: return float(default)
            s = str(val).split()[0].replace(',','.')
            return float(s)
        except:
            return float(default)

    params = {
        'diam_int':      _f(data.get('diam_int'),    0.30),
        'diam_ext':      _f(data.get('diam_ext'),    0.40),
        'profondeur':    _f(data.get('prof_puits'),  6.00),
        'alt_tete_ngf':  _f(data.get('alti_tete'),  107.5),
        'alt_fond_ngf':  _f(data.get('alti_fond'),  101.5),
        'ns':            _f(data.get('NS'),           2.8),
        'fond_fouille':  _f(data.get('fond_fouille', data.get('FF')), 6.0),
        'rayon_gravier': _f(data.get('diam_forage'),  0.22) / 2,
        'rayon_inf':     _f(data.get('rayon_inf_str'), 10.0),
        'T':             data.get('T_num',            1.6e-2),
        'S':             data.get('S_num',            0.22),
        'Q':             _f(data.get('Q_theis'),      2.29) / 3600.0,
    }

    # ── PAGE : Schéma coupe piézomètre ──
    tmp_piezo = os.path.join(tempfile.gettempdir(), "gmep_schema_piezometre.png")
    draw_piezometre(params, tmp_piezo)

    # Tableau des dimensions
    dim_rows = [
        ["Paramètre", "Valeur"],
        ["Diamètre intérieur (Ø int.)",                  f"{params['diam_int']*100:.0f} cm"],
        ["Diamètre extérieur du tube (Ø ext.)",          f"{params['diam_ext']*100:.0f} cm"],
        ["Diamètre du forage avec massif gravillonnaire",f"{params['rayon_gravier']*2*100:.0f} cm"],
        ["Profondeur totale",                            f"{params['profondeur']:.1f} m/TN"],
        ["Altitude tête ouvrage (NGF)",                  f"{params['alt_tete_ngf']:.1f} m NGF"],
        ["Altitude fond ouvrage (NGF)",                  f"{params['alt_fond_ngf']:.1f} m NGF"],
    ]
    from reportlab.platypus import TableStyle as TS
    dim_tbl = Table(dim_rows, colWidths=[10*cm, 7*cm])
    dim_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), C_TEAL_DARK),
        ("TEXTCOLOR",     (0,0), (-1,0), C_WHITE),
        ("FONTNAME",      (0,0), (-1,0), FONT_BOLD),
        ("FONTSIZE",      (0,0), (-1,-1), 9),
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_WHITE, HexColor("#E0F7FA")]),
        ("GRID",          (0,0), (-1,-1), 0.4, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.0, C_TEAL_DARK),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
    ]))

    # Bloc A : section title + sous-titre + image + tableau dimensions, groupé
    bloc_a = [
        section_header("2bis.  SCHÉMAS TECHNIQUES DE L'OUVRAGE", s),
        Spacer(1, 0.3*cm),
        subsection_header("A — Coupe schématique du puits / piézomètre", s),
        Spacer(1, 0.2*cm),
    ]
    if os.path.exists(tmp_piezo):
        bloc_a.append(RLImage(tmp_piezo, width=14*cm, height=18*cm, kind='proportional'))
        bloc_a.append(Spacer(1, 0.2*cm))
    bloc_a.append(dim_tbl)
    story.append(KeepTogether(bloc_a))
    story.append(PageBreak())

    # ── PAGE : Schéma cône de rabattement ──
    tmp_cone = os.path.join(tempfile.gettempdir(), "gmep_schema_cone.png")
    draw_cone_rabattement(params, tmp_cone)

    bloc_b = [
        subsection_header("B — Schéma du cône de rabattement", s),
        Spacer(1, 0.2*cm),
    ]
    if os.path.exists(tmp_cone):
        bloc_b.append(RLImage(tmp_cone, width=17*cm, height=12*cm, kind='proportional'))
        bloc_b.append(Spacer(1, 0.3*cm))

    # Tableau rabattement (adapté selon type d'opération et mode de calcul v15.46)
    _is_rab = bool(data.get('is_rabattement_fouille'))
    _mode_Q = bool(data.get('mode_Q_impose'))
    if _mode_Q:
        # MODE 2 : Q imposé, on a calculé s
        s_w = float(data.get('s_rab_calcule', params['fond_fouille'] - params['ns']))
        _ndc = float(data.get('niveau_dyn_calcule', params['fond_fouille']))
    else:
        # MODE 1 : niveau cible saisi
        s_w = params['fond_fouille'] - params['ns']
        _ndc = params['fond_fouille']

    _libelle_ndc = "Niveau dynamique visé (fond de fouille)" if _is_rab else "Niveau dynamique visé dans le puits"
    rab_rows = [
        ["Param\u00e8tre", "Valeur"],
        ["Niveau statique (NS)",                   f"{params['ns']:.2f} m/TN"],
        [_libelle_ndc,                              f"{_ndc:.2f} m/TN"],
        ["Rabattement maximal au puits (s)",        f"{s_w:.2f} m"],
        ["Rayon d'influence (R)",                  f"{params['rayon_inf']:.1f} m"],
        ["D\u00e9bit de calcul (Q Theis)",               f"{params['Q']*3600:.2f} m\u00b3/h"],
        ["Transmissivit\u00e9 (T)",                      f"{params['T']:.2e} m\u00b2/s"],
    ]
    # Ajout du mode de calcul en tête du tableau
    rab_rows.insert(1, ["Type d'op\u00e9ration",
                         "Rabattement de fouille (chantier au sec)" if _is_rab else "Pompage AEP / industriel"])
    rab_rows.insert(2, ["Mode de calcul",
                         "D\u00e9bit Q impos\u00e9 \u2192 rabattement s calcul\u00e9" if _mode_Q
                         else "Niveau dynamique cible \u2192 d\u00e9bit Q calcul\u00e9"])
    rab_tbl = Table(rab_rows, colWidths=[10*cm, 7*cm])
    rab_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), HexColor("#E65100")),
        ("TEXTCOLOR",     (0,0), (-1,0), C_WHITE),
        ("FONTNAME",      (0,0), (-1,0), FONT_BOLD),
        ("FONTSIZE",      (0,0), (-1,-1), 9),
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_WHITE, HexColor("#FFF3E0")]),
        ("GRID",          (0,0), (-1,-1), 0.4, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.0, HexColor("#E65100")),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
    ]))
    bloc_b.append(rab_tbl)
    story.append(KeepTogether(bloc_b))
    story.append(PageBreak())

    # ── PAGE : Schéma conceptuel puits + piézomètres ──
    tmp_piezo_ctrl = os.path.join(tempfile.gettempdir(), "gmep_schema_piezometres_ctrl.png")
    params_piezo = dict(params)
    params_piezo['t_s'] = data.get('t_s_num', 86400.0)
    draw_schema_piezometres(params_piezo, tmp_piezo_ctrl)

    bloc_c = [
        subsection_header("C — Schéma conceptuel — Puits de pompage et piézomètres de contrôle", s),
        Spacer(1, 0.2*cm),
    ]
    if os.path.exists(tmp_piezo_ctrl):
        bloc_c.append(RLImage(tmp_piezo_ctrl, width=17*cm, height=12*cm, kind='proportional'))
        bloc_c.append(Spacer(1, 0.3*cm))

    # Tableau des niveaux aux piézomètres
    import math
    def _Wu_pdf(u):
        if u <= 0: return 0.0
        try:
            if u < 0.02:
                return -0.5772 - math.log(u) + u - u**2/4
            a0,a1,a2,a3,a4 = 0.99999193,-0.24991055,0.05519968,-0.00976004,0.00107857
            b1,b2,b3,b4    = 8.5733287401,18.0590169730,8.6347608925,0.2677737343
            c1,c2,c3,c4    = 9.5733223454,25.6329561486,21.0996530827,3.9584969228
            ex = math.exp(-u)
            return (a0+u*(a1+u*(a2+u*(a3+u*a4))))*(-math.log(u)) + \
                   ex*(b1+u*(b2+u*(b3+u*b4)))/(c1+u*(c2+u*(c3+u*c4)))
        except: return 0.0

    T_v   = params['T']
    S_v   = params['S']
    Q_s   = params['Q']
    t_s_v = params_piezo['t_s']
    NS_v  = params['ns']
    FF_v  = params['fond_fouille']
    alt_TN_v = params['alt_tete_ngf']

    def _rab(d):
        if d <= 0 or T_v <= 0: return 0.0
        u = (d**2 * S_v) / (4 * T_v * t_s_v)
        return max(0.0, Q_s * _Wu_pdf(u) / (4 * math.pi * T_v))

    s_pw = FF_v - NS_v
    s_p1 = _rab(5.0)
    s_p2 = _rab(10.0)
    nd_pw = NS_v + s_pw
    nd_p1 = NS_v + s_p1
    nd_p2 = NS_v + s_p2

    piezo_rows = [
        ["Ouvrage", "Distance\ndu puits", "Niveau statique\n(NS)",
         "Rabattement\n(s)", "Niveau dynamique\n(ND m/TN)",
         "Altitude NS\n(m NGF)", "Altitude ND\n(m NGF)"],
        ["Puits de pompage", "—",
         f"{NS_v:.2f} m/TN", f"{s_pw:.2f} m", f"{nd_pw:.2f} m/TN",
         f"{alt_TN_v - NS_v:.2f}", f"{alt_TN_v - nd_pw:.2f}"],
        ["Piézomètre P1", "5,00 m",
         f"{NS_v:.2f} m/TN", f"{s_p1:.2f} m", f"{nd_p1:.2f} m/TN",
         f"{alt_TN_v - NS_v:.2f}", f"{alt_TN_v - nd_p1:.2f}"],
        ["Piézomètre P2", "10,00 m",
         f"{NS_v:.2f} m/TN", f"{s_p2:.2f} m", f"{nd_p2:.2f} m/TN",
         f"{alt_TN_v - NS_v:.2f}", f"{alt_TN_v - nd_p2:.2f}"],
    ]
    piezo_tbl = Table(piezo_rows,
                      colWidths=[3.5*cm, 2.0*cm, 2.5*cm, 2.2*cm, 2.8*cm, 2.3*cm, 2.3*cm])
    piezo_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), HexColor("#1B474D")),
        ("TEXTCOLOR",     (0,0), (-1,0), C_WHITE),
        ("FONTNAME",      (0,0), (-1,0), FONT_BOLD),
        ("FONTNAME",      (0,1), (-1,-1), FONT_BODY),
        ("FONTSIZE",      (0,0), (-1,-1), 8.5),
        ("ALIGN",         (0,0), (-1,-1), "CENTER"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_WHITE, HexColor("#E0F7FA")]),
        ("GRID",          (0,0), (-1,-1), 0.4, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.2, HexColor("#1B474D")),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("LEFTPADDING",   (0,0), (-1,-1), 5),
        ("RIGHTPADDING",  (0,0), (-1,-1), 5),
        # Ligne puits en rouge clair
        ("BACKGROUND",   (0,1), (-1,1), HexColor("#FFEBEE")),
        ("TEXTCOLOR",    (0,1), (-1,1), HexColor("#C62828")),
        ("FONTNAME",     (0,1), (-1,1), FONT_BOLD),
    ]))
    bloc_c.append(piezo_tbl)
    bloc_c.append(Spacer(1, 0.2*cm))
    bloc_c.append(Paragraph(
        "<i>Niveaux calculés par la méthode de Theis (régime transitoire) au débit de pompage retenu. "
        "Les piézomètres P1 (5 m) et P2 (10 m) permettent de contrôler le rabattement réel "
        "lors des essais de pompage et de valider les paramètres hydrodynamiques de l'aquifère.</i>",
        s["note"]))
    story.append(KeepTogether(bloc_c))
    # NB: pas de PageBreak ici — build_cartes() commence par son propre PageBreak


# ─────────────────────────────────────────────
# 3. MÉTHODES DE CALCUL
# ─────────────────────────────────────────────
def build_methodes(story, data, s):
    story.append(PageBreak())
    story.append(section_header("3. MÉTHODES DE CALCUL", s))
    story.append(Spacer(1, 0.3*cm))

    # Note explicative : distinction T_aquifère régional vs T_calcul site
    note_T = Paragraph(
        "<b>Note importante sur la transmissivité retenue pour les calculs :</b> deux valeurs "
        "distinctes apparaissent dans le présent dossier. "
        "<b>T<sub>aquifère</sub></b> (cf. § 2.2) correspond à la valeur de référence régionale "
        "BRGM/BDLISA pour la famille lithologique considérée (épaisseur typique d'aquifère "
        "plurimétrique). "
        "<b>T<sub>calcul</sub></b> (ci-après) correspond à la transmissivité effective au droit "
        "du puits, calculée par T = K × e<sub>captée</sub>, où e<sub>captée</sub> est l'épaisseur "
        "saturée réellement interceptée par l'ouvrage. Pour le présent projet, le fond de fouille "
        "étant au-dessus (ou tangent) au niveau d'eau, e<sub>captée</sub> est très faible voire nulle "
        "et T<sub>calcul</sub> &lt;&lt; T<sub>aquifère</sub>. Cette distinction est volontaire et "
        "conservative : elle démontre qu'aucun prélèvement gravitaire n'est requis (Q = 0 m³/h).",
        ParagraphStyle("noteT",
            fontName=FONT_BODY, fontSize=8.5, leading=11,
            textColor=C_TEAL_DARK,
            leftIndent=8, rightIndent=8,
            spaceBefore=4, spaceAfter=4,
            borderColor=C_TEAL_DARK, borderWidth=0.5, borderPadding=8,
            backColor=colors.HexColor("#F4FBFB"))
    )
    story.append(note_T)
    story.append(Spacer(1, 0.3*cm))

    # 3.1 Theis - bloc groupé
    bloc_theis = []
    bloc_theis.append(subsection_header("3.1  Méthode de Theis — Régime transitoire", s))
    theis_text = (
        "La méthode de Theis (1935) est utilisée pour déterminer le débit d'un puits en régime "
        "transitoire, c'est-à-dire avant que l'équilibre hydraulique ne soit atteint. Elle s'applique "
        "aux aquifères captifs et semi-captifs, mais est également utilisée en approximation pour les "
        "nappes libres à faible rabattement relatif."
        "<br/><br/>"
        "La formule exprime le rabattement <b>s</b> en fonction du débit <b>Q</b>, de la "
        "transmissivité <b>T</b> et du coefficient d'emmagasinement <b>S</b> :"
    )
    bloc_theis.append(Paragraph(theis_text, s["body"]))
    bloc_theis.append(Spacer(1, 0.2*cm))

    # Formule Theis
    formule_theis = Table([
        [Paragraph("s = (Q / 4πT) × W(u)", s["formula"])],
        [Paragraph("avec  u = r² × S / (4 × T × t)", s["formula"])],
    ], colWidths=[17*cm])
    formule_theis.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), C_TEAL_XLIGHT),
        ("BOX",          (0,0), (-1,-1), 0.8, C_TEAL_DARK),
        ("LEFTPADDING",  (0,0), (-1,-1), 20),
        ("RIGHTPADDING", (0,0), (-1,-1), 20),
        ("TOPPADDING",   (0,0), (-1,-1), 8),
        ("BOTTOMPADDING",(0,0), (-1,-1), 8),
    ]))
    bloc_theis.append(formule_theis)
    bloc_theis.append(Spacer(1, 0.2*cm))

    legende_theis = [
        ("s", "rabattement [m]"),
        ("Q", "débit de pompage [m³/s]"),
        ("T", f"transmissivité de l'aquifère [m²/s] = {data['T_calc']}"),
        ("W(u)", "fonction de puits de Theis (intégrale exponentielle)"),
        ("u", "paramètre adimensionnel de Theis"),
        ("r", f"rayon du puits [m] = {data['rayon_r']}"),
        ("S", f"coefficient d'emmagasinement [-] = {data['geo_S_libre']} (nappe libre)"),
        ("t", f"temps de pompage [s] = {data['t_s']} ({data['tps_pompage_str']} h)"),
    ]
    leg_data = [[Paragraph(f"<b>{sym}</b>", ParagraphStyle("ls",
                    fontName=FONT_BOLD, fontSize=8.5, textColor=C_TEAL_DARK, leading=11,
                    alignment=TA_CENTER)),
                 Paragraph(desc, ParagraphStyle("ld",
                    fontName=FONT_BODY, fontSize=8.5, leading=11))]
                for sym, desc in legende_theis]
    leg_tbl = Table(leg_data, colWidths=[1.5*cm, 15.5*cm])
    leg_tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (0,-1), "CENTER"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 4),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
        ("TOPPADDING",    (0,0), (-1,-1), 3),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
        ("FONTNAME",      (0,0), (0,-1), FONT_BOLD),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_GREY_LIGHT]),
    ]))
    bloc_theis.append(leg_tbl)
    story.append(KeepTogether(bloc_theis))
    story.append(Spacer(1, 0.5*cm))

    # 3.2 Dupuit-Thiem - bloc groupé
    bloc_dupuit = []
    bloc_dupuit.append(subsection_header("3.2  Méthode de Dupuit-Thiem — Régime permanent", s))
    dupuit_text = (
        "La méthode de Dupuit-Thiem (formule de Thiem, 1906, adaptée à Dupuit pour les nappes libres) "
        "est utilisée pour estimer le débit d'équilibre d'un puits en régime permanent, une fois la "
        "stabilisation du niveau piézométrique atteinte. Elle est particulièrement adaptée aux aquifères "
        "libres homogènes et isotropes."
        "<br/><br/>"
        "La formule de base pour une nappe libre est :"
    )
    bloc_dupuit.append(Paragraph(dupuit_text, s["body"]))
    bloc_dupuit.append(Spacer(1, 0.2*cm))

    formule_dupuit = Table([
        [Paragraph("Q = π × K × (H² − h²) / ln(R/r)", s["formula"])],
        [Paragraph("ou équivalent :  Q = 2π × T × s / ln(R/r)", s["formula"])],
    ], colWidths=[17*cm])
    formule_dupuit.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), C_TEAL_XLIGHT),
        ("BOX",          (0,0), (-1,-1), 0.8, C_TEAL_DARK),
        ("LEFTPADDING",  (0,0), (-1,-1), 20),
        ("RIGHTPADDING", (0,0), (-1,-1), 20),
        ("TOPPADDING",   (0,0), (-1,-1), 8),
        ("BOTTOMPADDING",(0,0), (-1,-1), 8),
    ]))
    bloc_dupuit.append(formule_dupuit)
    bloc_dupuit.append(Spacer(1, 0.2*cm))

    legende_dupuit = [
        ("Q", "débit de pompage [m³/s]"),
        ("K", f"conductivité hydraulique [m/s] = {data['geo_K']}"),
        ("H", "hauteur piézométrique initiale [m]"),
        ("h", "hauteur piézométrique au puits après rabattement [m]"),
        ("T", f"transmissivité [m²/s] = {data['T_calc']}"),
        ("s", f"rabattement [m] = {data['rabattement_s']}"),
        ("R", f"rayon d'influence [m] = {data['rayon_inf_str']} m"),
        ("r", f"rayon du puits [m] = {data['rayon_r']}"),
    ]
    leg2_data = [[Paragraph(f"<b>{sym}</b>", ParagraphStyle("ls2",
                    fontName=FONT_BOLD, fontSize=8.5, textColor=C_TEAL_DARK, leading=11,
                    alignment=TA_CENTER)),
                  Paragraph(desc, ParagraphStyle("ld2",
                    fontName=FONT_BODY, fontSize=8.5, leading=11))]
                 for sym, desc in legende_dupuit]
    leg2_tbl = Table(leg2_data, colWidths=[1.5*cm, 15.5*cm])
    leg2_tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (0,-1), "CENTER"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 4),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
        ("TOPPADDING",    (0,0), (-1,-1), 3),
        ("BOTTOMPADDING", (0,0), (-1,-1), 3),
        ("FONTNAME",      (0,0), (0,-1), FONT_BOLD),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_GREY_LIGHT]),
    ]))
    bloc_dupuit.append(leg2_tbl)
    story.append(KeepTogether(bloc_dupuit))
    story.append(Spacer(1, 0.4*cm))


# ─────────────────────────────────────────────
# 4. RÉSULTATS
# ─────────────────────────────────────────────
def build_resultats(story, data, s):
    story.append(PageBreak())
    story.append(section_header("4. RÉSULTATS DES CALCULS", s))
    story.append(Spacer(1, 0.3*cm))

    # 4.1 Paramètres intermédiaires
    bloc_41 = []
    bloc_41.append(subsection_header("4.1  Paramètres intermédiaires de calcul", s))
    bloc_41.append(Spacer(1, 0.2*cm))

    inter_rows = [
        ("Rabattement visé (s)", f"{data['rabattement_s']}"),
        ("Rayon du puits (r)", f"{data['rayon_r']}"),
        ("Temps de pompage (t)", f"{data['t_s']}"),
        ("Paramètre u de Theis", f"{data['u']}"),
        ("Fonction de puits W(u)", f"{data['Wu']}"),
        ("Transmissivité retenue (T)", f"{data['T_calc']}"),
        ("Coefficient d'emmagasinement (S)", f"{data['S_calc']}"),
        ("Temps de recharge piézométrique (t_rec)", data.get('t_rec_str', 'Non renseigné')),
        ("Durée unité de pompage (t_pc)", data.get('t_pc_str', '—')),
        ("Durée d'exploitation journalière (t_exploit)", data.get('t_exploit_str', '—')),
        ("Efficacité de recharge (η_rec)", data.get('eta_rec_str', '—')),
        ("Facteur cycle pompage/recharge", data.get('facteur_cycle_str', '—')),
        ("Pluie efficace locale (max P−ETP ; R)", data.get('pluie_eff_locale', '—')),
        ("Facteur f_P — correction pluviométrique", data.get('f_P', '—')),
        ("Facteur f_K — correction perméabilité", data.get('f_K', '—')),
    ]

    p_data = [[Paragraph(f"<b>{k}</b>", ParagraphStyle("pk",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_TEAL_DARK, leading=12)),
               Paragraph(str(v), ParagraphStyle("pv",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_BLUE_DARK, leading=12))]
              for k, v in inter_rows]
    p_tbl = Table(p_data, colWidths=[9*cm, 8*cm])
    p_tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 0.8, C_TEAL_DARK),
    ]))
    bloc_41.append(p_tbl)
    story.append(KeepTogether(bloc_41))
    story.append(Spacer(1, 0.5*cm))

    # 4.1 bis — Récapitulatif des facteurs de correction appliqués
    bloc_41bis = []
    bloc_41bis.append(subsection_header("4.1.bis  Facteurs de correction appliqués sur le débit durable", s))
    bloc_41bis.append(Paragraph(
        "Le débit durable Q_cycle est obtenu par <b>Q_Theis_brut × η × cycle × η_rec × f_P</b>. "
        "Le volume aquifère journalier V_aquif inclut en outre le facteur perméabilité <b>f_K</b>. "
        "Le volume pluvial V_pluie utilise la <b>pluie efficace</b> (P−ETP, plancherée par la recharge BRGM).",
        s["body"]
    ))
    bloc_41bis.append(Spacer(1, 0.3*cm))

    fact_rows = [
        ["Facteur", "Valeur", "Plage", "Source / Loi"],
        ["η — Rendement hydraulique",          data.get("eta", "70%"),                    "0.5 – 0.85",  "Saisie expert (DE!C32)"],
        ["η_rec — Efficacité de recharge",     data.get("eta_rec_str", "—").split("  ")[0], "0 – 1",        "1 − exp(−T·t_rec / S·r²)"],
        ["Cycle — Fraction temps actif",       data.get("facteur_cycle_str", "—").split("  ")[0], "0 – 1",  "t_pc / (t_pc + t_rec)"],
        ["f_K — Correction perméabilité",      data.get("f_K", "—"),                      "0.10 – 1.15", "MIN(1.15 ; MAX(0.10 ; 0.20+0.15·(log10(K)+8)))"],
        ["f_P — Correction pluviométrique",    data.get("f_P", "—"),                      "0.30 – 1.50", "MIN(1.5 ; MAX(0.3 ; pluie_eff/200))"],
    ]
    fact_tbl = Table(fact_rows, colWidths=[5.0*cm, 2.2*cm, 2.0*cm, 7.8*cm])
    fact_tbl.setStyle(TableStyle([
        ("FONTNAME",      (0,0), (-1,0), FONT_BOLD),
        ("FONTNAME",      (0,1), (-1,-1), FONT_BODY),
        ("FONTSIZE",      (0,0), (-1,-1), 8.5),
        ("BACKGROUND",    (0,0), (-1,0), C_TEAL_DARK),
        ("TEXTCOLOR",     (0,0), (-1,0), colors.white),
        ("ALIGN",         (1,1), (2,-1), "CENTER"),
        ("ALIGN",         (0,1), (0,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 0.8, C_TEAL_DARK),
    ]))
    bloc_41bis.append(fact_tbl)
    bloc_41bis.append(Spacer(1, 0.3*cm))
    bloc_41bis.append(Paragraph(
        f"<i>Données climatiques retenues : station <b>{data.get('station_meteo','—')}</b> "
        f"(dép. {data.get('dept_code','—')} {data.get('dept_nom','—')}) — "
        f"P = {data.get('P_mm', 0):.0f} mm/an, ETP = {data.get('ETP_mm', 0):.0f} mm/an, "
        f"recharge effective BRGM R = {data.get('R_mm', 0):.0f} mm/an. "
        f"Pluie efficace locale retenue = {data.get('pluie_eff_locale','—')} (= max(P−ETP ; R)).</i>",
        s["body"]
    ))
    story.append(KeepTogether(bloc_41bis))
    story.append(Spacer(1, 0.4*cm))

    # 4.1 ter — Décomposition du volume journalier V_aquif + V_pluie (v15.83)
    bloc_41ter = []
    bloc_41ter.append(subsection_header("4.1 ter  Décomposition du volume journalier (V_aquif + V_pluie)", s))
    _v_aquif_str  = data.get("vol_j_aquif", "—")
    _v_pluie_str  = data.get("vol_j_pluie", "—")
    _v_jour_str   = data.get("vol_jour",    "—")
    _v_an_str     = data.get("vol_an",      "—")
    _r_inf_final  = data.get("rayon_inf_final", data.get("rayon_inf", 30.0))
    _R_mode_str   = data.get("R_inf_mode",  f"R = {_r_inf_final:.0f} m")
    _r_inf_v      = _r_inf_final if isinstance(_r_inf_final, (int, float)) and _r_inf_final > 0 else 30.0
    _s_fouille_m2 = 3.14159 * _r_inf_v**2 if isinstance(_r_inf_v, (int, float)) else 0
    bloc_41ter.append(Paragraph(
        "Le volume journalier V<sub>jour</sub> intègre <b>deux contributions physiquement distinctes</b> : "
        "la drainance de l'aquifère (V<sub>aquif</sub>) et l'apport pluvial direct sur la fouille (V<sub>pluie</sub>). "
        "Ce tableau permet de retracer la formule complète :",
        s["body"]
    ))
    bloc_41ter.append(Spacer(1, 0.2*cm))
    decomp_rows = [
        ["Composante", "Formule détaillée", "Valeur", "Unité"],
        ["Q_cycle (débit moyen)",
         "Q_Theis × η × cycle × η_rec × f_P × f_C",
         data.get("Q_cycle", "—"),
         "m³/h"],
        ["V_aquif (apport aquifère)",
         "Q_cycle × t_exp × f_K",
         f"{_v_aquif_str} m³/j",
         "m³/j"],
        ["V_pluie (apport pluvial)",
         "S_fouille (= \u03c0·R²) × pluie_eff × 0,85 / 365 / 1000",
         f"{_v_pluie_str} m³/j",
         "m³/j"],
        ["V_jour = V_aquif + V_pluie",
         "(Bilan total journalier)",
         f"{_v_jour_str} m³/j",
         "m³/j"],
        ["V_an = V_jour × 365",
         "(Volume annuel réglementaire)",
         f"{_v_an_str} m³/an",
         "m³/an"],
    ]
    decomp_tbl_41ter = Table(decomp_rows, colWidths=[4.5*cm, 6.5*cm, 3.0*cm, 2.0*cm])
    decomp_tbl_41ter.setStyle(TableStyle([
        ("FONTNAME",      (0,0), (-1,0), FONT_BOLD),
        ("FONTNAME",      (0,1), (-1,-1), FONT_BODY),
        ("FONTSIZE",      (0,0), (-1,-1), 8.5),
        ("BACKGROUND",    (0,0), (-1,0), C_TEAL_DARK),
        ("TEXTCOLOR",     (0,0), (-1,0), colors.white),
        ("ALIGN",         (2,1), (3,-1), "CENTER"),
        ("ALIGN",         (0,1), (1,-1), "LEFT"),
        ("FONTNAME",      (0,-1), (-1,-1), FONT_BOLD),
        ("BACKGROUND",    (0,-1), (-1,-1), colors.HexColor("#E2EFDA")),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("ROWBACKGROUNDS",(0,1), (-1,-2), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 0.8, C_TEAL_DARK),
    ]))
    bloc_41ter.append(decomp_tbl_41ter)
    bloc_41ter.append(Spacer(1, 0.25*cm))
    bloc_41ter.append(Paragraph(
        f"<i>Rayon d'influence : {_R_mode_str} — S_fouille = \u03c0 × {_r_inf_v:.0f}² = {_s_fouille_m2:.0f} m². "
        "La contribution pluviale V_pluie est généralement minoritaire (&lt; 1 % du volume total) "
        "mais garantit la couverture réglementaire de l'intégralité des eaux collectées.</i>",
        s["body"]
    ))
    story.append(KeepTogether(bloc_41ter))
    story.append(Spacer(1, 0.4*cm))

    # Bloc DIAGNOSTIC — régime de calcul (plancher vs aquifère)
    is_plancher = data.get("regime_calcul") == "PLANCHER CHANTIER"
    diag_bg    = colors.HexColor("#FCE4D6") if is_plancher else colors.HexColor("#E2EFDA")
    diag_brd   = colors.HexColor("#C00000") if is_plancher else colors.HexColor("#2D7A2D")
    diag_color = colors.HexColor("#9C0006") if is_plancher else colors.HexColor("#375623")
    # v15.72 : remplacement des glyphes [!]/[OK] par marqueurs ASCII safe
    # (les polices par defaut reportlab ne contiennent pas ces glyphes,
    # ce qui produisait des caracteres parasites \u0013 dans le PDF)
    diag_title = ("[!]  DIAGNOSTIC — RÉGIME DE CALCUL : PLANCHER CHANTIER ACTIF"
                  if is_plancher
                  else "[OK]  DIAGNOSTIC — RÉGIME DE CALCUL : AQUIFÈRE NORMAL")
    diag_para_style = ParagraphStyle("diag_para",
        fontName=FONT_BODY, fontSize=9.5, textColor=diag_color, leading=13,
        alignment=TA_LEFT)
    diag_title_style = ParagraphStyle("diag_title",
        fontName=FONT_BOLD, fontSize=10.5, textColor=diag_color, leading=14,
        alignment=TA_LEFT, spaceAfter=4)
    diag_rows = [
        [Paragraph(diag_title, diag_title_style)],
        [Paragraph(data.get("regime_alerte", "—"), diag_para_style)],
    ]
    diag_tbl = Table(diag_rows, colWidths=[17*cm])
    diag_tbl.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), diag_bg),
        ("BOX",        (0,0), (-1,-1), 1.2, diag_brd),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 10),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
    ]))
    story.append(KeepTogether([diag_tbl]))
    story.append(Spacer(1, 0.5*cm))

    # 4.2 Débits calculés
    bloc_42 = []
    bloc_42.append(subsection_header("4.2  Débits calculés et fourchette recommandée", s))
    bloc_42.append(Spacer(1, 0.2*cm))

    # Tableau comparatif 3 colonnes
    bloc_42.append(result_table(
        ["Méthode", "Débit calculé (m³/h)", "Débit calculé (m³/j)"],
        [
            ["Theis — Régime transitoire",   data["Q_theis"],  data["Q_theis_jour"]],
            ["Dupuit-Thiem — Régime permanent", data["Q_dupuit"], data["Q_dupuit_jour"]],
            ["Q_cycle — Corrigé cycle pompage/recharge", data.get("Q_cycle", data["Q_theis"]), f"{float(data.get('Q_cycle', data['Q_theis']))*data.get('t_exploit_h_val', 8.0):.0f} (base {data.get('t_exploit_str', '8h')})"],
        ],
        s,
        col_widths=[8*cm, 4.5*cm, 4.5*cm]
    ))
    story.append(KeepTogether(bloc_42))
    story.append(Spacer(1, 0.4*cm))

    # Fourchette recommandée
    bloc_four = []
    bloc_four.append(Paragraph("Fourchette de débit recommandée (±15%) :", s["body_bold"]))
    bloc_four.append(Spacer(1, 0.15*cm))
    fourchette_rows = [
        ["Débit minimum recommandé (−15%)",
         Paragraph(f"<b>{data['Q_min']} m³/h</b>", ParagraphStyle("fv",
            fontName=FONT_BOLD, fontSize=10, textColor=C_TEAL_DARK,
            alignment=TA_CENTER, leading=13))],
        ["Débit maximum recommandé (+15%)",
         Paragraph(f"<b>{data['Q_max']} m³/h</b>", ParagraphStyle("fv2",
            fontName=FONT_BOLD, fontSize=10, textColor=C_TEAL_DARK,
            alignment=TA_CENTER, leading=13))],
    ]
    f_tbl = Table(fourchette_rows, colWidths=[11*cm, 6*cm])
    f_tbl.setStyle(TableStyle([
        ("FONTNAME",      (0,0), (0,-1), FONT_BOLD),
        ("FONTSIZE",      (0,0), (-1,-1), 9.5),
        ("TEXTCOLOR",     (0,0), (0,-1), C_TEAL_DARK),
        ("ALIGN",         (1,0), (1,-1), "CENTER"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_TEAL_XLIGHT, HexColor("#E8F4E8")]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 0.8, C_TEAL_DARK),
    ]))
    bloc_four.append(f_tbl)
    story.append(KeepTogether(bloc_four))
    story.append(Spacer(1, 0.4*cm))

    # Volumes prévisionnels
    bloc_vol = []
    bloc_vol.append(Paragraph("Volumes prévisionnels d'exploitation :", s["body_bold"]))
    bloc_vol.append(Spacer(1, 0.15*cm))
    vol_rows = [
        ["Volume journalier prévu (corrigé cycle)",  f"{data['vol_jour']} m³/j"],
        ["Volume mensuel estimé",    f"{data['vol_mois']} m³/mois"],
        ["Volume annuel estimé",     f"{data['vol_an']} m³/an"],
    ]
    v_tbl = Table(vol_rows, colWidths=[9*cm, 8*cm])
    v_tbl.setStyle(TableStyle([
        ("FONTNAME",      (0,0), (0,-1), FONT_BOLD),
        ("FONTSIZE",      (0,0), (-1,-1), 9.5),
        ("TEXTCOLOR",     (0,0), (0,-1), C_TEAL_DARK),
        ("TEXTCOLOR",     (1,0), (1,-1), C_GREEN_DARK),
        ("FONTNAME",      (1,0), (1,-1), FONT_BOLD),
        ("ALIGN",         (1,0), (1,-1), "CENTER"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 0.8, C_TEAL_DARK),
    ]))
    bloc_vol.append(v_tbl)
    story.append(KeepTogether(bloc_vol))
    story.append(Spacer(1, 0.4*cm))


# ─────────────────────────────────────────────
# 4.3  ANALYSE DE SENSIBILITÉ
# ─────────────────────────────────────────────
def build_sensibilite(story, data, s):
    """Section 4.3 — Deux graphiques en courbes : Q=f(T) et Profondeur=f(distance)."""
    import math, os, tempfile
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import numpy as np
    except ImportError:
        return  # matplotlib absent → section ignorée silencieusement

    story.append(section_header("4.3  ANALYSE DE SENSIBILITÉ — DÉBIT / TRANSMISSIVITÉ", s))
    story.append(Spacer(1, 0.3*cm))

    intro = (
        "L'analyse de sensibilité évalue l'impact de la transmissivité <i>T</i> sur le débit "
        "de pompage (méthode Theis, régime transitoire). "
        "Le graphique de gauche présente les courbes Q\u202f=\u202ff(T) pour six valeurs de rabattement, "
        "en faisant varier T sur l'axe des abscisses (échelle logarithmique). "
        "Le graphique de droite montre le profil de rabattement (profondeur de nappe en m/TN) "
        "en fonction de la distance au puits, pour six valeurs de transmissivité. "
        "Les paramètres fixes sont ceux du projet\u202f: rayon du puits, temps de pompage et coefficient d'emmagasinement."
    )
    story.append(Paragraph(intro, s["body"]))
    story.append(Spacer(1, 0.4*cm))

    # ─ Paramètres projet ─
    r    = data.get("diam_int_v", 0.112) / 2
    R    = data.get("rayon_inf", 10.0)
    NS   = data.get("NS", 2.8)
    FF   = data.get("fond_fouille", 6.0)
    s_   = FF - NS
    t_h  = data.get("tps_pompage", 24.0)
    t_s  = t_h * 3600.0
    T_proj = data.get("T_num", 0.0032)
    try:
        S_v = float(data.get("S_calc_v", data.get("S_calc", 0.05)))
    except Exception:
        S_v = 0.05

    def _Wu(u):
        if u <= 0: return None
        try:
            if u < 0.02:
                return -0.5772 - math.log(u) + u - u**2/4
            a0,a1,a2,a3,a4 = 0.99999193,-0.24991055,0.05519968,-0.00976004,0.00107857
            b1,b2,b3,b4    = 8.5733287401,18.0590169730,8.6347608925,0.2677737343
            c1,c2,c3,c4    = 9.5733223454,25.6329561486,21.0996530827,3.9584969228
            ex = math.exp(-u)
            return (a0+u*(a1+u*(a2+u*(a3+u*a4))))*(-math.log(u)) + \
                   ex*(b1+u*(b2+u*(b3+u*b4)))/(c1+u*(c2+u*(c3+u*c4)))
        except: return None

    # ─ Palettes ─
    GREEN_COLORS = ["#1A5C0E","#2E8C1C","#4AAA2E","#6BBF42","#90D060","#B8E890"]
    RED_COLORS   = ["#5C0000","#8B1010","#B02020","#C84040","#D96868","#E89898"]

    # ─ Graphique 1 : Q=f(T) pour 6 rabattements ─
    T_range = np.logspace(-5, -1, 80)
    s_vals  = [1.0, 2.0, s_, 4.0, 5.0, 6.0]
    s_labels = ["s = 1,0 m","s = 2,0 m",
                f"s = {s_:.1f} m  \u25c0 projet",
                "s = 4,0 m","s = 5,0 m","s = 6,0 m"]

    # ─ Graphique 2 : Profondeur=f(distance) pour 6 T ─
    T_fixed  = [0.0001, 0.0005, 0.001, 0.002, 0.005, 0.01]
    T_labels = ["T = 10\u207b\u2074 m\u00b2/s", "T = 5\u00d710\u207b\u2074 m\u00b2/s",
                "T = 10\u207b\u00b3 m\u00b2/s",  "T = 2\u00d710\u207b\u00b3 m\u00b2/s",
                "T = 5\u00d710\u207b\u00b3 m\u00b2/s","T = 10\u207b\u00b2 m\u00b2/s"]
    dist_arr = np.linspace(r, 20.0, 200)

    def _make_g1():
        fig, ax = plt.subplots(figsize=(9, 6.5))
        fig.patch.set_facecolor("#FFFFFF")
        ax.set_facecolor("#FAF9F6")
        for s_v, color, label in zip(s_vals, GREEN_COLORS, s_labels):
            Q = np.array([
                (lambda Wu: max(0.0,4*math.pi*Tx*s_v/Wu*3600) if Wu and Wu>0 else 0.0)(
                    _Wu((r**2*S_v)/(4*Tx*t_s)))
                for Tx in T_range
            ])
            lw = 2.5 if "projet" in label else 1.8
            ax.plot(T_range, Q, color=color, lw=lw, label=label, zorder=3)
            ax.annotate(f"{Q[-1]:.0f} m\u00b3/h",
                        xy=(T_range[-1], Q[-1]), xytext=(6,0),
                        textcoords="offset points", fontsize=8, color=color,
                        fontweight="bold", va="center",
                        bbox=dict(boxstyle="round,pad=0.2", fc="white",
                                  ec=color, alpha=0.9, lw=0.8))
        ax.axvline(T_proj, color="#A04000", lw=1.5, ls=":", alpha=0.85,
                   label=f"T projet = {T_proj:.4f} m\u00b2/s", zorder=4)
        ax.set_xscale("log")
        ax.set_xlim(5e-6, 0.15)
        ax.set_ylim(bottom=0)
        ax.set_xlabel("Transmissivit\u00e9 T (m\u00b2/s)", fontsize=10, labelpad=6)
        ax.set_ylabel("D\u00e9bit requis (m\u00b3/h)", fontsize=10, labelpad=6)
        ax.set_title(
            "Sensibilit\u00e9 du d\u00e9bit \u00e0 la transmissivit\u00e9\n"
            f"r\u202f=\u202f{r}\u202fm  \u2022  R\u202f=\u202f{R:.0f}\u202fm"
            f"  \u2022  t\u202f=\u202f{t_h:.0f}\u202fh  \u2022  S\u202f=\u202f{S_v}",
            fontsize=10, color="#1B474D", fontweight="bold", pad=10)
        ax.legend(fontsize=8.5, loc="upper left", framealpha=0.95,
                  edgecolor="#CCCCCC", fancybox=False)
        for sp in ["top","right"]: ax.spines[sp].set_visible(False)
        for sp in ["left","bottom"]: ax.spines[sp].set_color("#CCCCCC")
        ax.grid(color="#E0E0DC", lw=0.6, alpha=0.9, which="both")
        ax.tick_params(labelsize=9)
        plt.tight_layout(pad=1.5)
        return fig

    def _make_g2():
        fig, ax = plt.subplots(figsize=(9, 6.5))
        fig.patch.set_facecolor("#FFFFFF")
        ax.set_facecolor("#FFF8F8")
        end_pts = []
        for T_f, color, label in zip(T_fixed, RED_COLORS, T_labels):
            u_p  = (r**2*S_v)/(4*T_f*t_s)
            Wu_p = _Wu(u_p)
            if not Wu_p or Wu_p <= 0: continue
            Q_s  = 4*math.pi*T_f*s_/Wu_p
            profs = []
            for d in dist_arr:
                u_d  = (d**2*S_v)/(4*T_f*t_s)
                Wu_d = _Wu(u_d)
                if Wu_d and Wu_d > 0:
                    profs.append(NS + Q_s*Wu_d/(4*math.pi*T_f))
                else:
                    profs.append(NS)
            profs = np.array(profs)
            ax.plot(dist_arr, profs, color=color, lw=1.8, label=label, zorder=3)
            end_pts.append((profs[-1], color))
        # Étiquettes espacées
        end_pts.sort(key=lambda x: x[0])
        min_gap = 0.15; prev_y = -999.0
        for (yv, col) in end_pts:
            y_adj = max(yv, prev_y + min_gap)
            ax.annotate(f"{yv:.2f} m",
                        xy=(dist_arr[-1], yv), xytext=(6,0),
                        textcoords="offset points", fontsize=8, color=col,
                        fontweight="bold", va="center",
                        bbox=dict(boxstyle="round,pad=0.2", fc="white",
                                  ec=col, alpha=0.9, lw=0.7))
            prev_y = y_adj
        ax.axhline(NS, color="#2A7AAA", lw=1.3, ls=(0,(6,4)), alpha=0.85,
                   label=f"Niveau statique NS = {NS} m/TN", zorder=2)
        ax.axhline(FF, color="#C87800", lw=1.3, ls=(0,(6,4)), alpha=0.85,
                   label=f"Fond de fouille FF = {FF} m/TN", zorder=2)
        ax.set_xlim(0, 21.5)
        ax.set_ylim(0, 9)
        ax.set_xlabel("Distance au puits (m)", fontsize=10, labelpad=6)
        ax.set_ylabel("Profondeur nappe (m/TN)", fontsize=10, labelpad=6)
        ax.set_title(
            "Profondeur de la nappe en fonction de la distance\n"
            f"NS\u202f=\u202f{NS}\u202fm/TN  \u2022  FF\u202f=\u202f{FF}\u202fm/TN"
            f"  \u2022  s\u202f=\u202f{s_:.1f}\u202fm  \u2022  t\u202f=\u202f{t_h:.0f}\u202fh",
            fontsize=10, color="#6B1A1A", fontweight="bold", pad=10)
        ax.legend(fontsize=8.5, loc="lower right", framealpha=0.95,
                  edgecolor="#CCCCCC", fancybox=False)
        for sp in ["top","right"]: ax.spines[sp].set_visible(False)
        for sp in ["left","bottom"]: ax.spines[sp].set_color("#CCCCCC")
        ax.grid(color="#F0E0E0", lw=0.6, alpha=0.9)
        ax.tick_params(labelsize=9)
        plt.tight_layout(pad=1.5)
        return fig

    tmp_dir = tempfile.gettempdir()
    tmp_g1  = os.path.join(tmp_dir, "gmep_sens_g1.png")
    tmp_g2  = os.path.join(tmp_dir, "gmep_sens_g2.png")

    try:
        fig1 = _make_g1()
        fig1.savefig(tmp_g1, dpi=150, bbox_inches="tight", facecolor="white")
        plt.close(fig1)
    except Exception as e:
        print(f"[build_sensibilite] Erreur graphique 1 : {e}")
        tmp_g1 = None

    try:
        fig2 = _make_g2()
        fig2.savefig(tmp_g2, dpi=150, bbox_inches="tight", facecolor="white")
        plt.close(fig2)
    except Exception as e:
        print(f"[build_sensibilite] Erreur graphique 2 : {e}")
        tmp_g2 = None

    # ─ Insérer les deux images dans le PDF ─
    from PIL import Image as PILImage

    def _insert_img(path, label):
        if not path or not os.path.exists(path):
            return
        img_w = 17 * cm
        with PILImage.open(path) as im:
            px_w, px_h = im.size
        img_h = img_w * (px_h / px_w)
        story.append(Paragraph(label, s["body_bold"]))
        story.append(Spacer(1, 0.2*cm))
        story.append(RLImage(path, width=img_w, height=img_h))
        story.append(Spacer(1, 0.5*cm))

    _insert_img(tmp_g1, "Graphique 1 — Sensibilité du débit à la transmissivité")
    _insert_img(tmp_g2, "Graphique 2 — Profondeur de la nappe en fonction de la distance au puits")

    # ─ Tableau de synthèse des substrats comparables ─
    story.append(subsection_header("Tableau de synthèse — substrats comparables", s))
    story.append(Spacer(1, 0.2*cm))

    GEO_SENS = [
        ("Argile compacte",          "Argile",    1e-10,  1e-5),
        ("Argile sableuse",          "Argile",    2e-8,   1e-5),
        ("Marne argileuse",          "Argile",    8e-9,   1e-5),
        ("Marne calcaire",           "Marne",     3e-7,   1e-5),
        ("Marno-calcaire fissuré",   "Marne",     3e-5,   1e-4),
        ("Limon éolien (lœss)",      "Limon",     1e-6,   1e-4),
        ("Limon alluvial",           "Limon",     2.5e-6, 1e-4),
        ("Sable fin argileux",       "Sable fin", 1e-5,   1e-4),
        ("Sable fin quaternaire",    "Sable fin", 7.5e-5, 5e-4),
        ("Sable fin à moyen",        "Sable fin", 1.5e-4, 5e-4),
        ("Sable moyen propre",       "Sable moy.",1e-3,   1e-3),
        ("Sable grossier propre",    "Sable gros.",2e-3,  1e-3),
        ("Sable grossier argileux",  "Sable gros.",9e-4,  1e-3),
        ("Gravier sableux",          "Gravier",   1.5e-2, 1e-2),
        ("Gravier propre",           "Gravier",   1.2e-1, 1e-2),
        ("Alluvions grossières",     "Gravier",   1e-1,   1e-2),
        ("Gravier argileux",         "Gravier",   1e-3,   1e-2),
        ("Calcaire compact fissuré", "Calcaire",  3e-5,   1e-4),
        ("Calcaire karstifié",       "Calcaire",  5e-2,   1e-2),
        ("Craie",                    "Calcaire",  5e-5,   1e-4),
        ("Tuffeau (Val de Loire)",   "Calcaire",  1.5e-4, 5e-4),
        ("Calcaire gréseux",         "Calcaire",  2.5e-4, 5e-4),
        ("Grès fin consolidé",       "Grès",      3e-6,   1e-4),
        ("Grès poreux peu consolidé","Grès",      2.5e-4, 5e-4),
        ("Grès argileux",            "Grès",      2e-7,   1e-4),
        ("Arène granitique",         "Altérite",  1.5e-4, 5e-4),
        ("Altérite de schiste",      "Altérite",  5e-6,   1e-4),
        ("Granite fissuré",          "Socle",     2e-6,   1e-5),
        ("Basalte fissuré",          "Socle",     1.5e-5, 1e-4),
        ("Remblai hétérogène",       "Remblai",   3e-5,   1e-4),
        ("Grave de route / concassé","Remblai",   2e-3,   1e-3),
        # ── v15.78 : Pack France entier ──
        ("Marnes à meulières",       "Marne",     1e-5,   1e-5),
        ("Calcaire de Beauce",       "Calcaire",  1.5e-2, 1e-3),
        ("Calcaire de Saint-Ouen",   "Calcaire",  3e-4,   5e-4),
        ("Calcaire grossier du Lutétien","Calcaire",1.5e-3, 5e-4),
        ("Sables de Fontainebleau",  "Sable moy.",1.5e-2, 1e-3),
        ("Sables du Sparnacien",     "Sable fin", 2e-4,   5e-4),
        ("Argile à silex",           "Argile",    3e-7,   1e-5),
        ("Schistes altérés",         "Altérite",  2e-5,   1e-4),
        ("Conglomérat (poudingue)",  "Grès",      1e-4,   5e-4),
        ("Molasse miocène",          "Grès",      1.5e-3, 5e-4),
        ("Calcaire urgonien",        "Calcaire",  1.5e-1, 1e-2),
    ]

    substrat_sel = data.get("substrat", "").lower().strip()
    T_sel = data.get("T_num", 0.0032)

    Q_theis_vals, Q_dupuit_vals = [], []
    for nom, fam, T, S in GEO_SENS:
        try:
            u   = (r**2*S)/(4*T*t_s)
            Wu  = _Wu(u)
            qt  = max(0, 4*math.pi*T*s_/Wu*3600) if Wu and Wu>0 else 0
        except: qt = 0
        try:
            qd  = max(0, 2*math.pi*T*s_/math.log(R/r)*3600)
        except: qd = 0
        Q_theis_vals.append(qt)
        Q_dupuit_vals.append(qd)

    idx_close = sorted(range(len(GEO_SENS)),
                       key=lambda i: abs(math.log10(max(GEO_SENS[i][2],1e-12)) -
                                         math.log10(max(T_sel, 1e-12))))
    sel_idx = next((i for i,g in enumerate(GEO_SENS)
                    if g[0].lower().strip() == substrat_sel), None)
    shown = []
    if sel_idx is not None: shown.append(sel_idx)
    for i in idx_close:
        if i not in shown: shown.append(i)
        if len(shown) >= 8: break

    hdr = ["Substrat","Famille","T (m²/s)","Q Theis (m³/h)","Q Dupuit (m³/h)","Statut IOTA"]
    tbl_data = [hdr]
    for i in shown:
        nom,fam,T,S = GEO_SENS[i]
        qt = Q_theis_vals[i]; qd = Q_dupuit_vals[i]
        vol_an = qt*24*365
        statut = "Exonéré" if vol_an<10000 else ("Déclaration" if vol_an<200000 else "Autorisation")
        is_sel = nom.lower().strip() == substrat_sel
        row = [
            Paragraph(f"<b>{nom}</b>" if is_sel else nom, s["small"]),
            Paragraph(fam, s["small"]),
            Paragraph(f"{T:.2e}", s["small"]),
            Paragraph(f"<b>{qt:.2f}</b>" if is_sel else f"{qt:.2f}", s["small"]),
            Paragraph(f"<b>{qd:.2f}</b>" if is_sel else f"{qd:.2f}", s["small"]),
            Paragraph(f"<b>{statut}</b>" if is_sel else statut, s["small"]),
        ]
        tbl_data.append(row)

    col_w = [5.5*cm,2.5*cm,2.5*cm,2.5*cm,2.8*cm,2.7*cm]
    tbl = Table(tbl_data, colWidths=col_w, repeatRows=1)
    style_tbl = TableStyle([
        ("BACKGROUND",    (0,0),(-1,0), C_TEAL_DARK),
        ("TEXTCOLOR",     (0,0),(-1,0), C_WHITE),
        ("FONTNAME",      (0,0),(-1,0), FONT_BOLD),
        ("FONTSIZE",      (0,0),(-1,-1),8),
        ("ALIGN",         (0,0),(-1,0), "CENTER"),
        ("ALIGN",         (2,1),(-1,-1),"CENTER"),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0),(-1,-1),0.3, C_GREY_MED),
        ("BOX",           (0,0),(-1,-1),0.8, C_TEAL_DARK),
        ("TOPPADDING",    (0,0),(-1,-1),5),
        ("BOTTOMPADDING", (0,0),(-1,-1),5),
        ("LEFTPADDING",   (0,0),(-1,-1),5),
    ])
    for ri,i in enumerate(shown,start=1):
        if GEO_SENS[i][0].lower().strip()==substrat_sel:
            style_tbl.add("BACKGROUND",(0,ri),(-1,ri),HexColor("#FFF3E0"))
            style_tbl.add("TEXTCOLOR", (0,ri),(-1,ri),HexColor("#C8641A"))
    tbl.setStyle(style_tbl)
    story.append(tbl)
    story.append(Spacer(1, 0.4*cm))
    story.append(PageBreak())



# ─────────────────────────────────────────────
# 4.4 TOPOGRAPHIE & FORMATIONS LENTICULAIRES (IPL)
# ─────────────────────────────────────────────
def build_topographie_lenticulaire(story, data, s):
    """Section 4.4 — évaluation des pièges hydrogéologiques lenticulaires
    par signature topographique (TPI/TWI) + lithologie BDLISA + densité piézo."""
    import openpyxl
    xlsx_path = "/home/user/workspace/rabattement_logiciel/Modelisation_Rabattement_TSN_GMEP.xlsx"
    try:
        wb = openpyxl.load_workbook(xlsx_path, data_only=True)
        topo = wb["Topographie & Lenticulaire"]
        tpi_300  = topo["C28"].value
        tpi_1000 = topo["C29"].value
        tpi_2000 = topo["C30"].value
        slope    = topo["C31"].value
        twi      = topo["C33"].value
        n_aqu    = topo["C34"].value
        n_lith   = topo["C35"].value
        litho_e  = topo["E35"].value
        n_piezo  = topo["C36"].value
        ipl      = topo["C42"].value
        diag     = topo["E42"].value
        v_lent   = topo["C49"].value
        f_c      = topo["C50"].value
        q_lent_h = topo["C51"].value
        z_center = topo["C8"].value
        z1000_str= topo["C22"].value
        z2000_str= topo["C24"].value
    except Exception:
        return  # Pas de données topo → on n'ajoute pas la section

    story.append(section_header("4.4. TOPOGRAPHIE & FORMATIONS LENTICULAIRES (IPL)", s))
    story.append(Spacer(1, 0.3*cm))

    intro = (
        "Au-delà de la nappe principale identifiée par BDLISA, le profil topographique "
        "local peut révéler la présence de <b>formations lenticulaires</b> — alluvions, "
        "colluvions, saprolites, limons fluviatiles — dans lesquelles s'accumulent "
        "localement les eaux de surface, au même titre qu'une zone karstique souterraine. "
        "L'évaluation conduite ici croise trois sources :"
        "<br/>— l'<b>indice de position topographique (TPI)</b> calculé sur trois voisinages "
        "(300 m, 1 000 m, 2 000 m) à partir des altitudes IGN BDAlti (résolution 5 m) ;"
        "<br/>— le <b>Topographic Wetness Index</b> (Beven & Kirkby, 1979) évaluant la "
        "capacité du terrain à accumuler l'eau de ruissellement ;"
        "<br/>— la <b>lithologie superficielle BDLISA</b> et la densité de stations "
        "piézométriques nationales (Hub'Eau)."
    )
    story.append(Paragraph(intro, s["body"]))
    story.append(Spacer(1, 0.4*cm))

    def fmt(v, n=2, sign=True):
        try:
            f = float(v)
            return (f"{f:+.{n}f}" if sign else f"{f:.{n}f}")
        except (TypeError, ValueError):
            return str(v) if v is not None else "—"

    rows_indi = [
        ["Indicateur", "Valeur", "Interprétation"],
        ["Altitude tête puits (IGN)",
         f"{fmt(z_center, 2, sign=False)} m NGF",
         "Vérifiée par API IGN BDAlti"],
        ["Altitudes voisines 1 000 m",
         str(z1000_str)[:30],
         "Min / Moy / Max — couronne 8 azimuts"],
        ["Altitudes voisines 2 000 m",
         str(z2000_str)[:30],
         "Min / Moy / Max — couronne 8 azimuts"],
        ["TPI 300 m",
         f"{fmt(tpi_300)} m",
         "Position locale immédiate vs 8 voisins"],
        ["TPI 1 000 m",
         f"{fmt(tpi_1000)} m",
         ("Cuvette / talweg — accumulation marquée" if (tpi_1000 is not None and tpi_1000 <= -1)
          else "Position intermédiaire ou crête")],
        ["TPI 2 000 m",
         f"{fmt(tpi_2000)} m",
         "Bassin versant local élargi"],
        ["Pente moyenne",
         f"{fmt(slope, 2, sign=False)} °",
         "Pente Horn-like sur grille 3×3"],
        ["TWI = ln(SCA / tan β)",
         f"{fmt(twi, 2, sign=False)}",
         ("Forte tendance à accumulation d'eau" if (twi is not None and twi >= 8)
          else "Drainage rapide ou modéré")],
        ["Aquifères BDLISA présents au point",
         f"{n_aqu}",
         "Compté sur emprise nationale"],
        ["Lithologies lenticulaires (toit ≤ 30 m)",
         f"{n_lith}",
         (str(litho_e) if (n_lith and n_lith >= 1)
          else "Aucune formation meuble superficielle proche")],
        ["Stations piézo Hub'Eau (≤ 5 km)",
         f"{n_piezo}",
         "Densité = preuve indirecte d'aquifère exploité"],
    ]
    tbl = Table(
        [[Paragraph(c, s["small"]) for c in row] for row in rows_indi],
        colWidths=[6.2*cm, 4.4*cm, 7.4*cm],
    )
    tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,0), C_BLUE_DARK),
        ("TEXTCOLOR",    (0,0), (-1,0), C_WHITE),
        ("FONTNAME",     (0,0), (-1,-1), FONT_BODY),
        ("FONTSIZE",     (0,0), (-1,-1), 9),
        ("ALIGN",        (0,0), (-1,0), "CENTER"),
        ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
        ("GRID",         (0,0), (-1,-1), 0.4, C_GREY_MED),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_WHITE, C_GREY_LIGHT]),
        ("LEFTPADDING",  (0,0), (-1,-1), 5),
        ("RIGHTPADDING", (0,0), (-1,-1), 5),
        ("TOPPADDING",   (0,0), (-1,-1), 4),
        ("BOTTOMPADDING",(0,0), (-1,-1), 4),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 0.4*cm))

    if ipl is None:
        ipl = 0
    if ipl >= 2:
        bg = colors.HexColor("#C6EFCE")
        fg = colors.HexColor("#0E5A1A")
        label = f"IPL = {ipl}/3 — PRÉSOMPTION FORTE de pièges lenticulaires"
    elif ipl == 1:
        bg = colors.HexColor("#FFEB9C")
        fg = colors.HexColor("#7A5B00")
        label = f"IPL = {ipl}/3 — Présomption modérée"
    else:
        bg = colors.HexColor("#FFC7CE")
        fg = colors.HexColor("#8B0000")
        label = f"IPL = {ipl}/3 — Pas de signature lenticulaire détectée"

    box = Table(
        [[Paragraph(f"<b>{label}</b><br/>{diag or ''}", s["body"])]],
        colWidths=[18*cm],
    )
    box.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), bg),
        ("TEXTCOLOR",    (0,0), (-1,-1), fg),
        ("BOX",          (0,0), (-1,-1), 1.0, fg),
        ("LEFTPADDING",  (0,0), (-1,-1), 10),
        ("RIGHTPADDING", (0,0), (-1,-1), 10),
        ("TOPPADDING",   (0,0), (-1,-1), 8),
        ("BOTTOMPADDING",(0,0), (-1,-1), 8),
    ]))
    story.append(box)
    story.append(Spacer(1, 0.4*cm))

    # Effet sur les calculs : f_C et Q_lent_durable
    try:
        f_c_str = f"{float(f_c):.3f}"
        f_c_pct = f"+{(float(f_c)-1)*100:.0f}%"
    except (TypeError, ValueError):
        f_c_str = "—"
        f_c_pct = ""
    try:
        q_lent_str = f"{float(q_lent_h):.2f}"
        q_lent_j = f"{float(q_lent_h)*24:,.0f}".replace(",", " ")
    except (TypeError, ValueError):
        q_lent_str = "—"
        q_lent_j = "—"
    try:
        v_lent_str = f"{float(v_lent):,.0f}".replace(",", " ")
    except (TypeError, ValueError):
        v_lent_str = "—"

    impact = (
        "<b>Effets sur les calculs hydrogéologiques :</b>"
        "<br/>— <b>Facteur de concentration topographique f<sub>C</sub> = "
        f"{f_c_str}</b> ({f_c_pct}) — appliqué multiplicativement à Q<sub>cycle</sub>. "
        "Une cuvette lenticulaire concentre la recharge sur le puits, ce qui augmente "
        "le débit pompable à rabattement constant (calibration BRGM vallons sédimentaires)."
        f"<br/>— <b>Débit cuvette durable Q<sub>lent</sub> = {q_lent_str} m³/h "
        f"({q_lent_j} m³/j)</b> — débit moyen permanent fourni par la recharge pluviométrique "
        "sur la surface lenticulaire (S × R / 8 760 h). Quand l'aquifère principal est "
        "insuffisant, ce débit remplace le plancher chantier 5 m³/j."
        f"<br/>— <b>Volume mobilisable supplémentaire V<sub>lent</sub> = {v_lent_str} m³/an</b> "
        "(stock initial S×ép×n + recharge S×R) — utilisable comme réserve d'appoint."
    )
    story.append(Paragraph(impact, s["body"]))
    story.append(Spacer(1, 0.3*cm))

    # Cohérence dimensionnement pompe ↔ plancher cuvette lenticulaire
    coherence = (
        "<b>Cohérence dimensionnement pompe ↔ volume journalier (cas IPL ≥ 2) :</b> "
        "lorsque le régime <i>plancher cuvette lenticulaire</i> est actif (aquifère "
        "principal peu transmissif mais cuvette détectée), le débit de pompe "
        "recommandé est aligné sur la ressource cuvette pour rester cohérent avec "
        "le volume journalier exploitable :"
        "<br/>&nbsp;&nbsp;&nbsp;&nbsp;<b>Q<sub>pompe</sub> = MAX(Q<sub>aquifère corrigé</sub> ; Q<sub>lent durable</sub>)</b>"
        "<br/>Ainsi, sur un substrat à faible perméabilité (limon, argile) avec IPL = 3, "
        "le débit de pompe affiché reflète la ressource cuvette réellement exploitable "
        f"(ici {q_lent_str} m³/h), et le volume journalier (Q<sub>pompe</sub> × 24 h) "
        f"correspond au plancher cuvette ({q_lent_j} m³/j). La fourchette de "
        "dimensionnement ±15 % est calculée sur cette base — sans plus jamais afficher "
        "un débit nul face à un volume journalier non nul."
    )
    story.append(Paragraph(coherence, s["body"]))
    story.append(Spacer(1, 0.3*cm))

    note = (
        "<i>Références méthodologiques : Weiss A. (2001) pour le TPI — "
        "Beven K. & Kirkby M.J. (1979) pour le TWI — IGN BDAlti / RGE Alti via "
        "l'API Géoplateforme — BDLISA RP-67489-FR (BRGM/Eaufrance) — "
        "Hub'Eau Piézométrie nationale.</i>"
    )
    story.append(Paragraph(note, s["small"]))
    story.append(PageBreak())


# ─────────────────────────────────────────────
# 5. VÉRIFICATION IOTA
# ─────────────────────────────────────────────
def build_iota(story, data, s):
    """Section 5 — Nomenclature IOTA : 1.1.1.0, 1.1.2.0, 1.3.1.0 (ZRE),
    rejet exhaure (2.x.x.0) et masse d'eau souterraine SANDRE FRGG092."""
    story.append(section_header("5. VÉRIFICATION RÉGLEMENTAIRE — NOMENCLATURE IOTA", s))
    story.append(Spacer(1, 0.3*cm))

    texte_iota = (
        "La nomenclature IOTA (Installations, Ouvrages, Travaux et Activités) définie à "
        "l'article R.214-1 du Code de l'Environnement fixe les seuils de déclaration et "
        "d'autorisation pour les prélèvements d'eaux souterraines, ainsi que pour les "
        "rejets associés. Le présent rabattement de nappe relève simultanément de plusieurs "
        "rubriques, examinées ci-après."
    )
    story.append(Paragraph(texte_iota, s["body"]))
    story.append(Spacer(1, 0.4*cm))

    # Variables
    vol_an_str = data["vol_an"]
    vol_an_val = data.get("vol_an_float", 0.0)
    statut     = data["statut_iota"]
    autorisation_1120 = vol_an_val >= 200000
    declaration_1120  = vol_an_val >= 10000
    couleur_statut    = C_RED if autorisation_1120 else C_GREEN_DARK

    # ───────── 5.1 — Rubrique 1.1.1.0 (sans seuil, ouvrage > 10 m) ─────────
    story.append(subsection_header("5.1  Rubrique 1.1.1.0 — Sondage, forage, puits ou ouvrage souterrain", s))
    story.append(Paragraph(
        "<b>Intitulé réglementaire (R.214-1) :</b> sondages, forages, y compris les essais de "
        "pompage, création de puits ou d'ouvrage souterrain non destiné à un usage domestique, "
        "exécutés en vue de la recherche ou de la surveillance d'eaux souterraines ou en vue "
        "d'effectuer un prélèvement temporaire ou permanent dans les eaux souterraines, y "
        "compris dans les nappes d'accompagnement de cours d'eau (D.).",
        s["body"]
    ))
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph(
        "<b>Caractéristique :</b> rubrique sans seuil de volume — toute création d'ouvrage de "
        "prélèvement (puits, forage, piézomètre exploité) est soumise à <b>déclaration</b> dès "
        "lors qu'elle n'est pas à usage domestique au sens de l'article R.214-5.",
        s["body"]
    ))
    story.append(Spacer(1, 0.2*cm))
    story.append(result_table(
        ["Régime", "Condition", "Seuil"],
        [["Déclaration (D)", "Tout ouvrage non domestique", "Sans seuil"]],
        s,
        col_widths=[5*cm, 9*cm, 3*cm]
    ))
    story.append(Spacer(1, 0.2*cm))
    msg_1110 = (
        "[OK]  Les ouvrages de rabattement (puits, pointes filtrantes ou tranchées drainantes) "
        "projetés relèvent de la <b>rubrique 1.1.1.0 — DÉCLARATION</b>, indépendamment du volume."
    )
    msg_1110_tbl = Table([[Paragraph(msg_1110, s["iota_ok"])]], colWidths=[17*cm])
    msg_1110_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), HexColor("#E8F4E8")),
        ("BOX",          (0,0), (-1,-1), 1.2, C_GREEN_DARK),
        ("LEFTPADDING",  (0,0), (-1,-1), 12),
        ("RIGHTPADDING", (0,0), (-1,-1), 12),
        ("TOPPADDING",   (0,0), (-1,-1), 8),
        ("BOTTOMPADDING",(0,0), (-1,-1), 8),
    ]))
    story.append(msg_1110_tbl)
    story.append(Spacer(1, 0.5*cm))

    # ───────── 5.2 — Rubrique 1.1.2.0 (volume annuel) ─────────
    story.append(subsection_header("5.2  Rubrique 1.1.2.0 — Prélèvements permanents ou temporaires", s))
    story.append(Paragraph(
        "<b>Intitulé réglementaire (R.214-1) :</b> prélèvements permanents ou temporaires issus "
        "d'un forage, puits ou ouvrage souterrain dans un système aquifère, à l'exclusion de "
        "nappes d'accompagnement de cours d'eau, par pompage, drainage, dérivation ou tout "
        "autre procédé. Le volume total prélevé étant :",
        s["body"]
    ))
    story.append(Spacer(1, 0.2*cm))
    story.append(result_table(
        ["Régime", "Condition", "Seuil annuel"],
        [
            ["Autorisation (A)", "Volume annuel prélevé", "≥ 200 000 m³/an"],
            ["Déclaration (D)",  "Volume annuel prélevé", "≥ 10 000 et < 200 000 m³/an"],
            ["Hors nomenclature", "Volume annuel prélevé", "< 10 000 m³/an"],
        ],
        s,
        col_widths=[5*cm, 6*cm, 6*cm]
    ))
    story.append(Spacer(1, 0.3*cm))

    # Détail du calcul du volume annuel
    story.append(Paragraph("<b>Calcul du volume annuel prévisionnel</b>", s["body_bold"]))
    q_theis   = data.get("Q_theis", "—")
    q_cycle   = data.get("Q_cycle", "—")
    t_exploit = data.get("t_exploit_str", "—")
    vol_jour  = data.get("vol_jour", "—")
    vol_mois  = data.get("vol_mois", "—")
    calcul_data = [
        ["Débit pompé Q (Theis, corrigé η)", f"{q_theis} m³/h"],
        ["Débit moyen exploitable Q_cycle",  f"{q_cycle} m³/h"],
        ["Durée d'exploitation journalière", f"{t_exploit}"],
        ["Volume journalier Vj = Q_cycle × t_exploit", f"{vol_jour} m³/j"],
        ["Volume mensuel (30 j)",            f"{vol_mois} m³/mois"],
        ["Volume annuel V = Vj × 365 j",     f"{vol_an_str} m³/an"],
    ]
    c_data = [[Paragraph(f"<b>{k}</b>", ParagraphStyle("ck",
                    fontName=FONT_BOLD, fontSize=9.5, textColor=C_TEAL_DARK, leading=13)),
               Paragraph(str(v), ParagraphStyle("cv",
                    fontName=FONT_BODY, fontSize=10, leading=13))]
              for k, v in calcul_data]
    c_tbl = Table(c_data, colWidths=[8*cm, 9*cm])
    c_tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 10),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.0, C_TEAL_DARK),
        ("BACKGROUND",    (0,5), (-1,5), HexColor("#FFF4E5")),
    ]))
    story.append(c_tbl)
    story.append(Spacer(1, 0.3*cm))

    # Comparaison aux seuils
    cmp_10000 = "≥ 10 000 m³/an"   if declaration_1120 else "< 10 000 m³/an"
    cmp_200000 = "≥ 200 000 m³/an" if autorisation_1120 else "< 200 000 m³/an"
    cmp_data = [
        ["Volume annuel calculé", f"{vol_an_str} m³/an"],
        ["Comparaison seuil déclaration (10 000 m³/an)", cmp_10000],
        ["Comparaison seuil autorisation (200 000 m³/an)", cmp_200000],
        ["Statut réglementaire 1.1.2.0", statut],
    ]
    cmp_para = [[Paragraph(f"<b>{k}</b>", ParagraphStyle("vk",
                    fontName=FONT_BOLD, fontSize=9.5, textColor=C_TEAL_DARK, leading=13)),
               Paragraph(str(v), ParagraphStyle("vv",
                    fontName=FONT_BOLD, fontSize=10, leading=13,
                    textColor=couleur_statut if k.startswith("Statut") else C_BLACK))]
              for k, v in cmp_data]
    cmp_tbl = Table(cmp_para, colWidths=[8*cm, 9*cm])
    cmp_tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 10),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.0, C_TEAL_DARK),
        ("BACKGROUND",    (0,3), (-1,3), HexColor("#FFEEEE") if autorisation_1120 else HexColor("#E8F4E8")),
    ]))
    # cmp_tbl et msg_1120_tbl seront groupés ensemble en bas
    if autorisation_1120:
        msg_1120 = (
            "[!]  Le volume annuel prévu dépasse le seuil de 200 000 m³/an. "
            "Le projet est soumis à <b>AUTORISATION</b> au titre de la rubrique 1.1.2.0 "
            "(procédure R.181-13 — autorisation environnementale)."
        )
        style_msg_1120 = s["iota_alert"]
        bg_1120, brd_1120 = HexColor("#FFEEEE"), C_RED
    elif declaration_1120:
        msg_1120 = (
            "[OK]  Le volume annuel prévu (" + vol_an_str + " m³/an) est compris entre 10 000 et "
            "200 000 m³/an. Le projet est soumis à <b>DÉCLARATION</b> au titre de la rubrique "
            "1.1.2.0, cumulée à la déclaration au titre de la rubrique 1.1.1.0."
        )
        style_msg_1120 = s["iota_ok"]
        bg_1120, brd_1120 = HexColor("#E8F4E8"), C_GREEN_DARK
    else:
        msg_1120 = (
            "[OK]  Le volume annuel prévu est inférieur au seuil de déclaration de 10 000 m³/an. "
            "La rubrique 1.1.2.0 n'est <b>pas applicable</b>. Seule la rubrique 1.1.1.0 "
            "(création d'ouvrage) reste à déclarer."
        )
        style_msg_1120 = s["iota_ok"]
        bg_1120, brd_1120 = HexColor("#E8F4E8"), C_GREEN_DARK

    msg_1120_tbl = Table([[Paragraph(msg_1120, style_msg_1120)]], colWidths=[17*cm])
    msg_1120_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), bg_1120),
        ("BOX",          (0,0), (-1,-1), 1.5, brd_1120),
        ("LEFTPADDING",  (0,0), (-1,-1), 12),
        ("RIGHTPADDING", (0,0), (-1,-1), 12),
        ("TOPPADDING",   (0,0), (-1,-1), 10),
        ("BOTTOMPADDING",(0,0), (-1,-1), 10),
    ]))
    # Groupage : tableau de comparaison + message conclusion (évite coupure)
    story.append(KeepTogether([cmp_tbl, Spacer(1, 0.3*cm), msg_1120_tbl]))
    story.append(Spacer(1, 0.5*cm))

    # ───────── 5.3 — Rubrique 1.3.1.0 (ZRE) ─────────
    story.append(PageBreak())
    story.append(subsection_header("5.3  Rubrique 1.3.1.0 — Zone de Répartition des Eaux (ZRE)", s))
    story.append(Paragraph(
        "<b>Intitulé réglementaire :</b> à l'exception des prélèvements faisant l'objet d'une "
        "convention avec l'attributaire d'un débit affecté, prélèvements et installations et "
        "ouvrages permettant le prélèvement, y compris par dérivation, dans un cours d'eau, dans "
        "sa nappe d'accompagnement ou dans un plan d'eau ou canal alimenté par ce cours d'eau "
        "ou cette nappe, dans une zone où des mesures permanentes de répartition quantitative "
        "ont été instituées (ZRE) :",
        s["body"]
    ))
    story.append(Spacer(1, 0.2*cm))
    story.append(result_table(
        ["Régime", "Condition (capacité totale)", "Seuil"],
        [
            ["Autorisation (A)", "Capacité totale maximale", "≥ 8 m³/h"],
            ["Déclaration (D)",  "Capacité totale maximale", "< 8 m³/h"],
        ],
        s,
        col_widths=[5*cm, 7*cm, 5*cm]
    ))
    story.append(Spacer(1, 0.3*cm))

    # Contexte local — résolu automatiquement à partir de X/Y Lambert 93
    _commune = data.get("commune", "—")
    _insee   = data.get("code_insee", "—")
    _dpt     = data.get("departement", "—")
    _zstat   = data.get("zre_statut", "À VÉRIFIER")
    _znappe  = data.get("zre_nappe", "—")
    _zarrete = data.get("zre_arrete", "—")
    _zmaj    = data.get("zre_date_maj", "—")
    _zsource = data.get("zre_source", "—")
    _zcd     = data.get("zre_communes_deleguees", []) or []
    _agence  = data.get("agence_eau", "—")

    if _zstat == "CONFIRMÉ":
        cd_str = (" (communes déléguées : " + ", ".join(_zcd) + ")") if _zcd else ""
        contexte_txt = (
            f"<b>Contexte local — STATUT CONFIRMÉ :</b> la commune de <b>{_commune}</b> "
            f"(département {_dpt}, INSEE {_insee}){cd_str} est "
            f"<b>officiellement classée en Zone de Répartition des Eaux</b> au titre de la "
            f"<b>{_znappe}</b>, par {_zarrete}. Cette inscription est vérifiée dans la liste "
            f"officielle des communes ZRE publiée par l'{_agence} (mise à jour {_zmaj}). "
            f"<b>Source : {_zsource}.</b>"
        )
    elif _zstat.startswith("PRÉSOMPTION"):
        contexte_txt = (
            f"<b>Contexte local — PRÉSOMPTION ZRE :</b> la commune de <b>{_commune}</b> "
            f"(département {_dpt}, INSEE {_insee}) est située dans l'emprise géographique de la "
            f"<b>{_znappe}</b>, susceptible de relever d'un classement en Zone de Répartition des Eaux. "
            f"<b>Vérification à effectuer auprès de la mairie ou de la DDT du département {_dpt}</b> "
            f"pour confirmer le statut ZRE réglementaire ({_agence})."
        )
    else:
        contexte_txt = (
            f"<b>Contexte local — HORS ZRE :</b> la commune de <b>{_commune}</b> "
            f"(département {_dpt}, INSEE {_insee}) n'est pas inscrite sur les listes officielles "
            f"de Zones de Répartition des Eaux. La rubrique 1.3.1.0 ne s'applique pas. "
            f"Le projet relève uniquement des rubriques 1.1.1.0 et 1.1.2.0 "
            f"(seuils volumétriques de droit commun)."
        )
    story.append(Paragraph(contexte_txt, s["body"]))
    story.append(Spacer(1, 0.2*cm))

    # Test ZRE 1.3.1.0 sur le débit POMPE DIMENSIONNANT (Q_pompe = MAX(Q_aquif, Q_lent_durable si IPL≥2))
    # Le seuil 1.3.1.0 ne s'applique QUE si la commune est réellement en ZRE
    q_h_val = safe_float(data.get("Q_pompe_dim", data.get("Q_theis", 0)))
    _zre_actif = data.get("zre_actif", False)
    zre_alert = _zre_actif and (q_h_val >= 8.0)
    # Composante du débit pompe (Theis aquifère vs cuvette lenticulaire)
    q_theis_corr_val = safe_float(data.get("Q_theis_corr", data.get("Q_theis", 0)))
    q_lent_val = safe_float(data.get("Q_lent_durable", 0))
    ipl_val_pdf = data.get("ipl_value", 0)
    if data.get("fouille_hors_eau", False):
        composante = ("Néant — Fond de fouille au-dessus du niveau d'eau, "
                      "aucun pompage gravitaire requis")
    elif ipl_val_pdf >= 2 and q_lent_val > q_theis_corr_val:
        composante = (f"Plancher cuvette lenticulaire (IPL = {ipl_val_pdf}/3) : "
                      f"Q_lent_durable = {q_lent_val:.2f} m³/h "
                      f"&gt; Q_aquif\u00e8re corrig\u00e9 = {q_theis_corr_val:.2f} m³/h")
    else:
        composante = (f"Aquifère principal Theis corrigé η = {q_theis_corr_val:.2f} m³/h "
                      f"(Q_lent_durable référence : {q_lent_val:.2f} m³/h)")

    # Tableau ZRE construit dynamiquement à partir des résultats geo_resolver
    if _zstat == "CONFIRMÉ":
        _classement_lib = f"OUI — CONFIRMÉ ({_znappe}, commune INSEE {_insee})"
    elif _zstat.startswith("PRÉSOMPTION"):
        _classement_lib = f"PRÉSOMPTION ({_znappe}) — vérification mairie/DDT requise"
    else:
        _classement_lib = "NON — commune hors liste ZRE"

    _communes_concernees = (
        f"{_commune}" + (f" (" + ", ".join(_zcd) + ")" if _zcd else "")
    )
    if _zre_actif:
        regime_131_lib = "AUTORISATION (R.181-13)" if zre_alert else "DÉCLARATION (alinéa 2°)"
    else:
        regime_131_lib = "NON APPLICABLE (hors ZRE)"

    zre_data = [
        ["Classement ZRE", _classement_lib],
        ["Source officielle", _zsource],
        ["Arrêté préfectoral fondateur", _zarrete],
        ["Communes concernées", _communes_concernees],
        ["Débit pompe dimensionnant retenu", f"{q_h_val:.2f} m³/h"],
        ["Composante du débit (origine)", composante],
        ["Seuil 1.3.1.0 alinéa 1° (Autorisation en ZRE)", "≥ 8 m³/h"],
        ["Régime applicable au titre 1.3.1.0", regime_131_lib],
    ]
    z_para = [[Paragraph(f"<b>{k}</b>", ParagraphStyle("zk",
                    fontName=FONT_BOLD, fontSize=9.5, textColor=C_TEAL_DARK, leading=13)),
               Paragraph(str(v), ParagraphStyle("zv",
                    fontName=FONT_BOLD, fontSize=10, leading=13,
                    textColor=C_RED if (k.startswith("Régime") and zre_alert) else C_BLACK))]
              for k, v in zre_data]
    z_tbl = Table(z_para, colWidths=[8*cm, 9*cm])
    z_tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 10),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.0, C_TEAL_DARK),
        ("BACKGROUND",    (0,7), (-1,7), HexColor("#FFEEEE") if zre_alert else HexColor("#E8F4E8")),
    ]))
    story.append(z_tbl)
    story.append(Spacer(1, 0.3*cm))

    if data.get("fouille_hors_eau", False):
        msg_zre = (
            f"ℹ  <b>CONCLUSION DÉFINITIVE — HORS NOMENCLATURE :</b> le fond de fouille "
            f"({safe_float(data.get('FF_str'), 0):.2f} m/TN) est situé au-dessus du niveau d'eau "
            f"({safe_float(data.get('NS_str'), 0):.2f} m/TN). Aucun pompage gravitaire n'est requis. "
            "La rubrique 1.3.1.0 ne s'applique pas en l'absence de prélèvement. "
            f"Bien que la commune de {_commune} soit{' en ZRE ' + str(_znappe) if _zre_actif else ' hors ZRE'}, "
            "le projet ne déclenche aucune procédure réglementaire au titre du Code de l'environnement. "
            "Un suivi piézométrique préchantier est recommandé pour anticiper toute remontée saisonnière "
            "susceptible de modifier ce diagnostic."
        )
        style_zre = s["iota_ok"]
        bg_zre, brd_zre = HexColor("#E8F4E8"), C_GREEN_DARK
    elif zre_alert:
        msg_zre = (
            f"[!]  <b>CONCLUSION DÉFINITIVE — ZRE {_znappe.upper()} :</b> le classement ZRE de "
            f"la commune de {_commune} est <b>confirmé</b> (source : {_zsource}, mise à jour "
            f"{_zmaj}). Le débit prévisionnel ({q_h_val:.2f} m³/h) dépasse le seuil de "
            "8 m³/h de la rubrique 1.3.1.0 alinéa 1°. Le projet est en conséquence soumis "
            "à <b>AUTORISATION ENVIRONNEMENTALE (R.181-13)</b>, qui prime sur la procédure "
            "de déclaration des rubriques 1.1.1.0 et 1.1.2.0. Le dossier à déposer auprès "
            f"de la DDT {_dpt} est un <b>dossier UNIQUE d'autorisation environnementale</b> "
            "intégrant l'ensemble des rubriques (1.1.1.0 + 1.1.2.0 + 1.3.1.0 cumulées)."
        )
        style_zre = s["iota_alert"]
        bg_zre, brd_zre = HexColor("#FFEEEE"), C_RED
    elif _zre_actif:
        msg_zre = (
            f"[OK]  <b>CONCLUSION DÉFINITIVE :</b> bien que la commune de {_commune} soit en "
            f"ZRE {_znappe} (statut {_zstat.lower()}), le débit prévisionnel "
            f"({q_h_val:.2f} m³/h) est inférieur au seuil de 8 m³/h de la rubrique 1.3.1.0 "
            "alinéa 1°. Le projet relève donc de la déclaration au titre de l'alinéa 2° de "
            "cette rubrique, cumulable avec les rubriques 1.1.1.0 et 1.1.2.0."
        )
        style_zre = s["iota_ok"]
        bg_zre, brd_zre = HexColor("#E8F4E8"), C_GREEN_DARK
    else:
        msg_zre = (
            f"[OK]  <b>CONCLUSION DÉFINITIVE :</b> la commune de {_commune} (INSEE {_insee}) "
            "<b>n'est pas classée en Zone de Répartition des Eaux</b>. La rubrique 1.3.1.0 "
            "ne s'applique pas. Le projet relève uniquement des rubriques 1.1.1.0 "
            "(création d'ouvrage — déclaration systématique) et 1.1.2.0 (prélèvements — "
            "seuils volumétriques de droit commun : déclaration entre 10 000 et 200 000 m³/an, "
            "autorisation au-delà)."
        )
        style_zre = s["iota_ok"]
        bg_zre, brd_zre = HexColor("#E8F4E8"), C_GREEN_DARK

    msg_zre_tbl = Table([[Paragraph(msg_zre, style_zre)]], colWidths=[17*cm])
    msg_zre_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), bg_zre),
        ("BOX",          (0,0), (-1,-1), 1.5, brd_zre),
        ("LEFTPADDING",  (0,0), (-1,-1), 12),
        ("RIGHTPADDING", (0,0), (-1,-1), 12),
        ("TOPPADDING",   (0,0), (-1,-1), 10),
        ("BOTTOMPADDING",(0,0), (-1,-1), 10),
    ]))
    story.append(msg_zre_tbl)
    story.append(Spacer(1, 0.5*cm))

    # ───────── 5.4 — Rejet exhaure (rubriques 2.x.x.0) ─────────
    story.append(PageBreak())
    story.append(subsection_header("5.4  Rejet des eaux d'exhaure — Rubriques 2.x.x.0", s))
    story.append(Paragraph(
        "Les eaux pompées dans le cadre du rabattement (eaux d'exhaure) doivent faire l'objet "
        "d'un exutoire dûment identifié. Selon le mode de rejet retenu, plusieurs rubriques de "
        "la nomenclature IOTA peuvent s'appliquer :",
        s["body"]
    ))
    story.append(Spacer(1, 0.2*cm))
    story.append(result_table(
        ["Rubrique", "Objet", "Seuils (D / A)"],
        [
            ["2.1.5.0",
             "Rejet d'eaux pluviales dans les eaux superficielles ou dans un bassin versant",
             "D : 1 ≤ S < 20 ha   |   A : S ≥ 20 ha"],
            ["2.2.1.0",
             "Rejet en eau douce superficielle susceptible de modifier le régime des eaux",
             "D : 2 000 ≤ Q < 10 000 m³/j ou 25 ≤ Q/Q_amont < 5 %   |   A : Q ≥ 10 000 m³/j ou ≥ 5 % Q_amont"],
            ["2.2.3.0",
             "Rejet dans les eaux superficielles emportant des substances polluantes",
             "Selon flux (DBO5, DCO, MES, hydrocarbures, métaux)"],
            ["2.3.1.0",
             "Rejet dans les eaux souterraines",
             "Autorisation systématique (rejet direct interdit hors dérogation)"],
        ],
        s,
        col_widths=[2.5*cm, 6.5*cm, 8*cm]
    ))
    story.append(Spacer(1, 0.3*cm))

    flux_jour = data.get("vol_jour", "—")
    story.append(Paragraph(
        f"<b>Application au projet :</b> le débit journalier prévisionnel de rabattement est "
        f"de <b>{flux_jour} m³/j</b>. L'exutoire retenu doit être précisé dans le dossier de "
        f"déclaration (réseau pluvial communal, milieu superficiel, bassin tampon avec "
        f"infiltration, ou retour partiel à la nappe via réinjection). Les rubriques "
        f"applicables seront déterminées définitivement à la sélection du mode d'évacuation.",
        s["body"]
    ))
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph(
        "<b>Préconisations rejet :</b>",
        s["body_bold"]
    ))
    rejets = [
        "Caractérisation analytique préalable des eaux d'exhaure (MES, DBO5, DCO, hydrocarbures totaux, métaux).",
        "Mise en place d'un dispositif de décantation (bassin tampon) avant rejet.",
        "Filtration / déshuilage si présence d'hydrocarbures avérée.",
        "Définition formelle de l'exutoire (gestionnaire de réseau et/ou propriétaire du milieu récepteur).",
        "Suivi qualitatif périodique des rejets pendant la phase d'exploitation.",
        "Convention de rejet avec le gestionnaire en cas de raccordement à un réseau communal.",
    ]
    for i, r in enumerate(rejets, 1):
        story.append(Paragraph(f"   {i}.  {r}", s["body"]))
    story.append(Spacer(1, 0.5*cm))

    # ───────── 5.5 — Masse d'eau souterraine SANDRE (résolue auto X/Y) ─────────
    # Toutes les valeurs proviennent du module geo_resolver (API Hub'Eau / Référentiel SIE)
    _meso_code     = data.get("meso_code", "—")
    _meso_libelle  = data.get("meso_libelle", "—")
    _bassin_dce    = data.get("bassin_dce", "—")
    _sdage         = data.get("sdage", "—")
    _sage          = data.get("sage", "—")
    _meso_urn      = data.get("meso_urn", "—")
    _bdlisa_codes  = data.get("bdlisa_codes", []) or []
    _bdlisa_noms   = data.get("bdlisa_noms", []) or []
    _zre_actif     = bool(data.get("zre_actif", False))
    # Code SANDRE court (sans le préfixe FR si présent)
    _meso_short = _meso_code.replace("FR", "") if _meso_code.startswith("FR") else _meso_code
    # URL de référence SANDRE
    if _meso_urn and _meso_urn != "—":
        _meso_url = _meso_urn
    elif _meso_short and _meso_short != "—":
        _meso_url = f"https://id.eaufrance.fr/MasseDEauSouterraine_VRAP2010/{_meso_short}"
    else:
        _meso_url = "À renseigner — résolution géographique indisponible"
    # BDLISA (entité hydrogéologique fine)
    if _bdlisa_codes and _bdlisa_noms:
        _bdlisa_str = " ; ".join(
            f"{c} ({n})" for c, n in zip(_bdlisa_codes[:3], _bdlisa_noms[:3])
        )
    elif _bdlisa_codes:
        _bdlisa_str = " ; ".join(_bdlisa_codes[:3])
    else:
        _bdlisa_str = "À reporter selon référentiel BDLISA en vigueur"
    # État quantitatif : médiocre si ZRE active, sinon mention DCE
    _meso_etat_quanti = (
        "Médiocre (zone classée ZRE — pression sur la ressource)" if _zre_actif
        else "À reporter selon dernier état SDAGE en vigueur"
    )

    bloc_sandre = []
    bloc_sandre.append(subsection_header("5.5  Masse d'eau souterraine concernée — Référentiel SANDRE", s))
    _intro_sandre = (
        f"L'identification de la masse d'eau souterraine impactée est nécessaire pour "
        f"l'instruction du dossier au titre de la Directive-Cadre sur l'Eau (DCE) et du "
        f"<b>{_sdage}</b>. La résolution est effectuée automatiquement à partir des coordonnées "
        f"Lambert 93 du forage via le référentiel SANDRE / Hub'Eau."
    )
    bloc_sandre.append(Paragraph(_intro_sandre, s["body"]))
    bloc_sandre.append(Spacer(1, 0.2*cm))
    sandre_data = [
        ["Code SANDRE (DCE)",                _meso_code],
        ["Libellé",                          _meso_libelle],
        ["Type",                             "Masse d'eau souterraine"],
        ["District hydrographique",          _bassin_dce],
        ["SDAGE",                            _sdage],
        ["SAGE",                             _sage],
        ["Entité hydrogéologique BDLISA",    _bdlisa_str],
        ["État quantitatif",                 _meso_etat_quanti],
        ["État chimique (suivi DCE)",        "À reporter selon dernier état SDAGE en vigueur"],
        ["Référence en ligne",               _meso_url],
    ]
    sd_para = [[Paragraph(f"<b>{k}</b>", ParagraphStyle("sk",
                    fontName=FONT_BOLD, fontSize=9.5, textColor=C_TEAL_DARK, leading=13)),
               Paragraph(str(v), ParagraphStyle("sv",
                    fontName=FONT_BODY, fontSize=10, leading=13))]
              for k, v in sandre_data]
    sd_tbl = Table(sd_para, colWidths=[6.5*cm, 10.5*cm])
    sd_tbl.setStyle(TableStyle([
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 10),
        ("TOPPADDING",    (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.0, C_TEAL_DARK),
    ]))
    bloc_sandre.append(sd_tbl)
    story.append(KeepTogether(bloc_sandre))
    story.append(Spacer(1, 0.5*cm))

    # ───────── 5.6 — Régime cumulé & délais d'instruction ─────────
    # Bascule automatique selon Q_max (capacité pompe) et V/an — cf. tableur Excel section 6
    story.append(PageBreak())
    bloc_56 = []
    bloc_56.append(subsection_header(
        "5.6  Régime cumulé & délais d'instruction prévisionnels", s))
    bloc_56.append(Spacer(1, 0.2*cm))

    # Détermination automatique du régime
    _hors_eau_pdf = data.get("fouille_hors_eau", False)
    if _hors_eau_pdf:
        regime_autorisation = False
        regime_label = "HORS NOMENCLATURE"
        justification = ("Le fond de fouille est situ\u00e9 au-dessus du niveau d'eau — "
                         "aucun pompage gravitaire n'est requis pour les travaux. Le projet ne d\u00e9clenche "
                         "aucune rubrique de la nomenclature IOTA li\u00e9e au pr\u00e9l\u00e8vement (1.1.2.0, 1.3.1.0). "
                         "La rubrique 1.1.1.0 ne s'applique qu'en cas de cr\u00e9ation d'ouvrage temporaire "
                         "d'\u00e9puisement de chantier en cas de remont\u00e9e pi\u00e9zom\u00e9trique saisonni\u00e8re av\u00e9r\u00e9e.")
    else:
        regime_autorisation = bool(zre_alert or autorisation_1120)
        regime_label = "AUTORISATION ENVIRONNEMENTALE" if regime_autorisation else "DÉCLARATION"
        if zre_alert and autorisation_1120:
            justification = ("Q ≥ 8 m³/h en ZRE (1.3.1.0) <b>ET</b> V ≥ 200 000 m³/an (1.1.2.0) — "
                             "deux déclencheurs cumulés d'autorisation.")
        elif zre_alert:
            justification = ("Q ≥ 8 m³/h en ZRE — déclenche la rubrique 1.3.1.0 en régime <b>AUTORISATION</b>. "
                             "Le caractère cumulatif des rubriques IOTA impose le régime le plus contraignant pour l'ensemble du dossier.")
        elif autorisation_1120:
            justification = ("V ≥ 200 000 m³/an — déclenche la rubrique 1.1.2.0 en régime <b>AUTORISATION</b>. "
                             "Le caractère cumulatif des rubriques IOTA impose le régime le plus contraignant pour l'ensemble du dossier.")
        else:
            justification = ("Q &lt; 8 m³/h <b>ET</b> V &lt; 200 000 m³/an — le projet relève d'une <b>DÉCLARATION</b> cumulée "
                             "au titre des rubriques 1.1.1.0 + 1.1.2.0 + 1.3.1.0 (article R.214-32 du Code de l'environnement).")

    bloc_56.append(Paragraph(
        "La nomenclature IOTA étant cumulative, le projet relève du régime le plus contraignant parmi "
        "les rubriques 1.1.1.0, 1.1.2.0 et 1.3.1.0. Les seuils de bascule sont les suivants :", s["body"]))
    bloc_56.append(Spacer(1, 0.2*cm))

    # Tableau des seuils de bascule par rubrique
    seuils_data = [
        ["Rubrique", "Seuil de bascule", "Régime calculé"],
        ["1.1.1.0 — Forage / ouvrage souterrain",
         "Sans seuil (ouvrage non domestique)",
         "DÉCLARATION"],
        ["1.1.2.0 — Prélèvement (V annuel)",
         "≥ 200 000 m³/an : Autorisation\n10 000–200 000 m³/an : Déclaration",
         ("AUTORISATION" if autorisation_1120
          else ("DÉCLARATION" if vol_an_val >= 10000 else "Hors nomenclature"))],
        [(f"1.3.1.0 — ZRE {data.get('zre_nappe', '—')}"
          if data.get("zre_actif") else
          "1.3.1.0 — ZRE (hors zonage)"),
         "≥ 8 m³/h : Autorisation\n&lt; 8 m³/h : Déclaration",
         ("AUTORISATION" if zre_alert else ("DÉCLARATION" if data.get("zre_actif") else "Hors nomenclature"))],
    ]
    seuils_para = [[Paragraph(c, s["body"]) for c in row] for row in seuils_data]
    seuils_tbl = Table(seuils_para, colWidths=[5.0*cm, 7.0*cm, 5.0*cm])
    seuils_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,0), C_TEAL_DARK),
        ("TEXTCOLOR",    (0,0), (-1,0), C_WHITE),
        ("FONTNAME",     (0,0), (-1,0), "Helvetica-Bold"),
        ("ALIGN",        (0,0), (-1,-1), "CENTER"),
        ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
        ("GRID",         (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",          (0,0), (-1,-1), 1.0, C_TEAL_DARK),
        ("LEFTPADDING",  (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING",   (0,0), (-1,-1), 6),
        ("BOTTOMPADDING",(0,0), (-1,-1), 6),
    ]))
    bloc_56.append(seuils_tbl)
    bloc_56.append(Spacer(1, 0.4*cm))

    # Bandeau régime retenu
    bg_regime = HexColor("#FBEDF3") if regime_autorisation else HexColor("#E8F5E9")
    brd_regime = HexColor("#A12C7B") if regime_autorisation else HexColor("#1B5E20")
    txt_regime = HexColor("#A12C7B") if regime_autorisation else HexColor("#1B5E20")
    style_regime = ParagraphStyle(
        "regime_bandeau", parent=s["body"], fontSize=11, leading=14,
        textColor=txt_regime, fontName="Helvetica-Bold",
        alignment=TA_CENTER)
    bandeau = (f"→  RÉGIME RETENU : {regime_label}<br/>"
               f"<font size='9'>{justification}</font>")
    bandeau_tbl = Table([[Paragraph(bandeau, style_regime)]], colWidths=[17*cm])
    bandeau_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), bg_regime),
        ("BOX",          (0,0), (-1,-1), 1.5, brd_regime),
        ("LEFTPADDING",  (0,0), (-1,-1), 12),
        ("RIGHTPADDING", (0,0), (-1,-1), 12),
        ("TOPPADDING",   (0,0), (-1,-1), 12),
        ("BOTTOMPADDING",(0,0), (-1,-1), 12),
    ]))
    bloc_56.append(bandeau_tbl)
    story.append(KeepTogether(bloc_56))
    story.append(Spacer(1, 0.5*cm))

    # Tableau des délais d'instruction — dépendant du régime
    bloc_delais = []
    bloc_delais.append(Paragraph(
        "Délais d'instruction réglementaires :", s["subsection_title"]))
    bloc_delais.append(Spacer(1, 0.15*cm))

    if regime_autorisation:
        delais_intro = (
            "Le dossier relève de la procédure d'<b>autorisation environnementale</b> réformée par la "
            "loi n° 2023-973 du 23 octobre 2023 (\u00ab Industrie Verte \u00bb), avec parallélisation des phases "
            "d'examen et de consultation du public depuis octobre 2024.")
        delais_data = [
            ["Phase", "Durée réglementaire", "Référence"],
            ["①  Vérification complétude / régularité",
             "Quelques semaines\n(hors délai réglementaire)",
             "R.181-16 CE"],
            ["②  Examen + consultation parallélisée",
             "4 mois (examen)\nincluant 3 mois de consultation publique",
             "R.181-17 CE"],
            ["③  Décision préfectorale",
             "2 mois après rapport du commissaire enquêteur",
             "R.181-41 CE"],
            ["<b>⏱  DÉLAI GLOBAL</b>",
             "<b>9 mois (référence)</b>\n10 à 12 mois en pratique",
             "DREAL / DRIEAT"],
        ]
        aleas_txt = (
            "<b>Aléas pouvant prolonger les délais :</b> examen complexe (+4 mois), étude d'impact (+1 mois), "
            "passage en CODERST (+1 mois), demandes de compléments suspensives, évaluation environnementale au cas par cas.")
        recommandation_txt = (
            "<b>Recommandation :</b> dépôt du dossier au minimum <b>12 mois avant</b> la date prévisionnelle de "
            "démarrage du chantier de rabattement. Une concertation amont avec la DDT 41 et la DREAL "
            "Centre-Val de Loire est vivement recommandée pour cadrer les enjeux et limiter les demandes "
            "de compléments suspensives.")
    elif _hors_eau_pdf:
        delais_intro = (
            "Le projet ne déclenche aucune rubrique de la nomenclature IOTA liée au prélèvement. "
            "<b>Aucune procédure réglementaire au titre du Code de l'environnement n'est à engager</b> "
            "pour les travaux tant que le fond de fouille reste au-dessus du niveau d'eau. "
            "Un suivi piézométrique préchantier est cependant recommandé pour anticiper toute remontée saisonnière.")
        delais_data = [
            ["Phase", "Durée réglementaire", "Référence"],
            ["①  Suivi piézométrique préchantier",
             "Mesures sur 1 cycle hydrologique recommandées",
             "Bonne pratique"],
            ["②  Vérification absence de remontée",
             "Avant démarrage travaux",
             "Diligence MO"],
            ["③  Déclaration 1.1.1.0 — si pompage temporaire déclenché",
             "<b>2 mois</b> avant pompage éventuel",
             "R.214-32 CE"],
            ["<b>⏱  PROCÉDURE</b>",
             "<b>Aucune si fouille reste hors d'eau</b>",
             "Code env."],
        ]
        aleas_txt = (
            "<b>Surveillance recommandée :</b> en cas de remontée piézométrique saisonnière avérée "
            "amenant le niveau d'eau au-dessus du fond de fouille, un dispositif d'\u00e9puisement "
            "de chantier devra \u00eatre d\u00e9clar\u00e9 au titre de la rubrique 1.1.1.0 (cr\u00e9ation d'ouvrage temporaire).")
        recommandation_txt = (
            "<b>Recommandation :</b> r\u00e9aliser une campagne pi\u00e9zom\u00e9trique de r\u00e9f\u00e9rence "
            "avant le d\u00e9marrage des travaux pour confirmer la marge entre fond de fouille et niveau d'eau "
            "sur l'ensemble du cycle hydrologique. Conserver les enregistrements en cas de contr\u00f4le.")
    else:
        delais_intro = (
            "Le dossier relève de la procédure de <b>déclaration</b> au titre des rubriques 1.1.1.0 + 1.1.2.0 + 1.3.1.0 "
            "cumulées. Le préfet dispose d'un délai d'opposition fixé par l'article R.214-35 du Code de l'environnement "
            "— le silence vaut accord tacite à l'expiration du délai.")
        delais_data = [
            ["Phase", "Durée réglementaire", "Référence"],
            ["①  Dépôt et instruction",
             "Inclus dans le délai d'opposition",
             "R.214-32 CE"],
            ["②  Délai d'opposition préfet",
             "<b>2 mois</b>\n(silence = accord tacite)",
             "R.214-35 CE"],
            ["③  Récépissé ou opposition motivée",
             "Notification à l'expiration du délai",
             "R.214-33 CE"],
            ["<b>⏱  DÉLAI GLOBAL</b>",
             "<b>2 mois</b>\n(3 mois si DIG conjointe)",
             "DREAL / DDT"],
        ]
        aleas_txt = (
            "<b>Aléa principal :</b> si le préfet décide de soumettre le projet à évaluation environnementale "
            "au cas par cas, le délai d'instruction est <b>interrompu</b> jusqu'à la décision de l'autorité "
            "environnementale.")
        recommandation_txt = (
            "<b>Recommandation :</b> dépôt du dossier au minimum <b>4 mois avant</b> le démarrage des travaux, "
            "pour absorber un éventuel délai d'opposition complet et d'éventuelles demandes de compléments "
            "suspensives. Un échange amont avec la DDT 41 reste conseillé.")

    bloc_delais.append(Paragraph(delais_intro, s["body"]))
    bloc_delais.append(Spacer(1, 0.25*cm))

    delais_para = [[Paragraph(c, s["body"]) for c in row] for row in delais_data]
    delais_tbl = Table(delais_para, colWidths=[6.0*cm, 7.0*cm, 4.0*cm])
    delais_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,0), C_TEAL_DARK),
        ("TEXTCOLOR",    (0,0), (-1,0), C_WHITE),
        ("FONTNAME",     (0,0), (-1,0), "Helvetica-Bold"),
        ("BACKGROUND",   (0,-1), (-1,-1), HexColor("#FBEDF3") if regime_autorisation else HexColor("#E8F5E9")),
        ("ALIGN",        (0,0), (-1,-1), "CENTER"),
        ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
        ("GRID",         (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",          (0,0), (-1,-1), 1.0, C_TEAL_DARK),
        ("LEFTPADDING",  (0,0), (-1,-1), 6),
        ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ("TOPPADDING",   (0,0), (-1,-1), 6),
        ("BOTTOMPADDING",(0,0), (-1,-1), 6),
    ]))
    bloc_delais.append(delais_tbl)
    bloc_delais.append(Spacer(1, 0.3*cm))
    bloc_delais.append(Paragraph(aleas_txt, s["note"]))
    bloc_delais.append(Spacer(1, 0.2*cm))

    style_reco = ParagraphStyle(
        "reco_box", parent=s["body"], fontSize=10, leading=13,
        textColor=HexColor("#BF360C"), fontName="Helvetica")
    reco_tbl = Table([[Paragraph(recommandation_txt, style_reco)]], colWidths=[17*cm])
    reco_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), HexColor("#FFF3E0")),
        ("BOX",          (0,0), (-1,-1), 1.0, HexColor("#BF360C")),
        ("LEFTPADDING",  (0,0), (-1,-1), 12),
        ("RIGHTPADDING", (0,0), (-1,-1), 12),
        ("TOPPADDING",   (0,0), (-1,-1), 10),
        ("BOTTOMPADDING",(0,0), (-1,-1), 10),
    ]))
    bloc_delais.append(reco_tbl)
    story.append(KeepTogether(bloc_delais))
    story.append(Spacer(1, 0.5*cm))

    # ───────── Synthèse — obligations ─────────
    story.append(Paragraph("Synthèse des obligations réglementaires :", s["subsection_title"]))
    if _hors_eau_pdf:
        obligations = [
            "Aucune procédure de déclaration ou d'autorisation au titre du Code de l'environnement n'est requise tant que le fond de fouille reste au-dessus du niveau d'eau (hors nomenclature IOTA).",
            "Réaliser une campagne piézométrique de référence préchantier pour caractériser les fluctuations saisonnières du niveau d'eau et confirmer la marge avec le fond de fouille.",
            "Conserver les enregistrements piézométriques (BSS, AdES, mesures locales) pendant toute la durée des travaux — contrôle possible par la DDT.",
            "En cas de remontée piézométrique au-dessus du fond de fouille, mettre en place un épuisement de chantier temporaire et déposer une déclaration au titre de la rubrique 1.1.1.0 (création d'ouvrage temporaire) avant tout pompage.",
            f"Si le projet est situé en périmètre de protection de captage AEP ou en zone {('ZRE ' + data.get('zre_nappe', '—')) if data.get('zre_actif') else 'sensible'}, informer préalablement la DDT même en l'absence de pompage projeté.",
            "Prévoir une fiche de chantier précisant la cote du fond de fouille et la cote du niveau d'eau de référence, signée par le maître d'\u0153uvre.",
        ]
    elif zre_alert:
        obligations = [
            "Dépôt d'un dossier UNIQUE d'AUTORISATION ENVIRONNEMENTALE auprès de la DDT 41, intégrant les rubriques 1.1.1.0 + 1.1.2.0 + 1.3.1.0 cumulées (articles R.181-12 et suivants).",
            "Classement ZRE confirmé par la liste officielle AELB du 30/12/2024 — aucune vérification cartographique supplémentaire requise.",
            "Identification précise de l'exutoire des eaux d'exhaure et compléments aux rubriques 2.x.x.0 (2.1.5.0 / 2.2.1.0 / 2.2.3.0 / 2.3.1.0) selon le mode de rejet retenu.",
            "Délai réglementaire d'instruction d'autorisation environnementale (R.181-17) : démarrage des travaux après publication de l'arrêté préfectoral d'autorisation.",
            "Mise en place d'un compteur volumétrique agréé conforme à l'arrêté du 11 septembre 2003 (article 8) sur l'installation de pompage.",
            "Tenue d'un registre de suivi des volumes prélevés (transmission annuelle à la DDT 41 et à l'AELB).",
            "Suivi piézométrique obligatoire du niveau de la nappe en ZRE (rubrique 1.3.1.0).",
            "Caractérisation et suivi qualitatif des eaux d'exhaure rejetées (analyses MES, DBO5, DCO, hydrocarbures, métaux).",
        ]
    else:
        obligations = [
            "Dépôt d'un dossier UNIQUE de déclaration au titre des rubriques 1.1.1.0 et 1.1.2.0 cumulées auprès de la DDT 41.",
            "Classement ZRE confirmé : déclaration cumulée au titre de la rubrique 1.3.1.0 (Q < 8 m³/h, alinéa 2°).",
            "Identification de l'exutoire des eaux d'exhaure et compléments aux rubriques 2.x.x.0 selon le mode de rejet retenu.",
            "Respect du délai réglementaire de 2 mois (R.214-32) entre la déclaration et le début des travaux.",
            "Mise en place d'un dispositif de comptage volumétrique agréé sur l'installation de pompage.",
            "Tenue d'un registre de suivi des volumes prélevés (transmission annuelle à l'administration).",
            "Suivi piézométrique obligatoire du niveau de la nappe en ZRE.",
            "Caractérisation et suivi qualitatif des eaux d'exhaure rejetées.",
        ]
    for i, obl in enumerate(obligations, 1):
        story.append(Paragraph(f"   {i}.  {obl}", s["body"]))
    story.append(Spacer(1, 0.4*cm))


# ─────────────────────────────────────────────
# 6. SENSIBILITÉ ENVIRONNEMENTALE — ZNIEFF & NATURA 2000
# ─────────────────────────────────────────────
def build_znieff_natura2000(story, data, s):
    """Section 6 — Sensibilité environnementale : ZNIEFF et Natura 2000."""
    story.append(PageBreak())
    story.append(section_header(
        "6. SENSIBILITÉ ENVIRONNEMENTALE — ZNIEFF ET NATURA 2000", s))
    story.append(Spacer(1, 0.3*cm))

    # ── Valeurs dynamiques lues du tableur (C33/C34 + commune/département)
    _commune_dyn = (data.get("commune") or data.get("commune_geo") or "—")
    # Département : C38 du tableur (formule = code + nom), sinon dept_code/dept_nom
    _dept_full = data.get("departement", "—")
    if not _dept_full or _dept_full == "—":
        _dept_code = data.get("dept_code", "—")
        _dept_nom  = data.get("dept_nom", "—")
        _dept_full = f"{_dept_code} — {_dept_nom}" if _dept_nom != "—" else _dept_code
    _x_fmt = f"{int(round(float(data.get('lambert_x', 0)))):,}".replace(",", " ")
    _y_fmt = f"{int(round(float(data.get('lambert_y', 0)))):,}".replace(",", " ")
    intro_text = (
        "Dans le cadre de la Loi sur l'Eau (articles L.214-1 à L.214-6 du Code de l'Environnement), "
        "l'analyse des zonages environnementaux constitue un élément essentiel de l'évaluation des "
        "incidences du projet sur les milieux naturels. Conformément à l'article R.122-5 du Code de "
        "l'Environnement et aux dispositions de la Directive Habitats (92/43/CEE) et de la Directive "
        "Oiseaux (79/409/CEE), l'identification des zones à statut réglementaire dans un rayon de 5 km "
        "autour du site de captage est nécessaire."
        "<br/><br/>"
        f"Le site de captage est localisé sur la commune de <b>{_commune_dyn} ({_dept_full})</b>, "
        f"coordonnées Lambert 93 : X = {_x_fmt} m, Y = {_y_fmt} m. "
        "La prospection a été menée à partir des bases de données officielles "
        "(INPN/PatriNat, AgriMap, DOCOB officiels, services de l'État)."
    )
    story.append(Paragraph(intro_text, s["body"]))
    story.append(Spacer(1, 0.4*cm))

    # ───────────────────────────
    # 6.1  ZNIEFF Type I — Pelouses du Champ Noir
    story.append(subsection_header("6.1  ZNIEFF de Type I — Pelouses du Champ Noir", s))
    story.append(Spacer(1, 0.15*cm))

    znieff1_intro = (
        "La ZNIEFF de Type I <b>Pelouses du Champ Noir</b> (code officiel INPN : <b>240031093</b>) "
        "est une zone naturelle à fort intérêt écologique située directement <b>sur le territoire "
        "communal d'Oucques-la-Nouvelle</b>. Elle couvre également les communes de "
        "Saint-Léonard-en-Beauce et de Villeneuve-Frouville."
        "<br/><br/>"
        "Les ZNIEFF de Type I correspondent aux secteurs de plus grande valeur écologique identifiés "
        "par les scientifiques sur chaque grande région naturelle. Leur délimitation est fondée sur "
        "la présence d'espèces et d'habitats rares, remarquables ou protégés."
    )
    story.append(Paragraph(znieff1_intro, s["body"]))
    story.append(Spacer(1, 0.2*cm))

    znieff1_rows = [
        ["Paramètre", "Description"],
        ["Nom", "Pelouses du Champ Noir"],
        ["Code INPN", "240031093"],
        ["Type", "ZNIEFF de Type I"],
        ["Surface", "~19 ha (17,41 ha sur la commune d'Oucques-la-Nouvelle)"],
        ["Communes concernées", "Oucques-la-Nouvelle, Saint-Léonard-en-Beauce, Villeneuve-Frouville"],
        ["Localisation", "Secteur polynucléaire ~ 2 km à l'est du bourg de Villeneuve-Frouville"],
        ["Distance au site", "Sur le territoire communal (inclus dans la commune)"],
        ["Habitats remarquables",
         "Pelouses calcicoles (Mesobromion) en voie de fermeture par la fruticaille ; "
         "paysage de grande richesse floristique (~150 espèces)"],
        ["Espèces déterminantes",
         "Fraisier vert (Fragaria viridis) ; Œdicnème criard (Burhinus oedicnemus) — "
         "nidification régulière, plusieurs couples"],
    ]

    zn1_formatted = []
    for i, row in enumerate(znieff1_rows):
        if i == 0:
            zn1_formatted.append([
                Paragraph(f"<b>{row[0]}</b>", ParagraphStyle("zh0",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_WHITE,
                    alignment=TA_CENTER, leading=12)),
                Paragraph(f"<b>{row[1]}</b>", ParagraphStyle("zh1",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_WHITE,
                    alignment=TA_CENTER, leading=12)),
            ])
        else:
            zn1_formatted.append([
                Paragraph(row[0], ParagraphStyle("zk",
                    fontName=FONT_BOLD, fontSize=8.5, textColor=C_TEAL_DARK,
                    alignment=TA_LEFT, leading=12)),
                Paragraph(row[1], ParagraphStyle("zv",
                    fontName=FONT_BODY, fontSize=8.5, textColor=C_BLACK,
                    alignment=TA_LEFT, leading=12)),
            ])

    zn1_tbl = Table(zn1_formatted, colWidths=[4.5*cm, 12.5*cm])
    zn1_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), C_TEAL_DARK),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.0, C_TEAL_DARK),
    ]))
    story.append(zn1_tbl)
    story.append(Spacer(1, 0.4*cm))

    # ───────────────────────────
    # 6.2  ZNIEFF Type II — Forêt de Marchenoir
    story.append(PageBreak())
    story.append(subsection_header("6.2  ZNIEFF de Type II — Forêt de Marchenoir (proximité)", s))
    story.append(Spacer(1, 0.15*cm))

    znieff2_intro = (
        "La ZNIEFF de Type II <b>Forêt de Marchenoir</b> est un grand ensemble écologique "
        "de ~ 5 077 ha situé <b>à quelques kilomètres au sud-ouest d'Oucques-la-Nouvelle</b>. "
        "La commune n'est pas incluse dans son périmètre, mais sa commune limitrophe "
        "Saint-Léonard-en-Beauce figure dans les deux zonages."
        "<br/><br/>"
        "Les ZNIEFF de Type II désignent de grands ensembles naturels riches et peu modifiés, "
        "offrant des potentialités biologiques importantes. Elles peuvent englober des zones de "
        "Type I."
    )
    story.append(Paragraph(znieff2_intro, s["body"]))
    story.append(Spacer(1, 0.2*cm))

    znieff2_rows = [
        ["Paramètre", "Description"],
        ["Nom", "Forêt de Marchenoir"],
        ["Type", "ZNIEFF de Type II"],
        ["Surface", "~ 5 063 à 5 077 ha"],
        ["Communes concernées",
         "11 communes dont Saint-Léonard-en-Beauce (limitrophe d'Oucques), Autainville, Briou, "
         "Le Plessis-l'Échelle, Lorges, Marchenoir, Roches, Saint-Laurent-des-Bois, "
         "Vievy-le-Rayé, Villermain, Beauce la Romaine"],
        ["Distance au site", "Commune non incluse — la forêt se situe à quelques km au sud-ouest"],
        ["Habitats remarquables",
         "Chênaie sessiliflore acidophile à neutrophile ; grande cohérence écologique et "
         "naturalité forte par rapport aux cultures environnantes"],
        ["Espèces remarquables", "Cerf élaphe (Cervus elaphus) — présence notable"],
    ]

    zn2_formatted = []
    for i, row in enumerate(znieff2_rows):
        if i == 0:
            zn2_formatted.append([
                Paragraph(f"<b>{row[0]}</b>", ParagraphStyle("z2h0",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_WHITE,
                    alignment=TA_CENTER, leading=12)),
                Paragraph(f"<b>{row[1]}</b>", ParagraphStyle("z2h1",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_WHITE,
                    alignment=TA_CENTER, leading=12)),
            ])
        else:
            zn2_formatted.append([
                Paragraph(row[0], ParagraphStyle("z2k",
                    fontName=FONT_BOLD, fontSize=8.5, textColor=C_TEAL_DARK,
                    alignment=TA_LEFT, leading=12)),
                Paragraph(row[1], ParagraphStyle("z2v",
                    fontName=FONT_BODY, fontSize=8.5, textColor=C_BLACK,
                    alignment=TA_LEFT, leading=12)),
            ])

    zn2_tbl = Table(zn2_formatted, colWidths=[4.5*cm, 12.5*cm])
    zn2_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), HexColor("#1B5E7A")),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_WHITE, HexColor("#EAF4FB")]),
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.0, HexColor("#1B5E7A")),
    ]))
    story.append(zn2_tbl)
    story.append(Spacer(1, 0.4*cm))

    # ───────────────────────────
    # 6.3  Natura 2000 ZPS — Petite Beauce FR2410010
    story.append(PageBreak())
    story.append(subsection_header(
        "6.3  Zone Natura 2000 ZPS — Petite Beauce (FR2410010)", s))
    story.append(Spacer(1, 0.15*cm))

    n2000_intro = (
        "La Zone de Protection Spéciale (ZPS) <b>\u00ab Petite Beauce \u00bb</b> "
        "(code : <b>FR2410010</b>, Directive Oiseaux 79/409/CEE) "
        "couvre <b>52 565 ha</b> répartis sur 50 communes entre Blois et Vendôme. "
        "Une partie du territoire communal d'<b>Oucques-la-Nouvelle est directement incluse "
        "dans ce périmètre</b>, classé par arrêté ministériel du 3 mars 2006."
        "<br/><br/>"
        "Les ZPS sont des zones classées au titre de la Directive \u00ab Oiseaux \u00bb pour assurer "
        "la protection des espèces d'oiseaux sauvages inscrites à l'Annexe I de la Directive, "
        "ainsi que des espèces migratrices régulièrement présentes. Tout plan ou projet "
        "susceptible d'affecter significativement ce site doit faire l'objet d'une évaluation "
        "des incidences Natura 2000 (article L.414-4 du Code de l'Environnement)."
    )
    story.append(Paragraph(n2000_intro, s["body"]))
    story.append(Spacer(1, 0.2*cm))

    n2000_rows = [
        ["Paramètre", "Description"],
        ["Nom", "Petite Beauce"],
        ["Code européen", "FR2410010"],
        ["Type", "ZPS — Zone de Protection Spéciale (Directive Oiseaux 79/409/CEE)"],
        ["Surface totale", "52 565 ha"],
        ["Nombre de communes", "50 communes (Loir-et-Cher)"],
        ["Désignation", "Arrêté ministériel du 3 mars 2006"],
        ["Rapport au site", "Territoire communal d'Oucques-la-Nouvelle partiellement inclus dans le périmètre"],
        ["Habitats représentés",
         "Cultures de plaine sur plateau calcaire de Beauce (75 %), pelouses calcicoles "
         "(Mesobromion), prairies, marais, haies et bosquets"],
        ["Espèces annexe I (× année 2006)",
         "Busard cendré (Circus pygargus) • Busard Saint-Martin (Circus cyaneus) • "
         "Busard des roseaux (Circus aeruginosus) • Œdicnème criard (Burhinus oedicnemus) • "
         "Outarde canepetière (Tetrax tetrax) • Faucon émérillon (Falco columbarius) • "
         "Hibou des marais (Asio flammeus) • Pluvier doré (Pluvialis apricaria) • "
         "Cigogne blanche (zone de nourrissage)"],
        ["Autres espèces notables",
         "Caille des blés (Coturnix coturnix) • Perdrix grise (Perdix perdix)"],
    ]

    n2_formatted = []
    for i, row in enumerate(n2000_rows):
        if i == 0:
            n2_formatted.append([
                Paragraph(f"<b>{row[0]}</b>", ParagraphStyle("n2h0",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_WHITE,
                    alignment=TA_CENTER, leading=12)),
                Paragraph(f"<b>{row[1]}</b>", ParagraphStyle("n2h1",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_WHITE,
                    alignment=TA_CENTER, leading=12)),
            ])
        else:
            n2_formatted.append([
                Paragraph(row[0], ParagraphStyle("n2k",
                    fontName=FONT_BOLD, fontSize=8.5, textColor=HexColor("#5B2D8E"),
                    alignment=TA_LEFT, leading=12)),
                Paragraph(row[1], ParagraphStyle("n2v",
                    fontName=FONT_BODY, fontSize=8.5, textColor=C_BLACK,
                    alignment=TA_LEFT, leading=12)),
            ])

    n2_tbl = Table(n2_formatted, colWidths=[4.5*cm, 12.5*cm])
    n2_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), HexColor("#5B2D8E")),
        ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_WHITE, HexColor("#F3EEF9")]),
        ("ALIGN",         (0,0), (-1,-1), "LEFT"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0), (-1,-1), 1.0, HexColor("#5B2D8E")),
    ]))
    story.append(n2_tbl)
    story.append(Spacer(1, 0.4*cm))

    # Absence de ZSC
    no_zsc_text = (
        "<b>Absence de Zone Spéciale de Conservation (ZSC) sur la commune.</b> "
        "Aucune ZSC au titre de la Directive Habitats (92/43/CEE) ne couvre directement "
        "la commune d'Oucques-la-Nouvelle. Les ZSC de Loir-et-Cher (Domaine de Chambord, "
        "Vallée du Cher, Sologne, Vallée de la Loire, etc.) sont éloignées du secteur."
    )
    zsc_note = Table([[Paragraph(no_zsc_text, ParagraphStyle("zscn",
        fontName=FONT_BODY, fontSize=8.5, textColor=HexColor("#5B2D8E"),
        leading=12))]], colWidths=[17*cm])
    zsc_note.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), HexColor("#F3EEF9")),
        ("BOX",          (0,0), (-1,-1), 0.8, HexColor("#5B2D8E")),
        ("LEFTPADDING",  (0,0), (-1,-1), 10),
        ("RIGHTPADDING", (0,0), (-1,-1), 10),
        ("TOPPADDING",   (0,0), (-1,-1), 7),
        ("BOTTOMPADDING",(0,0), (-1,-1), 7),
    ]))
    story.append(zsc_note)
    story.append(Spacer(1, 0.4*cm))

    # ───────────────────────────
    # Tableau récapitulatif
    story.append(subsection_header("Tableau récapitulatif des zonages environnementaux", s))
    story.append(Spacer(1, 0.15*cm))

    recap_header = ["Zonage", "Nom", "Code", "Type", "Surface", "Rapport au site"]
    recap_data = [
        ["ZNIEFF I",  "Pelouses du Champ Noir", "240031093",
         "ZNIEFF Type I",         "~ 19 ha",     "Sur la commune"],
        ["ZNIEFF II", "Forêt de Marchenoir",   "NC",
         "ZNIEFF Type II",        "~ 5 077 ha",  "Commune voisine (quelques km)"],
        ["N2000 ZPS", "Petite Beauce",          "FR2410010",
         "ZPS — Dir. Oiseaux",    "52 565 ha",  "Partiellement sur la commune"],
        ["N2000 ZSC", "Aucune",                 "—",
         "ZSC — Dir. Habitats",   "—",           "Absente"],
    ]

    recap_colors = [
        C_TEAL_DARK,       # ZNIEFF I
        HexColor("#1B5E7A"),   # ZNIEFF II
        HexColor("#5B2D8E"),   # N2000 ZPS
        C_GREY_DARK,       # ZSC absente
    ]

    recap_formatted = [[
        Paragraph(f"<b>{h}</b>", ParagraphStyle("rh",
            fontName=FONT_BOLD, fontSize=8.5, textColor=C_WHITE,
            alignment=TA_CENTER, leading=11))
        for h in recap_header
    ]]
    for i, (row, col) in enumerate(zip(recap_data, recap_colors)):
        fmtd = [
            Paragraph(f"<b>{row[0]}</b>", ParagraphStyle(f"rt0_{i}",
                fontName=FONT_BOLD, fontSize=8, textColor=C_WHITE,
                alignment=TA_CENTER, leading=11)),
        ]
        for cell in row[1:]:
            fmtd.append(Paragraph(cell, ParagraphStyle(f"rtc_{i}",
                fontName=FONT_BODY, fontSize=8, textColor=C_BLACK,
                alignment=TA_LEFT, leading=11)))
        recap_formatted.append(fmtd)

    rec_tbl = Table(recap_formatted, colWidths=[2.0*cm, 4.0*cm, 2.5*cm, 3.2*cm, 2.0*cm, 3.3*cm])
    rec_styles = [
        ("BACKGROUND",    (0,0),  (-1,0),  HexColor("#2C4A3E")),   # en-tête sombre
        ("ALIGN",         (0,0),  (-1,-1), "LEFT"),
        ("VALIGN",        (0,0),  (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0),  (-1,-1), 5),
        ("RIGHTPADDING",  (0,0),  (-1,-1), 5),
        ("TOPPADDING",    (0,0),  (-1,-1), 4),
        ("BOTTOMPADDING", (0,0),  (-1,-1), 4),
        ("GRID",          (0,0),  (-1,-1), 0.3, C_GREY_MED),
        ("BOX",           (0,0),  (-1,-1), 1.0, HexColor("#2C4A3E")),
    ]
    for i, col in enumerate(recap_colors, 1):
        rec_styles.append(("BACKGROUND", (0,i), (0,i), col))
    rec_tbl.setStyle(TableStyle(rec_styles))
    story.append(rec_tbl)
    story.append(Spacer(1, 0.5*cm))

    # ───────────────────────────
    # 6.4  Évaluation des incidences Natura 2000
    story.append(subsection_header(
        "6.4  Évaluation des incidences du projet sur les zonages Natura 2000", s))
    story.append(Spacer(1, 0.15*cm))

    incid_intro = (
        "Conformément à l'article L.414-4 du Code de l'Environnement (transposition de la "
        "Directive Habitats), tout plan ou projet susceptible d'affecter de manière significative "
        "un site Natura 2000, individuellement ou en conjugaison avec d'autres plans et projets, "
        "doit faire l'objet d'une évaluation de ses incidences. L'évaluation ci-dessous est basée "
        "sur les caractéristiques du projet de captage."
    )
    story.append(Paragraph(incid_intro, s["body"]))
    story.append(Spacer(1, 0.25*cm))

    # Volume prélevé et sensibilité
    vol_an_val = data.get("vol_an_float", 0.0)
    t_exploit = data.get("t_exploit_str", "8,0 h/jour")
    incid_items = [
        ("Nature du projet",
         "Captage d'eaux souterraines par forage — usage non précisé (irrigation, usage domestique "
         "ou industriel). Pompage en nappe phréatique."),
        ("Volume annuel prélevé",
         f"{data.get('vol_an', '—')} m³/an — "
         f"Exploitation : {t_exploit} — Statut IOTA : {data.get('statut_iota', '—')}"),
        ("Impact sur la ZPS Petite Beauce (FR2410010)",
         "Le captage d'eau souterraine ne modifie pas directement les habitats terrestres "
         "utilisés par les espèces d'oiseaux de la ZPS. Il n'entraîne ni destruction de "
         "pelouses, ni fragmentation du milieu, ni perturbations sonores ou lumineuses étendues. "
         "L'incidence sur la ZPS est considérée comme <b>non significative</b>."),
        ("Impact sur la ZNIEFF I \u00ab Pelouses du Champ Noir \u00bb",
         "Les pelouses calcicoles du Champ Noir sont liées à un substrat calcaire superficiel. "
         "Un rabattement de nappe lié au pompage est localisé au droit du forage (cône de "
         f"dépression r = {data.get('rayon_inf_str', '10')} m de rayon d'influence estimé). "
         "Dans le contexte d'un captage de petite envergure soumis à déclaration, "
         "l'impact sur la nappe superficielle alimentant ces pelouses est très limité. "
         "Les mesures de suivi piézométrique prescrites en section 7.3 permettront de "
         "contrôler ce point."),
        ("Enjeu ornithologique commun",
         "L'Œdicnème criard (Burhinus oedicnemus), espèce classifiée Annexe I de la "
         "Directive Oiseaux, est présent à la fois dans la ZNIEFF I Pelouses du Champ Noir "
         "et dans la ZPS Petite Beauce. Il niche dans les milieux ouverts (labours, pelouses, "
         "vignes). Le chantier de forage devra éviter les périodes de reproduction "
         "(mars à août) si des individus sont détectés à proximité."),
        ("Conclusion",
         "Le projet de captage d'eaux souterraines, de faible volume prélevé, est compatible "
         "avec la préservation des objectifs de conservation des sites Natura 2000 et ZNIEFF "
         "identifiés. <b>L'évaluation des incidences Natura 2000 conclut à l'absence d'effets "
         "significatifs sur l'intégrité du site ZPS FR2410010 Petite Beauce.</b>"),
    ]

    incid_rows_fmt = []
    for k, v in incid_items:
        is_conclu = k == "Conclusion"
        incid_rows_fmt.append([
            Paragraph(f"<b>{k}</b>", ParagraphStyle(f"ik_{k[:4]}",
                fontName=FONT_BOLD, fontSize=8.5,
                textColor=C_GREEN_DARK if is_conclu else C_TEAL_DARK,
                alignment=TA_LEFT, leading=12)),
            Paragraph(v, ParagraphStyle(f"iv_{k[:4]}",
                fontName=FONT_BODY, fontSize=8.5,
                textColor=C_BLACK, alignment=TA_LEFT, leading=12)),
        ])

    incid_tbl = Table(incid_rows_fmt, colWidths=[4.5*cm, 12.5*cm])
    incid_tbl.setStyle(TableStyle([
        ("ROWBACKGROUNDS", (0,0), (-1,-2), [C_WHITE, C_TEAL_XLIGHT]),
        ("BACKGROUND",     (0,-1), (-1,-1), HexColor("#E8F4E8")),
        ("ALIGN",          (0,0), (-1,-1), "LEFT"),
        ("VALIGN",         (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING",    (0,0), (-1,-1), 8),
        ("RIGHTPADDING",   (0,0), (-1,-1), 8),
        ("TOPPADDING",     (0,0), (-1,-1), 6),
        ("BOTTOMPADDING",  (0,0), (-1,-1), 6),
        ("GRID",           (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("BOX",            (0,0), (-1,-1), 1.0, C_TEAL_DARK),
        ("LINEABOVE",      (0,-1), (-1,-1), 1.5, C_GREEN_DARK),
    ]))
    story.append(incid_tbl)
    story.append(Spacer(1, 0.4*cm))

    # Note réglementaire finale
    note_regl = (
        "<b>Note réglementaire :</b> En application de l'article R.414-19 du Code de l'Environnement, "
        "les projets soumis à simple déclaration au titre de la Loi sur l'Eau et dont l'évaluation "
        "préalable conclut à l'absence d'incidence significative ne sont pas tenus de déposer un "
        "dossier d'évaluation des incidences complète. La présente analyse, jointe au dossier de "
        "déclaration, satisfait à cette obligation."
    )
    note_tbl = Table([[Paragraph(note_regl, ParagraphStyle("nr",
        fontName=FONT_BODY, fontSize=8, textColor=C_GREY_DARK, leading=12))]], colWidths=[17*cm])
    note_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,-1), C_TEAL_XLIGHT),
        ("BOX",          (0,0), (-1,-1), 0.5, C_GREY_MED),
        ("LEFTPADDING",  (0,0), (-1,-1), 10),
        ("RIGHTPADDING", (0,0), (-1,-1), 10),
        ("TOPPADDING",   (0,0), (-1,-1), 8),
        ("BOTTOMPADDING",(0,0), (-1,-1), 8),
    ]))
    story.append(note_tbl)
    story.append(Spacer(1, 0.3*cm))


# ─────────────────────────────────────────────
# 6. PRÉCONISATIONS TECHNIQUES
# ─────────────────────────────────────────────
def build_preconisations(story, data, s):
    story.append(PageBreak())
    story.append(section_header("7. PRÉCONISATIONS TECHNIQUES", s))
    story.append(Spacer(1, 0.3*cm))

    # Pompe
    story.append(subsection_header("7.1  Équipement de pompage", s))
    # Débit nominal = Q_pompe_dim (débit pompe dimensionnant retenu) — cohérent avec la
    # section 5.3 ZRE et la conclusion. Q_theis brut peut être très faible pour des
    # substrats peu transmissifs : il ne doit pas apparaître comme débit nominal.
    Q_nominal = data.get("Q_pompe_dim", data.get("Q_theis", "—"))
    Q_max     = data["Q_max"]
    pompe_text = (
        f"Le débit de dimensionnement de la pompe est compris dans la fourchette suivante : "
        f"<b>{data['Q_min']} m³/h à {Q_max} m³/h</b>. "
        f"Il est recommandé de choisir une pompe immergée de débit nominal de "
        f"<b>{Q_nominal} m³/h</b> (débit pompe dimensionnant retenu, incluant l'apport "
        f"durable de la cuvette lenticulaire le cas échéant), avec une marge de sécurité de ±15 %."
        f"<br/><br/>"
        f"La pompe devra être équipée :"
    )
    story.append(Paragraph(pompe_text, s["body"]))

    pompe_items = [
        "D'un clapet anti-retour en partie basse.",
        "D'un pressostat de contrôle de niveau (protection anti-désamorçage).",
        "D'un débitmètre volumétrique agréé conforme aux exigences réglementaires.",
        "D'un boîtier de télégestion si usage industriel ou agricole intensif.",
        "D'un système de régulation à vitesse variable (recommandé pour optimiser la consommation énergétique).",
    ]
    for item in pompe_items:
        story.append(Paragraph(f"   —  {item}", s["body"]))
    story.append(Spacer(1, 0.3*cm))

    # Système d'exhaure et rejet (rubriques 2.x.x.0)
    story.append(subsection_header("7.2  Système d'exhaure et d'évacuation des eaux", s))
    flux_jour_p = data.get("vol_jour", "—")
    exhaure_text = (
        f"Le rabattement de nappe induit un flux journalier d'eaux d'exhaure de l'ordre de "
        f"<b>{flux_jour_p} m³/j</b>. La gestion de ce volume doit être formalisée dans le "
        f"dossier de déclaration. Les rubriques de la nomenclature IOTA susceptibles de "
        f"s'appliquer au rejet sont détaillées au paragraphe 5.4 du présent document. Les "
        f"préconisations techniques associées sont les suivantes :"
    )
    story.append(Paragraph(exhaure_text, s["body"]))
    story.append(Spacer(1, 0.2*cm))
    story.append(Paragraph("<b>Pré-traitement avant rejet :</b>", s["body_bold"]))
    pretraitement = [
        "Bassin de décantation dimensionné pour un temps de transit minimal de 24 à 48 h.",
        "Déshuileur / séparateur à hydrocarbures si présence d'engins thermiques au droit du chantier.",
        "Filtration complémentaire (sable, géotextile) si la teneur en MES excède les seuils de l'exutoire.",
        "Contrôle des paramètres pH, conductivité, MES, hydrocarbures totaux avant rejet.",
    ]
    for it in pretraitement:
        story.append(Paragraph(f"   —  {it}", s["body"]))
    story.append(Spacer(1, 0.2*cm))

    story.append(Paragraph("<b>Modes d'évacuation envisageables (à arrêter dans le dossier) :</b>", s["body_bold"]))
    evacuation = [
        "Rejet en milieu superficiel (fossé, cours d'eau) — rubrique 2.2.1.0 (D si Q ≥ 2 000 m³/j) éventuellement cumulée à 2.2.3.0 selon flux polluants.",
        "Rejet en réseau pluvial communal sur convention écrite avec le gestionnaire — rubrique 2.1.5.0 à vérifier selon la surface du bassin versant intercepté.",
        "Infiltration via bassin tampon à fond perméable (sous réserve compatibilité ZRE et qualité des eaux).",
        "Réinjection partielle dans la nappe (rubrique 2.3.1.0 — autorisation requise, rejet direct interdit hors dérogation).",
        "Réutilisation pour arrosage / irrigation chantier (sous réserve d'analyses physico-chimiques de compatibilité).",
    ]
    for it in evacuation:
        story.append(Paragraph(f"   —  {it}", s["body"]))
    story.append(Spacer(1, 0.2*cm))

    story.append(Paragraph(
        "<b>Suivi qualitatif des rejets :</b> caractérisation analytique préalable (MES, DBO5, "
        "DCO, hydrocarbures totaux, métaux dissous) puis suivi périodique pendant la phase "
        "d'exploitation, conformément aux prescriptions de l'arrêté de prescriptions générales "
        "applicable et aux exigences du gestionnaire de l'exutoire.",
        s["body"]
    ))
    story.append(Spacer(1, 0.3*cm))

    # Suivi piézométrique
    story.append(subsection_header("7.3  Suivi piézométrique", s))
    piezo_text = (
        "Il est fortement recommandé de mettre en place un suivi régulier du niveau piézométrique "
        "de la nappe, notamment :"
    )
    story.append(Paragraph(piezo_text, s["body"]))
    piezo_items = [
        "Mesure du niveau statique avant chaque campagne de pompage.",
        "Suivi du niveau dynamique en cours de pompage (fréquence minimale : toutes les heures).",
        "Mesure du niveau de remontée après arrêt du pompage.",
        "Enregistrement et archivage des données sur une durée minimale de 5 ans.",
    ]
    for item in piezo_items:
        story.append(Paragraph(f"   —  {item}", s["body"]))
    story.append(Spacer(1, 0.3*cm))

    # Tête de puits
    story.append(subsection_header("7.4  Protection et tête de puits", s))
    tete_text = (
        f"La tête d'ouvrage devra être protégée contre les pollutions superficielles par :"
        f"<br/>—  Une margelle bétonnée ou une dalle périphérique étanche (rayon minimal 0,5 m)."
        f"<br/>—  Un capot verrouillé étanche aux eaux de ruissellement."
        f"<br/>—  Un espace annulaire cimenté sur au moins {data.get('cimentage', '2 m')}."
        f"<br/><br/>"
        f"L'altimétrie de la tête d'ouvrage est de {data['alti_tete']} m NGF. "
        f"Elle doit être supérieure au niveau des plus hautes eaux connues sur le site."
    )
    story.append(Paragraph(tete_text, s["body"]))
    story.append(Spacer(1, 0.4*cm))


# ─────────────────────────────────────────────
# 7. CONCLUSION
# ─────────────────────────────────────────────
def build_conclusion(story, data, s):
    story.append(section_header("8. CONCLUSION — SYNTHÈSE", s))
    story.append(Spacer(1, 0.3*cm))

    date_str = datetime.now().strftime("%d/%m/%Y")
    vol_a_f = data.get("vol_an_float", 0)
    # Débit pompe dimensionnant retenu (Q_pompe_dim) — cohérent avec la section ZRE 1.3.1.0
    q_h_v   = safe_float(data.get("Q_pompe_dim", data.get("Q_theis", 0)))

    # ====== Variables géo-résolues automatiquement (geo_resolver → X/Y Lambert 93) ======
    _commune       = data.get("commune", "—")
    _insee         = data.get("code_insee", "—")
    _zstat         = data.get("zre_statut", "À VÉRIFIER")
    _zre_confirme  = bool(data.get("zre_confirme", False))
    _zre_presomp   = bool(data.get("zre_presomption", False))
    _zre_actif     = bool(data.get("zre_actif", False))
    _zre_nappe     = data.get("zre_nappe", "—")
    _zre_arrete    = data.get("zre_arrete", "—")
    _zre_date_maj  = data.get("zre_date_maj", "—")
    _zre_source    = data.get("zre_source", "—")
    _zre_communes_d= data.get("zre_communes_deleguees", []) or []
    _bassin_dce_c  = data.get("bassin_dce", "—")
    _agence_eau    = data.get("agence_eau", "—")
    _sdage_c       = data.get("sdage", "—")
    _sage_c        = data.get("sage", "—")
    _meso_code_c   = data.get("meso_code", "—")
    _meso_lib_c    = data.get("meso_libelle", "—")

    zre_seuil_autorisation = (_zre_actif and q_h_v >= 8.0)

    # ====== Garde-fou physique : fouille hors d'eau prime sur tout ======
    _fouille_hors_eau = bool(data.get("fouille_hors_eau", False))
    _ff_val = safe_float(data.get("fond_fouille", data.get("FF", 0)))
    _ns_val = safe_float(data.get("niveau_statique", data.get("NS", 0)))

    # ====== Régime réglementaire déduit du contexte ======
    if _fouille_hors_eau:
        regime_synthese = "HORS NOMENCLATURE — aucun pompage gravitaire requis"
        commentaire = (
            f"égal à 0 m³/an : le fond de fouille ({_ff_val:.2f} m/TN) étant <b>au-dessus du "
            f"niveau d'eau</b> ({_ns_val:.2f} m/TN), aucun pompage gravitaire n'est requis et "
            f"le projet <b>ne déclenche aucune rubrique de la nomenclature IOTA</b> liée au "
            f"prélèvement (rubriques 1.1.1.0, 1.1.2.0, 1.3.1.0)"
        )
    elif _zre_actif and zre_seuil_autorisation:
        regime_synthese = "AUTORISATION ENVIRONNEMENTALE (rubriques 1.1.1.0 + 1.1.2.0 + 1.3.1.0 cumulées)"
        commentaire = (
            f"compris entre 10 000 et 200 000 m³/an. Au seul titre de la rubrique 1.1.2.0, "
            f"le projet relèverait d'une déclaration. Toutefois, la commune étant "
            f"<b>{'confirmée' if _zre_confirme else 'en présomption'} en ZRE \"{_zre_nappe}\"</b> "
            f"et le débit prévisionnel ({q_h_v:.2f} m³/h) étant supérieur au seuil de 8 m³/h, "
            f"le régime <b>AUTORISATION</b> de la rubrique 1.3.1.0 prime et impose une "
            f"<b>autorisation environnementale unique (R.181-13)</b>"
        )
    elif vol_a_f >= 200000:
        regime_synthese = "AUTORISATION ENVIRONNEMENTALE (rubrique 1.1.2.0)"
        commentaire = (
            "supérieur au seuil de 200 000 m³/an : le projet relève d'une <b>autorisation "
            "environnementale (R.181-13)</b> au titre de la rubrique 1.1.2.0"
        )
    elif vol_a_f >= 10000 and _zre_actif:
        regime_synthese = "DÉCLARATION (rubriques 1.1.1.0 + 1.1.2.0 + 1.3.1.0 cumulées)"
        commentaire = (
            "compris entre 10 000 et 200 000 m³/an : le projet relève d'une <b>déclaration "
            "unique cumulant les rubriques 1.1.1.0, 1.1.2.0 et 1.3.1.0 (alinéa 2°)</b>"
        )
    elif vol_a_f >= 10000:
        regime_synthese = "DÉCLARATION (rubriques 1.1.1.0 + 1.1.2.0 cumulées)"
        commentaire = (
            "compris entre 10 000 et 200 000 m³/an : le projet relève d'une <b>déclaration "
            "cumulant les rubriques 1.1.1.0 et 1.1.2.0</b>"
        )
    elif _zre_actif:
        regime_synthese = "DÉCLARATION (rubriques 1.1.1.0 + 1.3.1.0)"
        commentaire = (
            "inférieur au seuil de 10 000 m³/an : la rubrique 1.1.1.0 (création d'ouvrage) "
            "et la rubrique 1.3.1.0 alinéa 2° (ZRE) restent à déclarer"
        )
    else:
        regime_synthese = "DÉCLARATION (rubrique 1.1.1.0)"
        commentaire = (
            "inférieur au seuil de 10 000 m³/an : seule la rubrique 1.1.1.0 "
            "(création d'ouvrage souterrain non domestique) reste à déclarer"
        )

    # ====== Bloc ZRE dynamique (4 cas : hors eau / confirmé / présomption / non ZRE) ======
    if _fouille_hors_eau:
        zre_block = (
            f"<b>Statut réglementaire :</b> le fond de fouille projeté ({_ff_val:.2f} m/TN) "
            f"est situé <b>au-dessus du niveau d'eau</b> ({_ns_val:.2f} m/TN). "
            f"Aucun pompage gravitaire n'est physiquement requis pour la mise hors d'eau de "
            f"la fouille. Le projet <b>ne sollicite donc pas la ressource en eau souterraine</b> "
            f"et <b>n'active aucune rubrique de la nomenclature IOTA</b> liée au prélèvement, "
            f"indépendamment du statut ZRE de la commune."
        )
    elif _zre_confirme:
        _communes_d_str = (
            f" (communes déléguées : {', '.join(_zre_communes_d)})"
            if _zre_communes_d else ""
        )
        zre_block = (
            f"<b>Statut ZRE — CONFIRMÉ :</b> la commune de {_commune} (INSEE {_insee}){_communes_d_str} "
            f"est <b>officiellement classée en Zone de Répartition des Eaux</b> au titre de la "
            f"nappe \"{_zre_nappe}\" ({_zre_arrete}). Cette inscription est attestée par {_zre_source} "
            f"(mise à jour {_zre_date_maj}). Le débit prévisionnel ({q_h_v:.2f} m³/h) "
        )
        if zre_seuil_autorisation:
            zre_block += (
                f"<b>dépasse</b> le seuil de 8 m³/h de la rubrique 1.3.1.0 alinéa 1° : le projet "
                f"est en conséquence soumis à <b>autorisation environnementale</b>, qui prime sur "
                f"la procédure de déclaration des rubriques 1.1.x.0."
            )
        else:
            zre_block += (
                f"est <b>inférieur</b> au seuil de 8 m³/h de la rubrique 1.3.1.0 alinéa 1° : "
                f"le projet relève de la déclaration au titre de l'alinéa 2° de cette rubrique, "
                f"cumulable avec les rubriques 1.1.1.0 et 1.1.2.0."
            )
    elif _zre_presomp:
        zre_block = (
            f"<b>Statut ZRE — PRÉSOMPTION :</b> la commune de {_commune} (INSEE {_insee}) est "
            f"située dans l'emprise de la nappe \"{_zre_nappe}\". Une <b>vérification auprès de la "
            f"DDT du département et de la mairie</b> est requise pour confirmer le classement "
            f"officiel ZRE avant dépôt du dossier. "
            + (f"En cas de confirmation, et compte tenu d'un débit prévisionnel de {q_h_v:.2f} m³/h "
               f"&gt; 8 m³/h, le projet relèverait d'une autorisation environnementale (rubrique 1.3.1.0 alinéa 1°)."
               if q_h_v >= 8.0
               else f"Même en cas de confirmation, le débit prévisionnel ({q_h_v:.2f} m³/h) restant "
                    f"inférieur à 8 m³/h, le projet relèverait de la déclaration au titre de "
                    f"l'alinéa 2° de la rubrique 1.3.1.0.")
        )
    else:
        zre_block = (
            f"<b>Statut ZRE — NON CONCERNÉ :</b> la commune de {_commune} (INSEE {_insee}) "
            f"n'apparaît pas dans les listes officielles de communes classées en Zone de "
            f"Répartition des Eaux du bassin {_bassin_dce_c}. La rubrique 1.3.1.0 n'est en "
            f"conséquence pas activée par le présent projet. "
            f"<i>Cette information sera à confirmer par interrogation de la DDT compétente lors "
            f"de l'instruction du dossier.</i>"
        )

    # ====== Bloc masse d'eau dynamique ======
    if _meso_code_c and _meso_code_c != "—":
        meso_url_short = f"id.eaufrance.fr/MasseDEauSouterraine/{_meso_code_c.replace('FR', '')}"
        meso_block = (
            f"<b>Masse d'eau souterraine concernée :</b> {_meso_code_c} ({_meso_lib_c}) — "
            f"{_sdage_c}, {_sage_c}. Référentiel SANDRE : {meso_url_short}."
        )
    else:
        meso_block = (
            f"<b>Masse d'eau souterraine concernée :</b> à confirmer par interrogation du "
            f"référentiel SANDRE — {_sdage_c}."
        )

    conclu_text = (
        f"Le présent dossier établit les paramètres de fonctionnement du captage d'eaux souterraines "
        f"projeté par <b>{data['mo_nom']}</b> sur le site de <b>{_commune}</b> (INSEE {_insee}, "
        f"bassin {_bassin_dce_c})."
        f"<br/><br/>"
        f"Les calculs réalisés selon les méthodes de Theis (régime transitoire) et Dupuit-Thiem "
        f"(régime permanent), sur la base des paramètres hydrogéologiques du substrat "
        f"<b>{data['substrat']}</b>, montrent que le captage est compatible avec les ressources "
        f"en eau disponibles dans les conditions hydrauliques définies."
        f"<br/><br/>"
        f"Le volume annuel prévisionnel de <b>{data['vol_an']} m³/an</b> est {commentaire} de la "
        f"nomenclature IOTA (article R.214-1 du Code de l'Environnement)."
        f"<br/><br/>"
        f"<b>Régime réglementaire applicable :</b> {regime_synthese}."
        f"<br/><br/>"
        f"{zre_block}"
        f"<br/><br/>"
        f"{meso_block}"
        f"<br/><br/>"
        f"<b>Eaux d'exhaure :</b> l'exutoire des eaux pompées devra être formellement défini dans "
        f"le dossier déposé. Les rubriques 2.1.5.0, 2.2.1.0, 2.2.3.0 et 2.3.1.0 sont susceptibles "
        f"d'être activées selon le mode de rejet retenu."
    )
    story.append(Paragraph(conclu_text, s["body"]))
    story.append(Spacer(1, 0.4*cm))

    # Tableau de synthèse (groupé avec son titre)
    story.append(PageBreak())
    bloc_syn = [Paragraph("Tableau de synthèse :", s["subsection_title"])]

    synthese_data = [
        ["Paramètre", "Valeur", "Unité"],
        ["Substrat géologique", data["substrat"], "—"],
        ["Transmissivité calculée (T)", str(data["T_calc"]).replace(" m²/s", ""), "m²/s"],
        ["Conductivité hydraulique (K)", str(data["geo_K"]).replace(" m/s", ""), "m/s"],
        ["Coefficient d'emmagasinement (S)", data["geo_S_libre"], "—"],
        ["Rabattement visé (s)", str(data["rabattement_s"]).replace(" m", ""), "m"],
        ["Débit Theis (régime transitoire)", data["Q_theis"], "m³/h"],
        ["Débit Dupuit-Thiem (régime permanent)", data["Q_dupuit"], "m³/h"],
        ["Fourchette recommandée", f"{data['Q_min']} à {data['Q_max']}", "m³/h"],
        ["Volume journalier", data["vol_jour"], "m³/j"],
        ["Volume annuel estimé", data["vol_an"], "m³/an"],
        ["Statut IOTA", data["statut_iota"], "—"],
    ]

    syn_rows_formatted = []
    for i, row in enumerate(synthese_data):
        if i == 0:
            syn_rows_formatted.append([
                Paragraph(f"<b>{c}</b>", ParagraphStyle("sh",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_WHITE,
                    alignment=TA_CENTER, leading=12))
                for c in row
            ])
        elif i == len(synthese_data) - 1:
            syn_rows_formatted.append([
                Paragraph(str(row[0]), ParagraphStyle("sk",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_TEAL_DARK,
                    alignment=TA_LEFT, leading=12)),
                Paragraph(str(row[1]), ParagraphStyle("sv",
                    fontName=FONT_BOLD, fontSize=9.5, textColor=C_GREEN_DARK,
                    alignment=TA_CENTER, leading=12)),
                Paragraph(str(row[2]), ParagraphStyle("su",
                    fontName=FONT_BODY, fontSize=9, textColor=C_GREY_DARK,
                    alignment=TA_CENTER, leading=12)),
            ])
        else:
            syn_rows_formatted.append([
                Paragraph(str(row[0]), ParagraphStyle("sk2",
                    fontName=FONT_BODY, fontSize=9, textColor=C_TEAL_DARK,
                    alignment=TA_LEFT, leading=12)),
                Paragraph(str(row[1]), ParagraphStyle("sv2",
                    fontName=FONT_BOLD, fontSize=9, textColor=C_BLACK,
                    alignment=TA_CENTER, leading=12)),
                Paragraph(str(row[2]), ParagraphStyle("su2",
                    fontName=FONT_BODY, fontSize=8.5, textColor=C_GREY_DARK,
                    alignment=TA_CENTER, leading=12)),
            ])

    syn_tbl = Table(syn_rows_formatted, colWidths=[8*cm, 5.5*cm, 3.5*cm])
    syn_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), C_TEAL_DARK),
        ("BACKGROUND",    (0,-1), (-1,-1), HexColor("#E8F4E8")),
        ("ALIGN",         (1,0), (-1,-1), "CENTER"),
        ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
        ("LEFTPADDING",   (0,0), (-1,-1), 8),
        ("RIGHTPADDING",  (0,0), (-1,-1), 8),
        ("TOPPADDING",    (0,0), (-1,-1), 5),
        ("BOTTOMPADDING", (0,0), (-1,-1), 5),
        ("ROWBACKGROUNDS",(0,1), (-1,-2), [C_WHITE, C_TEAL_XLIGHT]),
        ("GRID",          (0,0), (-1,-1), 0.4, C_GREY_MED),
        ("LINEBELOW",     (0,0), (-1,0), 1.0, C_TEAL_DARK),
        ("LINEABOVE",     (0,-1), (-1,-1), 1.5, C_GREEN_DARK),
    ]))
    bloc_syn.append(syn_tbl)
    story.append(KeepTogether(bloc_syn))
    story.append(Spacer(1, 0.5*cm))

    # Signature
    sig_data = [
        [Paragraph("Établi par :", ParagraphStyle("sl",
            fontName=FONT_BOLD, fontSize=9, textColor=C_TEAL_DARK, leading=12)),
         Paragraph("Visa :", ParagraphStyle("sl2",
            fontName=FONT_BOLD, fontSize=9, textColor=C_TEAL_DARK,
            alignment=TA_CENTER, leading=12))],
        [Paragraph(f"<b>{data['be_nom']}</b><br/>"
                   f"{data['be_adresse']}<br/>"
                   f"{data['be_cp_ville']}<br/>"
                   f"{data['be_email']}<br/><br/>"
                   f"Le {date_str}",
                   ParagraphStyle("be2", fontName=FONT_BODY, fontSize=9, leading=13,
                                  textColor=C_BLACK)),
         Paragraph("", ParagraphStyle("sig", fontName=FONT_BODY, fontSize=9, leading=13))],
    ]
    sig_tbl = Table(sig_data, colWidths=[9*cm, 8*cm])
    sig_tbl.setStyle(TableStyle([
        ("BACKGROUND",    (0,0), (-1,0), C_TEAL_XLIGHT),
        ("VALIGN",        (0,0), (-1,-1), "TOP"),
        ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ("RIGHTPADDING",  (0,0), (-1,-1), 10),
        ("TOPPADDING",    (0,0), (-1,-1), 8),
        ("BOTTOMPADDING", (0,0), (-1,-1), 8),
        ("BOX",           (0,0), (-1,-1), 0.8, C_TEAL_DARK),
        ("INNERGRID",     (0,0), (-1,-1), 0.3, C_GREY_MED),
        ("ROWSPAN",       (1,1), (1,1)),
        ("MINROWHEIGHT",  (0,1), (-1,1), 2.5*cm),
    ]))
    story.append(sig_tbl)


# ─────────────────────────────────────────────
# EN-TÊTE ET PIED DE PAGE
# ─────────────────────────────────────────────
def make_header_footer(data):
    be_nom    = data.get("be_nom", "G.M.E.P")
    be_adresse= data.get("be_adresse", "9 rue de la Marne")
    be_cp     = data.get("be_cp_ville", "79400 Saint-Maixent-l'École")
    be_email  = data.get("be_email", "gmep.france@gmail.com")
    ref       = data.get("ref_dossier", "—")
    commune   = data.get("commune", "—")
    mo        = data.get("mo_nom", "—")
    date_str  = datetime.now().strftime("%d/%m/%Y")
    # Libellé d'en-tête dynamique selon statut IOTA
    _stat_hf = str(data.get("statut_iota", "")).upper()
    if _stat_hf.startswith("AUTORISATION"):
        _hdr_label = "Dossier d'autorisation environnementale Loi sur l'Eau"
    elif _stat_hf.startswith("HORS NOMENCLATURE"):
        _hdr_label = "Dossier technique \u2014 Hors nomenclature IOTA"
    else:
        _hdr_label = "Dossier de d\u00e9claration Loi sur l'Eau"

    def draw(canvas_obj, doc):
        canvas_obj.saveState()
        page_w, page_h = A4

        # ── En-tête (sauf page de garde = page 1) ──
        if doc.page > 1:
            # Bande de fond
            canvas_obj.setFillColor(C_TEAL_DARK)
            canvas_obj.rect(1.5*cm, page_h - 1.8*cm,
                            page_w - 3*cm, 1.2*cm, fill=1, stroke=0)

            # Titre à gauche
            canvas_obj.setFillColor(C_WHITE)
            canvas_obj.setFont(FONT_BOLD, 8.5)
            canvas_obj.drawString(1.8*cm, page_h - 1.25*cm,
                f"G.M.E.P  \u2014  {_hdr_label}")

            # Référence à droite
            canvas_obj.setFont(FONT_BODY, 7.5)
            canvas_obj.drawRightString(page_w - 1.8*cm, page_h - 1.25*cm,
                f"Réf. : {ref}  |  {commune}")

        # ── Pied de page ──
        # Ligne
        canvas_obj.setStrokeColor(C_TEAL_DARK)
        canvas_obj.setLineWidth(0.8)
        canvas_obj.line(1.5*cm, 1.6*cm, page_w - 1.5*cm, 1.6*cm)

        # Bureau d'études
        canvas_obj.setFillColor(C_TEAL_DARK)
        canvas_obj.setFont(FONT_BOLD, 7)
        canvas_obj.drawString(1.5*cm, 1.2*cm, f"{be_nom}")
        canvas_obj.setFont(FONT_BODY, 6.5)
        canvas_obj.setFillColor(C_GREY_DARK)
        canvas_obj.drawString(1.5*cm, 0.85*cm,
            f"{be_adresse}  |  {be_cp}  |  {be_email}")

        # Maître d'ouvrage
        canvas_obj.setFont(FONT_BODY, 6.5)
        canvas_obj.setFillColor(C_GREY_DARK)
        canvas_obj.drawCentredString(page_w/2, 1.2*cm, f"MO : {mo}  |  {date_str}")

        # Numéro de page
        canvas_obj.setFont(FONT_BOLD, 7.5)
        canvas_obj.setFillColor(C_TEAL_DARK)
        canvas_obj.drawRightString(page_w - 1.5*cm, 1.2*cm, f"Page {doc.page}")

        canvas_obj.restoreState()

    return draw


# ─────────────────────────────────────────────
# SECTION CARTES RÉGLEMENTAIRES
# ─────────────────────────────────────────────
def build_cartes(story, data, s, map_paths):
    """Section 2bis — Cartes réglementaires intégrées au rapport."""
    story.append(PageBreak())
    story.append(section_header(
        "2bis. CONTEXTE GÉOGRAPHIQUE ET RÉGLEMENTAIRE — CARTES", s))
    story.append(Spacer(1, 0.3*cm))

    # Coordonnées Lambert 93
    from pyproj import Transformer
    tr = Transformer.from_crs("EPSG:2154", "EPSG:4326", always_xy=True)
    lon, lat = tr.transform(data["lambert_x"], data["lambert_y"])

    # Mention finale conditionnelle selon statut IOTA réel
    _is_hors_nom = bool(data.get("fouille_hors_eau", False))
    _statut_iota_str = str(data.get("statut_iota", ""))
    _is_autorisation_iota = ("AUTORISATION" in _statut_iota_str.upper())
    if _is_hors_nom:
        _mention_doc = ("Elles complètent le dossier technique informatif établi à titre conservatoire — "
                        "le projet est hors nomenclature IOTA (fond de fouille au-dessus du niveau d'eau).")
    elif _is_autorisation_iota:
        _mention_doc = ("Elles correspondent aux exigences documentaires du dossier de demande "
                        "d'autorisation environnementale au titre des Rubriques 1.1.1.0, 1.1.2.0 et 1.3.1.0 (ZRE).")
    else:
        _mention_doc = ("Elles correspondent aux exigences documentaires du dossier de déclaration "
                        "au titre des Rubriques 1.1.1.0 et 1.1.2.0.")
    intro_text = (
        f"Le site est localisé en coordonnées Lambert 93 (RGF93, EPSG:2154) à :"
        f" <b>X = {data['lambert_x']:,.0f} m</b> — <b>Y = {data['lambert_y']:,.0f} m</b>."
        f" L'altitude de la tête d'ouvrage est de <b>{data['alti_ngf']:.1f} m NGF</b> (IGN69)."
        f"<br/>Coordonnées WGS84 : lat {lat:.5f}° N — lon {lon:.5f}° E."
        f"<br/><br/>"
        f"Les cartes ci-dessous ont été générées automatiquement à partir de la position "
        f"du site et des services cartographiques publics français (IGN Géoportail, "
        f"BRGM InfoTerre, Eau France SANDRE, Patrinat). {_mention_doc}"
    ).replace(",", " ")
    story.append(Paragraph(intro_text, s["body"]))
    story.append(Spacer(1, 0.3*cm))

    # Tableau des cartes à présenter
    CARTE_DEFS = [
        ("localisation",  "Carte 1", "Localisation générale",
         "Emprise ± 8 km — échelle approx. 1:100 000",
         "Identification et situation du site dans son contexte régional.",
         "Source : IGN Géoportail PLANIGNV2"),
        ("topographique", "Carte 2", "Topographique du site",
         "Emprise ± 1 500 m — échelle approx. 1:25 000",
         "Contexte topographique local : relief, routes, bâti, végétation.",
         "Source : IGN Géoportail PLANIGNV2"),
        ("geologique",   "Carte 3", "Géologique",
         "Emprise ± 3 km — échelle approx. 1:50 000",
         "Nature du substrat géologique et formations affleurantes. "
         "Points BSS (ouvrages répertoriés BRGM).",
         "Source : BRGM InfoTerre — Carte géologique 50 000e"),
        ("hydrologique",  "Carte 4", "Hydrologique",
         "Emprise ± 2 500 m — échelle approx. 1:25 000",
         "Réseau hydrographique, zones hydrologiques SANDRE et cours d'eau voisins.",
         "Source : IGN Hydrographie + Eau France SANDRE"),
        ("masses_eau",   "Carte 5", "Masses d'eau souterraine (DCE)",
         "Emprise ± 10 km — échelle approx. 1:200 000",
         "Masse(s) d'eau souterraine au sens de la Directive Cadre sur l'Eau (2000/60/CE). "
         "Ouvrages BSS BRGM sur la zone.",
         "Source : Eau France MDO + BRGM BSS"),
        ("znieff",       "Carte 6", "ZNIEFF et Natura 2000",
         "Emprise ± 5 km — échelle approx. 1:50 000",
         "Zones Naturelles d'Intérêt Écologique, Faunistique et Floristique "
         "(type I et II) et zones Natura 2000 dans un rayon de 5 km du site.",
         "Source : Patrinat / data.geopf"),
        ("synthese",     "Carte 7", "Synthèse multi-couches",
         "Emprise ± 3 km — échelle approx. 1:50 000",
         "Carte de synthèse réglementaire superposant l'ensemble des couches thématiques "
         "sur fond IGN/OSM : géologie BRGM, hydrographie, masses d'eau souterraine DCE, "
         "ZNIEFF type I et II, zones Natura 2000, ouvrages BSS et site du projet. "
         "Permet d'apprécier d'un seul regard les enjeux environnementaux croisés.",
         "Sources : IGN · BRGM · SANDRE · Patrinat / data.geopf"),
        ("bss",          "Carte 8", "Ouvrages BSS voisins",
         "Emprise ± 1,5 km — échelle approx. 1:25 000",
         "Cartographie des ouvrages référencés en Banque du Sous-Sol (BSS) du BRGM dans "
         "un rayon de 1,5 km autour du forage projet : forages AEP, forages domestiques, "
         "pompes à chaleur, piézomètres et puits anciens. Chaque ouvrage est positionné "
         "avec son code BSS et sa profondeur. Cette carte permet d'évaluer la cohérence "
         "du dimensionnement avec les ouvrages voisins exploitant la même nappe.",
         "Sources : BRGM InfoTerre / Hub'Eau Piézométrie"),
    ]

    IMG_W = 16 * cm   # largeur de l'image dans le PDF
    IMG_H = 16 * cm   # hauteur

    for idx, (key, num, titre, echelle, description, source) in enumerate(CARTE_DEFS):
        # Metadonnées de la carte
        meta_rows = [
            ("Emprise / échelle", echelle),
            ("Description",      description),
            ("Source",           source),
        ]
        meta_tbl = Table(
            [[Paragraph(f"<b>{k}</b>", ParagraphStyle("mk",
                fontName=FONT_BOLD, fontSize=8.5, textColor=C_TEAL_DARK, leading=12)),
              Paragraph(v, ParagraphStyle("mv",
                fontName=FONT_BODY, fontSize=8.5, leading=12))]
             for k, v in meta_rows],
            colWidths=[4*cm, 13*cm]
        )
        meta_tbl.setStyle(TableStyle([
            ("ALIGN",         (0,0), (-1,-1), "LEFT"),
            ("VALIGN",        (0,0), (-1,-1), "MIDDLE"),
            ("LEFTPADDING",   (0,0), (-1,-1), 6),
            ("RIGHTPADDING",  (0,0), (-1,-1), 6),
            ("TOPPADDING",    (0,0), (-1,-1), 3),
            ("BOTTOMPADDING", (0,0), (-1,-1), 3),
            ("ROWBACKGROUNDS",(0,0), (-1,-1), [C_WHITE, C_TEAL_XLIGHT]),
            ("GRID",          (0,0), (-1,-1), 0.3, C_GREY_MED),
        ]))

        # Image de la carte
        img_path = map_paths.get(key)
        carte_block = [
            subsection_header(f"{num} — {titre}", s),
            Spacer(1, 0.1*cm),
            meta_tbl,
            Spacer(1, 0.2*cm),
        ]
        if img_path and os.path.exists(img_path):
            img_tbl = Table(
                [[RLImage(img_path, width=IMG_W, height=IMG_H)]],
                colWidths=[IMG_W + 0.4*cm]
            )
            img_tbl.setStyle(TableStyle([
                ("BOX",          (0,0), (-1,-1), 1.5, C_TEAL_DARK),
                ("LEFTPADDING",  (0,0), (-1,-1), 2),
                ("RIGHTPADDING", (0,0), (-1,-1), 2),
                ("TOPPADDING",   (0,0), (-1,-1), 2),
                ("BOTTOMPADDING",(0,0), (-1,-1), 2),
            ]))
            carte_block.append(img_tbl)
        else:
            carte_block.append(Paragraph(
                f"[Carte non disponible — {img_path}]",
                s["note"]))

        story.append(KeepTogether(carte_block))
        # Saut de page entre cartes (sauf après la dernière)
        if idx < len(CARTE_DEFS) - 1:
            story.append(PageBreak())

    # ═══════════════════════════════════════════════════════════════
    # SECTION : CADASTRE & OUVRAGES BSS VOISINS
    # (lue depuis geocode_result.json si disponible)
    # ═══════════════════════════════════════════════════════════════
    geocode_path = os.path.join(os.path.dirname(__file__), "geocode_result.json")
    if os.path.exists(geocode_path):
        try:
            with open(geocode_path, "r", encoding="utf-8") as f:
                geo = json.load(f)
        except Exception:
            geo = None

        # ── SYNCHRONISATION OBLIGATOIRE des X/Y avec le tableur (C33/C34) ──
        # Si l'utilisateur modifie les coordonnées Lambert 93 dans Excel,
        # le tableau Cadastre du PDF doit reprendre ces nouvelles valeurs,
        # même si le cache geocode_result.json n'a pas été régénéré.
        if geo:
            try:
                _x_excel = float(data.get("lambert_x", 0))
                _y_excel = float(data.get("lambert_y", 0))
                _x_cache = float(geo.get("x_l93", 0))
                _y_cache = float(geo.get("y_l93", 0))
                if (abs(_x_excel - _x_cache) > 0.5) or (abs(_y_excel - _y_cache) > 0.5):
                    print(f"  Synchro cadastre : X/Y du tableur ({_x_excel:.2f}, {_y_excel:.2f}) "
                          f"≠ cache ({_x_cache:.2f}, {_y_cache:.2f}) → mise à jour")
                    geo["x_l93"] = _x_excel
                    geo["y_l93"] = _y_excel
                    # Recalcul WGS84 à partir des nouvelles coordonnées Lambert 93
                    try:
                        from pyproj import Transformer
                        _tr = Transformer.from_crs("EPSG:2154", "EPSG:4326", always_xy=True)
                        _lon, _lat = _tr.transform(_x_excel, _y_excel)
                        geo["lon_wgs84"] = round(_lon, 6)
                        geo["lat_wgs84"] = round(_lat, 6)
                    except Exception as _e_tr:
                        print(f"  (avertissement) reprojection WGS84 échouée : {_e_tr}")
                    # Reprend l'altitude NGF saisie dans le tableur (C35) si présente
                    _alt_excel = data.get("alti_ngf")
                    if _alt_excel:
                        geo["altitude_ngf_m"] = _alt_excel
                    # Reprend la commune du tableur si elle a changé
                    _commune_excel = data.get("commune")
                    if _commune_excel and _commune_excel != "—":
                        geo["commune"] = _commune_excel
            except (TypeError, ValueError) as _e_sync:
                print(f"  (avertissement) synchro cadastre échouée : {_e_sync}")

        if geo:
            story.append(section_header("CADASTRE & OUVRAGES BSS VOISINS", s))
            story.append(Spacer(1, 0.3*cm))

            story.append(Paragraph(
                "Identification cadastrale et altim\u00e9trique",
                s["subsection_title"]))

            ref_cad = f"{geo.get('code_insee','')} {geo.get('section','')} {str(geo.get('numero','')).zfill(4)}"
            cad_data = [
                ["Param\u00e8tre", "Valeur", "Source"],
                ["R\u00e9f\u00e9rence cadastrale", ref_cad, "API IGN apicarto/cadastre"],
                ["Commune", str(geo.get("commune", "")), "INSEE"],
                ["Surface parcelle", f"{geo.get('surface_parcelle_m2','—')} m\u00b2", "Cadastre IGN"],
                ["Coordonn\u00e9es Lambert 93", f"X = {geo.get('x_l93',0):.2f} m\nY = {geo.get('y_l93',0):.2f} m", "IGN RGF93/L93 EPSG:2154"],
                ["Coordonn\u00e9es WGS84", f"Lat = {geo.get('lat_wgs84',0):.6f}\u00b0\nLon = {geo.get('lon_wgs84',0):.6f}\u00b0", "IGN EPSG:4326"],
                ["Altitude NGF", f"{geo.get('altitude_ngf_m','—')} m", "RGE Alti IGN (alti.geopf.fr)"],
            ]
            cad_tbl = Table(cad_data, colWidths=[5.0*cm, 6.5*cm, 5.0*cm])
            cad_tbl.setStyle(TableStyle([
                ("BACKGROUND",   (0,0), (-1,0), colors.HexColor("#01696F")),
                ("TEXTCOLOR",    (0,0), (-1,0), colors.white),
                ("FONTNAME",     (0,0), (-1,0), "Helvetica-Bold"),
                ("FONTSIZE",     (0,0), (-1,-1), 9),
                ("FONTNAME",     (0,1), (0,-1), "Helvetica-Bold"),
                ("BACKGROUND",   (0,1), (0,-1), colors.HexColor("#F0F7F8")),
                ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
                ("ALIGN",        (0,0), (-1,0),  "CENTER"),
                ("GRID",         (0,0), (-1,-1), 0.4, colors.HexColor("#01696F")),
                ("TOPPADDING",   (0,0), (-1,-1), 5),
                ("BOTTOMPADDING",(0,0), (-1,-1), 5),
                ("LEFTPADDING",  (0,0), (-1,-1), 6),
                ("RIGHTPADDING", (0,0), (-1,-1), 6),
            ]))
            story.append(cad_tbl)
            story.append(Spacer(1, 0.4*cm))

            story.append(Paragraph(
                "Source des donn\u00e9es : API officielle IGN apicarto/cadastre (parcelle), IGN "
                "RGE Alti (altitude NGF, pr\u00e9cision &plusmn; 0,30 m en plaine). Coordonn\u00e9es "
                "projet\u00e9es Lambert 93 (EPSG:2154) - syst\u00e8me l\u00e9gal fran\u00e7ais.",
                s["note"]))
            story.append(Spacer(1, 0.5*cm))

            # ── Tableau des ouvrages BSS voisins ──
            ouvrages = geo.get("ouvrages_bss", []) or []
            if ouvrages:
                story.append(Paragraph(
                    f"Ouvrages souterrains recens\u00e9s en Banque du Sous-Sol (BSS / BRGM) - {len(ouvrages)} ouvrages dans un rayon de 1,5 km",
                    s["subsection_title"]))

                # Style local pour cellules en wrap (Paragraph)
                _bss_cell = ParagraphStyle("bss_cell", fontName=FONT_BODY, fontSize=7.5, leading=9)
                _bss_hdr  = ParagraphStyle("bss_hdr",  fontName=FONT_BOLD, fontSize=8, leading=10, textColor=C_WHITE, alignment=1)

                bss_data = [[Paragraph(h, _bss_hdr) for h in
                             ["Code BSS", "Nature", "Adresse", "Prof.<br/>(m)", "Alt.<br/>NGF", "Niv. eau<br/>(m)", "Usage", "Dist.<br/>(m)"]]]
                for o in ouvrages:
                    prof = f"{o.get('profondeur_m','—')}" if o.get('profondeur_m') is not None else "—"
                    alti = f"{o.get('altitude_ngf','—')}" if o.get('altitude_ngf') is not None else "—"
                    niv  = f"{o.get('niveau_eau_m','—')}" if o.get('niveau_eau_m') is not None else "—"
                    dist = f"{int(o.get('distance_m',0))}" if o.get('distance_m') is not None else "—"
                    adresse = (o.get('adresse','') or '—')
                    nature = (o.get('nature','') or '—')
                    usage = (o.get('usage','') or '—')
                    bss_data.append([
                        Paragraph(str(o.get('code_bss','—')), _bss_cell),
                        Paragraph(nature, _bss_cell),
                        Paragraph(adresse, _bss_cell),
                        prof, alti, niv,
                        Paragraph(usage, _bss_cell),
                        dist,
                    ])

                bss_tbl = Table(bss_data, colWidths=[2.4*cm, 2.6*cm, 3.6*cm, 1.0*cm, 1.0*cm, 1.2*cm, 2.7*cm, 1.0*cm], repeatRows=1)
                bss_tbl.setStyle(TableStyle([
                    ("BACKGROUND",   (0,0), (-1,0), colors.HexColor("#01696F")),
                    ("TEXTCOLOR",    (0,0), (-1,0), colors.white),
                    ("FONTNAME",     (0,0), (-1,0), "Helvetica-Bold"),
                    ("FONTSIZE",     (0,0), (-1,0), 8),
                    ("FONTSIZE",     (0,1), (-1,-1), 7.5),
                    ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
                    ("ALIGN",        (0,0), (-1,0),  "CENTER"),
                    ("ALIGN",        (3,1), (5,-1), "CENTER"),
                    ("ALIGN",        (7,1), (7,-1), "CENTER"),
                    ("GRID",         (0,0), (-1,-1), 0.3, colors.HexColor("#01696F")),
                    ("ROWBACKGROUNDS",(0,1),(-1,-1), [colors.white, colors.HexColor("#F7FAFA")]),
                    ("TOPPADDING",   (0,0), (-1,-1), 4),
                    ("BOTTOMPADDING",(0,0), (-1,-1), 4),
                    ("LEFTPADDING",  (0,0), (-1,-1), 3),
                    ("RIGHTPADDING", (0,0), (-1,-1), 3),
                ]))
                story.append(bss_tbl)
                story.append(Spacer(1, 0.3*cm))
                story.append(Paragraph(
                    "Source : Banque du Sous-Sol BSS / BRGM (infoterre.brgm.fr) - "
                    "Distances calcul\u00e9es depuis l'ouvrage projet\u00e9 sur la parcelle. "
                    "Cf. Carte 8 pour la localisation cartographique.",
                    s["note"]))
                story.append(Spacer(1, 0.6*cm))

                # ── Bloc informatif : profondeur de la masse d'eau souterraine principale ──
                profs = [o.get('profondeur_m') for o in ouvrages if isinstance(o.get('profondeur_m'), (int, float))]
                if profs:
                    prof_min = min(profs)
                    prof_max = max(profs)
                    prof_med = sorted(profs)[len(profs)//2]
                    # Profondeur indicative de la masse d'eau souterraine principale (forages AEP / géothermiques voisins)
                    profs_aep_pac = [o.get('profondeur_m') for o in ouvrages
                                      if isinstance(o.get('profondeur_m'), (int, float))
                                      and any(k in (o.get('nature','') or '') for k in ['AEP','g\u00e9otherm','PAC'])]
                    prof_mes = max(profs_aep_pac) if profs_aep_pac else prof_max
                    prof_mes_finale = round(prof_mes + 5)

                    bloc_prof = []
                    bloc_prof.append(Paragraph(
                        "Profondeur indicative de la masse d'eau souterraine principale",
                        s["subsection_title"]))

                    bloc_prof.append(Paragraph(
                        "\u00c0 titre informatif uniquement \u2014 ces valeurs sont sans rapport avec la profondeur "
                        "du forage projet, qui vise une nappe perch\u00e9e superficielle situ\u00e9e nettement au-dessus.",
                        s["note"]))
                    bloc_prof.append(Spacer(1, 0.2*cm))

                    reco_data = [
                        ["Param\u00e8tre", "Valeur"],
                        ["Profondeur min des ouvrages voisins", f"{prof_min:.1f} m"],
                        ["Profondeur m\u00e9diane", f"{prof_med:.1f} m"],
                        ["Profondeur max des ouvrages voisins", f"{prof_max:.1f} m"],
                        ["Profondeur max forages AEP / g\u00e9othermiques", f"{prof_mes:.1f} m"],
                        ["Profondeur indicative de la masse d'eau souterraine", f"~ {prof_mes_finale} m"],
                    ]
                    reco_tbl = Table(reco_data, colWidths=[10.5*cm, 5.0*cm])
                    reco_tbl.setStyle(TableStyle([
                        ("BACKGROUND",   (0,0), (-1,0), colors.HexColor("#01696F")),
                        ("TEXTCOLOR",    (0,0), (-1,0), colors.white),
                        ("FONTNAME",     (0,0), (-1,0), "Helvetica-Bold"),
                        ("FONTSIZE",     (0,0), (-1,-1), 9),
                        ("FONTNAME",     (0,-1), (-1,-1), "Helvetica-Bold"),
                        ("BACKGROUND",   (0,-1), (-1,-1), colors.HexColor("#E8F4E8")),
                        ("TEXTCOLOR",    (0,-1), (-1,-1), colors.HexColor("#01696F")),
                        ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
                        ("ALIGN",        (0,0), (-1,0),  "CENTER"),
                        ("ALIGN",        (1,1), (1,-1), "CENTER"),
                        ("GRID",         (0,0), (-1,-1), 0.4, colors.HexColor("#01696F")),
                        ("TOPPADDING",   (0,0), (-1,-1), 6),
                        ("BOTTOMPADDING",(0,0), (-1,-1), 6),
                        ("LEFTPADDING",  (0,0), (-1,-1), 8),
                        ("RIGHTPADDING", (0,0), (-1,-1), 8),
                    ]))
                    bloc_prof.append(reco_tbl)
                    bloc_prof.append(Spacer(1, 0.4*cm))

                    bloc_prof.append(Paragraph(
                        "<b>Note informative :</b> localement, la masse d'eau souterraine principale "
                        f"(calcaires karstifi\u00e9s de Beauce) est situ\u00e9e \u00e0 environ <b>{prof_mes_finale} m</b> "
                        "de profondeur sous le terrain naturel, selon les forages AEP et g\u00e9othermiques "
                        "recens\u00e9s en BSS / BRGM dans un rayon de 1,5 km. Cette donn\u00e9e est fournie \u00e0 "
                        "titre de contexte hydrog\u00e9ologique r\u00e9gional. <b>Le pr\u00e9sent dossier ne porte pas "
                        "sur cet aquif\u00e8re profond</b> mais sur la nappe perch\u00e9e superficielle effectivement "
                        "capt\u00e9e par l'ouvrage projet (cf. section suivante).",
                        s["body"]))
                    story.append(KeepTogether(bloc_prof))

            story.append(PageBreak())

    # ═══════════════════════════════════════════════════════════════
    # SECTION : ANALYSE DE LA NAPPE CAPTÉE + COUPE LITHOLOGIQUE
    # ═══════════════════════════════════════════════════════════════
    story.append(section_header("ANALYSE DE LA NAPPE CAPT\u00c9E", s))
    story.append(Spacer(1, 0.3*cm))

    story.append(Paragraph(
        "Diagnostic hydrog\u00e9ologique du forage et identification du substratum capt\u00e9",
        s["subsection_title"]))

    # ── PARAM\u00c8TRES DYNAMIQUES depuis le tableur ──
    _alt_tete   = float(data.get("alti_ngf", 124.63))          # C35
    _NS_m       = float(data.get("NS", 2.8))                   # C63
    _FF_m       = float(data.get("fond_fouille", 3.0))         # C64
    _alt_nappe  = _alt_tete - _NS_m                            # cote NGF de la nappe
    _alt_fond   = _alt_tete - _FF_m                            # cote NGF du fond de fouille
    _substrat   = str(data.get("lithologie", data.get("substrat", "—")) or "—")
    _hors_eau   = bool(data.get("fouille_hors_eau", False))
    _Q_calc     = float(data.get("Q_theis_corr_m3h", data.get("Q_theis", 0)) or 0)

    # ── SC\u00c9NARIO 1 : FOUILLE HORS D'EAU (FF \u2264 NS) ──
    if _hors_eau:
        story.append(Paragraph(
            f"Lors de la r\u00e9alisation du forage, un niveau d'eau a \u00e9t\u00e9 observ\u00e9 \u00e0 "
            f"<b>-{_NS_m:.2f} m</b> sous la t\u00eate de forage (soit \u00e0 la cote "
            f"<b>{_alt_nappe:.2f} m NGF</b>). Cette venue d'eau correspond au "
            f"<b>niveau haut d'une nappe perch\u00e9e superficielle</b>, distincte de la nappe "
            f"r\u00e9gionale principale.",
            s["body"]))
        story.append(Spacer(1, 0.2*cm))
        story.append(Paragraph(
            f"<b>Cal\u00e9e sur cette donn\u00e9e pi\u00e9zom\u00e9trique, la profondeur du puits de pompage "
            f"est limit\u00e9e \u00e0 -{_FF_m:.2f} m / TN (cote fond {_alt_fond:.2f} m NGF)</b>, "
            f"soit <b>au droit (ou au-dessus) du niveau haut de la nappe perch\u00e9e</b> "
            f"({_alt_nappe:.2f} m NGF). Le point bas du puits est ainsi positionn\u00e9 "
            "\u00e0 la limite sup\u00e9rieure de la zone satur\u00e9e perch\u00e9e : aucune \u00e9paisseur "
            "d'eau n'est intercept\u00e9e par la fouille et <b>aucun pompage n'est requis</b> (d\u00e9bit "
            "d'exhaure nul). Cette disposition justifie le classement <b>hors nomenclature IOTA</b> "
            "vis-\u00e0-vis de la rubrique 1.1.2.0 (pr\u00e9l\u00e8vement en nappe).",
            s["body"]))
        story.append(Spacer(1, 0.4*cm))
    # ── SC\u00c9NARIO 2 : FOUILLE EN EAU (FF > NS) ──
    else:
        _s_rab = _FF_m - _NS_m  # rabattement requis
        story.append(Paragraph(
            f"Lors de la r\u00e9alisation du forage, un niveau d'eau a \u00e9t\u00e9 observ\u00e9 \u00e0 "
            f"<b>-{_NS_m:.2f} m</b> sous la t\u00eate de forage (cote <b>{_alt_nappe:.2f} m NGF</b>). "
            f"Le substrat capt\u00e9 est constitu\u00e9 de <b>{_substrat}</b>.",
            s["body"]))
        story.append(Spacer(1, 0.2*cm))
        story.append(Paragraph(
            f"<b>La profondeur projet\u00e9e du fond de fouille est de -{_FF_m:.2f} m / TN "
            f"(cote {_alt_fond:.2f} m NGF)</b>, soit <b>{_s_rab:.2f} m sous le niveau statique "
            f"de la nappe</b>. Un <b>rabattement de {_s_rab:.2f} m</b> est donc n\u00e9cessaire "
            "pour maintenir la fouille hors d'eau pendant les travaux. Le d\u00e9bit de pompage "
            f"correspondant, calcul\u00e9 par les m\u00e9thodes de Theis et Dupuit-Thiem, est de "
            f"<b>Q = {_Q_calc:.2f} m\u00b3/h</b>. Cette op\u00e9ration rel\u00e8ve donc des rubriques "
            "<b>1.1.1.0</b> (sondage/forage), <b>1.1.2.0</b> (pr\u00e9l\u00e8vement en nappe) et, "
            "le cas \u00e9ch\u00e9ant, <b>1.3.1.0</b> (pr\u00e9l\u00e8vement en ZRE) de la nomenclature IOTA.",
            s["body"]))
        story.append(Spacer(1, 0.4*cm))

    # ── Tableau de synth\u00e8se des cotes ── dynamique ──
    cotes_data = [
        ["\u00c9l\u00e9ment", "Profondeur / TN", "Cote NGF"],
        ["T\u00eate de forage (TN)", "0,00 m", f"{_alt_tete:.2f} m"],
        ["Niveau d'eau observ\u00e9 (statique)", f"-{_NS_m:.2f} m", f"{_alt_nappe:.2f} m"],
        [("Fond du forage projet\u00e9 (limite hors d'eau)" if _hors_eau
          else "Fond du forage projet\u00e9 (en eau)"),
         f"-{_FF_m:.2f} m", f"{_alt_fond:.2f} m"],
    ]
    cotes_tbl = Table(cotes_data, colWidths=[8.5*cm, 4.0*cm, 4.0*cm])
    cotes_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,0), colors.HexColor("#01696F")),
        ("TEXTCOLOR",    (0,0), (-1,0), colors.white),
        ("FONTNAME",     (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",     (0,0), (-1,-1), 9),
        ("FONTNAME",     (0,1), (0,-1), "Helvetica-Bold"),
        ("BACKGROUND",   (0,1), (0,-1), colors.HexColor("#F0F7F8")),
        ("BACKGROUND",   (0,2), (-1,2), colors.HexColor("#E3F2FD")),  # nappe
        ("BACKGROUND",   (0,3), (-1,3), colors.HexColor("#E8F4E8")),  # forage projeté
        ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN",        (0,0), (-1,0),  "CENTER"),
        ("ALIGN",        (1,1), (-1,-1), "CENTER"),
        ("GRID",         (0,0), (-1,-1), 0.4, colors.HexColor("#01696F")),
        ("TOPPADDING",   (0,0), (-1,-1), 5),
        ("BOTTOMPADDING",(0,0), (-1,-1), 5),
    ]))
    story.append(cotes_tbl)
    story.append(Spacer(1, 0.5*cm))

    # ── D\u00e9monstration nappe perch\u00e9e ── UNIQUEMENT si sc\u00e9nario hors d'eau ──
    if _hors_eau:
        story.append(Paragraph(
            f"<b>D\u00e9monstration hydrog\u00e9ologique :</b> la nappe observ\u00e9e \u00e0 "
            f"{_alt_nappe:.2f} m NGF est <b>une nappe perch\u00e9e superficielle</b>, distincte "
            "du r\u00e9servoir r\u00e9gional sous-jacent. Les arguments suivants l'\u00e9tablissent :",
            s["body"]))
        arguments = [
            f"<b>S\u00e9paration verticale</b> entre le niveau d'eau observ\u00e9 ({_alt_nappe:.2f} m NGF) "
            "et le toit des calcaires r\u00e9gionaux sous-jacents : cette zone est occup\u00e9e par "
            "des formations majoritairement imperm\u00e9ables (limons, argiles \u00e0 silex, marnes) "
            "qui constituent un <b>plancher imperm\u00e9able</b> pi\u00e9geant les eaux d'infiltration "
            "et formant une nappe perch\u00e9e d'imbibition.",

            "<b>Cote pi\u00e9zom\u00e9trique r\u00e9gionale</b> nettement plus basse que le niveau "
            "d'eau observ\u00e9 : l'eau capt\u00e9e est trop haute pour appartenir au r\u00e9servoir "
            "principal, il s'agit bien d'une nappe perch\u00e9e ind\u00e9pendante.",

            "<b>Type d'aquif\u00e8re</b> : nappe perch\u00e9e d'imbibition, sans inertie propre, "
            "\u00e9paisseur satur\u00e9e r\u00e9duite (\u22c5 quelques d\u00e9cim\u00e8tres \u00e0 quelques m\u00e8tres), "
            "alimentation directe par les pluies efficaces, vidange rapide en \u00e9tiage.",
        ]
        for arg in arguments:
            story.append(Paragraph("&bull; " + arg, s["body"]))
            story.append(Spacer(1, 0.15*cm))

        story.append(Spacer(1, 0.2*cm))
        _marge_cm = (_alt_fond - _alt_nappe) * 100
        story.append(Paragraph(
            f"<b>Calage du point bas du puits de pompage par rapport au niveau haut de la "
            f"nappe perch\u00e9e :</b> le fond du puits projet\u00e9 est positionn\u00e9 \u00e0 "
            f"<b>-{_FF_m:.2f} m / TN (cote {_alt_fond:.2f} m NGF)</b>, soit "
            f"<b>{_marge_cm:+.0f} cm</b> par rapport au niveau haut observ\u00e9 de la nappe "
            f"perch\u00e9e ({_alt_nappe:.2f} m NGF). <b>Aucune \u00e9paisseur d'eau n'est "
            "intercept\u00e9e</b>, le d\u00e9bit d'exhaure est par cons\u00e9quent "
            "<b>nul (0 m\u00b3/h)</b>, ce qui place le projet <b>hors nomenclature IOTA</b> "
            "vis-\u00e0-vis de la rubrique 1.1.2.0 (pr\u00e9l\u00e8vement en nappe).",
            s["body"]))
    else:
        # ── Cas EN EAU : on d\u00e9crit le contexte hydrog\u00e9ologique sans th\u00e8se nappe perch\u00e9e ──
        story.append(Paragraph(
            f"<b>Contexte hydrog\u00e9ologique :</b> le fond de fouille intercepte la nappe sur "
            f"une \u00e9paisseur de <b>{(_FF_m - _NS_m):.2f} m</b>. Un dispositif de pompage "
            "d'exhaure est n\u00e9cessaire pendant toute la dur\u00e9e des travaux pour maintenir "
            "la fouille hors d'eau. Le projet rel\u00e8ve donc des rubriques IOTA correspondantes "
            "(rabattement de nappe, pr\u00e9l\u00e8vement temporaire) et fait l'objet d'une "
            "<b>d\u00e9claration ou autorisation</b> au titre de la Loi sur l'Eau selon les seuils "
            "de la nomenclature R.214-1 (cf. section r\u00e9glementaire ci-apr\u00e8s).",
            s["body"]))

    story.append(PageBreak())

    # ── Coupe lithologique réelle — v15.82 ──
    story.append(Paragraph(
        "Coupe lithologique forage — données saisies",
        s["subsection_title"]))

    coupe_path = os.path.join(os.path.dirname(__file__), "cartes_gmep", "Coupe_Lithologique_Forage.png")
    # Toujours régénérer pour refléter les données réelles saisies dans l'onglet Coupe_Geologique (v15.82)
    try:
        if os.path.exists(coupe_path):
            os.remove(coupe_path)
    except Exception:
        pass
    if not os.path.exists(coupe_path):
        try:
            from coupe_lithologique import schema_coupe_forage_reelle, lire_coupe_xlsm
            os.makedirs(os.path.dirname(coupe_path), exist_ok=True)

            # ── Lire la coupe RÉELLE depuis l'onglet Coupe_Geologique du xlsm ──
            _xlsm_path = XLSX_PATH  # variable globale = chemin vers le .xlsm/.xlsx
            _coupe_data = None
            if _xlsm_path and os.path.exists(_xlsm_path):
                try:
                    _coupe_data = lire_coupe_xlsm(_xlsm_path)
                except Exception as _exc_read:
                    print(f"  [coupe v15.82] lecture xlsm : {_exc_read}")

            if _coupe_data and _coupe_data.get("couches"):
                # Données réelles disponibles
                _couches_reelles = _coupe_data["couches"]
                _z_tn_real       = _coupe_data["z_tn"]
                _z_fond_real     = _coupe_data["z_fond_forage"]
                _ns_real         = _coupe_data["NS"]
                _ff_real         = _coupe_data["FF"]
                _arrivee_eau     = _coupe_data.get("prof_arrivee_eau")
                _commune_coupe   = _coupe_data.get("commune") or data.get("commune", "")
                _ref_cad_coupe   = _coupe_data.get("ref_cad") or data.get("ref_cad", "")
            else:
                # Fallback : paramètres issus de data (onglet Données d'Entrée)
                _z_tn_real   = safe_float(data.get("alti_tete"), 125.50)
                _prof_real   = safe_float(data.get("prof_forage_m"), 11.0)
                _z_fond_real = _z_tn_real - _prof_real
                _ns_real     = safe_float(data.get("NS", data.get("niveau_statique", 2.80)), 2.80)
                _ff_real     = safe_float(data.get("fond_fouille", _ns_real + 1.0), _ns_real + 1.0)
                _arrivee_eau = None
                _commune_coupe   = data.get("commune", "")
                _ref_cad_coupe   = data.get("ref_cad", "")
                # Couches de secours : couverture générique
                _couches_reelles = [
                    {"libelle": "Sol / Remblai", "de": 0.0, "a": max(1.0, _ns_real), "K": 1e-5, "e_sat": 0.0},
                    {"libelle": "Terrain naturel", "de": max(1.0, _ns_real), "a": _prof_real, "K": 1e-6, "e_sat": max(0, _ff_real - _ns_real)},
                ]

            schema_coupe_forage_reelle(
                out_path=coupe_path,
                couches=_couches_reelles,
                z_tn=_z_tn_real,
                z_fond_forage=_z_fond_real,
                NS=_ns_real,
                FF=_ff_real,
                prof_arrivee_eau=_arrivee_eau,
                commune=_commune_coupe,
                ref_cad=_ref_cad_coupe,
            )
        except Exception as exc:
            print(f"  [coupe lithologique v15.82] erreur génération : {exc}")
            import traceback; traceback.print_exc()
            # Fallback ultime : appel wrapper de compatibilité
            try:
                from coupe_lithologique import schema_coupe_lithologique
                schema_coupe_lithologique(coupe_path)
            except Exception:
                pass

    if os.path.exists(coupe_path):
        img = RLImage(coupe_path, width=16*cm, height=12.4*cm)
        img.hAlign = "CENTER"
        story.append(img)
        story.append(Spacer(1, 0.2*cm))
        # Légende dynamique selon le scénario (hors d'eau / en eau)
        if _hors_eau:
            _legende_coupe = (
                f"<i>Coupe lithologique basée sur les données saisies dans l'onglet "
                f"Coupe Géologique G.M.E.P. "
                f"Cote verticale en mètres NGF. Le fond de fouille projeté "
                f"({_alt_fond:.2f} m NGF) reste au-dessus du niveau d'eau "
                f"({_alt_nappe:.2f} m NGF). Aucun pompage d'exhaure nécessaire.</i>"
            )
        else:
            _legende_coupe = (
                f"<i>Coupe lithologique basée sur les données saisies dans l'onglet "
                f"Coupe Géologique G.M.E.P. "
                f"Cote verticale en mètres NGF. Substrat capté : <b>{_substrat}</b>, "
                f"niveau statique à {_alt_nappe:.2f} m NGF. "
                f"Le fond de fouille ({_alt_fond:.2f} m NGF) intercepte la nappe "
                f"sur {(_FF_m - _NS_m):.2f} m, nécessitant un pompage de rabattement.</i>"
            )
        story.append(Paragraph(_legende_coupe, s["note"]))
        story.append(Spacer(1, 0.4*cm))

    bloc_dbat = []
    bloc_dbat.append(Paragraph(
        "D\u00e9bits attendus selon le sc\u00e9nario de captage",
        s["subsection_title"]))
    bloc_dbat.append(Spacer(1, 0.2*cm))

    # Style de cellule (Paragraph) pour wrap correct + interprétation HTML
    cell_style = ParagraphStyle("debits_cell",
        fontName=FONT_BODY, fontSize=8.5, leading=11,
        textColor=HexColor("#1A1A1A"), alignment=TA_LEFT)
    cell_center = ParagraphStyle("debits_cell_c",
        fontName=FONT_BODY, fontSize=8.5, leading=11,
        textColor=HexColor("#1A1A1A"), alignment=TA_CENTER)
    head_style = ParagraphStyle("debits_head",
        fontName=FONT_BOLD, fontSize=8.5, leading=11,
        textColor=colors.white, alignment=TA_CENTER)
    # ── Tableau Débits attendus ── ligne 1 dynamique selon sc\u00e9nario ──
    if _hors_eau:
        _ligne1_sc  = f"<b>Fouille hors d'eau ({_FF_m:.2f} m)</b><br/><b>Fond au-dessus du niveau d'eau</b>"
        _ligne1_q   = "<b>0 m\u00b3/h</b>"
        _ligne1_jus = (f"Le fond de fouille ({_alt_fond:.2f} m NGF) est maintenu au-dessus du "
                       f"niveau d'eau observ\u00e9 ({_alt_nappe:.2f} m NGF). <b>Aucun pompage n\u00e9cessaire.</b>")
    else:
        _ligne1_sc  = (f"<b>Fouille en eau ({_FF_m:.2f} m)</b><br/>"
                       f"<b>Rabattement {(_FF_m - _NS_m):.2f} m</b>")
        _ligne1_q   = f"<b>{_Q_calc:.2f} m\u00b3/h</b>"
        _ligne1_jus = (f"Le fond de fouille ({_alt_fond:.2f} m NGF) intercepte la nappe sur "
                       f"{(_FF_m - _NS_m):.2f} m. Substrat capt\u00e9 : <b>{_substrat}</b>. "
                       f"D\u00e9bit calcul\u00e9 par Theis et Dupuit-Thiem.")

    debits_data = [
        [Paragraph("Sc\u00e9nario", head_style),
         Paragraph("D\u00e9bit attendu", head_style),
         Paragraph("Justification", head_style)],
        [Paragraph(_ligne1_sc, cell_style),
         Paragraph(_ligne1_q, cell_center),
         Paragraph(_ligne1_jus, cell_style)],
        [Paragraph("Drainance ponctuelle<br/>(hypoth\u00e8se minoritaire)", cell_style),
         Paragraph("1 \u00e0 5 m\u00b3/h", cell_center),
         Paragraph("Fracturation locale dans la couverture, communication imparfaite avec le r\u00e9servoir profond.", cell_style)],
        [Paragraph("<b>Forage approfondi (\u2265 25-30 m)</b><br/><b>Captage r\u00e9servoir r\u00e9gional</b>", cell_style),
         Paragraph("<b>20 \u00e0 100 m\u00b3/h</b>", cell_center),
         Paragraph("Acc\u00e8s direct au r\u00e9servoir profond. D\u00e9bit sp\u00e9cifique 1 \u00e0 10 m\u00b3/h/m typique.", cell_style)],
        [Paragraph("Forage profond zone fortement productive", cell_style),
         Paragraph("100 \u00e0 300 m\u00b3/h", cell_center),
         Paragraph("Karstification ou fracturation locale favorable (cf. SIGES r\u00e9gional).", cell_style)],
    ]
    debits_tbl = Table(debits_data, colWidths=[5.5*cm, 3.5*cm, 7.5*cm])
    debits_tbl.setStyle(TableStyle([
        ("BACKGROUND",   (0,0), (-1,0), colors.HexColor("#01696F")),
        ("TEXTCOLOR",    (0,0), (-1,0), colors.white),
        ("FONTNAME",     (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",     (0,0), (-1,-1), 8.5),
        ("BACKGROUND",   (0,3), (-1,3), colors.HexColor("#E8F4E8")),  # ligne recommandée
        ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
        ("ALIGN",        (0,0), (-1,0),  "CENTER"),
        ("ALIGN",        (1,1), (1,-1), "CENTER"),
        ("GRID",         (0,0), (-1,-1), 0.4, colors.HexColor("#01696F")),
        ("TOPPADDING",   (0,0), (-1,-1), 6),
        ("BOTTOMPADDING",(0,0), (-1,-1), 6),
        ("LEFTPADDING",  (0,0), (-1,-1), 5),
        ("RIGHTPADDING", (0,0), (-1,-1), 5),
    ]))
    bloc_dbat.append(debits_tbl)
    bloc_dbat.append(Spacer(1, 0.4*cm))

    if data.get("fouille_hors_eau", False):
        bloc_dbat.append(Paragraph(
            "<b>Recommandations techniques :</b> le fond de fouille \u00e9tant situ\u00e9 "
            f"{safe_float(data.get('FF_str'), 0):.2f} m sous le terrain naturel, soit au-dessus "
            f"du niveau d'eau ({safe_float(data.get('NS_str'), 0):.2f} m/TN), aucun pompage gravitaire "
            "n'est requis pour les travaux. Il est recommand\u00e9 de r\u00e9aliser un suivi pi\u00e9zom\u00e9trique "
            "avant et pendant chantier pour confirmer l'absence de fluctuations saisonni\u00e8res susceptibles "
            "de remonter le niveau d'eau au-dessus du fond de fouille. En cas de remont\u00e9e av\u00e9r\u00e9e, "
            "un dispositif d'\u00e9puisement de chantier (pompage temporaire) sera mis en place "
            "avec d\u00e9claration au titre de la rubrique 1.1.1.0 (cr\u00e9ation d'ouvrage temporaire).",
            s["body"]))
    else:
        _q_recom = safe_float(data.get("Q_pompe_dim"), 0.0)
        bloc_dbat.append(Paragraph(
            f"<b>Recommandations techniques :</b> le d\u00e9bit de pompage retenu pour les travaux "
            f"est de <b>{_q_recom:.2f} m\u00b3/h</b> sur la base d'un rabattement de "
            f"<b>{(_FF_m - _NS_m):.2f} m</b> dans le substrat <b>{_substrat}</b>. Le dispositif de "
            "rabattement doit comporter : (i) un pompage de la fouille par pointes filtrantes ou "
            "puits filtrant adapt\u00e9 au substrat ; (ii) un dispositif de mesure du d\u00e9bit r\u00e9el "
            "(compteur volum\u00e9trique) ; (iii) un suivi pi\u00e9zom\u00e9trique en P1 et P2 pour v\u00e9rifier "
            "l'absence d'impact sur les ouvrages riverains ; (iv) une gestion conforme des eaux "
            "d'exhaure (rejet apr\u00e8s d\u00e9cantation au milieu r\u00e9cepteur ou r\u00e9utilisation). "
            "Le projet rel\u00e8ve d'une <b>d\u00e9claration ou autorisation</b> au titre de la Loi sur "
            "l'Eau selon les seuils des rubriques 1.1.1.0, 1.1.2.0 et, le cas \u00e9ch\u00e9ant, 1.3.1.0 "
            "(ZRE) de la nomenclature R.214-1.",
            s["body"]))
    story.append(KeepTogether(bloc_dbat))

    story.append(PageBreak())

    # ═══════════════════════════════════════════════════════════════
    # SECTION : RÉFÉRENTIEL NATIONAL DES SUBSTRATUMS AQUIFÈRES
    # ═══════════════════════════════════════════════════════════════
    story.append(section_header("R\u00c9F\u00c9RENTIEL NATIONAL DES AQUIF\u00c8RES", s))
    story.append(Spacer(1, 0.3*cm))

    story.append(Paragraph(
        "Cadre national de r\u00e9f\u00e9rence du choix de substratum",
        s["subsection_title"]))

    story.append(Paragraph(
        "Le pr\u00e9sent dossier s'appuie sur un r\u00e9f\u00e9rentiel national de <b>23 grands syst\u00e8mes "
        "aquif\u00e8res</b> couvrant l'ensemble de la France m\u00e9tropolitaine, \u00e9tabli \u00e0 partir "
        "des bases de donn\u00e9es BDLISA (BRGM), des SIGES r\u00e9gionaux et des SAGE en vigueur. "
        "Le choix du substratum aquif\u00e8re est fond\u00e9 sur cinq crit\u00e8res hydrog\u00e9ologiques : "
        "(i) pr\u00e9sence g\u00e9ographique au droit du projet, (ii) profondeur du toit de l'aquif\u00e8re, "
        "(iii) d\u00e9bit forage attendu, (iv) compatibilit\u00e9 d'usage, (v) vuln\u00e9rabilit\u00e9 naturelle.",
        s["body"]))
    story.append(Spacer(1, 0.4*cm))

    # Tableau synthétique des aquifères les plus productifs
    story.append(Paragraph(
        "Top 10 des aquif\u00e8res fran\u00e7ais par d\u00e9bit forage",
        s["subsection_title"]))

    # On lit le CSV pour avoir les donn\u00e9es
    csv_path = os.path.join(os.path.dirname(__file__), "..", "aquiferes_france.csv")
    aquiferes_top = []
    if os.path.exists(csv_path):
        import csv as csvmod
        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csvmod.DictReader(f)
            for row in reader:
                try:
                    qmax = float(row.get("debit_forage_max", 0))
                except (ValueError, TypeError):
                    qmax = 0
                aquiferes_top.append((qmax, row))
        aquiferes_top.sort(key=lambda t: -t[0])
        aquiferes_top = aquiferes_top[:10]

    if aquiferes_top:
        _top_cell = ParagraphStyle("top_cell", fontName=FONT_BODY, fontSize=7.5, leading=9)
        _top_hdr  = ParagraphStyle("top_hdr",  fontName=FONT_BOLD, fontSize=8, leading=10, textColor=C_WHITE, alignment=1)

        top_data = [[Paragraph(h, _top_hdr) for h in
                     ["Rang", "Aquif\u00e8re", "Bassin", "Type", "Prof. toit", "D\u00e9bit (m\u00b3/h)", "Vuln."]]]
        for i, (qmax, row) in enumerate(aquiferes_top, start=1):
            nom = row.get("nom", "") or ""
            bassin = row.get("bassin", "") or ""
            ecoulement = row.get("ecoulement", "") or ""
            etat = row.get("etat", "") or ""
            type_aq = f"{ecoulement}<br/>{etat}"
            prof = f"{row.get('prof_toit_min','')}-{row.get('prof_toit_max','')} m"
            debit = f"{row.get('debit_forage_min','')}-{int(qmax)}"
            vuln = row.get("vulnerabilite", "") or ""
            top_data.append([
                str(i),
                Paragraph(nom, _top_cell),
                Paragraph(bassin, _top_cell),
                Paragraph(type_aq, _top_cell),
                prof, debit,
                Paragraph(vuln, _top_cell),
            ])

        top_tbl = Table(top_data, colWidths=[1.4*cm, 5.0*cm, 3.2*cm, 2.4*cm, 1.8*cm, 1.8*cm, 1.6*cm], repeatRows=1)
        top_tbl.setStyle(TableStyle([
            ("BACKGROUND",   (0,0), (-1,0), colors.HexColor("#01696F")),
            ("TEXTCOLOR",    (0,0), (-1,0), colors.white),
            ("FONTNAME",     (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",     (0,0), (-1,0), 8),
            ("FONTSIZE",     (0,1), (-1,-1), 7.5),
            ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
            ("ALIGN",        (0,0), (-1,0),  "CENTER"),
            ("ALIGN",        (0,1), (0,-1),  "CENTER"),
            ("ALIGN",        (3,1), (-1,-1), "CENTER"),
            ("GRID",         (0,0), (-1,-1), 0.3, colors.HexColor("#01696F")),
            ("ROWBACKGROUNDS",(0,1),(-1,-1), [colors.white, colors.HexColor("#F7FAFA")]),
            ("TOPPADDING",   (0,0), (-1,-1), 4),
            ("BOTTOMPADDING",(0,0), (-1,-1), 4),
        ]))
        story.append(top_tbl)
        story.append(Spacer(1, 0.3*cm))

    story.append(Paragraph(
        "Sources : BRGM (BDLISA, infoterre), SIGES r\u00e9gionaux, SAGE, Atlas g\u00e9othermie. "
        "Le r\u00e9f\u00e9rentiel complet (transmissivit\u00e9, perm\u00e9abilit\u00e9, d\u00e9bit sp\u00e9cifique, qualit\u00e9 "
        "naturelle, usages dominants par syst\u00e8me aquif\u00e8re) est disponible aupr\u00e8s du BRGM.",
        s["note"]))
    story.append(Spacer(1, 0.4*cm))

    # ─────────────────────────────────────────────
# SECTION : LEXIQUE DES ABRÉVIATIONS
# ─────────────────────────────────────────────
def build_lexique(story, data, s):
    """Section finale — Lexique des abréviations et acronymes utilisés dans le rapport."""

    story.append(PageBreak())
    story.append(section_header("LEXIQUE DES ABR\u00c9VIATIONS", s))
    story.append(Spacer(1, 0.3*cm))

    story.append(Paragraph(
        "Liste des abréviations, acronymes et symboles utilisés dans le présent dossier, "
        "classés par thématique.",
        s["body"]))
    story.append(Spacer(1, 0.4*cm))

    _lex_term = ParagraphStyle("lex_term", fontName=FONT_BOLD, fontSize=8.5,
                                leading=11, textColor=C_TEAL_DARK)
    _lex_def  = ParagraphStyle("lex_def",  fontName=FONT_BODY, fontSize=8.5,
                                leading=11, textColor=colors.HexColor("#28251D"))
    _lex_hdr  = ParagraphStyle("lex_hdr",  fontName=FONT_BOLD, fontSize=10,
                                leading=12, textColor=C_WHITE, alignment=1)

    groupes = [
        ("Réglementation — Loi sur l'Eau", [
            ("IOTA",       "Installations, Ouvrages, Travaux et Activités soumis à la nomenclature de l'article R.214-1 du Code de l'Environnement"),
            ("D",          "Déclaration au titre de la Loi sur l'Eau"),
            ("A",          "Autorisation environnementale au titre de la Loi sur l'Eau (R.181-13)"),
            ("AE",         "Autorisation Environnementale unique"),
            ("ZRE",        "Zone de Répartition des Eaux (R.211-71 du Code de l'Environnement)"),
            ("ICPE",       "Installation Classée pour la Protection de l'Environnement"),
            ("DDT(M)",     "Direction Départementale des Territoires (et de la Mer)"),
            ("DREAL",      "Direction Régionale de l'Environnement, de l'Aménagement et du Logement"),
            ("AELB",       "Agence de l'Eau Loire-Bretagne"),
            ("OFB",        "Office Français de la Biodiversité"),
            ("ONEMA",      "Office National de l'Eau et des Milieux Aquatiques (devenu OFB)"),
            ("SDAGE",      "Schéma Directeur d'Aménagement et de Gestion des Eaux"),
            ("SAGE",       "Schéma d'Aménagement et de Gestion des Eaux"),
            ("DCE",        "Directive Cadre sur l'Eau (2000/60/CE)"),
            ("PPRI",       "Plan de Prévention des Risques d'Inondation"),
            ("AEP",        "Alimentation en Eau Potable"),
        ]),
        ("Hydrogéologie — calculs de rabattement", [
            ("NS",         "Niveau Statique de la nappe (cote du toit de la nappe au repos)"),
            ("ND",         "Niveau Dynamique de la nappe (cote en cours de pompage)"),
            ("TN",         "Terrain Naturel — cote de référence à la tête de l'ouvrage"),
            ("NGF",        "Nivellement Général de la France — référence altimétrique nationale"),
            ("s",          "Rabattement de nappe (m) = NS − ND, soit la différence entre niveau statique et niveau dynamique"),
            ("R",          "Rayon d'influence du pompage (m)"),
            ("Q",          "Débit de pompage (m³/h ou m³/s)"),
            ("K",          "Conductivité hydraulique ou perméabilité de Darcy (m/s)"),
            ("T",          "Transmissivité de l'aquifère (m²/s) — T = K × épaisseur"),
            ("S",          "Coefficient d'emmagasinement (sans unité)"),
            ("S<sub>libre</sub>",   "Coefficient d'emmagasinement en nappe libre (≈ porosité efficace)"),
            ("S<sub>captif</sub>",  "Coefficient d'emmagasinement en nappe captive"),
            ("n",          "Porosité efficace ou drainable (%)"),
            ("e",          "Épaisseur saturée de l'aquifère (m)"),
            ("u",          "Variable adimensionnelle de Theis : u = r²·S / (4·T·t)"),
            ("W(u)",       "Fonction de puits de Theis (well function)"),
            ("f<sub>K</sub>",       "Facteur correctif de perméabilité (clipping K)"),
            ("f<sub>P</sub>",       "Facteur correctif de profondeur (épaisseur saturée)"),
            ("f<sub>C</sub>",       "Facteur correctif de cuvette lenticulaire (1 + 0,15·IPL)"),
            ("IPL",        "Indice de Probabilité Lenticulaire (0–3, score topographique)"),
            ("TWI",        "Topographic Wetness Index (Beven &amp; Kirkby, 1979)"),
            ("TPI",        "Topographic Position Index (Weiss, 2001)"),
        ]),
        ("Bases de données — géoréférentiels", [
            ("BSS",        "Banque du Sous-Sol (BRGM — infoterre.brgm.fr)"),
            ("BRGM",       "Bureau de Recherches Géologiques et Minières"),
            ("BDLISA",     "Base de Données des Limites des Systèmes Aquifères (BRGM)"),
            ("SIGES",      "Système d'Information pour la Gestion des Eaux Souterraines (BRGM)"),
            ("SANDRE",     "Service d'Administration Nationale des Données et Référentiels sur l'Eau"),
            ("IGN",        "Institut National de l'Information Géographique et Forestière"),
            ("RGE Alti",   "Référentiel à Grande Échelle Altimétrique de l'IGN"),
            ("BD ALTI",    "Base de Données Altimétrique de l'IGN"),
            ("BD ORTHO",   "Base de Données Orthophotographique de l'IGN"),
            ("BD TOPO",    "Base de Données Topographique de l'IGN"),
            ("WMS",        "Web Map Service — protocole de diffusion de cartes en ligne"),
            ("INSEE",      "Institut National de la Statistique et des Études Économiques (codes communes)"),
            ("Hub'Eau",    "Plateforme nationale d'accès aux données de l'eau (api.hubeau.eaufrance.fr)"),
        ]),
        ("Coordonnées géoréférencées", [
            ("L93",        "Lambert 93 (EPSG:2154) — système de projection légal français"),
            ("RGF93",      "Réseau Géodésique Français 1993"),
            ("WGS84",      "World Geodetic System 1984 (EPSG:4326) — latitude/longitude internationale"),
            ("EPSG",       "European Petroleum Survey Group (codes officiels des systèmes géodésiques)"),
        ]),
        ("Milieux et habitats naturels", [
            ("ZNIEFF",     "Zone Naturelle d'Intérêt Écologique, Faunistique et Floristique"),
            ("Natura 2000","Réseau européen de sites protégés (Directives Habitats et Oiseaux)"),
            ("ZSC",        "Zone Spéciale de Conservation (Natura 2000 — Directive Habitats)"),
            ("ZPS",        "Zone de Protection Spéciale (Natura 2000 — Directive Oiseaux)"),
            ("DOCOB",      "Document d'Objectifs (Natura 2000)"),
            ("FRGG",       "Code masse d'eau souterraine (référentiel SANDRE / DCE)"),
        ]),
        ("Climat et bilan hydrique", [
            ("P",          "Pluviométrie annuelle (mm/an)"),
            ("ETP",        "Évapotranspiration Potentielle (mm/an)"),
            ("R<sub>nette</sub>",   "Recharge nette de la nappe (mm/an) — P − ETR"),
            ("ETR",        "Évapotranspiration Réelle (mm/an)"),
        ]),
        ("Paramètres physico-chimiques (rejets)", [
            ("MES",        "Matières En Suspension"),
            ("DBO5",       "Demande Biochimique en Oxygène sur 5 jours"),
            ("DCO",        "Demande Chimique en Oxygène"),
            ("pH",         "Potentiel hydrogène (acidité / basicité)"),
        ]),
    ]

    for titre, rows in groupes:
        bloc_lex = [
            Paragraph(titre, s["subsection_title"]),
            Spacer(1, 0.15*cm),
        ]

        lex_data = [[Paragraph("Abréviation", _lex_hdr),
                     Paragraph("Signification", _lex_hdr)]]
        for term, defi in rows:
            lex_data.append([Paragraph(term, _lex_term), Paragraph(defi, _lex_def)])

        lex_tbl = Table(lex_data, colWidths=[3.6*cm, 14.0*cm], repeatRows=1)
        lex_tbl.setStyle(TableStyle([
            ("BACKGROUND",   (0,0), (-1,0), colors.HexColor("#01696F")),
            ("VALIGN",       (0,0), (-1,-1), "MIDDLE"),
            ("ALIGN",        (0,0), (-1,0),  "CENTER"),
            ("GRID",         (0,0), (-1,-1), 0.3, colors.HexColor("#01696F")),
            ("ROWBACKGROUNDS",(0,1),(-1,-1), [C_WHITE, colors.HexColor("#F2FAFB")]),
            ("TOPPADDING",   (0,0), (-1,-1), 4),
            ("BOTTOMPADDING",(0,0), (-1,-1), 4),
            ("LEFTPADDING",  (0,0), (-1,-1), 6),
            ("RIGHTPADDING", (0,0), (-1,-1), 6),
        ]))
        bloc_lex.append(lex_tbl)
        story.append(KeepTogether(bloc_lex))
        story.append(Spacer(1, 0.5*cm))

    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "Symboles math\u00e9matiques courants : \u00b7 \u2248 (environ) \u2014 \u2264 (inf\u00e9rieur ou \u00e9gal) \u2014 "
        "\u2265 (sup\u00e9rieur ou \u00e9gal) \u2014 \u00b1 (plus ou moins) \u2014 10^-3 (notation scientifique).",
        s["note"]))

    story.append(PageBreak())


# ─────────────────────────────────────────────
# PROGRAMME PRINCIPAL
# ─────────────────────────────────────────────
def _step(msg):
    """Affiche une etape de progression avec horodatage."""
    ts = datetime.now().strftime("%H:%M:%S")
    print(f"  [{ts}] {msg}", flush=True)


def main(with_maps=True):
    print(flush=True)
    print("  ================================================", flush=True)
    print("   G.M.E.P  --  Generation Dossier Loi sur l'Eau", flush=True)
    print("  ================================================", flush=True)
    print(flush=True)

    _step("Lecture du fichier Excel...")

    # v15.62 — Garde-fou TOLERANT : attendre jusqu'a 15s qu'Excel/OneDrive
    # liberent le fichier (les lanceurs .bat/.vbs ferment deja Excel avant
    # d'appeler ce script, mais OneDrive peut conserver un verrou).
    # On n'arrete le script QUE si le verrou persiste apres 15s d'attente.
    _xlsx_check = os.path.join(SCRIPT_DIR, "Modelisation_Rabattement_TSN_GMEP.xlsx")
    if os.path.exists(_xlsx_check):
        import time as _time
        _dir = os.path.dirname(_xlsx_check) or "."
        _base = os.path.basename(_xlsx_check)
        _lock_office = os.path.join(_dir, f"~${_base}")
        _lock_lo = os.path.join(_dir, f".~lock.{_base}#")
        _wait_sec = 0
        _max_wait = 15
        _warned = False
        while _wait_sec <= _max_wait:
            _is_locked = os.path.exists(_lock_office) or os.path.exists(_lock_lo)
            if not _is_locked:
                try:
                    with open(_xlsx_check, "r+b"):
                        pass
                except (OSError, PermissionError):
                    _is_locked = True
            if not _is_locked:
                if _warned:
                    print(f"  -> Fichier libere apres {_wait_sec}s. Reprise.", flush=True)
                break
            if not _warned:
                print(flush=True)
                print("  Attente de la liberation du fichier Excel (max 15s)...", flush=True)
                _warned = True
            # Tenter de supprimer le verrou Office orphelin
            try:
                if os.path.exists(_lock_office):
                    os.remove(_lock_office)
            except Exception:
                pass
            try:
                if os.path.exists(_lock_lo):
                    os.remove(_lock_lo)
            except Exception:
                pass
            _time.sleep(1)
            _wait_sec += 1
        else:
            print(flush=True)
            print("  " + "!" * 60, flush=True)
            print("  !!  LE FICHIER EXCEL EST TOUJOURS VERROUILLE              !!", flush=True)
            print("  " + "!" * 60, flush=True)
            print(flush=True)
            print("  Apres 15 secondes d'attente, le fichier", flush=True)
            print(f"  '{_base}' est toujours verrouille.", flush=True)
            print(flush=True)
            print("  -> SOLUTION :", flush=True)
            print("     1. Fermez completement Microsoft Excel (Ctrl+S puis Alt+F4).", flush=True)
            print("     2. Si OneDrive synchronise : attendez 30 secondes.", flush=True)
            print("     3. Relancez Generer_PDF.bat.", flush=True)
            print(flush=True)
            print("  " + "!" * 60, flush=True)
            print(flush=True)
            try:
                input("  Appuyez sur Entree pour quitter...")
            except Exception:
                pass
            sys.exit(2)

    data = read_excel_data()

    # Mise à jour automatique du bloc géo Excel (commune/INSEE/ZRE/masse d'eau)
    # à partir des coordonnées X/Y Lambert 93 saisies en C33/C34
    # Correction durable v15.88 : ce bloc ciblait en dur le fichier modèle
    # générique (Modelisation_Rabattement_TSN_GMEP.xlsx) au lieu du fichier
    # réellement ouvert par l'utilisateur (XLSX_PATH), ce qui laissait les
    # cellules C118-C128 (bassin DCE, SDAGE, masse d'eau, statut ZRE) figées
    # sur les données du modèle de démonstration après un changement de site.
    try:
        from update_excel_geo import update_geo_block
        update_geo_block(XLSX_PATH)
        _step("  Bloc geo Excel mis a jour (commune/INSEE/ZRE/masse d'eau)")
    except Exception as _e:
        _step(f"  Avertissement maj Excel geo : {_e}")

    _step(f"  Maitre d'ouvrage : {data['mo_nom']}")
    _step(f"  Substrat         : {data['substrat']}")
    _step(f"  Commune          : {data['commune_geo']}")
    _step(f"  Type opération  : {'Rabattement de fouille' if data.get('is_rabattement_fouille') else 'Pompage AEP / industriel'}")
    _step(f"  Mode de calcul  : {'Q imposé → s calculé' if data.get('mode_Q_impose') else 'Niveau cible → Q calculé'}")
    if data.get('mode_Q_impose'):
        _step(f"  Q imposé        : {data.get('Q_impose_m3h', 0):.1f} m3/h")
        _step(f"  s induit        : {data.get('s_rab_calcule', 0):.2f} m (niveau dyn : {data.get('niveau_dyn_calcule', 0):.2f} m/TN)")
    _step(f"  Q Theis          : {data['Q_theis']} m3/h")
    _step(f"  Q Dupuit         : {data['Q_dupuit']} m3/h")
    _step(f"  Volume annuel    : {data['vol_an']} m3/an")
    _step(f"  Statut IOTA      : {data['statut_iota']}")
    if not data.get('coherence_puits', True) and not data.get('fouille_hors_eau', False):
        _step(f"  [!] Cohérence puits/niveau : écart de sécurité = {data.get('ecart_securite_m', 0):.2f} m (négatif = pompe risque dénoyage)")
    else:
        _step(f"  Cohérence puits : OK (écart sécurité = {data.get('ecart_securite_m', 0):.2f} m)")
    print(flush=True)

    # Génération des cartes réglementaires
    map_paths = {}
    if with_maps:
        _step("Generation des cartes reglementaires (IGN/WMS)...")
        try:
            from generate_maps import generate_all_maps
            commune = data["commune_geo"] if data["commune_geo"] != "—" else data["commune"]
            dept    = data["dept_geo"]    if data["dept_geo"]    != "—" else data["departement"]
            if commune == "—": commune = "Site"
            if dept    == "—": dept    = "—"
            map_paths = generate_all_maps(
                x_l93    = data["lambert_x"],
                y_l93    = data["lambert_y"],
                alti_ngf = data["alti_ngf"],
                commune  = commune,
                dept     = dept,
                substrat = data["substrat"],
            )
            _step(f"  {len(map_paths)} carte(s) generee(s).")
        except Exception as e:
            _step(f"  Avertissement cartes : {e} -- PDF sans cartes")
    print(flush=True)

    output_path = os.path.join(SCRIPT_DIR, "Dossier_Declaration_Loi_Eau_GMEP.pdf")

    # === V15.54 : Vérifier que le PDF de sortie n'est pas verrouillé (ouvert dans Adobe Reader, etc.) ===
    if os.path.exists(output_path):
        try:
            with open(output_path, "r+b") as _fh:
                pass
        except (PermissionError, OSError):
            print("")
            print("  =====================================================================")
            print("  *** ERREUR : le PDF de sortie est encore OUVERT ***")
            print("  =====================================================================")
            print("")
            print(f"  Fichier : {output_path}")
            print("")
            print("  AVANT de regenerer le PDF, vous devez :")
            print("    1) FERMER le PDF s'il est ouvert dans Adobe Reader, Edge,")
            print("       Chrome, Firefox ou tout autre lecteur de PDF")
            print("    2) Relancer la generation")
            print("")
            print("  =====================================================================")
            sys.exit(3)

    _step("Construction du rapport PDF...")

    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        title="Dossier d'Autorisation Environnementale Loi sur l'Eau -- Rubriques 1.1.1.0 + 1.1.2.0 + 1.3.1.0",
        author="G.M.E.P",
        leftMargin=1.5*cm,
        rightMargin=1.5*cm,
        topMargin=2.2*cm,
        bottomMargin=2.2*cm,
    )

    s = build_styles()
    story = []

    _step("  Page de couverture...")
    build_cover(story, data, s)
    _step("  Sommaire...")
    build_sommaire(story, s, data)
    _step("  Objet du dossier...")
    build_objet(story, data, s)
    _step("  Donnees du projet...")
    build_donnees(story, data, s)
    _step("  Schemas techniques...")
    build_schemas_techniques(story, data, s)
    if map_paths:
        _step("  Integration des cartes...")
        build_cartes(story, data, s, map_paths)
    _step("  Methodes de calcul...")
    build_methodes(story, data, s)
    _step("  Resultats et debits...")
    build_resultats(story, data, s)
    _step("  Analyse de sensibilite T -> Q...")
    build_sensibilite(story, data, s)
    _step("  Topographie et formations lenticulaires (IPL)...")
    build_topographie_lenticulaire(story, data, s)
    _step("  Verification reglementaire IOTA...")
    build_iota(story, data, s)
    # Sections spécifiques au site d'Oucques-la-Nouvelle (INSEE 41171) :
    # ZNIEFF/Natura 2000 "Petite Beauce" et tableau débits-cibles Stampien.
    # Pour un autre site (X/Y différents), ces sections sont remplacées par un 
    # placeholder générique invitant l'expert à compléter les éléments locaux.
    _is_oucques = (str(data.get("code_insee", "")).strip() == "41171")
    if _is_oucques:
        _step("  Zones ZNIEFF / Natura 2000...")
        build_znieff_natura2000(story, data, s)
        _step("  Preconisations...")
        build_preconisations(story, data, s)
    else:
        _step("  Zones environnementales (placeholder portabilité)...")
        story.append(section_header("6. ZONES ÉCOLOGIQUEMENT SENSIBLES — À COMPLÉTER", s))
        story.append(Spacer(1, 0.3*cm))
        _commune_pl = data.get("commune", "—")
        _insee_pl   = data.get("code_insee", "—")
        story.append(Paragraph(
            f"L'analyse des zones écologiquement sensibles (ZNIEFF de type I et II, sites Natura 2000 "
            f"ZSC et ZPS, zones humides, périmètres de protection des captages AEP) doit être conduite "
            f"spécifiquement pour la commune de <b>{_commune_pl}</b> (INSEE {_insee_pl}). "
            f"<br/><br/>"
            f"Sources à consulter pour cette commune :"
            f"<br/>• INPN (Inventaire National du Patrimoine Naturel) : inpn.mnhn.fr"
            f"<br/>• Géoportail couches Natura 2000, ZNIEFF, ZICO"
            f"<br/>• DREAL régionale compétente (cartographie locale)"
            f"<br/>• ARS / DDT du département (périmètres de protection AEP)"
            f"<br/><br/>"
            f"<i>Cette section sera étoffée dossier par dossier en fonction du contexte local du "
            f"projet. Elle constitue une exigence réglementaire au titre de l'étude d'incidence "
            f"environnementale (R.181-13 ou R.214-32 selon régime).</i>",
            s["body"]))
        story.append(PageBreak())
    _step("  Conclusion...")
    build_conclusion(story, data, s)
    _step("  Lexique des abreviations...")
    build_lexique(story, data, s)

    _step("  Mise en page finale (en-tetes / pieds de page)...")
    hf = make_header_footer(data)
    doc.build(story, onFirstPage=hf, onLaterPages=hf)

    # Post-traitement qpdf en deux passes :
    #  1) Normalisation legere (object-streams=disable) -> compat lecteurs anciens
    #  2) Linearisation (--linearize) -> ouverture rapide Adobe Reader / Apercu Mac
    # Si une etape echoue, on conserve le PDF brut.
    try:
        import shutil, subprocess
        qpdf_bin = shutil.which("qpdf")
        if qpdf_bin:
            # Etape 1 : normalisation
            tmp_out = output_path + ".norm"
            res = subprocess.run(
                [qpdf_bin, "--object-streams=disable",
                 "--stream-data=preserve", "--normalize-content=n",
                 output_path, tmp_out],
                capture_output=True, text=True
            )
            if res.returncode == 0 and os.path.exists(tmp_out):
                os.replace(tmp_out, output_path)
            else:
                if os.path.exists(tmp_out):
                    os.remove(tmp_out)

            # Etape 2 : linearisation pour ouverture optimale
            tmp_lin = output_path + ".lin"
            res2 = subprocess.run(
                [qpdf_bin, "--linearize",
                 "--object-streams=disable",
                 "--remove-unreferenced-resources=yes",
                 output_path, tmp_lin],
                capture_output=True, text=True
            )
            if res2.returncode in (0, 3) and os.path.exists(tmp_lin):
                # returncode 3 = warnings non bloquants
                os.replace(tmp_lin, output_path)
                _step("  PDF normalise + linearise (compatibilite lecteur maximale)")
            else:
                if os.path.exists(tmp_lin):
                    os.remove(tmp_lin)
                _step("  PDF normalise (linearisation ignoree)")
    except Exception as _e:
        pass

    size = os.path.getsize(output_path)
    print(flush=True)
    print("  ================================================", flush=True)
    _step(f"PDF genere avec succes !")
    _step(f"Fichier : {output_path}")
    _step(f"Taille  : {size:,} octets")
    print("  ================================================", flush=True)
    print(flush=True)
    return output_path


if __name__ == "__main__":
    main()
