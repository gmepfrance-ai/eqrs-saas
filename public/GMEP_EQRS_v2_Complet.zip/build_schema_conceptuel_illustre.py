#!/usr/bin/env python3
"""
Schéma conceptuel illustré EQRS — style BRGM/INERIS
Coupe géologique + site industriel + cibles + flèches de transfert a-h
Les couleurs des flèches évoluent automatiquement selon les Σ QD / Σ ERI
calculés dans le classeur EQRS_Johnson_Ettinger.

Usage :
    python3 build_schema_conceptuel_illustre.py [chemin_xlsx]
Si aucun chemin n'est fourni : utilise EQRS_Johnson_Ettinger_V7.xlsx
"""

import sys, os, subprocess
from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch, Rectangle, Polygon, Circle, Wedge
from matplotlib.path import Path as MplPath
import matplotlib.path as mpath
import numpy as np
import openpyxl

# Dossier du script (portable Windows / Mac / Linux)
# Si un chemin xlsx est passé en argument, on utilisera son dossier ;
# sinon on prend le dossier de ce script.
import sys as _sys, os as _os
if len(_sys.argv) > 1 and _sys.argv[1]:
    WORKSPACE = Path(_os.path.abspath(_sys.argv[1])).parent
else:
    WORKSPACE = Path(_os.path.dirname(_os.path.abspath(__file__)))
DEFAULT_XLSX = WORKSPACE / 'EQRS_Johnson_Ettinger_V7.xlsx'

# Seuils EQRS (méthodologie INERIS/SSP)
QD_INACCEPTABLE = 1.0
QD_VIGILANCE    = 0.2
ERI_INACCEPTABLE = 1e-5
ERI_VIGILANCE    = 1e-6

# Palette
C_OK      = '#3F8E3F'   # vert
C_WARN    = '#E58E1A'   # orange
C_DANGER  = '#C0272D'   # rouge
C_NEUTRAL = '#6E6E6E'   # gris (donnée absente)

C_GROUND_NS = '#F2E4C9'   # zone non saturée — beige
C_GROUND_S  = '#C9D9E8'   # zone saturée — bleu pâle
C_SUBSTRAT  = '#9B9081'   # substratum — gris-brun
C_PLUME_NS  = '#8B7C5C'   # panache zone non saturée
C_PLUME_S   = '#6F8AA8'   # panache zone saturée
C_LINE      = '#2A2A2A'
C_DASH_LIM  = '#4A4A4A'   # ligne pointillée limite site

# -------------------------------------------------------------------
def get_risk_level(qd, eri):
    """Renvoie 'danger' | 'warn' | 'ok' | 'neutral'."""
    if qd is None and eri is None:
        return 'neutral'
    qd = qd or 0
    eri = eri or 0
    if qd >= QD_INACCEPTABLE or eri >= ERI_INACCEPTABLE:
        return 'danger'
    if qd >= QD_VIGILANCE or eri >= ERI_VIGILANCE:
        return 'warn'
    return 'ok'

def color_for(level):
    return {'danger': C_DANGER, 'warn': C_WARN,
            'ok': C_OK, 'neutral': C_NEUTRAL}[level]

# -------------------------------------------------------------------
def read_risks(xlsx_path):
    """Lit les Σ QD / Σ ERI par voie depuis le classeur.

    NOUVEAU (v2) : lit la ligne MAX par organe cible :
      - Résultats_QD L112 (MAX sur les 13 organes par voie, lignes 99-111)
      - Résultats_ERI L64  (MAX sur les 8 effets cancérigènes, lignes 56-63)
    Fallback automatique sur les anciennes sommes globales (L90 / L47)
    si les nouveaux tableaux ne sont pas présents.
    """
    try:
        wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    except Exception as e:
        print(f"[avert] Lecture {xlsx_path} impossible : {e}", file=sys.stderr)
        return {k: (None, None) for k in
                ['ingestion_sol', 'eau_aep', 'inhal_vapeurs',
                 'canalisation', 'arrosage', 'plantes',
                 'percolation', 'retombees']}

    def cell(sheet, addr):
        try:
            v = wb[sheet][addr].value
            return float(v) if v not in (None, '', '#DIV/0!', '#N/A', '#REF!') else None
        except (TypeError, ValueError, KeyError):
            return None

    # Détection automatique : la ligne MAX par organe existe-t-elle ?
    has_organ_qd  = wb['Résultats_QD'].cell(row=112, column=2).value == "MAX par voie d'exposition"
    has_organ_eri = wb['Résultats_ERI'].cell(row=64,  column=2).value == "MAX par voie d'exposition"

    if has_organ_qd:
        QD_ROW = 112  # MAX par organe cible
        print("[info] Lecture QD depuis la ligne MAX par organe (L112)")
    else:
        QD_ROW = 90   # fallback ancienne somme globale
        print("[avert] Tableau par organe non détecté, fallback sur Σ globale L90")

    if has_organ_eri:
        ER_ROW = 64
        print("[info] Lecture ERI depuis la ligne MAX par organe (L64)")
    else:
        ER_ROW = 47
        print("[avert] Tableau cancer non détecté, fallback sur Σ globale L47")

    QD = lambda col: cell('Résultats_QD',  f"{col}{QD_ROW}")
    ER = lambda col: cell('Résultats_ERI', f"{col}{ER_ROW}")

    def maxv(*vals):
        vals = [v for v in vals if v is not None]
        return max(vals) if vals else None

    # Mapping voie → colonnes utiles
    risks = {
        # a — Percolation (sol → nappe)
        'percolation':    (maxv(QD('E'), QD('F'), QD('L')),
                           maxv(ER('E'), ER('H'), ER('M'))),
        # b — Transfert via eaux souterraines (nappe → captage AEP)
        'eau_aep':        (maxv(QD('G'), QD('H'), QD('M')),
                           maxv(ER('E'), ER('H'), ER('M'))),
        # c — Arrosage (eau → potager)
        'arrosage':       (maxv(QD('G'), QD('H')),
                           maxv(ER('E'), ER('H'))),
        # d — Volatilisation J&E (sources COV → air intérieur)
        'inhal_vapeurs':  (maxv(QD('P'), QD('Q'), QD('R')),
                           ER('G')),
        # e — Canalisation AEP (perméation)
        'canalisation':   (maxv(QD('G'), QD('H')),
                           maxv(ER('E'), ER('H'))),
        # f — Anciennes retombées atmosphériques (air → sol)
        'retombees':      (maxv(QD('I'), QD('J'), QD('N')),
                           maxv(ER('F'), ER('I'), ER('N'))),
        # g — Sols de subsurface (contact + ingestion)
        'ingestion_sol':  (maxv(QD('E'), QD('F'), QD('K'), QD('L'), QD('O')),
                           maxv(ER('E'), ER('H'), ER('K'), ER('M'))),
        # h — Plantes (transfert sol/eau → légumes potager)
        'plantes':        (maxv(QD('E'), QD('F'), QD('G'), QD('H')),
                           maxv(ER('E'), ER('H'))),
    }
    return risks


def read_organ_details(xlsx_path):
    """Renvoie la liste des organes impactés avec leur niveau, pour le bandeau.

    Retourne deux dict : {organe: (max_qd, niveau)} et {cancer: (max_eri, niveau)}.
    """
    try:
        wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    except Exception:
        return {}, {}

    organes_qd = {}
    cancers_eri = {}

    ws = wb['Résultats_QD']
    if ws.cell(row=112, column=2).value == "MAX par voie d'exposition":
        for r in range(99, 112):
            organe = ws.cell(row=r, column=2).value
            if not organe:
                continue
            vals = []
            for c in range(5, 19):
                v = ws.cell(row=r, column=c).value
                try:
                    vv = float(v)
                    if vv > 0:
                        vals.append(vv)
                except (TypeError, ValueError):
                    pass
            mx = max(vals) if vals else None
            organes_qd[organe] = (mx, get_risk_level(mx, None))

    ws = wb['Résultats_ERI']
    if ws.cell(row=64, column=2).value == "MAX par voie d'exposition":
        for r in range(56, 64):
            cancer = ws.cell(row=r, column=2).value
            if not cancer:
                continue
            vals = []
            for c in range(5, 15):
                v = ws.cell(row=r, column=c).value
                try:
                    vv = float(v)
                    if vv > 0:
                        vals.append(vv)
                except (TypeError, ValueError):
                    pass
            mx = max(vals) if vals else None
            cancers_eri[cancer] = (mx, get_risk_level(None, mx))

    return organes_qd, cancers_eri

# -------------------------------------------------------------------
def draw_schema(risks, outfile_png, outfile_pdf=None):
    fig, ax = plt.subplots(figsize=(16, 10), dpi=180)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 70)
    ax.set_aspect('auto')
    ax.axis('off')

    # === EN-TÊTES (gauche / droite) ===
    ax.text(25, 67.5, "Emprise du site : maîtrise des usages",
            ha='center', fontsize=12, fontweight='bold', color='#1A1A1A')
    ax.text(25, 65.5, "(plan de gestion)",
            ha='center', fontsize=10, style='italic', color='#3A3A3A')
    ax.text(73, 67.5, "Périphérie du site : usages imposés",
            ha='center', fontsize=12, fontweight='bold', color='#1A1A1A')
    ax.text(73, 65.5, "(interprétation de l'état des milieux)",
            ha='center', fontsize=10, style='italic', color='#3A3A3A')

    ax.text(12, 60, "Ancien site\nindustriel",
            ha='center', fontsize=9.5, style='italic', color='#3A3A3A')
    ax.text(90, 60, "Usage résidentiel",
            ha='center', fontsize=9.5, style='italic', color='#3A3A3A')

    # === LIMITE SITE (verticale pointillée) ===
    ax.plot([50, 50], [3, 64], linestyle=(0, (4, 3)), color=C_DASH_LIM, lw=1.5, zorder=2)

    # === COUPE GÉOLOGIQUE ===
    # Surface du sol y=42
    # Zone non saturée 42 → 30
    # Toit nappe y=30 (trait bleu)
    # Zone saturée 30 → 12
    # Substratum 12 → 6
    y_surf = 42
    y_nappe = 30
    y_sub = 12

    # Fond zone non saturée
    ax.add_patch(Rectangle((2, y_nappe), 96, y_surf - y_nappe,
                           facecolor=C_GROUND_NS, edgecolor='none', zorder=0))
    # Fond zone saturée
    ax.add_patch(Rectangle((2, y_sub), 96, y_nappe - y_sub,
                           facecolor=C_GROUND_S, edgecolor='none', zorder=0))
    # Substratum hachuré
    ax.add_patch(Rectangle((2, 6), 96, y_sub - 6,
                           facecolor=C_SUBSTRAT, edgecolor='none', zorder=0))
    ax.add_patch(Rectangle((2, 6), 96, y_sub - 6,
                           facecolor='none', edgecolor='#5C5246', hatch='///',
                           linewidth=0.5, zorder=0.5))

    # Trait surface
    ax.plot([2, 98], [y_surf, y_surf], color=C_LINE, lw=1.5, zorder=3)
    # Trait nappe avec symbole ▽
    ax.plot([2, 98], [y_nappe, y_nappe], color='#1F5A8C', lw=1.0, zorder=3)
    ax.text(3.5, y_nappe + 0.4, '▽', fontsize=12, color='#1F5A8C', zorder=4)
    # Trait toit substratum
    ax.plot([2, 98], [y_sub, y_sub], color=C_LINE, lw=1.0, zorder=3)

    # Labels strates (à gauche, sur la marge)
    for y, lbl, bold in [(y_surf + 0.6, 'Surface du sol', True),
                          (36, 'Zone non\nsaturée', False),
                          (21, 'Zone saturée', False),
                          (9, 'Substratum', True)]:
        ax.text(-7, y, lbl, ha='left', va='center', fontsize=9.5,
                color='#1A1A1A', fontweight='bold' if bold else 'normal')

    # === ÉLÉMENTS GAUCHE (site industriel) ===
    # Bâtiment industriel barré (croix noire) avec cheminée
    # Bâtiment
    bat = Polygon([(14, y_surf), (14, 50), (24, 50), (24, y_surf)],
                  facecolor='#C9A35C', edgecolor=C_LINE, lw=1.2, zorder=4)
    ax.add_patch(bat)
    # Toit pente
    ax.add_patch(Polygon([(14, 50), (19, 53), (24, 50)],
                         facecolor='#A37B3C', edgecolor=C_LINE, lw=1.2, zorder=4))
    # Cheminée
    ax.add_patch(Rectangle((20, 50), 2.2, 6.5,
                           facecolor='#5A5A5A', edgecolor=C_LINE, lw=1, zorder=5))
    # Croix barrée (site abandonné)
    ax.plot([13, 25], [y_surf, 53], color=C_LINE, lw=2, zorder=6)
    ax.plot([25, 13], [y_surf, 53], color=C_LINE, lw=2, zorder=6)

    # Fumée historique (panache gris au-dessus cheminée)
    smoke_pts = [(21, 56.5), (18, 59), (24, 60), (28, 61.5), (35, 62.5),
                 (45, 63), (38, 64), (30, 63.5), (22, 62), (16, 60)]
    ax.add_patch(Polygon(smoke_pts, facecolor='#9A9A9A',
                         edgecolor='#7A7A7A', lw=0.8, alpha=0.85, zorder=5))

    # Piézomètre (tube vertical mince à gauche du bâtiment) — décalé pour éviter chevauchement
    ax.plot([5, 5], [y_surf, 18], color=C_LINE, lw=1.5, zorder=5)
    ax.plot([4.3, 5.7], [y_surf + 0.3, y_surf + 0.3], color=C_LINE, lw=1.5, zorder=5)
    ax.annotate('Piézomètre', xy=(5, y_surf), xytext=(5, y_surf + 8),
                ha='center', fontsize=9, color='#1A1A1A',
                arrowprops=dict(arrowstyle='-', color='#1A1A1A', lw=0.6))

    # Panache sol (sous bâtiment) — zone non saturée + saturée
    plume_ns = Polygon([
        (15, y_surf), (23, y_surf), (26, 38), (24, 34),
        (22, 31), (16, 31), (13, 34), (12, 38)
    ], facecolor=C_PLUME_NS, edgecolor='none', alpha=0.85, zorder=2)
    ax.add_patch(plume_ns)
    plume_s = Polygon([
        (13, y_nappe), (26, y_nappe), (30, 25), (33, 20),
        (28, 16), (20, 15), (12, 17), (10, 22)
    ], facecolor=C_PLUME_S, edgecolor='none', alpha=0.85, zorder=2)
    ax.add_patch(plume_s)

    # === ÉLÉMENTS DROITE (cibles) ===
    # Habitations
    h_x, h_y = 78, y_surf
    ax.add_patch(Polygon([(h_x, h_y), (h_x, h_y + 5), (h_x + 8, h_y + 5), (h_x + 8, h_y)],
                         facecolor='#D7B58E', edgecolor=C_LINE, lw=1.2, zorder=4))
    ax.add_patch(Polygon([(h_x, h_y + 5), (h_x + 4, h_y + 8), (h_x + 8, h_y + 5)],
                         facecolor='#A85A3D', edgecolor=C_LINE, lw=1.2, zorder=4))
    # Petite fenêtre
    ax.add_patch(Rectangle((h_x + 3, h_y + 1.5), 2, 2,
                           facecolor='#F2E4C9', edgecolor=C_LINE, lw=0.6, zorder=5))
    ax.text(h_x + 4, h_y + 10, 'Habitations', ha='center', fontsize=9.5,
            color='#1A1A1A', fontweight='bold')

    # Personnage (silhouette adulte) à droite des habitations
    px, py = 91, y_surf
    ax.add_patch(Circle((px, py + 5.2), 0.9, color=C_LINE, zorder=5))  # tête
    ax.plot([px, px], [py + 0.5, py + 4.3], color=C_LINE, lw=2, zorder=5)  # corps
    ax.plot([px - 1.3, px + 1.3], [py + 3.2, py + 3.2], color=C_LINE, lw=1.5, zorder=5)  # bras
    ax.plot([px, px - 1.2], [py + 0.5, py - 1.5], color=C_LINE, lw=1.5, zorder=5)  # jambe
    ax.plot([px, px + 1.2], [py + 0.5, py - 1.5], color=C_LINE, lw=1.5, zorder=5)  # jambe

    # Jardins potagers (petits traits verticaux verts) entre maisons et nappe
    pot_x = 67
    for i in range(5):
        ax.plot([pot_x + i*1.1, pot_x + i*1.1],
                [y_surf, y_surf + 1.8], color='#2D7A3D', lw=1.8, zorder=4)
    ax.text(pot_x + 2.5, y_surf + 11, 'Jardins\npotagers',
            ha='center', fontsize=9, color='#1A1A1A')
    # Trait de rappel
    ax.plot([pot_x + 2.5, pot_x + 2.5], [y_surf + 2, y_surf + 9.5],
            color='#7A7A7A', lw=0.6, linestyle=':', zorder=3)

    # Puits privatif (tube + margelle) au milieu droit
    pu_x = 60
    ax.add_patch(Rectangle((pu_x - 0.6, y_surf), 1.2, 1.5,
                           facecolor='#9A9A9A', edgecolor=C_LINE, lw=0.8, zorder=5))
    ax.plot([pu_x, pu_x], [y_surf, 18], color=C_LINE, lw=1.4, zorder=4)
    ax.plot([pu_x - 0.6, pu_x + 0.6], [18, 18], color=C_LINE, lw=1.4, zorder=4)
    ax.text(pu_x, y_surf + 6.5, 'Puits\nprivatif', ha='center', fontsize=9, color='#1A1A1A')
    ax.plot([pu_x, pu_x], [y_surf + 2, y_surf + 5], color='#7A7A7A', lw=0.6, linestyle=':', zorder=3)

    # Canalisation AEP (horizontal noir) sous le sol à droite
    ax.add_patch(Rectangle((85, y_surf - 4), 12, 1.2,
                           facecolor='#3A3A3A', edgecolor=C_LINE, lw=0.8, zorder=4))
    ax.text(91, y_surf - 6.8, 'Canalisation\n(eau potable)',
            ha='center', fontsize=8.5, color='#1A1A1A', style='italic')

    # Sens d'écoulement de la nappe (flèche horizontale noire dans zone saturée)
    ax.annotate('', xy=(85, 23), xytext=(45, 23),
                arrowprops=dict(arrowstyle='-|>', color=C_LINE, lw=1.5))
    ax.text(65, 24.5, "Sens d'écoulement\ndes eaux", ha='center', fontsize=8.5,
            color=C_LINE, style='italic')

    # === FLÈCHES DE TRANSFERT (couleurs dynamiques) ===
    # Chaque flèche : (clé risque, x1, y1, x2, y2, lettre, label_x_offset)
    def arrow(level_key, x1, y1, x2, y2, letter, lbl_dx=0, lbl_dy=0):
        qd, eri = risks[level_key]
        lvl = get_risk_level(qd, eri)
        col = color_for(lvl)
        a = FancyArrowPatch((x1, y1), (x2, y2),
                            arrowstyle='-|>', mutation_scale=18,
                            color=col, lw=2.6, zorder=7,
                            shrinkA=2, shrinkB=2)
        ax.add_patch(a)
        # Pastille blanche avec la lettre
        mx = (x1 + x2) / 2 + lbl_dx
        my = (y1 + y2) / 2 + lbl_dy
        ax.add_patch(Circle((mx, my), 1.2, facecolor='white',
                            edgecolor=col, lw=1.5, zorder=8))
        ax.text(mx, my, letter, ha='center', va='center', fontsize=9.5,
                fontweight='bold', style='italic', color=col, zorder=9)

    # a — Percolation : surface site → panache zone non saturée → nappe
    arrow('percolation', 19, y_surf - 0.5, 19, 32, 'a', lbl_dx=2.2, lbl_dy=0)

    # b — Transfert via eaux souterraines : panache nappe → captage (puits)
    arrow('eau_aep', 32, 22, 58, 22, 'b', lbl_dx=0, lbl_dy=2.5)

    # c — Arrosage : depuis puits/canalisation → potager (flèche courbe descendante au-dessus du potager)
    arrow('arrosage', 60, y_surf + 6, 66, y_surf + 2, 'c', lbl_dx=-1.5, lbl_dy=2)

    # d — Volatilisation J&E : panache zone non saturée → air intérieur habitation
    arrow('inhal_vapeurs', 67, 36, 80, y_surf + 0.5, 'd', lbl_dx=0, lbl_dy=1)

    # e — Canalisation AEP (perméation depuis nappe vers tuyau)
    arrow('canalisation', 88, y_surf - 1, 88, y_surf - 3.8, 'e', lbl_dx=2, lbl_dy=0)

    # f — Anciennes retombées atmosphériques (fumée → habitations)
    arrow('retombees', 45, 63, 78, 50, 'f', lbl_dx=0, lbl_dy=2)

    # g — Sols de subsurface (contact direct → personne)
    arrow('ingestion_sol', 95, y_surf - 1, 92, y_surf + 1, 'g', lbl_dx=1.8, lbl_dy=0)

    # h — Plantes (sol/eau → potager)
    arrow('plantes', 65, y_surf - 1, 66, y_surf + 1.5, 'h', lbl_dx=2, lbl_dy=0)

    # === BANDEAU DE LÉGENDE (en bas) — 3 lignes pour aération ===
    leg_y = -2.5
    leg_h = 7.5
    ax.add_patch(Rectangle((-9, leg_y), 110, leg_h, facecolor='white',
                           edgecolor='#7A7A7A', lw=1, zorder=10))
    ax.text(-7, leg_y + leg_h - 0.9, "Légende", fontsize=10.5,
            fontweight='bold', color='#1A1A1A', zorder=11)

    # Ligne 1 — Sources de pollution
    row1_y = leg_y + leg_h - 2.3
    ax.text(-7, row1_y, "Sources de pollution :", fontsize=8.5,
            color='#1A1A1A', zorder=11, va='center', fontweight='bold')
    sources = [
        ('1', 'Solvants chlorés'),
        ('2', 'Remblais souillés au plomb'),
        ('3', 'Sols souillés au plomb'),
    ]
    sx = 14
    for num, lbl in sources:
        ax.add_patch(Circle((sx, row1_y), 0.9, facecolor='white',
                            edgecolor=C_LINE, lw=1, zorder=11))
        ax.text(sx, row1_y, num, ha='center', va='center',
                fontsize=8.5, fontweight='bold', color=C_LINE, zorder=12)
        ax.text(sx + 1.6, row1_y, lbl, fontsize=8,
                color='#1A1A1A', va='center', zorder=11)
        sx += 18

    # Ligne 1 droite — Transfert
    ax.annotate('', xy=(96, row1_y), xytext=(91, row1_y),
                arrowprops=dict(arrowstyle='-|>', color=C_DANGER, lw=2.5), zorder=12)
    ax.text(89.5, row1_y, 'Transfert de pollution :',
            fontsize=8.5, color='#1A1A1A', ha='right', va='center',
            zorder=11, fontweight='bold')

    # Lignes 2-3 — Lettres a-h (4 par ligne)
    letters_def = [
        ('a', 'Percolation'),
        ('b', 'Transfert via les eaux souterraines'),
        ('c', 'Arrosage'),
        ('d', 'Volatilisation'),
        ('e', 'Canalisation AEP'),
        ('f', 'Anciennes retombées atmosphériques'),
        ('g', 'Sols de subsurface'),
        ('h', 'Plantes'),
    ]
    row2_y = leg_y + leg_h - 4.5
    row3_y = leg_y + leg_h - 6.4
    col_x = [-7, 22, 51, 80]
    for i, (l, lbl) in enumerate(letters_def):
        row_y = row2_y if i < 4 else row3_y
        cx = col_x[i % 4]
        ax.add_patch(Circle((cx, row_y), 0.9, facecolor='white',
                            edgecolor=C_LINE, lw=1, zorder=11))
        ax.text(cx, row_y, l, ha='center', va='center',
                fontsize=8.5, fontweight='bold', style='italic',
                color=C_LINE, zorder=12)
        ax.text(cx + 1.6, row_y, lbl, fontsize=8,
                color='#1A1A1A', va='center', zorder=11)

    # === BANDEAU DYNAMIQUE EN HAUT — synthèse des risques détectés ===
    danger = [k for k, (q, e) in risks.items() if get_risk_level(q, e) == 'danger']
    warn   = [k for k, (q, e) in risks.items() if get_risk_level(q, e) == 'warn']
    if danger:
        col_box = C_DANGER
        msg = f"État : INACCEPTABLE — {len(danger)} voie(s) > seuils EQRS — mesures de gestion à mettre en œuvre"
    elif warn:
        col_box = C_WARN
        msg = f"État : VIGILANCE — {len(warn)} voie(s) en zone d'attention — investigations complémentaires"
    else:
        col_box = C_OK
        msg = "État : ACCEPTABLE — toutes voies sous seuils EQRS"

    ax.add_patch(Rectangle((1, 69), 98, 2.2, facecolor=col_box,
                           edgecolor='none', alpha=0.9, zorder=10))
    ax.text(50, 70.1, msg, ha='center', va='center', fontsize=10.5,
            fontweight='bold', color='white', zorder=11)

    # Titre Figure (sous la légende)
    ax.text(50, -7, "Figure : Schéma conceptuel du cas étudié — "
                    "couleur des flèches selon QD/ERI calculés "
                    "(vert = acceptable, orange = vigilance, rouge = inacceptable)",
            ha='center', va='top', fontsize=9, style='italic', color='#1A1A1A')
    ax.set_xlim(-10, 102)
    ax.set_ylim(-9, 72)

    plt.tight_layout()
    plt.savefig(outfile_png, dpi=200, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    if outfile_pdf:
        plt.savefig(outfile_pdf, bbox_inches='tight',
                    facecolor='white', edgecolor='none')
    plt.close(fig)
    print(f"[OK] Schéma écrit : {outfile_png}")
    if outfile_pdf:
        print(f"[OK] Schéma écrit : {outfile_pdf}")

# -------------------------------------------------------------------
def integrate_into_xlsx(xlsx_path, png_path):
    """Insère le PNG dans la feuille Schéma_Conceptuel à partir de la ligne 22.

    Tolérant : si le classeur est ouvert dans Excel (PermissionError),
    on saute proprement cette étape sans interrompre le pipeline
    (le PNG/PDF du schéma sont déjà écrits côté disque).
    """
    from openpyxl.drawing.image import Image as XLImage
    try:
        wb = openpyxl.load_workbook(xlsx_path)
    except PermissionError:
        print("[info] Le classeur est ouvert dans Excel — intégration de l'image dans le "
              ".xlsx sautée (le PNG/PDF du schéma sont quand même écrits dans le dossier).")
        return
    except Exception as e:
        print(f"[avert] Impossible d'ouvrir le classeur pour intégration : {e}")
        return
    if 'Schéma_Conceptuel' not in wb.sheetnames:
        print("[avert] Feuille Schéma_Conceptuel absente — création requise au préalable.")
        return
    ws = wb['Schéma_Conceptuel']
    # Supprimer images existantes (idempotent)
    ws._images = []
    img = XLImage(png_path)
    # Redimensionner (largeur 980px env. = ~14 colonnes)
    img.width = 980
    img.height = 630
    img.anchor = 'B22'
    ws.add_image(img)
    out = xlsx_path
    try:
        wb.save(out)
        print(f"[OK] Image insérée dans {out} (feuille Schéma_Conceptuel, ancrage B22)")
    except PermissionError:
        print("[info] Sauvegarde du classeur impossible (fichier verrouillé par Excel) — "
              "étape sautée. Le PNG/PDF du schéma sont OK.")
    except Exception as e:
        print(f"[avert] Sauvegarde du classeur échouée : {e}")

# -------------------------------------------------------------------
if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    flags = [a for a in sys.argv[1:] if a.startswith('--')]
    xlsx = Path(args[0]) if args else DEFAULT_XLSX

    if '--demo-mixed' in flags:
        out_png = WORKSPACE / 'Schema_Conceptuel_Illustre_demo_mixed.png'
        out_pdf = WORKSPACE / 'Schema_Conceptuel_Illustre_demo_mixed.pdf'
        # Scénario de démonstration : sols et vapeurs en risque, eaux ok
        risks = {
            'percolation':   (1.5, 2e-5),    # INACCEPTABLE
            'eau_aep':       (0.05, 1e-7),   # ok
            'arrosage':      (0.3, 5e-7),    # VIGILANCE
            'inhal_vapeurs': (2.0, 3e-5),    # INACCEPTABLE
            'canalisation':  (0.1, 2e-7),    # ok
            'retombees':     (0.25, 5e-7),   # VIGILANCE
            'ingestion_sol': (1.8, 1.5e-5),  # INACCEPTABLE
            'plantes':       (0.4, 2e-6),    # VIGILANCE
        }
    else:
        out_png = WORKSPACE / 'Schema_Conceptuel_Illustre.png'
        out_pdf = WORKSPACE / 'Schema_Conceptuel_Illustre.pdf'
        risks = read_risks(xlsx)
    print("=== Risques détectés ===")
    for k, (q, e) in risks.items():
        lvl = get_risk_level(q, e)
        print(f"  {k:18s} QD={q} ERI={e}  →  {lvl}")

    draw_schema(risks, out_png, out_pdf)
    if '--demo-mixed' not in flags:
        integrate_into_xlsx(xlsx, str(out_png))
