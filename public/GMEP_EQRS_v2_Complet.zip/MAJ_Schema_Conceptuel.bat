@echo off
REM ========================================================================
REM GMEP - Mise a jour du schema conceptuel EQRS
REM Lance le script Python qui regenere le schema selon les QD/ERI calcules
REM ========================================================================

setlocal
cd /d "%~dp0"

set "XLSX=EQRS_Johnson_Ettinger_V7.xlsx"
set "SCRIPT=build_schema_conceptuel_illustre.py"

if not exist "%XLSX%" (
    echo Fichier introuvable : %XLSX%
    echo Placez ce .bat dans le meme dossier que le classeur.
    pause
    exit /b 1
)
if not exist "%SCRIPT%" (
    echo Script introuvable : %SCRIPT%
    pause
    exit /b 1
)

REM Detection de Python
where py >nul 2>&1
if %errorlevel%==0 (
    set "PYEXE=py"
) else (
    where python >nul 2>&1
    if %errorlevel%==0 (
        set "PYEXE=python"
    ) else (
        echo Python introuvable.
        echo Installez-le depuis https://www.python.org/downloads/ en cochant 'Add to PATH'.
        pause
        exit /b 1
    )
)

echo.
echo === Mise a jour du schema conceptuel EQRS ===
echo.
%PYEXE% "%SCRIPT%" "%XLSX%"
if %errorlevel% neq 0 (
    echo.
    echo *** Erreur. Verifiez l'installation des dependances :
    echo     pip install matplotlib openpyxl
    pause
    exit /b 1
)

echo.
echo === Termine. Vous pouvez rouvrir le classeur Excel pour voir le schema mis a jour. ===
echo.
pause
