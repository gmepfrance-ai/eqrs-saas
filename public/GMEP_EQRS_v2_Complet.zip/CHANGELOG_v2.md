# GMEP — EQRS Johnson & Ettinger — Notes de version v2.1

**Date :** 22 mai 2026
**Auteur :** GMEP — Eric Azulay (gmep.france@gmail.com)
**Site :** www.gmep-france.eu

---

## Révision v2.1 — Rapport PDF enrichi

Le rapport PDF passe de **5 à 14 pages** avec ajout de cinq nouvelles sections :

- **§5. Notes de calcul** — formules détaillées (DJE, QD, ERI), seuils
  d'interprétation colorés et tableau des paramètres d'exposition par cible
  (Adulte / Enfant / Salarié — BW, IR, ED, EF, SA).
- **§6. Tableau VTR à seuil complet** — ~70 substances classées par famille
  (BTEX, HAP, Métaux, Solvants chlorés, COV, Hydrocarbures TPHCWG, Pesticides,
  PCB, PFAS, Dioxines) avec n° CAS, VTR Orale / Inhalation / Cutanée, source
  et effet critique.
- **§7. Tableau VTR sans seuil complet** — ~30 substances cancérigènes avec
  ERU Oral et ERU Inhalation, source et effet.
- **§8. Détail QD par substance et par voie** — 3 sous-tableaux
  (Adulte / Enfant / Salarié) avec coloration cellule par cellule selon les
  seuils (vert / orange / rouge).
- **§9. Détail ERI par substance et par voie** — 3 sous-tableaux avec
  coloration par seuil.

Le rapport est régénéré à chaque clic sur le bouton du classeur ou via
`EDITER_Rapport_PDF.bat`. Tant qu'aucune concentration n'est saisie, les
sections détail QD/ERI affichent un message d'invitation à saisir les données.

---

## Synthèse v2

Mise en conformité totale avec la **méthodologie INERIS DRC-09-103096-09387C** et
**US-EPA RAGS Part A §8.2 / §8.3** : les Σ QD et Σ ERI ne sont plus additionnés
globalement, mais **uniquement par organe cible** ou par type de cancer.

---

## Évolutions majeures

### 1. Classeur Excel `EQRS_Johnson_Ettinger_V7.xlsx`

#### Feuille **Résultats_QD**
- **Lignes 95-113** : nouveau tableau « EFFETS CUMULÉS SUR LA SANTÉ — Σ QD PAR ORGANE CIBLE ».
- **13 organes cibles** : Sang/hématopoïèse, SNC, Foie, Reins, Système respiratoire, Système immunitaire, Système thyroïdien, Cardiovasculaire, Tractus gastro-intestinal, Peau, Endocrinien/métabolique, Développement/reproduction, Effets systémiques multiples.
- Pour chaque organe : effets sanitaires attendus, nombre de substances mappées, **Σ QD par voie d'exposition** (SUMPRODUCT).
- **Ligne 112** : MAX par voie d'exposition (lue par le schéma conceptuel).
- **Ligne 113** : état sanitaire (Acceptable / Vigilance / Inacceptable) avec format conditionnel vert/orange/rouge.

#### Feuille **Résultats_ERI**
- **Lignes 52-65** : nouveau tableau « EFFETS CANCÉRIGÈNES CUMULÉS PAR ORGANE CIBLE — Σ ERI ».
- **8 organes cancer** : Sang (leucémie), Foie, Poumon, Peau, Rein, Voies digestives/multi-organes, Voies aérodigestives supérieures, Thyroïde.
- Ligne 64 : MAX par voie ; ligne 65 : état sanitaire coloré.

#### Feuille **Sommaire**
- **Lignes 31-37** : synthèse exécutive avec **4 indicateurs colorés** (Pire Σ QD adulte/enfant, Pire Σ ERI adulte/enfant) et liens vers les tableaux détaillés.
- **Lignes 42-45** : nouvelle carte « Éditer le rapport PDF complet » avec instructions d'utilisation.

### 2. Schéma conceptuel dynamique
- Le script `build_schema_conceptuel_illustre.py` détecte automatiquement la présence des nouveaux tableaux organes cibles.
- Si présents : lit `Résultats_QD!L112` (QD MAX par voie) et `Résultats_ERI!L64` (ERI MAX par voie).
- Sinon : fallback compatible v1 sur L90 / L47.
- Les flèches a-h sont colorées selon le pire Σ par organe sur chaque voie.

### 3. Rapport PDF complet (NOUVEAU)
- Nouveau script `build_rapport_EQRS.py` qui génère `Rapport_EQRS_Johnson_Ettinger.pdf` :
  1. Couverture (titre, date, GMEP, méthodologie INERIS / US-EPA).
  2. Synthèse exécutive (4 indicateurs colorés + listing organes/cancers en alerte).
  3. Schéma conceptuel régénéré.
  4. Tableau Σ QD par organe (13 lignes, niveaux colorés).
  5. Tableau Σ ERI par cancer (8 lignes, niveaux colorés).
  6. Conclusion sanitaire adaptative (acceptable / vigilance / inacceptable).
- Lanceur Windows `EDITER_Rapport_PDF.bat`.
- Macro VBA `EditerRapportEQRS` (module `modSchemaEQRS.bas`) → lance le script et ouvre le PDF.

### 4. Site internet www.gmep-france.eu
- Page **EQRS Johnson & Ettinger** : nouvelle section « Σ QD et Σ ERI par organe cible » (6 feature-cards + détail repliable des 13 organes + 8 cancers).
- Ajout des références INERIS DRC-09-103096-09387C et US-EPA RAGS Part A §8.2/§8.3.

### 5. Guide d'installation
- Refonte de `Guide_Installation_Schema_EQRS.pdf` (7 pages) :
  - §4 : nouvelle section « Σ QD et Σ ERI par organe cible » avec tableau des 13 organes.
  - §5 : nouvelle section « Édition du rapport PDF complet » (option .bat + option VBA).
  - Dépannage enrichi (reportlab, rapport PDF, sommes par organe).

---

## Fichier de mapping
- **`mapping_organes_eqrs.json`** : 26 effets seuil → 13 organes ; 15 cancers → 8 organes cancer.
- 100 % des effets de VTR_Seuil et VTR_SansSeuil sont couverts.

---

## Vérifications
- Recalcul du classeur : **0 erreur sur 3823 formules**.
- Rapport PDF testé sur classeur vierge : génération nominale (synthèse en mode « non évalué »).
- Schéma conceptuel testé avec fallback v1 et nouveau mode v2.

---

## Méthodologie de référence

> **INERIS DRC-09-103096-09387C** — Évaluation des risques sanitaires dans les études d'impact des installations classées ; cumul des QD par organe cible et des ERI par effet cancérigène (méthodologie nationale française).
>
> **US-EPA RAGS Part A §8.2 (Hazard Index by target organ)** et **§8.3 (Cancer risk by cancer type)** — Risk Assessment Guidance for Superfund Volume 1 : sommation des risques uniquement entre substances agissant sur le même organe.

---

## Contact
**Eric Azulay — gmep.france@gmail.com — www.gmep-france.eu**
