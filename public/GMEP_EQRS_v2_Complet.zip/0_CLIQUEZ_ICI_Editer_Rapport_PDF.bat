@echo off
REM ========================================================================
REM GMEP - Edition du rapport EQRS complet en PDF
REM 1) Regenere le schema conceptuel selon les QD/ERI calcules
REM 2) Genere le rapport PDF complet (synthese, organes, conclusion)
REM 3) Ouvre automatiquement le PDF
REM ========================================================================

setlocal
cd /d "%~dp0"

set "XLSX=EQRS_Johnson_Ettinger_V7.xlsx"
set "SCRIPT_SCHEMA=build_schema_conceptuel_illustre.py"
set "SCRIPT_RAPPORT=build_rapport_EQRS.py"
set "PDF_OUT=Rapport_EQRS_Johnson_Ettinger.pdf"

if not exist "%XLSX%" (
    echo Fichier introuvable : %XLSX%
    echo Placez ce .bat dans le meme dossier que le classeur.
    pause
    exit /b 1
)
if not exist "%SCRIPT_SCHEMA%" (
    echo Script introuvable : %SCRIPT_SCHEMA%
    pause
    exit /b 1
)
if not exist "%SCRIPT_RAPPORT%" (
    echo Script introuvable : %SCRIPT_RAPPORT%
    pause
    exit /b 1
)

REM Detection de Python
where py >nul 2>&1
if %errorlevel%==0 (
    set "PYEXE=py"
) else (
    where python >nul 2>&1
    if %errorlevel%==0 (
        set "PYEXE=python"
    ) else (
        echo Python introuvable.
        echo Installez-le depuis https://www.python.org/downloads/ en cochant 'Add to PATH'.
        pause
        exit /b 1
    )
)

echo.
echo === Etape 1/2 : regeneration du schema conceptuel ===
echo.
%PYEXE% "%SCRIPT_SCHEMA%" "%XLSX%"
if %errorlevel% neq 0 (
    echo.
    echo *** Erreur lors de la regeneration du schema.
    echo *** Verifiez les dependances :
    echo     pip install matplotlib openpyxl reportlab
    pause
    exit /b 1
)

echo.
echo === Etape 2/2 : generation du rapport PDF ===
echo.
%PYEXE% "%SCRIPT_RAPPORT%" "%XLSX%"
if %errorlevel% neq 0 (
    echo.
    echo *** Erreur lors de la generation du rapport.
    echo *** Verifiez les dependances :
    echo     pip install matplotlib openpyxl reportlab
    pause
    exit /b 1
)

echo.
echo === Termine. Ouverture du rapport PDF... ===
echo.

if exist "%PDF_OUT%" (
    start "" "%PDF_OUT%"
) else (
    echo Rapport PDF introuvable apres generation.
    pause
    exit /b 1
)

endlocal
