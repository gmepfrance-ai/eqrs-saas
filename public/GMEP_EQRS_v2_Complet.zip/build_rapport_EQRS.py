#!/usr/bin/env python3
"""
Génère un rapport PDF complet d'EQRS à partir du classeur Excel.

Contenu :
  - Page de garde
  - Synthèse exécutive (organes/cancers impactés)
  - Schéma conceptuel dynamique
  - Tableau Σ QD par organe cible
  - Tableau Σ ERI par type de cancer
  - Conclusion et signature

Usage :
    python3 build_rapport_EQRS.py [chemin_xlsx]

Sans argument : utilise EQRS_Johnson_Ettinger_V7.xlsx
Sortie : Rapport_EQRS_Johnson_Ettinger.pdf
"""

import sys, os, subprocess
from pathlib import Path
from datetime import datetime
import openpyxl
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak,
    Table, TableStyle, HRFlowable, KeepTogether
)

# Dossier du script (portable Windows / Mac / Linux)
import sys as _sys, os as _os
if len(_sys.argv) > 1 and _sys.argv[1]:
    WORKSPACE = Path(_os.path.abspath(_sys.argv[1])).parent
else:
    WORKSPACE = Path(_os.path.dirname(_os.path.abspath(__file__)))
DEFAULT_XLSX = WORKSPACE / 'EQRS_Johnson_Ettinger_V7.xlsx'
DEFAULT_PDF  = WORKSPACE / 'Rapport_EQRS_Johnson_Ettinger.pdf'

# Palette
C_TITLE  = HexColor('#1F3864')
C_ACCENT = HexColor('#2E5496')
C_BG     = HexColor('#D9E2F3')
C_OK     = HexColor('#3F8E3F')
C_WARN   = HexColor('#E58E1A')
C_DANGER = HexColor('#C0272D')
C_NEUTRAL= HexColor('#6E6E6E')
C_TEXT   = HexColor('#262626')
C_GREY   = HexColor('#595959')

# Seuils EQRS
QD_INACCEPT = 1.0
QD_VIGIL    = 0.2
ERI_INACCEPT = 1e-5
ERI_VIGIL    = 1e-6

# Styles
styles = getSampleStyleSheet()
s_h1 = ParagraphStyle('h1', parent=styles['Heading1'],
                     fontName='Helvetica-Bold', fontSize=18,
                     textColor=C_TITLE, spaceAfter=10, spaceBefore=14)
s_h2 = ParagraphStyle('h2', parent=styles['Heading2'],
                     fontName='Helvetica-Bold', fontSize=13,
                     textColor=C_ACCENT, spaceAfter=6, spaceBefore=14)
s_body = ParagraphStyle('body', parent=styles['BodyText'],
                       fontName='Helvetica', fontSize=10,
                       textColor=C_TEXT, leading=14, alignment=TA_JUSTIFY,
                       spaceAfter=4)
s_note = ParagraphStyle('note', parent=s_body,
                       fontSize=9, textColor=C_GREY,
                       fontName='Helvetica-Oblique')
s_cell = ParagraphStyle('cell', parent=s_body, fontSize=9, leading=11,
                        spaceAfter=0, alignment=TA_LEFT)
s_cell_hdr = ParagraphStyle('cell_hdr', parent=s_body, fontSize=8.5, leading=10,
                            spaceAfter=0, alignment=TA_CENTER,
                            textColor=HexColor('#FFFFFF'),
                            fontName='Helvetica-Bold')

def page_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica', 8)
    canvas.setFillColor(C_GREY)
    canvas.drawString(2*cm, 1.2*cm,
                      "GMEP - www.gmep-france.eu - gmep.france@gmail.com")
    canvas.drawRightString(A4[0] - 2*cm, 1.2*cm, f"Page {doc.page}")
    canvas.restoreState()


# ----------------------------------------------------------------
def get_level_qd(qd):
    if qd is None: return ('neutral', 'Non évalué', C_NEUTRAL)
    if qd >= QD_INACCEPT: return ('danger', 'Inacceptable', C_DANGER)
    if qd >= QD_VIGIL:    return ('warn',   'Vigilance',    C_WARN)
    return ('ok', 'Acceptable', C_OK)

def get_level_eri(eri):
    if eri is None: return ('neutral', 'Non évalué', C_NEUTRAL)
    if eri >= ERI_INACCEPT: return ('danger', 'Inacceptable', C_DANGER)
    if eri >= ERI_VIGIL:    return ('warn',   'Acceptable',   C_WARN)
    return ('ok', 'Négligeable', C_OK)


def fmt_qd(v):
    if v is None or v == 0: return '—'
    if v < 0.001: return f'{v:.2e}'
    return f'{v:.3f}'

def fmt_eri(v):
    if v is None or v == 0: return '—'
    return f'{v:.2e}'

def fmt_num_vtr(v):
    """Formate une valeur VTR/ERU (peut être None, str, ou float)."""
    if v is None or v == '':
        return '—'
    if isinstance(v, str):
        return v
    try:
        f = float(v)
        if f == 0:
            return '—'
        if f < 0.001 or f >= 1e5:
            return f'{f:.2e}'
        if f < 1:
            return f'{f:.4f}'.rstrip('0').rstrip('.')
        return f'{f:.3g}'
    except (TypeError, ValueError):
        return str(v)


# ----------------------------------------------------------------
def read_workbook(xlsx_path):
    """Extrait toutes les données nécessaires au rapport."""
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    data = {}

    # === Synthèse globale (Sommaire) ===
    ws_s = wb['Sommaire']
    data['indicateurs'] = []
    for r in range(35, 39):
        label = ws_s.cell(row=r, column=2).value
        val   = ws_s.cell(row=r, column=3).value
        etat  = ws_s.cell(row=r, column=4).value
        if label:
            data['indicateurs'].append((label, val, etat))

    # === Tableaux organes (Résultats_QD lignes 99-111) ===
    ws_q = wb['Résultats_QD']
    organes = []
    for r in range(99, 112):
        organe = ws_q.cell(row=r, column=2).value
        if not organe:
            continue
        desc = ws_q.cell(row=r, column=3).value
        nb = ws_q.cell(row=r, column=4).value
        # Toutes les valeurs QD de la ligne (colonnes 5..18)
        vals = []
        for c in range(5, 19):
            v = ws_q.cell(row=r, column=c).value
            try:
                vv = float(v)
                if vv > 0: vals.append(vv)
            except (TypeError, ValueError):
                pass
        mx = max(vals) if vals else None
        organes.append({
            'organe': organe,
            'desc': desc,
            'nb': nb,
            'max_qd': mx,
        })
    data['organes'] = organes

    # === Tableaux cancers (Résultats_ERI lignes 56-63) ===
    ws_e = wb['Résultats_ERI']
    cancers = []
    for r in range(56, 64):
        cancer = ws_e.cell(row=r, column=2).value
        if not cancer:
            continue
        desc = ws_e.cell(row=r, column=3).value
        nb = ws_e.cell(row=r, column=4).value
        vals = []
        for c in range(5, 15):
            v = ws_e.cell(row=r, column=c).value
            try:
                vv = float(v)
                if vv > 0: vals.append(vv)
            except (TypeError, ValueError):
                pass
        mx = max(vals) if vals else None
        cancers.append({
            'cancer': cancer,
            'desc': desc,
            'nb': nb,
            'max_eri': mx,
        })
    data['cancers'] = cancers

    # === Concentrations saisies (sommaire des substances présentes) ===
    ws_c = wb['Concentrations']
    subst_actives = []
    for r in range(7, 90):
        nom = ws_c.cell(row=r, column=2).value
        # On regarde si au moins une concentration est saisie (colonnes C..F)
        if not nom: continue
        for c in range(3, 8):
            v = ws_c.cell(row=r, column=c).value
            try:
                if v is not None and float(v) > 0:
                    subst_actives.append(nom)
                    break
            except (TypeError, ValueError):
                pass
    data['substances_actives'] = subst_actives

    # === VTR à seuil (feuille VTR_Seuil, lignes 5-89) ===
    # En-têtes : B=Substance | C=CAS | D=VTR Orale | E=VTR Inhal. | F=VTR Cutanée | G=Source | H=Effet
    ws_v = wb['VTR_Seuil']
    vtr_seuil = []
    for r in range(5, 90):
        nom = ws_v.cell(row=r, column=2).value
        if not nom:
            continue
        cas = ws_v.cell(row=r, column=3).value
        vtr_o = ws_v.cell(row=r, column=4).value
        vtr_i = ws_v.cell(row=r, column=5).value
        vtr_c = ws_v.cell(row=r, column=6).value
        src = ws_v.cell(row=r, column=7).value
        eff = ws_v.cell(row=r, column=8).value
        # Ligne de famille = uniquement la colonne B remplie, tout le reste vide
        is_family = (not cas and vtr_o is None and vtr_i is None and vtr_c is None
                     and not src and not eff)
        vtr_seuil.append({
            'is_family': is_family,
            'substance': nom,
            'cas': cas,
            'vtr_o': vtr_o,
            'vtr_i': vtr_i,
            'vtr_c': vtr_c,
            'source': src,
            'effet': eff,
        })
    data['vtr_seuil'] = vtr_seuil

    # === VTR sans seuil (feuille VTR_SansSeuil, lignes 5-46) ===
    # En-têtes : B=Substance | C=CAS | D=ERU Oral | E=ERU Inhal. | F=Source | G=Effet
    ws_vs = wb['VTR_SansSeuil']
    vtr_sans = []
    for r in range(5, 47):
        nom = ws_vs.cell(row=r, column=2).value
        if not nom:
            continue
        cas = ws_vs.cell(row=r, column=3).value
        eru_o = ws_vs.cell(row=r, column=4).value
        eru_i = ws_vs.cell(row=r, column=5).value
        src = ws_vs.cell(row=r, column=6).value
        eff = ws_vs.cell(row=r, column=7).value
        is_family = (not cas and eru_o is None and eru_i is None
                     and not src and not eff)
        vtr_sans.append({
            'is_family': is_family,
            'substance': nom,
            'cas': cas,
            'eru_o': eru_o,
            'eru_i': eru_i,
            'source': src,
            'effet': eff,
        })
    data['vtr_sans_seuil'] = vtr_sans

    # === Détail QD par substance et par voie (lignes 6-88) ===
    # Voies utiles (col, label) — on conserve les 14 voies d'exposition
    qd_voies = [
        (5,  'Ing.Sol Ad'),  (6,  'Ing.Sol Enf'),
        (7,  'Ing.Eau Ad'),  (8,  'Ing.Eau Enf'),
        (9,  'Inhal. Ad'),   (10, 'Inhal. Enf'),
        (11, 'Cutané Ad'),
        (12, 'Ing.Sol Sal'), (13, 'Ing.Eau Sal'),
        (14, 'Inhal. Sal'),  (15, 'Cutané Sal'),
        (16, 'J&E Inhal.Ad'), (17, 'J&E Inhal.Enf'), (18, 'J&E Inhal.Sal'),
    ]
    detail_qd = []
    for r in range(6, 89):
        subst = ws_q.cell(row=r, column=2).value
        if not subst:
            continue
        voies_vals = {}
        somme_qd = 0.0
        for col, lbl in qd_voies:
            v = ws_q.cell(row=r, column=col).value
            try:
                vv = float(v)
                if vv > 0:
                    voies_vals[lbl] = vv
                    somme_qd += vv
            except (TypeError, ValueError):
                pass
        if voies_vals:
            detail_qd.append({
                'substance': subst,
                'voies': voies_vals,
                'max': max(voies_vals.values()),
                'somme': somme_qd,
            })
    data['detail_qd'] = detail_qd
    data['qd_voies_ordre'] = [lbl for _, lbl in qd_voies]

    # === Détail ERI par substance et par voie (lignes 6-46) ===
    eri_voies = [
        (5,  'Ing.Ad'),       (6,  'Inhal.Ad'),  (7,  'J&E Inh.Ad'),
        (8,  'Ing.Enf'),      (9,  'Inhal.Enf'), (10, 'J&E Inh.Enf'),
        (11, 'Cutané Enf'),   (12, 'Total Enf'),
        (13, 'Ing.Sal'),      (14, 'Inhal.Sal'),
    ]
    detail_eri = []
    for r in range(6, 47):
        subst = ws_e.cell(row=r, column=2).value
        if not subst:
            continue
        voies_vals = {}
        somme_eri = 0.0
        for col, lbl in eri_voies:
            v = ws_e.cell(row=r, column=col).value
            try:
                vv = float(v)
                if vv > 0:
                    voies_vals[lbl] = vv
                    somme_eri += vv
            except (TypeError, ValueError):
                pass
        if voies_vals:
            detail_eri.append({
                'substance': subst,
                'voies': voies_vals,
                'max': max(voies_vals.values()),
                'somme': somme_eri,
            })
    data['detail_eri'] = detail_eri
    data['eri_voies_ordre'] = [lbl for _, lbl in eri_voies]

    return data


# ----------------------------------------------------------------
def build_pdf(xlsx_path, out_pdf):
    data = read_workbook(xlsx_path)

    # Régénérer le schéma au préalable (si script disponible)
    schema_png = WORKSPACE / 'Schema_Conceptuel_Illustre.png'
    script = WORKSPACE / 'build_schema_conceptuel_illustre.py'
    if script.exists():
        try:
            subprocess.run([sys.executable, str(script), str(xlsx_path)],
                           check=False, capture_output=True, timeout=120)
        except Exception as e:
            print(f"[avert] Régénération schéma échouée : {e}")

    doc = SimpleDocTemplate(str(out_pdf), pagesize=A4,
                            leftMargin=2*cm, rightMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm,
                            title="Rapport EQRS - Johnson & Ettinger",
                            author="GMEP")
    story = []

    # === COUVERTURE ===
    story.append(Spacer(1, 3*cm))
    story.append(Paragraph(
        "Évaluation Quantitative<br/>des Risques Sanitaires",
        ParagraphStyle('cover', parent=s_h1, fontSize=26,
                       alignment=TA_CENTER, leading=32,
                       textColor=C_TITLE)))
    story.append(Spacer(1, 0.6*cm))
    story.append(Paragraph(
        "Modèle Johnson &amp; Ettinger — Intrusion de vapeurs",
        ParagraphStyle('sub', parent=s_body, fontSize=14,
                       alignment=TA_CENTER, textColor=C_ACCENT)))
    story.append(Spacer(1, 1.5*cm))
    story.append(HRFlowable(width="60%", thickness=2,
                            color=C_ACCENT, hAlign='CENTER'))
    story.append(Spacer(1, 1*cm))

    today = datetime.now().strftime('%d/%m/%Y')
    story.append(Paragraph(
        f"<b>Date d'édition :</b> {today}",
        ParagraphStyle('meta', parent=s_body, alignment=TA_CENTER, fontSize=11)))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "<b>Bureau d'études :</b> GMEP - Modélisation environnementale",
        ParagraphStyle('meta', parent=s_body, alignment=TA_CENTER, fontSize=11)))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "<b>Méthodologie :</b> INERIS DRC-09-103096-09387C — "
        "US-EPA RAGS Part A — MTES SSP 2017",
        ParagraphStyle('meta', parent=s_body, alignment=TA_CENTER, fontSize=10)))

    story.append(Spacer(1, 3*cm))
    story.append(HRFlowable(width="100%", thickness=1, color=C_ACCENT))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "<b>Important :</b> les quotients de danger (Σ QD) et excès de risque "
        "individuel (Σ ERI) sont calculés <b>par organe cible</b>. Seules les "
        "substances agissant sur le même organe ou induisant le même type de "
        "cancer sont additionnées (méthodologie INERIS / US-EPA).",
        s_note))
    story.append(PageBreak())

    # === 1. SYNTHÈSE EXÉCUTIVE ===
    story.append(Paragraph("1. Synthèse exécutive", s_h1))

    # Tableau des 4 indicateurs globaux
    ind_rows = [['Indicateur', 'Valeur', 'État sanitaire']]
    for label, val, etat in data['indicateurs']:
        if isinstance(val, float):
            if 'ERI' in (label or ''):
                vstr = f'{val:.2e}'
            else:
                vstr = f'{val:.3f}'
        else:
            vstr = str(val) if val is not None else '—'
        ind_rows.append([Paragraph(label, s_cell), vstr, etat or '—'])

    t = Table(ind_rows, colWidths=[9*cm, 3*cm, 4*cm])
    style_cmds = [
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR',  (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 10),
        ('FONT', (0,1), (-1,-1), 'Helvetica', 9.5),
        ('GRID', (0,0), (-1,-1), 0.5, HexColor('#8FAADC')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (1,0), (-1,-1), 'CENTER'),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('TOPPADDING', (0,0), (-1,-1), 6),
        ('BOTTOMPADDING', (0,0), (-1,-1), 6),
    ]
    # Coloration de la colonne État selon contenu
    for i, (_, _, etat) in enumerate(data['indicateurs']):
        if etat and 'Inacceptable' in str(etat):
            style_cmds.append(('BACKGROUND', (2, i+1), (2, i+1), HexColor('#FFC7CE')))
            style_cmds.append(('TEXTCOLOR',  (2, i+1), (2, i+1), HexColor('#9C0006')))
        elif etat and 'Vigilance' in str(etat):
            style_cmds.append(('BACKGROUND', (2, i+1), (2, i+1), HexColor('#FFEB9C')))
            style_cmds.append(('TEXTCOLOR',  (2, i+1), (2, i+1), HexColor('#9C5700')))
        elif etat and ('Acceptable' in str(etat) or 'Négligeable' in str(etat)):
            style_cmds.append(('BACKGROUND', (2, i+1), (2, i+1), HexColor('#C6EFCE')))
            style_cmds.append(('TEXTCOLOR',  (2, i+1), (2, i+1), HexColor('#006100')))
    t.setStyle(TableStyle(style_cmds))
    story.append(t)
    story.append(Spacer(1, 0.4*cm))

    # Listing des organes/cancers en alerte
    organes_alertes = [o for o in data['organes']
                       if o['max_qd'] is not None and o['max_qd'] >= QD_VIGIL]
    cancers_alertes = [c for c in data['cancers']
                       if c['max_eri'] is not None and c['max_eri'] >= ERI_VIGIL]

    if organes_alertes or cancers_alertes:
        story.append(Paragraph("Organes / effets à surveiller", s_h2))
        bullets = []
        for o in sorted(organes_alertes, key=lambda x: -(x['max_qd'] or 0)):
            lvl, lbl, col = get_level_qd(o['max_qd'])
            bullets.append(f"<b>{o['organe']}</b> — Σ QD max = {fmt_qd(o['max_qd'])} "
                           f"(<font color='#{col.hexval()[2:]}'><b>{lbl}</b></font>)")
        for c in sorted(cancers_alertes, key=lambda x: -(x['max_eri'] or 0)):
            lvl, lbl, col = get_level_eri(c['max_eri'])
            bullets.append(f"<b>{c['cancer']}</b> — Σ ERI max = {fmt_eri(c['max_eri'])} "
                           f"(<font color='#{col.hexval()[2:]}'><b>{lbl}</b></font>)")
        for b in bullets:
            story.append(Paragraph("• " + b, s_body))
    else:
        story.append(Paragraph(
            "<b>Aucun organe / type de cancer n'atteint le seuil de vigilance.</b> "
            "Tous les Σ QD < 0,2 et tous les Σ ERI < 10<super>-6</super>.",
            ParagraphStyle('ok', parent=s_body, textColor=C_OK,
                          fontName='Helvetica-Bold')))

    story.append(Spacer(1, 0.4*cm))

    # Substances saisies
    if data['substances_actives']:
        story.append(Paragraph(
            f"<b>Substances avec concentration saisie :</b> "
            f"{len(data['substances_actives'])} — "
            f"{', '.join(data['substances_actives'][:15])}"
            f"{'…' if len(data['substances_actives'])>15 else ''}",
            s_note))
    else:
        story.append(Paragraph(
            "<b>Aucune substance saisie dans la feuille Concentrations.</b> "
            "Saisir les concentrations puis régénérer le rapport.", s_note))

    story.append(PageBreak())

    # === 2. SCHÉMA CONCEPTUEL ===
    story.append(Paragraph("2. Schéma conceptuel du site", s_h1))
    story.append(Paragraph(
        "Le schéma ci-dessous représente les sources, vecteurs et cibles de "
        "pollution. Les flèches a-h sont colorées dynamiquement selon le "
        "pire Σ QD / Σ ERI calculé <b>par organe cible</b> sur chaque voie "
        "d'exposition.",
        s_body))
    if schema_png.exists():
        story.append(Spacer(1, 0.3*cm))
        story.append(Image(str(schema_png), width=17*cm, height=10.6*cm,
                          kind='proportional'))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "<b>Légende des couleurs :</b> "
        "<font color='#3F8E3F'><b>Vert</b></font> = acceptable "
        "(QD < 0,2 et ERI < 10<super>-6</super>) ; "
        "<font color='#E58E1A'><b>Orange</b></font> = vigilance "
        "(0,2 &#8804; QD &lt; 1 ou 10<super>-6</super> &#8804; ERI &lt; 10<super>-5</super>) ; "
        "<font color='#C0272D'><b>Rouge</b></font> = inacceptable "
        "(QD &#8805; 1 ou ERI &#8805; 10<super>-5</super>).",
        s_note))

    story.append(PageBreak())

    # === 3. TABLEAU Σ QD PAR ORGANE CIBLE ===
    story.append(Paragraph(
        "3. Effets cumulés sur la santé — Σ QD par organe cible", s_h1))
    story.append(Paragraph(
        "Pour chaque organe ou effet critique, on additionne uniquement les "
        "Quotients de Danger (QD) des substances qui agissent sur cet organe. "
        "Méthodologie INERIS DRC-09-103096-09387C / US-EPA RAGS Part A §8.2.",
        s_body))
    story.append(Spacer(1, 0.2*cm))

    rows = [['Organe / Effet', 'Effets sanitaires attendus', 'Subst.',
             'Σ QD max', 'État']]
    for o in data['organes']:
        lvl, lbl, col = get_level_qd(o['max_qd'])
        rows.append([
            Paragraph(f"<b>{o['organe']}</b>", s_cell),
            Paragraph(o['desc'] or '—', s_cell),
            str(o['nb'] or 0),
            fmt_qd(o['max_qd']),
            lbl,
        ])
    t = Table(rows, colWidths=[3.8*cm, 7.5*cm, 1.3*cm, 1.8*cm, 2.4*cm])
    style_cmds = [
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 9.5),
        ('FONT', (0,1), (-1,-1), 'Helvetica', 9),
        ('GRID', (0,0), (-1,-1), 0.4, HexColor('#8FAADC')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (2,1), (-1,-1), 'CENTER'),
        ('ROWBACKGROUNDS', (0,1), (-1,-1),
         [HexColor('#FFFFFF'), HexColor('#F4F6FB')]),
        ('LEFTPADDING', (0,0), (-1,-1), 4),
        ('RIGHTPADDING', (0,0), (-1,-1), 4),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ]
    for i, o in enumerate(data['organes']):
        lvl, _, _ = get_level_qd(o['max_qd'])
        if lvl == 'danger':
            style_cmds.append(('BACKGROUND', (4, i+1), (4, i+1), HexColor('#FFC7CE')))
            style_cmds.append(('TEXTCOLOR', (4, i+1), (4, i+1), HexColor('#9C0006')))
        elif lvl == 'warn':
            style_cmds.append(('BACKGROUND', (4, i+1), (4, i+1), HexColor('#FFEB9C')))
            style_cmds.append(('TEXTCOLOR', (4, i+1), (4, i+1), HexColor('#9C5700')))
        elif lvl == 'ok':
            style_cmds.append(('BACKGROUND', (4, i+1), (4, i+1), HexColor('#C6EFCE')))
            style_cmds.append(('TEXTCOLOR', (4, i+1), (4, i+1), HexColor('#006100')))
    t.setStyle(TableStyle(style_cmds))
    story.append(t)

    story.append(PageBreak())

    # === 4. TABLEAU Σ ERI PAR CANCER ===
    story.append(Paragraph(
        "4. Effets cancérigènes cumulés par organe cible — Σ ERI", s_h1))
    story.append(Paragraph(
        "Pour chaque type de cancer, on additionne uniquement les Excès de "
        "Risque Individuel (ERI) des substances induisant ce cancer. "
        "Méthodologie US-EPA RAGS Part A §8.3.",
        s_body))
    story.append(Spacer(1, 0.2*cm))

    rows = [['Organe / Cancer', 'Effets sanitaires attendus', 'Subst.',
             'Σ ERI max', 'État']]
    for c in data['cancers']:
        lvl, lbl, col = get_level_eri(c['max_eri'])
        rows.append([
            Paragraph(f"<b>{c['cancer']}</b>", s_cell),
            Paragraph(c['desc'] or '—', s_cell),
            str(c['nb'] or 0),
            fmt_eri(c['max_eri']),
            lbl,
        ])
    t = Table(rows, colWidths=[4*cm, 7.3*cm, 1.3*cm, 2*cm, 2.2*cm])
    style_cmds = [
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 9.5),
        ('FONT', (0,1), (-1,-1), 'Helvetica', 9),
        ('GRID', (0,0), (-1,-1), 0.4, HexColor('#8FAADC')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (2,1), (-1,-1), 'CENTER'),
        ('ROWBACKGROUNDS', (0,1), (-1,-1),
         [HexColor('#FFFFFF'), HexColor('#F4F6FB')]),
        ('LEFTPADDING', (0,0), (-1,-1), 4),
        ('RIGHTPADDING', (0,0), (-1,-1), 4),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ]
    for i, cc in enumerate(data['cancers']):
        lvl, _, _ = get_level_eri(cc['max_eri'])
        if lvl == 'danger':
            style_cmds.append(('BACKGROUND', (4, i+1), (4, i+1), HexColor('#FFC7CE')))
            style_cmds.append(('TEXTCOLOR', (4, i+1), (4, i+1), HexColor('#9C0006')))
        elif lvl == 'warn':
            style_cmds.append(('BACKGROUND', (4, i+1), (4, i+1), HexColor('#FFEB9C')))
            style_cmds.append(('TEXTCOLOR', (4, i+1), (4, i+1), HexColor('#9C5700')))
        elif lvl == 'ok':
            style_cmds.append(('BACKGROUND', (4, i+1), (4, i+1), HexColor('#C6EFCE')))
            style_cmds.append(('TEXTCOLOR', (4, i+1), (4, i+1), HexColor('#006100')))
    t.setStyle(TableStyle(style_cmds))
    story.append(t)

    story.append(Spacer(1, 0.4*cm))

    # ============================================================
    # === 5. NOTES DE CALCUL DÉTAILLÉES ===
    # ============================================================
    story.append(Paragraph("5. Notes de calcul — Formules et hypothèses", s_h1))
    story.append(Paragraph(
        "Les Quotients de Danger (QD) et les Excès de Risque Individuel (ERI) "
        "sont calculés selon la méthodologie INERIS et US-EPA RAGS. Chaque "
        "substance fait l'objet d'un calcul de Dose Journalière d'Exposition "
        "(DJE) puis d'une comparaison avec sa Valeur Toxicologique de Référence "
        "(VTR) pour les effets à seuil, ou avec son Excès de Risque Unitaire "
        "(ERU) pour les effets sans seuil (cancérigènes).",
        s_body))

    story.append(Paragraph("5.1. Dose Journalière d'Exposition (DJE)", s_h2))
    story.append(Paragraph(
        "<b>DJE = (C × IR × ED × EF) / (BW × AT)</b>",
        ParagraphStyle('formule', parent=s_body, fontName='Helvetica-Bold',
                       alignment=TA_CENTER, fontSize=11, textColor=C_ACCENT,
                       spaceAfter=8, spaceBefore=4)))
    story.append(Paragraph(
        "Où :<br/>"
        "• <b>C</b> = concentration mesurée du polluant dans le milieu "
        "(mg/kg pour sol, mg/L pour eau, µg/m³ pour air)<br/>"
        "• <b>IR</b> = taux d'ingestion ou d'inhalation (kg/j, L/j, ou m³/j)<br/>"
        "• <b>ED</b> = durée d'exposition (années)<br/>"
        "• <b>EF</b> = fréquence d'exposition (jours/an)<br/>"
        "• <b>BW</b> = poids corporel de la cible (kg)<br/>"
        "• <b>AT</b> = temps de moyennation (jours) ; égal à ED × 365 pour effets à "
        "seuil, 70 ans × 365 = 25 550 j pour effets sans seuil (vie entière)",
        s_body))

    story.append(Paragraph("5.2. Quotient de Danger (effet à seuil)", s_h2))
    story.append(Paragraph(
        "<b>QD = DJE / VTR</b>",
        ParagraphStyle('formule', parent=s_body, fontName='Helvetica-Bold',
                       alignment=TA_CENTER, fontSize=11, textColor=C_ACCENT,
                       spaceAfter=8, spaceBefore=4)))
    story.append(Paragraph(
        "Pour chaque organe cible, on additionne les QD des substances qui "
        "agissent sur le même organe (méthodologie INERIS DRC-09-103096-09387C, "
        "US-EPA RAGS Part A §8.2.2) :<br/>"
        "<b>Σ QD<sub>organe</sub> = Σ (QD<sub>i</sub>)</b> pour toutes substances i "
        "agissant sur cet organe.<br/><br/>"
        "<b>Seuils d'interprétation :</b><br/>"
        "• <font color='#3F8E3F'><b>Σ QD &lt; 0,2</b></font> : risque acceptable<br/>"
        "• <font color='#E58E1A'><b>0,2 ≤ Σ QD &lt; 1</b></font> : vigilance, "
        "investigations complémentaires<br/>"
        "• <font color='#C0272D'><b>Σ QD ≥ 1</b></font> : risque inacceptable, "
        "mesures de gestion requises",
        s_body))

    story.append(Paragraph("5.3. Excès de Risque Individuel (effet sans seuil)", s_h2))
    story.append(Paragraph(
        "<b>ERI = DJE × ERU</b>",
        ParagraphStyle('formule', parent=s_body, fontName='Helvetica-Bold',
                       alignment=TA_CENTER, fontSize=11, textColor=C_ACCENT,
                       spaceAfter=8, spaceBefore=4)))
    story.append(Paragraph(
        "Pour chaque type de cancer, on additionne les ERI des substances "
        "induisant ce même cancer (US-EPA RAGS Part A §8.3) :<br/>"
        "<b>Σ ERI<sub>cancer</sub> = Σ (ERI<sub>i</sub>)</b> pour toutes substances i "
        "induisant ce type de cancer.<br/><br/>"
        "<b>Seuils d'interprétation :</b><br/>"
        "• <font color='#3F8E3F'><b>Σ ERI &lt; 10<super>-6</super></b></font> : "
        "risque négligeable<br/>"
        "• <font color='#E58E1A'><b>10<super>-6</super> ≤ Σ ERI &lt; 10<super>-5</super></b></font> : "
        "acceptable, attention<br/>"
        "• <font color='#C0272D'><b>Σ ERI ≥ 10<super>-5</super></b></font> : inacceptable, "
        "mesures de gestion requises",
        s_body))

    story.append(Paragraph("5.4. Paramètres d'exposition par cible", s_h2))
    param_rows = [
        ['Paramètre', 'Adulte résident', 'Enfant résident', 'Salarié'],
        ['Poids corporel BW (kg)', '70', '15', '70'],
        ['Ingestion sol IR (mg/j)', '50', '200', '50'],
        ['Ingestion eau IR (L/j)', '2,0', '1,0', '1,0'],
        ['Inhalation IR (m³/j)', '20', '8', '10 (8 h)'],
        ['Durée exposition ED (ans)', '30', '6', '40'],
        ['Fréquence EF (j/an)', '350', '350', '220'],
        ['Surface cutanée SA (cm²)', '5 700', '2 800', '3 300'],
    ]
    tparam = Table(param_rows, colWidths=[5.2*cm, 3.8*cm, 3.8*cm, 3.8*cm])
    tparam.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 9.5),
        ('FONT', (0,1), (-1,-1), 'Helvetica', 9),
        ('GRID', (0,0), (-1,-1), 0.4, HexColor('#8FAADC')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (1,1), (-1,-1), 'CENTER'),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [HexColor('#FFFFFF'), HexColor('#F4F6FB')]),
    ]))
    story.append(tparam)
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "<b>Voies d'exposition prises en compte :</b> ingestion accidentelle de sol, "
        "ingestion d'eau souterraine, inhalation d'air ambiant, contact cutané avec "
        "le sol, inhalation par intrusion de vapeurs (modèle Johnson &amp; Ettinger). "
        "Pour la cible salarié, seules les voies de l'exposition au poste de travail "
        "sont retenues.",
        s_note))
    story.append(Paragraph(
        "<b>Références méthodologiques :</b> INERIS DRC-09-103096-09387C — Évaluation "
        "des risques sanitaires (2009) ; US-EPA RAGS Part A §8.2 et §8.3 ; EPA 2004 "
        "— User's Guide for Evaluating Subsurface Vapor Intrusion (Johnson &amp; "
        "Ettinger) ; ANSES 2018 — VTR et méthodologie IEM ; MTES SSP avril 2017.",
        s_note))

    story.append(PageBreak())

    # ============================================================
    # === 6. TABLEAU VTR À SEUIL ===
    # ============================================================
    story.append(Paragraph("6. Valeurs Toxicologiques de Référence (effets à seuil)", s_h1))
    story.append(Paragraph(
        "Tableau des VTR utilisées pour le calcul des Quotients de Danger. Les VTR "
        "sont issues des bases reconnues (ANSES, ATSDR, OEHHA, US-EPA IRIS, OMS). "
        "VTR orale en mg/kg/j, VTR inhalation en mg/m³, VTR cutanée en mg/kg/j.",
        s_body))
    story.append(Spacer(1, 0.2*cm))

    rows = [['Substance', 'N° CAS', 'VTR Or.\n(mg/kg/j)', 'VTR Inh.\n(mg/m³)',
             'VTR Cut.\n(mg/kg/j)', 'Source', 'Effet critique']]
    family_idx = []  # index des lignes famille dans le tableau
    for entry in data['vtr_seuil']:
        if entry['is_family']:
            family_idx.append(len(rows))
            rows.append([
                Paragraph(f"<b>{entry['substance']}</b>", s_cell),
                '', '', '', '', '', ''
            ])
        else:
            rows.append([
                Paragraph(str(entry['substance'] or ''), s_cell),
                Paragraph(str(entry['cas'] or '—'), s_cell),
                fmt_num_vtr(entry['vtr_o']),
                fmt_num_vtr(entry['vtr_i']),
                fmt_num_vtr(entry['vtr_c']),
                Paragraph(str(entry['source'] or '—'), s_cell),
                Paragraph(str(entry['effet'] or '—'), s_cell),
            ])
    tvtr = Table(rows, colWidths=[3.5*cm, 1.7*cm, 1.6*cm, 1.5*cm, 1.6*cm, 1.6*cm, 5.1*cm],
                 repeatRows=1)
    style_cmds = [
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 8.5),
        ('FONT', (0,1), (-1,-1), 'Helvetica', 7.5),
        ('GRID', (0,0), (-1,-1), 0.3, HexColor('#8FAADC')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (1,1), (4,-1), 'CENTER'),
        ('LEFTPADDING', (0,0), (-1,-1), 3),
        ('RIGHTPADDING', (0,0), (-1,-1), 3),
        ('TOPPADDING', (0,0), (-1,-1), 2),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2),
    ]
    for fi in family_idx:
        style_cmds.append(('BACKGROUND', (0, fi), (-1, fi), HexColor('#D9E2F3')))
        style_cmds.append(('SPAN', (0, fi), (-1, fi)))
        style_cmds.append(('FONT', (0, fi), (-1, fi), 'Helvetica-Bold', 9))
        style_cmds.append(('TEXTCOLOR', (0, fi), (-1, fi), C_TITLE))
    tvtr.setStyle(TableStyle(style_cmds))
    story.append(tvtr)

    story.append(PageBreak())

    # ============================================================
    # === 7. TABLEAU VTR SANS SEUIL ===
    # ============================================================
    story.append(Paragraph(
        "7. Excès de Risque Unitaire (effets sans seuil — cancérigènes)", s_h1))
    story.append(Paragraph(
        "Tableau des ERU pour les substances à effet sans seuil (cancérigènes "
        "génotoxiques). ERU oral en (mg/kg/j)<super>-1</super>, ERU inhalation en "
        "(µg/m³)<super>-1</super>.",
        s_body))
    story.append(Spacer(1, 0.2*cm))

    rows = [['Substance', 'N° CAS',
             Paragraph('ERU Oral<br/>(mg/kg/j)<super>-1</super>', s_cell_hdr),
             Paragraph('ERU Inhal.<br/>(µg/m³)<super>-1</super>', s_cell_hdr),
             'Source', 'Effet']]
    family_idx = []
    for entry in data['vtr_sans_seuil']:
        if entry['is_family']:
            family_idx.append(len(rows))
            rows.append([
                Paragraph(f"<b>{entry['substance']}</b>", s_cell),
                '', '', '', '', ''
            ])
        else:
            rows.append([
                Paragraph(str(entry['substance'] or ''), s_cell),
                Paragraph(str(entry['cas'] or '—'), s_cell),
                fmt_num_vtr(entry['eru_o']),
                fmt_num_vtr(entry['eru_i']),
                Paragraph(str(entry['source'] or '—'), s_cell),
                Paragraph(str(entry['effet'] or '—'), s_cell),
            ])
    teru = Table(rows, colWidths=[3.8*cm, 1.8*cm, 2.4*cm, 2.4*cm, 1.8*cm, 4.4*cm],
                 repeatRows=1)
    style_cmds = [
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 8.5),
        ('FONT', (0,1), (-1,-1), 'Helvetica', 7.5),
        ('GRID', (0,0), (-1,-1), 0.3, HexColor('#8FAADC')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (1,1), (3,-1), 'CENTER'),
        ('LEFTPADDING', (0,0), (-1,-1), 3),
        ('RIGHTPADDING', (0,0), (-1,-1), 3),
        ('TOPPADDING', (0,0), (-1,-1), 2),
        ('BOTTOMPADDING', (0,0), (-1,-1), 2),
    ]
    for fi in family_idx:
        style_cmds.append(('BACKGROUND', (0, fi), (-1, fi), HexColor('#D9E2F3')))
        style_cmds.append(('SPAN', (0, fi), (-1, fi)))
        style_cmds.append(('FONT', (0, fi), (-1, fi), 'Helvetica-Bold', 9))
        style_cmds.append(('TEXTCOLOR', (0, fi), (-1, fi), C_TITLE))
    teru.setStyle(TableStyle(style_cmds))
    story.append(teru)

    story.append(PageBreak())

    # ============================================================
    # === 8. TABLEAU DÉTAIL QD PAR SUBSTANCE ET PAR VOIE ===
    # ============================================================
    story.append(Paragraph(
        "8. Détail des Quotients de Danger par substance et par voie", s_h1))
    if not data['detail_qd']:
        story.append(Paragraph(
            "<b>Aucune substance à effet seuil n'a de valeur QD &gt; 0.</b> "
            "Saisir les concentrations dans la feuille Concentrations puis régénérer "
            "le rapport.",
            s_note))
    else:
        story.append(Paragraph(
            "Tableau détaillé des QD par substance et par voie d'exposition. "
            "Seules les substances présentant au moins une valeur QD &gt; 0 sont "
            "listées. Mise en évidence : <font color='#C0272D'><b>rouge</b></font> "
            "si QD ≥ 1 ; <font color='#E58E1A'><b>orange</b></font> si 0,2 ≤ QD &lt; 1.",
            s_body))
        story.append(Spacer(1, 0.2*cm))
        # Tableau compact : Substance | Σ QD | QD max | voies (toutes)
        # On affiche les voies en colonnes ; pour rester lisible on coupe en 2 sous-tableaux
        voies_ad = ['Ing.Sol Ad', 'Ing.Eau Ad', 'Inhal. Ad', 'Cutané Ad',
                    'J&E Inhal.Ad']
        voies_enf = ['Ing.Sol Enf', 'Ing.Eau Enf', 'Inhal. Enf', 'J&E Inhal.Enf']
        voies_sal = ['Ing.Sol Sal', 'Ing.Eau Sal', 'Inhal. Sal', 'Cutané Sal',
                     'J&E Inhal.Sal']

        def _qd_table(title, voies_list):
            story.append(Paragraph(title, s_h2))
            hdr = ['Substance'] + voies_list + ['Max']
            rrows = [hdr]
            max_per_col = [0.0] * len(voies_list)
            for entry in data['detail_qd']:
                # Ne génère la ligne que si au moins une voie de la liste est > 0
                if not any(entry['voies'].get(v) for v in voies_list):
                    continue
                row = [Paragraph(f"<b>{entry['substance']}</b>", s_cell)]
                local_max = 0.0
                for i, v in enumerate(voies_list):
                    val = entry['voies'].get(v)
                    row.append(fmt_qd(val) if val else '—')
                    if val:
                        local_max = max(local_max, val)
                        max_per_col[i] = max(max_per_col[i], val)
                row.append(fmt_qd(local_max) if local_max else '—')
                rrows.append(row)
            if len(rrows) == 1:
                story.append(Paragraph("— Aucune valeur —", s_note))
                return
            ncols = len(hdr)
            col_w = [3.6*cm] + [(13.4/(ncols-2))*cm] * (ncols-2) + [1.6*cm]
            t = Table(rrows, colWidths=col_w, repeatRows=1)
            cmds = [
                ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
                ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
                ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 8),
                ('FONT', (0,1), (-1,-1), 'Helvetica', 7.5),
                ('GRID', (0,0), (-1,-1), 0.3, HexColor('#8FAADC')),
                ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
                ('ALIGN', (1,1), (-1,-1), 'CENTER'),
                ('LEFTPADDING', (0,0), (-1,-1), 2),
                ('RIGHTPADDING', (0,0), (-1,-1), 2),
                ('TOPPADDING', (0,0), (-1,-1), 2),
                ('BOTTOMPADDING', (0,0), (-1,-1), 2),
                ('ROWBACKGROUNDS', (0,1), (-1,-1),
                 [HexColor('#FFFFFF'), HexColor('#F4F6FB')]),
            ]
            # Color cells per QD level
            for ri in range(1, len(rrows)):
                entry_match = [e for e in data['detail_qd']
                               if any(e['voies'].get(v) for v in voies_list)]
                if ri-1 >= len(entry_match):
                    continue
                entry = entry_match[ri-1]
                for ci, v in enumerate(voies_list):
                    val = entry['voies'].get(v)
                    if val is None:
                        continue
                    col_idx = 1 + ci
                    if val >= QD_INACCEPT:
                        cmds.append(('BACKGROUND', (col_idx, ri), (col_idx, ri),
                                     HexColor('#FFC7CE')))
                        cmds.append(('TEXTCOLOR', (col_idx, ri), (col_idx, ri),
                                     HexColor('#9C0006')))
                    elif val >= QD_VIGIL:
                        cmds.append(('BACKGROUND', (col_idx, ri), (col_idx, ri),
                                     HexColor('#FFEB9C')))
                        cmds.append(('TEXTCOLOR', (col_idx, ri), (col_idx, ri),
                                     HexColor('#9C5700')))
            t.setStyle(TableStyle(cmds))
            story.append(t)
            story.append(Spacer(1, 0.3*cm))

        _qd_table("8.1. Cible Adulte résident", voies_ad)
        _qd_table("8.2. Cible Enfant résident", voies_enf)
        _qd_table("8.3. Cible Salarié", voies_sal)

    story.append(PageBreak())

    # ============================================================
    # === 9. TABLEAU DÉTAIL ERI PAR SUBSTANCE ET PAR VOIE ===
    # ============================================================
    story.append(Paragraph(
        "9. Détail des Excès de Risque Individuel par substance et par voie", s_h1))
    if not data['detail_eri']:
        story.append(Paragraph(
            "<b>Aucune substance cancérigène n'a de valeur ERI &gt; 0.</b> "
            "Saisir les concentrations puis régénérer.",
            s_note))
    else:
        story.append(Paragraph(
            "Tableau détaillé des ERI par substance et par voie. Seules les "
            "substances présentant au moins une valeur ERI &gt; 0 sont listées. "
            "<font color='#C0272D'><b>Rouge</b></font> si ERI ≥ 10<super>-5</super> ; "
            "<font color='#E58E1A'><b>orange</b></font> si 10<super>-6</super> ≤ ERI "
            "&lt; 10<super>-5</super>.",
            s_body))
        story.append(Spacer(1, 0.2*cm))

        voies_ad_e = ['Ing.Ad', 'Inhal.Ad', 'J&E Inh.Ad']
        voies_enf_e = ['Ing.Enf', 'Inhal.Enf', 'J&E Inh.Enf', 'Cutané Enf', 'Total Enf']
        voies_sal_e = ['Ing.Sal', 'Inhal.Sal']

        def _eri_table(title, voies_list):
            story.append(Paragraph(title, s_h2))
            hdr = ['Substance'] + voies_list + ['Max']
            rrows = [hdr]
            matched = []
            for entry in data['detail_eri']:
                if not any(entry['voies'].get(v) for v in voies_list):
                    continue
                matched.append(entry)
                row = [Paragraph(f"<b>{entry['substance']}</b>", s_cell)]
                local_max = 0.0
                for v in voies_list:
                    val = entry['voies'].get(v)
                    row.append(fmt_eri(val) if val else '—')
                    if val:
                        local_max = max(local_max, val)
                row.append(fmt_eri(local_max) if local_max else '—')
                rrows.append(row)
            if len(rrows) == 1:
                story.append(Paragraph("— Aucune valeur —", s_note))
                return
            ncols = len(hdr)
            col_w = [3.6*cm] + [(13.4/(ncols-2))*cm] * (ncols-2) + [2.2*cm]
            t = Table(rrows, colWidths=col_w, repeatRows=1)
            cmds = [
                ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
                ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
                ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 8),
                ('FONT', (0,1), (-1,-1), 'Helvetica', 7.5),
                ('GRID', (0,0), (-1,-1), 0.3, HexColor('#8FAADC')),
                ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
                ('ALIGN', (1,1), (-1,-1), 'CENTER'),
                ('LEFTPADDING', (0,0), (-1,-1), 2),
                ('RIGHTPADDING', (0,0), (-1,-1), 2),
                ('TOPPADDING', (0,0), (-1,-1), 2),
                ('BOTTOMPADDING', (0,0), (-1,-1), 2),
                ('ROWBACKGROUNDS', (0,1), (-1,-1),
                 [HexColor('#FFFFFF'), HexColor('#F4F6FB')]),
            ]
            for ri in range(1, len(rrows)):
                entry = matched[ri-1]
                for ci, v in enumerate(voies_list):
                    val = entry['voies'].get(v)
                    if val is None:
                        continue
                    col_idx = 1 + ci
                    if val >= ERI_INACCEPT:
                        cmds.append(('BACKGROUND', (col_idx, ri), (col_idx, ri),
                                     HexColor('#FFC7CE')))
                        cmds.append(('TEXTCOLOR', (col_idx, ri), (col_idx, ri),
                                     HexColor('#9C0006')))
                    elif val >= ERI_VIGIL:
                        cmds.append(('BACKGROUND', (col_idx, ri), (col_idx, ri),
                                     HexColor('#FFEB9C')))
                        cmds.append(('TEXTCOLOR', (col_idx, ri), (col_idx, ri),
                                     HexColor('#9C5700')))
            t.setStyle(TableStyle(cmds))
            story.append(t)
            story.append(Spacer(1, 0.3*cm))

        _eri_table("9.1. Cible Adulte résident", voies_ad_e)
        _eri_table("9.2. Cible Enfant résident", voies_enf_e)
        _eri_table("9.3. Cible Salarié", voies_sal_e)

    story.append(PageBreak())

    # ============================================================
    # === 10. CONCLUSION ===
    # ============================================================
    story.append(Paragraph("10. Conclusion", s_h1))

    nb_inaccept = sum(1 for o in data['organes']
                      if o['max_qd'] is not None and o['max_qd'] >= QD_INACCEPT)
    nb_inaccept += sum(1 for c in data['cancers']
                       if c['max_eri'] is not None and c['max_eri'] >= ERI_INACCEPT)
    nb_vigil = sum(1 for o in data['organes']
                   if o['max_qd'] is not None and QD_VIGIL <= o['max_qd'] < QD_INACCEPT)
    nb_vigil += sum(1 for c in data['cancers']
                    if c['max_eri'] is not None and ERI_VIGIL <= c['max_eri'] < ERI_INACCEPT)

    if nb_inaccept > 0:
        story.append(Paragraph(
            f"<b><font color='#{C_DANGER.hexval()[2:]}'>"
            f"État sanitaire : INACCEPTABLE.</font></b> "
            f"{nb_inaccept} organe(s) ou type(s) de cancer dépasse(nt) les seuils "
            f"réglementaires. Des <b>mesures de gestion</b> sont à mettre en œuvre :"
            f" maîtrise des usages, dépollution, plan de gestion, ARR si applicable.",
            s_body))
    elif nb_vigil > 0:
        story.append(Paragraph(
            f"<b><font color='#{C_WARN.hexval()[2:]}'>"
            f"État sanitaire : VIGILANCE.</font></b> "
            f"{nb_vigil} organe(s) ou type(s) de cancer en zone d'attention. "
            f"Des <b>investigations complémentaires</b> sont recommandées "
            f"(monitoring renforcé, caractérisation fine des sources).",
            s_body))
    else:
        story.append(Paragraph(
            f"<b><font color='#{C_OK.hexval()[2:]}'>"
            f"État sanitaire : ACCEPTABLE.</font></b> "
            f"Aucun organe ni type de cancer ne dépasse les seuils réglementaires. "
            f"Le site peut être déclaré compatible avec l'usage projeté sous "
            f"réserve de la confirmation par l'ARR.",
            s_body))

    story.append(Spacer(1, 0.4*cm))
    story.append(Paragraph(
        "Le présent rapport est généré automatiquement à partir du classeur "
        "EQRS_Johnson_Ettinger. Toute modification des concentrations ou "
        "paramètres entraîne une mise à jour des sommes par organe cible et "
        "du schéma conceptuel.",
        s_note))

    story.append(Spacer(1, 1*cm))
    story.append(HRFlowable(width="100%", thickness=1, color=C_ACCENT))
    story.append(Spacer(1, 0.3*cm))
    story.append(Paragraph(
        "<b>GMEP - Modélisation environnementale</b><br/>"
        "Eric AZULAY — gmep.france@gmail.com<br/>"
        "www.gmep-france.eu",
        ParagraphStyle('sig', parent=s_body, alignment=TA_CENTER,
                      textColor=C_TITLE, fontSize=10)))

    doc.build(story, onFirstPage=page_footer, onLaterPages=page_footer)
    print(f"[OK] Rapport écrit : {out_pdf}")


if __name__ == '__main__':
    args = [a for a in sys.argv[1:] if not a.startswith('--')]
    xlsx = Path(args[0]) if args else DEFAULT_XLSX
    out  = Path(args[1]) if len(args) > 1 else DEFAULT_PDF
    build_pdf(xlsx, out)
