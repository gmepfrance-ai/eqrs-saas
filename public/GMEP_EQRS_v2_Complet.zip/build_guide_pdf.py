#!/usr/bin/env python3
"""Guide PDF d'installation et d'utilisation du schéma conceptuel dynamique."""
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm, mm
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak,
    Table, TableStyle, HRFlowable
)

C_TITLE  = HexColor('#1F3864')
C_ACCENT = HexColor('#2E5496')
C_BG     = HexColor('#D9E2F3')
C_OK     = HexColor('#3F8E3F')
C_WARN   = HexColor('#E58E1A')
C_DANGER = HexColor('#C0272D')
C_TEXT   = HexColor('#262626')
C_GREY   = HexColor('#595959')

styles = getSampleStyleSheet()

s_h1 = ParagraphStyle('h1', parent=styles['Heading1'],
                     fontName='Helvetica-Bold', fontSize=18,
                     textColor=C_TITLE, spaceAfter=10, spaceBefore=10)
s_h2 = ParagraphStyle('h2', parent=styles['Heading2'],
                     fontName='Helvetica-Bold', fontSize=13,
                     textColor=C_ACCENT, spaceAfter=6, spaceBefore=14)
s_h3 = ParagraphStyle('h3', parent=styles['Heading3'],
                     fontName='Helvetica-Bold', fontSize=11,
                     textColor=C_ACCENT, spaceAfter=4, spaceBefore=8)
s_body = ParagraphStyle('body', parent=styles['BodyText'],
                       fontName='Helvetica', fontSize=10,
                       textColor=C_TEXT, leading=14, alignment=TA_JUSTIFY,
                       spaceAfter=4)
s_code = ParagraphStyle('code', parent=styles['BodyText'],
                       fontName='Courier', fontSize=9.5,
                       textColor=C_TITLE, leading=13,
                       leftIndent=18, spaceBefore=4, spaceAfter=6,
                       backColor=HexColor('#F2F4F8'),
                       borderColor=C_ACCENT, borderWidth=0.5,
                       borderPadding=6)
s_note = ParagraphStyle('note', parent=s_body,
                       fontSize=9.5, textColor=C_GREY,
                       fontName='Helvetica-Oblique')

def cover_footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('Helvetica', 8)
    canvas.setFillColor(C_GREY)
    canvas.drawString(2*cm, 1.2*cm,
                      "GMEP - www.gmep-france.eu - gmep.france@gmail.com")
    canvas.drawRightString(A4[0] - 2*cm, 1.2*cm, f"Page {doc.page}")
    canvas.restoreState()

def build():
    out = '/home/user/workspace/Guide_Installation_Schema_EQRS.pdf'
    doc = SimpleDocTemplate(out, pagesize=A4,
                            leftMargin=2*cm, rightMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm,
                            title="Guide installation - Schema conceptuel EQRS",
                            author="GMEP")
    story = []

    # Couverture
    story.append(Spacer(1, 1.5*cm))
    story.append(Paragraph("Guide d'installation et d'utilisation", s_h1))
    story.append(Paragraph("Schéma conceptuel dynamique EQRS — Johnson &amp; Ettinger",
                          ParagraphStyle('sub', parent=s_body, fontSize=13,
                                        textColor=C_ACCENT, fontName='Helvetica',
                                        spaceAfter=12)))
    story.append(HRFlowable(width="100%", thickness=2, color=C_ACCENT))
    story.append(Spacer(1, 0.4*cm))
    story.append(Paragraph(
        "Ce document explique comment installer et utiliser la mise à jour automatique "
        "du schéma conceptuel intégré au classeur EQRS_Johnson_Ettinger. Les couleurs "
        "des flèches de transfert (a-h) reflètent automatiquement les niveaux de risque "
        "calculés (Σ QD et Σ ERI) — vert = acceptable, orange = vigilance, rouge = inacceptable.",
        s_body))
    story.append(Spacer(1, 0.3*cm))

    # Aperçu du schéma
    story.append(Paragraph("Aperçu du schéma dynamique", s_h2))
    try:
        img = Image('/home/user/workspace/Schema_Conceptuel_Illustre_demo_mixed.png',
                    width=16*cm, height=10*cm, kind='proportional')
        story.append(img)
        story.append(Paragraph(
            "Exemple : voies « percolation », « volatilisation » et « sols de subsurface » "
            "en rouge (QD &#8805; 1 ou ERI &#8805; 10<super>-5</super>), voies « arrosage », « retombées » et « plantes » "
            "en orange (vigilance), voies « eaux AEP » et « canalisation » en vert (acceptable).",
            s_note))
    except Exception as e:
        story.append(Paragraph(f"[image non disponible : {e}]", s_note))

    story.append(PageBreak())

    # Contenu du dossier
    story.append(Paragraph("1. Contenu du dossier livré", s_h1))
    story.append(Paragraph(
        "Le dossier <b>GMEP_EQRS_Schema_Dynamique</b> contient les fichiers suivants. "
        "<b>Tous doivent rester ensemble dans le même dossier.</b>", s_body))

    files_data = [
        ['Fichier', 'Description'],
        ['EQRS_Johnson_Ettinger_V7.xlsx', 'Classeur EQRS avec Σ QD/ERI par organe cible et feuille Schéma_Conceptuel'],
        ['build_schema_conceptuel_illustre.py', 'Script Python qui régénère le schéma selon QD/ERI'],
        ['build_rapport_EQRS.py', 'Script Python qui génère le rapport PDF complet (NOUVEAU v2)'],
        ['MAJ_Schema_Conceptuel.bat', 'Lanceur Windows en un clic — schéma uniquement'],
        ['EDITER_Rapport_PDF.bat', 'Lanceur Windows — schéma + rapport PDF complet (NOUVEAU v2)'],
        ['modSchemaEQRS.bas', 'Module VBA — macros MettreAJourSchemaEQRS et EditerRapportEQRS'],
        ['mapping_organes_eqrs.json', 'Mapping substances → organes cibles (INERIS / US-EPA)'],
        ['Schema_Conceptuel_Illustre.png', 'Image actuelle du schéma (régénérée automatiquement)'],
        ['Schema_Conceptuel_Illustre.pdf', 'Schéma en PDF haute qualité'],
        ['Rapport_EQRS_Johnson_Ettinger.pdf', 'Rapport PDF complet (exemple, régénéré à chaque édition)'],
        ['Guide_Installation_Schema_EQRS.pdf', 'Le présent guide'],
    ]
    t = Table(files_data, colWidths=[6.5*cm, 9.5*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 10),
        ('FONT', (0,1), (-1,-1), 'Helvetica', 9),
        ('FONT', (0,1), (0,-1), 'Helvetica-Bold', 9),
        ('GRID', (0,0), (-1,-1), 0.5, HexColor('#8FAADC')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [HexColor('#FFFFFF'), HexColor('#F4F6FB')]),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.5*cm))

    # Prérequis
    story.append(Paragraph("2. Prérequis (à faire une seule fois)", s_h1))

    story.append(Paragraph("2.1 Installer Python", s_h2))
    story.append(Paragraph(
        "Téléchargez Python 3.10 ou plus récent depuis "
        "<font color='#2E5496'><b>https://www.python.org/downloads/</b></font> et "
        "installez-le. <b>Cochez impérativement la case « Add Python to PATH »</b> "
        "sur le premier écran de l'installateur, sinon Excel ne pourra pas trouver Python.",
        s_body))

    story.append(Paragraph("2.2 Installer les bibliothèques Python", s_h2))
    story.append(Paragraph(
        "Ouvrez l'invite de commandes Windows (touche Windows + R, tapez "
        "<font name='Courier'>cmd</font>, validez), puis tapez :", s_body))
    story.append(Paragraph("pip install matplotlib openpyxl reportlab", s_code))
    story.append(Paragraph(
        "Cela installe les trois bibliothèques nécessaires (matplotlib pour le schéma, "
        "openpyxl pour Excel, reportlab pour le rapport PDF — ~70 Mo, durée 2-3 minutes).",
        s_note))

    story.append(PageBreak())

    # Utilisation - option 1 (BAT)
    story.append(Paragraph("3. Utilisation quotidienne", s_h1))

    story.append(Paragraph("Option A — Le plus simple : lanceur Windows (.bat)", s_h2))
    story.append(Paragraph("Recommandée pour la majorité des utilisateurs.",
                          ParagraphStyle('hint', parent=s_note, textColor=C_OK,
                                        fontName='Helvetica-Bold')))
    story.append(Spacer(1, 0.2*cm))

    steps_bat = [
        ['1', 'Saisissez vos concentrations dans la feuille <b>Concentrations</b> du classeur Excel.'],
        ['2', 'Enregistrez le classeur (Ctrl+S) et fermez-le.'],
        ['3', 'Dans l\'explorateur Windows, double-cliquez sur <b>MAJ_Schema_Conceptuel.bat</b>.'],
        ['4', 'Une fenêtre noire s\'ouvre quelques secondes. Le schéma est régénéré.'],
        ['5', 'Rouvrez le classeur Excel : la feuille <b>Schéma_Conceptuel</b> affiche le schéma à jour avec les bonnes couleurs.'],
    ]
    t = Table([[Paragraph(f"<b>{n}</b>", s_body), Paragraph(txt, s_body)]
               for n, txt in steps_bat],
              colWidths=[1*cm, 15*cm])
    t.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('BACKGROUND', (0,0), (0,-1), C_BG),
        ('ALIGN', (0,0), (0,-1), 'CENTER'),
        ('LEFTPADDING', (1,0), (1,-1), 10),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ('LINEBELOW', (0,0), (-1,-2), 0.3, HexColor('#8FAADC')),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.4*cm))

    # Option 2 - VBA
    story.append(Paragraph("Option B — Bouton intégré dans Excel (avancée)", s_h2))
    story.append(Paragraph(
        "Cette option ajoute un vrai bouton « Mettre à jour le schéma » directement "
        "dans la feuille Schéma_Conceptuel. Installation 1 minute, ensuite 1 clic à chaque mise à jour.",
        s_body))

    story.append(Paragraph("Étape 1 — Enregistrer le classeur en .xlsm", s_h3))
    story.append(Paragraph(
        "Ouvrez le classeur, faites Fichier > Enregistrer sous, et choisissez le format "
        "<b>« Classeur Excel prenant en charge les macros (*.xlsm) »</b>. "
        "Vous obtenez EQRS_Johnson_Ettinger_V7.xlsm.",
        s_body))

    story.append(Paragraph("Étape 2 — Importer le module VBA", s_h3))
    story.append(Paragraph(
        "Dans Excel, appuyez sur <b>Alt + F11</b> pour ouvrir l'éditeur Visual Basic. "
        "Dans la fenêtre de gauche, faites un clic droit sur VBAProject(EQRS_Johnson_Ettinger_V7.xlsm), "
        "puis <b>Importer un fichier...</b> et sélectionnez <b>modSchemaEQRS.bas</b>. "
        "Fermez l'éditeur VBA. Enregistrez le classeur.",
        s_body))

    story.append(Paragraph("Étape 3 — Ajouter le bouton dans la feuille", s_h3))
    story.append(Paragraph(
        "Activez l'onglet <b>Développeur</b> (Fichier > Options > Personnaliser le ruban "
        "> cocher Développeur). Dans la feuille Schéma_Conceptuel, "
        "cliquez sur Développeur > Insérer > <b>Bouton (contrôle de formulaire)</b>, "
        "tracez un rectangle vers la cellule B19, et dans la fenêtre qui apparaît "
        "choisissez la macro <b>MettreAJourSchemaEQRS</b>. Renommez le bouton "
        "« Mettre à jour le schéma ».",
        s_body))

    story.append(Paragraph("Utilisation quotidienne (option B)", s_h3))
    story.append(Paragraph(
        "Après chaque saisie, cliquez sur le bouton. Le schéma se met à jour en 3-5 secondes "
        "sans fermer Excel.",
        s_body))

    story.append(PageBreak())

    # ======================================================================
    # NOUVEAU v2 : Σ QD / Σ ERI par organe cible
    # ======================================================================
    story.append(Paragraph("4. Σ QD et Σ ERI par organe cible (v2)", s_h1))
    story.append(Paragraph(
        "<b>Nouveauté v2 — conformité INERIS / US-EPA.</b> Les quotients de danger (QD) "
        "et les excès de risque individuel (ERI) ne sont plus additionnés globalement, "
        "mais <b>uniquement par organe cible</b> (méthodologie INERIS DRC-09-103096-09387C "
        "et US-EPA RAGS Part A §8.2 et §8.3).",
        s_body))
    story.append(Paragraph(
        "<b>Pourquoi ?</b> Additionner un QD du benzène (effet : anémie, sang) avec un QD du PCE "
        "(effet : hépatite, foie) n'a aucun sens biologique : les organes touchés ne sont pas les mêmes. "
        "Seules les substances qui agissent sur le même organe peuvent être cumulées.",
        s_body))

    story.append(Paragraph("4.1 Effets seuil — 13 organes cibles", s_h2))
    story.append(Paragraph(
        "Feuille <b>Résultats_QD</b>, lignes 95-113. Pour chaque organe, le tableau additionne "
        "les QD des substances correspondantes et affiche un <b>Σ QD max</b> par voie d'exposition. "
        "L'état sanitaire est codé en couleur :",
        s_body))
    organes_data = [
        ['Organe / Effet', 'Effets sanitaires attendus (exemples)'],
        ['Sang / hématopoïèse', 'Anémie, leucopénie (benzène, zinc)'],
        ['Système nerveux central', 'Troubles cognitifs (toluène, plomb, méthylmercure)'],
        ['Foie', 'Hépatite chronique, fibrose (PCE, TCE, HAP)'],
        ['Reins', 'Néphropathie tubulaire (cadmium, mercure)'],
        ['Système respiratoire', 'Irritation chronique, fibrose (naphtalène, nickel)'],
        ['Système immunitaire', 'Immunodépression (PCB)'],
        ['Système thyroïdien', 'Hypothyroïdie (cyanures)'],
        ['Système cardiovasculaire', 'Hypertension (atrazine)'],
        ['Tractus gastro-intestinal', 'Lésions muqueuses (chrome VI, cuivre)'],
        ['Peau', 'Hyperkératose (arsenic)'],
        ['Système endocrinien / métabolique', 'Sélénose, perturbations (antimoine, sélénium)'],
        ['Développement / reproduction', 'Effets tératogènes (benzo(a)pyrène)'],
        ['Effets systémiques multiples', 'Atteintes multi-organes (dioxines, PCB-TEQ)'],
    ]
    cell_st = ParagraphStyle('os', parent=s_body, fontSize=8.5, leading=10.5, spaceAfter=0)
    organes_p = [organes_data[0]] + [[Paragraph(r[0], cell_st), Paragraph(r[1], cell_st)] for r in organes_data[1:]]
    t = Table(organes_p, colWidths=[5.5*cm, 10.5*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 9),
        ('GRID', (0,0), (-1,-1), 0.4, HexColor('#8FAADC')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [HexColor('#FFFFFF'), HexColor('#F4F6FB')]),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 3),
        ('BOTTOMPADDING', (0,0), (-1,-1), 3),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.4*cm))

    story.append(Paragraph("4.2 Effets cancérigènes — 8 organes / types de cancer", s_h2))
    story.append(Paragraph(
        "Feuille <b>Résultats_ERI</b>, lignes 52-65. Pour chaque type de cancer, le tableau "
        "additionne les ERI des substances cancérigènes correspondantes (8 catégories : "
        "sang/leucémie, foie, poumon, peau, rein, voies digestives/multi-organes, voies aérodigestives supérieures, thyroïde).",
        s_body))

    story.append(Paragraph("4.3 Synthèse exécutive — feuille Sommaire", s_h2))
    story.append(Paragraph(
        "En tête de la feuille <b>Sommaire</b> (lignes 31-37) : 4 indicateurs colorés résument "
        "l'état sanitaire global :",
        s_body))
    story.append(Paragraph("&nbsp;&nbsp;• Pire Σ QD <b>adulte</b> (toutes voies, par organe)", s_body))
    story.append(Paragraph("&nbsp;&nbsp;• Pire Σ QD <b>enfant</b> (toutes voies, par organe)", s_body))
    story.append(Paragraph("&nbsp;&nbsp;• Pire Σ ERI <b>adulte</b> (toutes voies, par cancer)", s_body))
    story.append(Paragraph("&nbsp;&nbsp;• Pire Σ ERI <b>enfant</b> (toutes voies, par cancer)", s_body))

    story.append(PageBreak())

    # ======================================================================
    # NOUVEAU v2 : Rapport PDF complet
    # ======================================================================
    story.append(Paragraph("5. Édition du rapport PDF complet (v2)", s_h1))
    story.append(Paragraph(
        "<b>Nouveauté v2.</b> Un rapport PDF prêt à transmettre aux administrations (DDT, ARS) "
        "est généré automatiquement à partir du classeur. Il comprend :",
        s_body))
    story.append(Paragraph("&nbsp;&nbsp;1. Couverture (titre, date, méthodologie INERIS / US-EPA)", s_body))
    story.append(Paragraph("&nbsp;&nbsp;2. Synthèse exécutive (4 indicateurs colorés + liste des organes en alerte)", s_body))
    story.append(Paragraph("&nbsp;&nbsp;3. Schéma conceptuel du site (régénéré automatiquement)", s_body))
    story.append(Paragraph("&nbsp;&nbsp;4. Tableau détaillé Σ QD par organe cible (13 organes)", s_body))
    story.append(Paragraph("&nbsp;&nbsp;5. Tableau détaillé Σ ERI par cancer (8 catégories)", s_body))
    story.append(Paragraph("&nbsp;&nbsp;6. Conclusion sanitaire adaptative (acceptable / vigilance / inacceptable)", s_body))

    story.append(Paragraph("Option A — Lanceur Windows (le plus simple)", s_h2))
    story.append(Paragraph(
        "Double-cliquez sur <b>EDITER_Rapport_PDF.bat</b>. Le schéma est régénéré puis le rapport PDF "
        "est créé et ouvert automatiquement dans votre lecteur PDF par défaut.",
        s_body))

    story.append(Paragraph("Option B — Bouton VBA dans Excel", s_h2))
    story.append(Paragraph(
        "Après import du module modSchemaEQRS.bas (voir §3, option B), une seconde macro "
        "<b>EditerRapportEQRS</b> est disponible. Pour ajouter le bouton :",
        s_body))
    story.append(Paragraph(
        "&nbsp;&nbsp;1. Onglet Développeur → Insérer → Bouton (contrôle de formulaire)<br/>"
        "&nbsp;&nbsp;2. Tracer le bouton sur la feuille Sommaire ou Schéma_Conceptuel<br/>"
        "&nbsp;&nbsp;3. Affecter la macro <b>EditerRapportEQRS</b><br/>"
        "&nbsp;&nbsp;4. Renommer le bouton « Éditer rapport PDF »",
        s_body))
    story.append(Paragraph(
        "En cliquant, le schéma est régénéré, le rapport PDF est édité, et le document s'ouvre automatiquement.",
        s_note))

    story.append(PageBreak())

    # Interprétation
    story.append(Paragraph("6. Interprétation des couleurs", s_h1))
    story.append(Paragraph(
        "Chacune des 8 voies de transfert (a-h) est colorée selon les seuils EQRS "
        "(méthodologie INERIS SSP / MTES) :",
        s_body))

    crit_style = ParagraphStyle('crit', parent=s_body, fontSize=9.5,
                                alignment=TA_LEFT, spaceAfter=0, leading=12)
    leg_data = [
        ['Couleur', 'Critère', 'Signification', 'Action'],
        ['', Paragraph('QD &lt; 0,2 &nbsp;et&nbsp; ERI &lt; 10<super>-6</super>', crit_style),
         'Acceptable', 'Aucune mesure'],
        ['', Paragraph('0,2 &#8804; QD &lt; 1 &nbsp;ou&nbsp; 10<super>-6</super> &#8804; ERI &lt; 10<super>-5</super>', crit_style),
         'Vigilance', 'Investigations complémentaires'],
        ['', Paragraph('QD &#8805; 1 &nbsp;ou&nbsp; ERI &#8805; 10<super>-5</super>', crit_style),
         'Inacceptable', 'Mesures de gestion obligatoires'],
    ]
    t = Table(leg_data, colWidths=[1.5*cm, 5.5*cm, 3.5*cm, 5*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 10),
        ('FONT', (0,1), (-1,-1), 'Helvetica', 9.5),
        ('FONT', (2,1), (2,-1), 'Helvetica-Bold', 9.5),
        ('GRID', (0,0), (-1,-1), 0.5, HexColor('#8FAADC')),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('ALIGN', (0,0), (0,-1), 'CENTER'),
        ('BACKGROUND', (0,1), (0,1), C_OK),
        ('BACKGROUND', (0,2), (0,2), C_WARN),
        ('BACKGROUND', (0,3), (0,3), C_DANGER),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('TOPPADDING', (0,0), (-1,-1), 8),
        ('BOTTOMPADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(t)
    story.append(Spacer(1, 0.5*cm))

    story.append(Paragraph("6.1 Correspondance flèches / voies d'exposition", s_h2))
    voies_data = [
        ['Lettre', 'Voie', 'Sources QD / ERI utilisées'],
        ['a', 'Percolation (sol → nappe)', 'Σ QD ingestion + cutané ; Σ ERI ingestion'],
        ['b', 'Eaux souterraines (nappe → captage AEP)', 'Σ QD ingestion eau ; Σ ERI ingestion'],
        ['c', 'Arrosage (eau → potager)', 'Σ QD eau ; Σ ERI ingestion'],
        ['d', 'Volatilisation Johnson &amp; Ettinger (vapeurs)', 'Σ QD J&amp;E inhalation ; Σ ERI J&amp;E'],
        ['e', 'Canalisation AEP (perméation)', 'Σ QD eau ; Σ ERI ingestion'],
        ['f', 'Anciennes retombées atmosphériques', 'Σ QD inhalation ; Σ ERI inhalation'],
        ['g', 'Sols de subsurface (contact + ingestion)', 'Σ QD sol+cutané ; Σ ERI cutané'],
        ['h', 'Plantes (sol/eau → légumes potager)', 'Σ QD sol+eau ; Σ ERI ingestion'],
    ]
    voies_data = [[r[0], r[1], r[2]] for r in voies_data]
    # Wrap text cells in Paragraphs to enable proper line wrapping
    voie_cell = ParagraphStyle('vc', parent=s_body, fontSize=9, leading=11, spaceAfter=0)
    voies_data_p = [voies_data[0]] + [
        [r[0], Paragraph(r[1], voie_cell), Paragraph(r[2], voie_cell)]
        for r in voies_data[1:]
    ]
    voies_data = voies_data_p
    t = Table(voies_data, colWidths=[1.5*cm, 6*cm, 8*cm])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), C_ACCENT),
        ('TEXTCOLOR', (0,0), (-1,0), HexColor('#FFFFFF')),
        ('FONT', (0,0), (-1,0), 'Helvetica-Bold', 9.5),
        ('FONT', (0,1), (-1,-1), 'Helvetica', 9),
        ('FONT', (0,1), (0,-1), 'Helvetica-BoldOblique', 10),
        ('ALIGN', (0,0), (0,-1), 'CENTER'),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
        ('GRID', (0,0), (-1,-1), 0.5, HexColor('#8FAADC')),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [HexColor('#FFFFFF'), HexColor('#F4F6FB')]),
        ('LEFTPADDING', (0,0), (-1,-1), 6),
        ('RIGHTPADDING', (0,0), (-1,-1), 6),
        ('TOPPADDING', (0,0), (-1,-1), 5),
        ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ]))
    story.append(t)

    story.append(Spacer(1, 0.5*cm))

    # Dépannage
    story.append(Paragraph("7. Dépannage", s_h1))
    troubles = [
        ('« Python n\'a pas été trouvé »',
         'Réinstallez Python en cochant « Add Python to PATH ». Redémarrez Windows.'),
        ('« ModuleNotFoundError: No module named matplotlib » ou « reportlab »',
         'Ouvrez cmd et tapez : pip install matplotlib openpyxl reportlab'),
        ('Le rapport PDF ne s\'ouvre pas',
         'Vérifiez qu\'un lecteur PDF (Adobe Reader, navigateur) est installé par défaut. '
         'Le rapport est sauvegardé dans Rapport_EQRS_Johnson_Ettinger.pdf.'),
        ('Les sommes par organe affichent 0',
         'Ce comportement est normal tant qu\'aucune concentration n\'est saisie. '
         'Renseignez les concentrations dans la feuille Concentrations puis F9 ou re-cliquez sur le bouton.'),
        ('Le schéma ne change pas de couleur',
         'Vérifiez que des concentrations ont bien été saisies dans la feuille Concentrations '
         'et que les feuilles Résultats_QD et Résultats_ERI ont été recalculées (F9).'),
        ('Erreur « PermissionError » dans la fenêtre noire',
         'Fermez le classeur Excel avant de lancer le .bat. Excel verrouille le fichier '
         'tant qu\'il est ouvert.'),
    ]
    for q, a in troubles:
        story.append(Paragraph(f"<b>Problème :</b> {q}", s_body))
        story.append(Paragraph(f"<b>Solution :</b> {a}",
                              ParagraphStyle('sol', parent=s_body,
                                            leftIndent=12, spaceAfter=8)))

    # Pied de page final
    story.append(Spacer(1, 0.8*cm))
    story.append(HRFlowable(width="100%", thickness=1, color=C_ACCENT))
    story.append(Paragraph(
        "<b>GMEP - Modélisation environnementale</b><br/>"
        "www.gmep-france.eu &nbsp;·&nbsp; gmep.france@gmail.com<br/>"
        "Méthodologie : INERIS DRC-09-103096-09387C, US-EPA OSWER 9355.4-24, "
        "Johnson &amp; Ettinger (1991), MTES SSP avril 2017.",
        ParagraphStyle('foot', parent=s_note, alignment=TA_CENTER,
                      textColor=C_TITLE, fontSize=9)))

    doc.build(story, onFirstPage=cover_footer, onLaterPages=cover_footer)
    print(f"[OK] Guide écrit : {out}")

if __name__ == '__main__':
    build()
