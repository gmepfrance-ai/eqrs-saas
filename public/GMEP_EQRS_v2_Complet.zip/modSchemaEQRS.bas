Attribute VB_Name = "modSchemaEQRS"
Option Explicit

' ========================================================================
' GMEP - Outils EQRS : schema conceptuel + rapport PDF
' ------------------------------------------------------------------------
' MettreAJourSchemaEQRS : regenere le schema conceptuel (PNG)
' EditerRapportEQRS     : regenere schema + genere le rapport PDF complet
' ========================================================================
' Auteur : GMEP - Eric Azulay (gmep.france@gmail.com)
' Site   : www.gmep-france.eu
' ========================================================================

Public Sub MettreAJourSchemaEQRS()
    Dim wbPath As String, wbDir As String, scriptPath As String
    Dim pythonExe As String, cmd As String
    Dim wsh As Object
    Dim rc As Long

    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationAutomatic
    Application.Calculate
    ThisWorkbook.Save

    wbPath = ThisWorkbook.FullName
    wbDir = ThisWorkbook.Path
    scriptPath = wbDir & "\build_schema_conceptuel_illustre.py"

    If Dir(scriptPath) = "" Then
        MsgBox "Script Python introuvable :" & vbCrLf & scriptPath & vbCrLf & vbCrLf & _
               "Placez build_schema_conceptuel_illustre.py dans le meme dossier que ce classeur.", _
               vbCritical, "GMEP - Schema EQRS"
        Exit Sub
    End If

    pythonExe = TrouverPython()
    If pythonExe = "" Then
        MsgBox "Python n'a pas ete trouve sur ce poste." & vbCrLf & vbCrLf & _
               "Installez Python depuis https://www.python.org/downloads/" & vbCrLf & _
               "en cochant 'Add Python to PATH'.", _
               vbCritical, "GMEP - Schema EQRS"
        Exit Sub
    End If

    cmd = """" & pythonExe & """ """ & scriptPath & """ """ & wbPath & """"

    Application.StatusBar = "Regeneration du schema conceptuel en cours..."

    Set wsh = CreateObject("WScript.Shell")
    rc = wsh.Run("cmd /c " & cmd, 0, True)

    Application.StatusBar = False

    If rc <> 0 Then
        MsgBox "Le script Python a renvoye une erreur (code " & rc & ")." & vbCrLf & _
               "Verifiez l'installation des dependances Python :" & vbCrLf & vbCrLf & _
               "    pip install matplotlib openpyxl reportlab", _
               vbExclamation, "GMEP - Schema EQRS"
        Exit Sub
    End If

    RechargerImageSchema

    Application.ScreenUpdating = True
    MsgBox "Schema conceptuel mis a jour avec succes." & vbCrLf & _
           "Les couleurs des fleches refletent les QD/ERI calcules.", _
           vbInformation, "GMEP - Schema EQRS"
End Sub

' ------------------------------------------------------------------------
' EditerRapportEQRS - regenere le schema PUIS produit le rapport PDF complet
' Le rapport comporte : couverture, synthese executive (4 indicateurs),
' schema conceptuel, tableaux Sigma QD par organe / Sigma ERI par cancer,
' conclusion sanitaire adaptative.
' ------------------------------------------------------------------------
Public Sub EditerRapportEQRS()
    Dim wbPath As String, wbDir As String
    Dim scriptSchema As String, scriptRapport As String, pdfPath As String
    Dim pythonExe As String, cmd As String
    Dim wsh As Object
    Dim rc As Long

    Application.ScreenUpdating = False
    Application.Calculation = xlCalculationAutomatic
    Application.Calculate
    ThisWorkbook.Save

    wbPath = ThisWorkbook.FullName
    wbDir = ThisWorkbook.Path
    scriptSchema = wbDir & "\build_schema_conceptuel_illustre.py"
    scriptRapport = wbDir & "\build_rapport_EQRS.py"
    pdfPath = wbDir & "\Rapport_EQRS_Johnson_Ettinger.pdf"

    If Dir(scriptSchema) = "" Or Dir(scriptRapport) = "" Then
        MsgBox "Scripts Python introuvables." & vbCrLf & vbCrLf & _
               "Verifiez la presence de :" & vbCrLf & _
               " - build_schema_conceptuel_illustre.py" & vbCrLf & _
               " - build_rapport_EQRS.py" & vbCrLf & vbCrLf & _
               "dans le meme dossier que ce classeur.", _
               vbCritical, "GMEP - Rapport EQRS"
        Exit Sub
    End If

    pythonExe = TrouverPython()
    If pythonExe = "" Then
        MsgBox "Python n'a pas ete trouve sur ce poste." & vbCrLf & vbCrLf & _
               "Installez Python depuis https://www.python.org/downloads/" & vbCrLf & _
               "en cochant 'Add Python to PATH'." & vbCrLf & vbCrLf & _
               "Puis : pip install matplotlib openpyxl reportlab", _
               vbCritical, "GMEP - Rapport EQRS"
        Exit Sub
    End If

    Set wsh = CreateObject("WScript.Shell")

    ' --- Etape 1 : regenerer le schema (le rapport l'inclut)
    Application.StatusBar = "Etape 1/2 : regeneration du schema conceptuel..."
    cmd = """" & pythonExe & """ """ & scriptSchema & """ """ & wbPath & """"
    rc = wsh.Run("cmd /c " & cmd, 0, True)
    If rc <> 0 Then
        Application.StatusBar = False
        MsgBox "Erreur lors de la regeneration du schema (code " & rc & ")." & vbCrLf & _
               "Dependances requises : pip install matplotlib openpyxl reportlab", _
               vbExclamation, "GMEP - Rapport EQRS"
        Exit Sub
    End If

    ' --- Etape 2 : generer le rapport PDF
    Application.StatusBar = "Etape 2/2 : generation du rapport PDF..."
    cmd = """" & pythonExe & """ """ & scriptRapport & """ """ & wbPath & """"
    rc = wsh.Run("cmd /c " & cmd, 0, True)
    Application.StatusBar = False

    If rc <> 0 Then
        MsgBox "Erreur lors de la generation du rapport PDF (code " & rc & ")." & vbCrLf & _
               "Dependances requises : pip install reportlab matplotlib openpyxl", _
               vbExclamation, "GMEP - Rapport EQRS"
        Exit Sub
    End If

    ' Recharger l'image du schema dans la feuille
    RechargerImageSchema

    Application.ScreenUpdating = True

    If Dir(pdfPath) <> "" Then
        ' Ouvrir le PDF avec l'application par defaut
        wsh.Run """" & pdfPath & """", 1, False
        MsgBox "Rapport PDF genere avec succes :" & vbCrLf & pdfPath & vbCrLf & vbCrLf & _
               "Le document s'ouvre dans votre lecteur PDF.", _
               vbInformation, "GMEP - Rapport EQRS"
    Else
        MsgBox "Le rapport PDF n'a pas ete trouve apres generation." & vbCrLf & _
               "Verifiez les messages d'erreur Python.", _
               vbExclamation, "GMEP - Rapport EQRS"
    End If
End Sub

Private Function TrouverPython() As String
    Dim wsh As Object
    Set wsh = CreateObject("WScript.Shell")
    Dim candidates As Variant
    candidates = Array("py", "python", "python3")
    Dim c As Variant
    Dim exec As Object
    For Each c In candidates
        On Error Resume Next
        Set exec = wsh.exec(CStr(c) & " --version")
        If Err.Number = 0 Then
            exec.StdOut.ReadAll
            TrouverPython = CStr(c)
            On Error GoTo 0
            Exit Function
        End If
        Err.Clear
        On Error GoTo 0
    Next c
    TrouverPython = ""
End Function

Private Sub RechargerImageSchema()
    Dim ws As Worksheet
    Dim shp As Shape
    Dim imgPath As String
    Dim pic As Shape

    imgPath = ThisWorkbook.Path & "\Schema_Conceptuel_Illustre.png"
    If Dir(imgPath) = "" Then Exit Sub

    On Error Resume Next
    Set ws = ThisWorkbook.Sheets("Schema_Conceptuel")
    If ws Is Nothing Then Set ws = ThisWorkbook.Sheets(ChrW(83) & "ch" & ChrW(233) & "ma_Conceptuel")
    On Error GoTo 0
    If ws Is Nothing Then Exit Sub

    ' Supprimer les images (sauf les boutons qui sont des Forms.Button)
    For Each shp In ws.Shapes
        If shp.Type = msoPicture Then shp.Delete
    Next shp

    Set pic = ws.Shapes.AddPicture(imgPath, msoFalse, msoTrue, _
                                    ws.Range("B22").Left, _
                                    ws.Range("B22").Top, _
                                    980, 630)
End Sub
