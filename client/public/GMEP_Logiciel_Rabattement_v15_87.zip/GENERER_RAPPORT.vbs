' ================================================================
' G.M.E.P -- Generateur v14
' REGLE N°1 : Jamais executer depuis OneDrive ou le Bureau.
'             Ce script se copie AUTOMATIQUEMENT dans C:\GMEP\
'             et relance depuis la.
' ================================================================
Option Explicit

Dim WshShell, FSO
Set WshShell = CreateObject("WScript.Shell")
Set FSO      = CreateObject("Scripting.FileSystemObject")

Dim ScriptFolder
ScriptFolder = FSO.GetParentFolderName(WScript.ScriptFullName)

Dim DestFolder
DestFolder = "C:\GMEP"

' ============================================================
' TOUJOURS copier vers C:\GMEP\ sauf si on y est deja
' ============================================================
Dim AlreadyInDest
AlreadyInDest = (LCase(ScriptFolder) = LCase(DestFolder))

If Not AlreadyInDest Then

    ' Creer C:\GMEP si besoin
    If Not FSO.FolderExists(DestFolder) Then
        On Error Resume Next
        FSO.CreateFolder DestFolder
        If Err.Number <> 0 Then
            MsgBox "Impossible de creer C:\GMEP" & vbCrLf & Err.Description, _
                   vbCritical, "G.M.E.P"
            WScript.Quit 1
        End If
        On Error GoTo 0
    End If

    ' Copier TOUS les fichiers source -> C:\GMEP\
    Dim f, nOK, nErr
    nOK = 0 : nErr = 0
    For Each f In FSO.GetFolder(ScriptFolder).Files
        On Error Resume Next
        FSO.CopyFile f.Path, DestFolder & "\" & f.Name, True
        If Err.Number = 0 Then
            nOK = nOK + 1
        Else
            nErr = nErr + 1
            Err.Clear
        End If
        On Error GoTo 0
    Next

    If nOK = 0 Then
        MsgBox "Echec total de la copie (" & nErr & " erreurs)." & vbCrLf & _
               "Copiez manuellement le dossier dans C:\GMEP\", _
               vbCritical, "G.M.E.P"
        WScript.Quit 1
    End If

    ' Relancer depuis C:\GMEP\ et quitter ce script
    Dim NewVbs
    NewVbs = DestFolder & "\GENERER_RAPPORT.vbs"
    If Not FSO.FileExists(NewVbs) Then
        MsgBox "Copie incomplete -- GENERER_RAPPORT.vbs absent de C:\GMEP\", _
               vbCritical, "G.M.E.P"
        WScript.Quit 1
    End If

    WshShell.Run "wscript """ & NewVbs & """"
    WScript.Quit 0

End If

' ============================================================
' On est dans C:\GMEP\ -- lancer Python directement
' ============================================================
Dim LogFile, PDFPath, PythonScript, ExcelFile
PDFPath      = DestFolder & "\Dossier_Declaration_Loi_Eau_GMEP.pdf"
PythonScript = DestFolder & "\generate_rapport_loi_eau.py"
ExcelFile    = DestFolder & "\Modelisation_Rabattement_TSN_GMEP.xlsx"

' Dossier temporaire pour les fichiers log et cmd (jamais dans C:\GMEP\)
Dim TmpDir
TmpDir = WshShell.ExpandEnvironmentStrings("%TEMP%") & "\GMEP"
On Error Resume Next
If Not FSO.FolderExists(TmpDir) Then FSO.CreateFolder TmpDir
On Error GoTo 0
If Not FSO.FolderExists(TmpDir) Then
    TmpDir = WshShell.ExpandEnvironmentStrings("%TEMP%")
End If

LogFile = TmpDir & "\gmep_log.txt"

' Ecrire le log dans %TEMP%\GMEP\ -- jamais dans C:\GMEP\
Dim fLog
On Error Resume Next
Set fLog = FSO.CreateTextFile(LogFile, True, True)
If Err.Number = 0 Then
    fLog.WriteLine "GMEP Log - " & Now()
    fLog.WriteLine "Dossier execution : " & DestFolder
    fLog.WriteLine "Dossier log       : " & TmpDir
    fLog.Close
Else
    ' Log impossible -> on continue sans log
    LogFile = ""
    Err.Clear
End If
On Error GoTo 0

' Verifier les fichiers
If Not FSO.FileExists(PythonScript) Then
    Call WriteLog(LogFile, "[ERREUR] generate_rapport_loi_eau.py absent de C:\GMEP\")
    MsgBox "generate_rapport_loi_eau.py absent de C:\GMEP\", vbCritical, "G.M.E.P"
    WScript.Quit 1
End If

' Chercher l'Excel (nom exact ou premier xlsx du dossier)
If Not FSO.FileExists(ExcelFile) Then
    Dim fx
    For Each fx In FSO.GetFolder(DestFolder).Files
        If LCase(Right(fx.Name,5)) = ".xlsx" Or LCase(Right(fx.Name,5)) = ".xlsm" Then
            ExcelFile = fx.Path : Exit For
        End If
    Next
End If

Call WriteLog(LogFile, "[OK] Script : " & PythonScript)
Call WriteLog(LogFile, "[OK] Excel  : " & ExcelFile)

' Trouver Python
Dim PythonExe
PythonExe = FindPython(LogFile)
If PythonExe = "" Then
    Call WriteLog(LogFile, "[ERREUR] Python introuvable")
    MsgBox "Python n'est pas installe." & vbCrLf & "Lancez INSTALLER_PYTHON.bat", _
           vbCritical, "G.M.E.P"
    WScript.Quit 1
End If
Call WriteLog(LogFile, "[OK] Python : " & PythonExe)

' Sauvegarder Excel si ouvert
On Error Resume Next
Dim ExcelApp, wb
Set ExcelApp = GetObject(, "Excel.Application")
If Not IsNull(ExcelApp) And Not IsEmpty(ExcelApp) Then
    For Each wb In ExcelApp.Workbooks
        If InStr(LCase(wb.Name), "rabattement") > 0 Or _
           InStr(LCase(wb.Name), "modelisation") > 0 Then
            wb.Save : Exit For
        End If
    Next
End If
On Error GoTo 0

' Confirmation
Dim Rep
Rep = MsgBox("Generation du rapport PDF depuis C:\GMEP\" & vbCrLf & vbCrLf & _
             "Python : " & PythonExe & vbCrLf & _
             "Excel  : " & ExcelFile & vbCrLf & vbCrLf & _
             "Duree : 30 a 90 secondes." & vbCrLf & "Cliquez OK pour lancer.", _
             vbOKCancel + vbInformation, "G.M.E.P")
If Rep = vbCancel Then WScript.Quit 0

' Injecter les variables d'environnement UTF-8
WshShell.Environment("Process")("PYTHONUTF8")       = "1"
WshShell.Environment("Process")("PYTHONIOENCODING") = "utf-8:replace"

' La sortie Python va directement dans la fenetre cmd (visible)
' Le log est gere cote Python via variable GMEP_LOG_FILE
Dim LogRedir
LogRedir = ""  ' pas de redirection -- sortie visible dans la fenetre
If LogFile <> "" Then
    WshShell.Environment("Process")("GMEP_LOG_FILE") = LogFile
End If

' ── ETAPE 1 : Ecrire check.py dans %TEMP%\GMEP\ ──
Dim CheckScript, fChk
CheckScript = TmpDir & "\check.py"
On Error Resume Next
Set fChk = FSO.CreateTextFile(CheckScript, True, False)
If Err.Number <> 0 Then
    ' Ecriture impossible -> passer directement au script principal
    Err.Clear
    CheckScript = ""
End If
On Error GoTo 0

If CheckScript <> "" Then
    fChk.WriteLine "# -*- coding: utf-8 -*-"
    fChk.WriteLine "import sys, subprocess"
    fChk.WriteLine "print('Python ' + sys.version)"
    fChk.WriteLine ""
    fChk.WriteLine "modules = ['openpyxl', 'reportlab', 'Pillow', 'matplotlib', 'requests']"
    fChk.WriteLine "missing = []"
    fChk.WriteLine "for mod in modules:"
    fChk.WriteLine "    import_name = 'PIL' if mod == 'Pillow' else mod"
    fChk.WriteLine "    try:"
    fChk.WriteLine "        __import__(import_name)"
    fChk.WriteLine "        print('OK ' + mod)"
    fChk.WriteLine "    except ImportError:"
    fChk.WriteLine "        print('MANQUE ' + mod)"
    fChk.WriteLine "        missing.append(mod)"
    fChk.WriteLine ""
    fChk.WriteLine "if missing:"
    fChk.WriteLine "    print('Installation : ' + ' '.join(missing))"
    fChk.WriteLine "    r = subprocess.run("
    fChk.WriteLine "        [sys.executable, '-m', 'pip', 'install', '--quiet'] + missing,"
    fChk.WriteLine "        capture_output=True, text=True"
    fChk.WriteLine "    )"
    fChk.WriteLine "    print(r.stdout)"
    fChk.WriteLine "    if r.returncode != 0:"
    fChk.WriteLine "        print('ERREUR pip : ' + r.stderr)"
    fChk.WriteLine "        sys.exit(1)"
    fChk.WriteLine "    print('Installation terminee.')"
    fChk.WriteLine "else:"
    fChk.WriteLine "    print('Tous les modules sont presents.')"
    fChk.Close

    ' Executer check.py en arriere-plan -- toujours silencieux vers log
    Dim RunCheck, fRC
    Dim ChkRedir
    If LogFile <> "" Then
        ChkRedir = " >> """ & LogFile & """ 2>&1"
    Else
        ChkRedir = " > nul 2>&1"
    End If
    RunCheck = TmpDir & "\run_check.cmd"
    Set fRC = FSO.CreateTextFile(RunCheck, True, False)
    fRC.WriteLine "@echo off"
    fRC.WriteLine "chcp 65001 > nul"
    fRC.WriteLine """" & PythonExe & """ -X utf8 -u """ & CheckScript & """" & ChkRedir
    fRC.Close

    Dim ChkRet
    ChkRet = WshShell.Run("""" & RunCheck & """", 0, True)  ' 0 = invisible
    Call WriteLog(LogFile, "Code check/install : " & ChkRet)
End If

' ── ETAPE 2 : Executer generate_rapport_loi_eau.py -- fenetre visible ──
Dim RunPy, fRP
RunPy = TmpDir & "\run_python.cmd"
Set fRP = FSO.CreateTextFile(RunPy, True, False)
fRP.WriteLine "@echo off"
fRP.WriteLine "chcp 65001 > nul"
fRP.WriteLine "title G.M.E.P  --  Generation du rapport PDF en cours..."
fRP.WriteLine "color 1F"
fRP.WriteLine "echo."
fRP.WriteLine "echo  ================================================"
fRP.WriteLine "echo   G.M.E.P  --  Generation du Dossier Loi sur l'Eau"
fRP.WriteLine "echo  ================================================"
fRP.WriteLine "echo."
fRP.WriteLine "echo  Lecture du fichier Excel..."
fRP.WriteLine "echo  Generation des calculs et du rapport PDF..."
fRP.WriteLine "echo  (Cette fenetre se fermera automatiquement)"
fRP.WriteLine "echo."
fRP.WriteLine "cd /d """ & DestFolder & """"
If ExcelFile <> "" Then
    fRP.WriteLine """" & PythonExe & """ -X utf8 -u """ & PythonScript & """ """ & ExcelFile & """" & LogRedir
Else
    fRP.WriteLine """" & PythonExe & """ -X utf8 -u """ & PythonScript & """" & LogRedir
End If
fRP.WriteLine "echo."
fRP.WriteLine "if %ERRORLEVEL% NEQ 0 echo  ERREUR : code %ERRORLEVEL%"
fRP.Close

Call WriteLog(LogFile, "Lancement script principal...")

Dim PyRet
PyRet = WshShell.Run("""" & RunPy & """", 1, True)  ' 1 = fenetre visible, attend la fin
Call WriteLog(LogFile, "Code retour Python : " & PyRet)

' Lire le log pour affichage
Dim LogTxt
LogTxt = ReadLog(LogFile)
Dim LogAffiche
If Len(LogTxt) > 2000 Then
    LogAffiche = Left(LogTxt,900) & vbCrLf & "..." & vbCrLf & Right(LogTxt,900)
Else
    LogAffiche = LogTxt
End If

' Succes
If PyRet = 0 And FSO.FileExists(PDFPath) Then
    ' Copier le PDF sur le Bureau de l'utilisateur pour faciliter le partage
    Dim Desktop, PDFOnDesktop, CopyOK
    Desktop = WshShell.SpecialFolders("Desktop")
    PDFOnDesktop = Desktop & "\Dossier_Declaration_Loi_Eau_GMEP.pdf"
    CopyOK = False
    On Error Resume Next
    FSO.CopyFile PDFPath, PDFOnDesktop, True
    If Err.Number = 0 Then CopyOK = True
    Err.Clear
    On Error GoTo 0

    Dim MsgFinal
    If CopyOK Then
        MsgFinal = "Rapport genere avec succes !" & vbCrLf & vbCrLf & _
                   "Original : " & PDFPath & vbCrLf & _
                   "Copie sur le Bureau : " & PDFOnDesktop & vbCrLf & vbCrLf & _
                   "Le PDF va s'ouvrir automatiquement."
    Else
        MsgFinal = "Rapport genere avec succes !" & vbCrLf & vbCrLf & PDFPath & vbCrLf & vbCrLf & _
                   "(Copie sur le Bureau impossible -- ouverture directe)"
    End If
    MsgBox MsgFinal, vbInformation, "G.M.E.P"
    WshShell.Run """" & PDFPath & """"
    WScript.Quit 0
End If

' Erreur
Dim Choix
If LogFile <> "" Then
    Choix = MsgBox("ERREUR (code " & PyRet & ")" & vbCrLf & vbCrLf & _
                   LogAffiche & vbCrLf & vbCrLf & _
                   "Oui = ouvrir le log complet dans Bloc-notes", _
                   vbYesNo + vbCritical, "G.M.E.P -- Erreur")
    If Choix = vbYes Then WshShell.Run "notepad """ & LogFile & """"
Else
    MsgBox "ERREUR Python (code " & PyRet & ")" & vbCrLf & _
           "Le PDF n'a pas ete genere.", vbCritical, "G.M.E.P -- Erreur"
End If

Set WshShell = Nothing : Set FSO = Nothing
WScript.Quit 1

' ================================================================
' Fonctions
' ================================================================
Function WriteLog(path, msg)
    If path = "" Then Exit Function
    Dim fso2, f2
    Set fso2 = CreateObject("Scripting.FileSystemObject")
    On Error Resume Next
    Set f2 = fso2.OpenTextFile(path, 8, True, True)
    If Err.Number = 0 Then f2.WriteLine msg : f2.Close
    On Error GoTo 0
End Function

Function ReadLog(path)
    ReadLog = ""
    If path = "" Then Exit Function
    Dim fso2, f2
    Set fso2 = CreateObject("Scripting.FileSystemObject")
    If Not fso2.FileExists(path) Then Exit Function
    On Error Resume Next
    Set f2 = fso2.OpenTextFile(path, 1, False, -2)
    ReadLog = f2.ReadAll : f2.Close
    On Error GoTo 0
End Function

Function FindPython(logPath)
    Dim fso2, sh2
    Set fso2 = CreateObject("Scripting.FileSystemObject")
    Set sh2  = CreateObject("WScript.Shell")
    FindPython = ""
    Dim v, p
    For Each v In Array("313","312","311","310","39","38")
        p = sh2.ExpandEnvironmentStrings("%LOCALAPPDATA%") & _
            "\Programs\Python\Python" & v & "\python.exe"
        If fso2.FileExists(p) Then
            Call WriteLog(logPath, "[FIND] Python" & v & " : " & p)
            FindPython = p : Exit Function
        End If
    Next
    ' Registre HKCU
    Dim ver
    For Each ver In Array("3.13","3.12","3.11","3.10","3.9")
        On Error Resume Next
        p = sh2.RegRead("HKCU\Software\Python\PythonCore\" & ver & "\InstallPath\ExecutablePath")
        If Err.Number = 0 And p <> "" And fso2.FileExists(p) Then
            Call WriteLog(logPath, "[FIND] RegHKCU " & ver & " : " & p)
            FindPython = p : Exit Function
        End If
        Err.Clear : On Error GoTo 0
    Next
    ' Registre HKLM
    For Each ver In Array("3.13","3.12","3.11","3.10","3.9")
        On Error Resume Next
        p = sh2.RegRead("HKLM\Software\Python\PythonCore\" & ver & "\InstallPath\ExecutablePath")
        If Err.Number = 0 And p <> "" And fso2.FileExists(p) Then
            Call WriteLog(logPath, "[FIND] RegHKLM " & ver & " : " & p)
            FindPython = p : Exit Function
        End If
        Err.Clear : On Error GoTo 0
    Next
    ' where python (evite stub Store)
    On Error Resume Next
    Dim oExec, line
    Set oExec = sh2.Exec("where python")
    If Err.Number = 0 Then
        Do While Not oExec.StdOut.AtEndOfStream
            line = Trim(oExec.StdOut.ReadLine())
            If InStr(LCase(line),"windowsapps") = 0 And fso2.FileExists(line) Then
                Call WriteLog(logPath, "[FIND] PATH : " & line)
                FindPython = line : Exit Function
            End If
        Loop
    End If
    Err.Clear : On Error GoTo 0
End Function
