#!/bin/bash
# GMEP - Ouverture directe du PDF Loi sur l'Eau (Mac)
cd "$(dirname "$0")"
PDF="Dossier_Declaration_Loi_Eau_GMEP.pdf"

if [ ! -f "$PDF" ]; then
    echo ""
    echo "Le fichier PDF n'existe pas encore : $PDF"
    echo "Lancez d'abord Generer_PDF.command"
    echo ""
    read -p "Appuyez sur Entree pour fermer..."
    exit 1
fi

open "$PDF"
