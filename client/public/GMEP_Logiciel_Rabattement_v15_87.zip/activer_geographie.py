#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
activer_geographie.py — Met à jour les données géographiques du tableur
========================================================================
Lit X/Y Lambert 93 (C33, C34) depuis Modelisation_Rabattement_TSN_GMEP.xlsx
et résout automatiquement commune, INSEE, département, ZRE, masse d'eau.
"""
import sys
import os
import shutil
from pathlib import Path

# Encodage UTF-8
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
        sys.stderr.reconfigure(encoding='utf-8')
    except Exception:
        pass

SCRIPT_DIR = Path(__file__).resolve().parent
XLSM = SCRIPT_DIR / "Modelisation_Rabattement_TSN_GMEP.xlsx"

print("=" * 70)
print("  GMEP — Mise à jour automatique de la géographie")
print("=" * 70)
print()

# === Dépendances ===
try:
    import openpyxl
except ImportError:
    print("Installation du module openpyxl...")
    os.system(f'"{sys.executable}" -m pip install --quiet openpyxl')
    import openpyxl

# === Vérification fichier ===
if not XLSM.exists():
    print(f"ERREUR : Fichier introuvable : {XLSM}")
    input("\nAppuyez sur Entrée pour fermer...")
    sys.exit(1)

# === Lecture coordonnées ===
print(f"Lecture du tableur : {XLSM.name}")
wb = openpyxl.load_workbook(XLSM, keep_vba=True, data_only=False)

if "Données d'Entrée" not in wb.sheetnames:
    print("ERREUR : Feuille 'Données d'Entrée' introuvable")
    input("\nAppuyez sur Entrée pour fermer...")
    sys.exit(1)

ws = wb["Données d'Entrée"]
x_lambert = ws["C33"].value
y_lambert = ws["C34"].value

print(f"  Coordonnée X (C33) : {x_lambert}")
print(f"  Coordonnée Y (C34) : {y_lambert}")
print()

try:
    x = float(x_lambert)
    y = float(y_lambert)
except (TypeError, ValueError):
    print("ERREUR : Coordonnées Lambert 93 invalides en C33/C34")
    input("\nAppuyez sur Entrée pour fermer...")
    sys.exit(1)

if not (0 <= x <= 1300000 and 6000000 <= y <= 7200000):
    print("ERREUR : Coordonnées hors France métropolitaine")
    input("\nAppuyez sur Entrée pour fermer...")
    sys.exit(1)

# === Résolution ===
print("Résolution en cours (APIs geo.api.gouv.fr, Hub'Eau, SANDRE)...")
sys.path.insert(0, str(SCRIPT_DIR))

try:
    from geo_resolver import resolve_geo
except ImportError as e:
    print(f"ERREUR : module geo_resolver introuvable ({e})")
    input("\nAppuyez sur Entrée pour fermer...")
    sys.exit(1)

try:
    geo = resolve_geo(x, y)
except Exception as e:
    print(f"ERREUR de résolution : {e}")
    print("Vérifiez votre connexion Internet.")
    input("\nAppuyez sur Entrée pour fermer...")
    sys.exit(1)

if not geo.get('resolution_ok'):
    print("ERREUR : la résolution a échoué (résultat partiel).")
    print("Vérifiez votre connexion Internet ou saisissez la commune manuellement.")
    input("\nAppuyez sur Entrée pour fermer...")
    sys.exit(1)

# Récupération valeurs
commune = geo.get('commune_nom', '')
insee = geo.get('code_insee', '')
dpt = geo.get('code_dpt', '')
region_code = geo.get('code_region', '')
lon = geo.get('lon_wgs84', 0)
lat = geo.get('lat_wgs84', 0)
bassin = geo.get('bassin_dce', '—')
agence = geo.get('agence_eau', '—')
sdage = geo.get('sdage', '—')
sage = geo.get('sage', '—')
meso_code = geo.get('meso_code', '—')
meso_lib = geo.get('meso_libelle', '—')
zre_statut = geo.get('zre_statut', '—')
zre_nappe = geo.get('zre_nappe', '—')
zre_arrete = geo.get('zre_arrete', '—')
zre_date = geo.get('zre_date_maj', '—')

# Nom du département (lookup simple)
dpts_noms = {
    "01": "Ain", "02": "Aisne", "03": "Allier", "04": "Alpes-de-Haute-Provence",
    "05": "Hautes-Alpes", "06": "Alpes-Maritimes", "07": "Ardèche", "08": "Ardennes",
    "09": "Ariège", "10": "Aube", "11": "Aude", "12": "Aveyron", "13": "Bouches-du-Rhône",
    "14": "Calvados", "15": "Cantal", "16": "Charente", "17": "Charente-Maritime",
    "18": "Cher", "19": "Corrèze", "2A": "Corse-du-Sud", "2B": "Haute-Corse",
    "21": "Côte-d'Or", "22": "Côtes-d'Armor", "23": "Creuse", "24": "Dordogne",
    "25": "Doubs", "26": "Drôme", "27": "Eure", "28": "Eure-et-Loir", "29": "Finistère",
    "30": "Gard", "31": "Haute-Garonne", "32": "Gers", "33": "Gironde", "34": "Hérault",
    "35": "Ille-et-Vilaine", "36": "Indre", "37": "Indre-et-Loire", "38": "Isère",
    "39": "Jura", "40": "Landes", "41": "Loir-et-Cher", "42": "Loire", "43": "Haute-Loire",
    "44": "Loire-Atlantique", "45": "Loiret", "46": "Lot", "47": "Lot-et-Garonne",
    "48": "Lozère", "49": "Maine-et-Loire", "50": "Manche", "51": "Marne",
    "52": "Haute-Marne", "53": "Mayenne", "54": "Meurthe-et-Moselle", "55": "Meuse",
    "56": "Morbihan", "57": "Moselle", "58": "Nièvre", "59": "Nord", "60": "Oise",
    "61": "Orne", "62": "Pas-de-Calais", "63": "Puy-de-Dôme", "64": "Pyrénées-Atlantiques",
    "65": "Hautes-Pyrénées", "66": "Pyrénées-Orientales", "67": "Bas-Rhin", "68": "Haut-Rhin",
    "69": "Rhône", "70": "Haute-Saône", "71": "Saône-et-Loire", "72": "Sarthe",
    "73": "Savoie", "74": "Haute-Savoie", "75": "Paris", "76": "Seine-Maritime",
    "77": "Seine-et-Marne", "78": "Yvelines", "79": "Deux-Sèvres", "80": "Somme",
    "81": "Tarn", "82": "Tarn-et-Garonne", "83": "Var", "84": "Vaucluse", "85": "Vendée",
    "86": "Vienne", "87": "Haute-Vienne", "88": "Vosges", "89": "Yonne",
    "90": "Territoire de Belfort", "91": "Essonne", "92": "Hauts-de-Seine",
    "93": "Seine-Saint-Denis", "94": "Val-de-Marne", "95": "Val-d'Oise",
}
dpt_nom = dpts_noms.get(dpt, "")

# Nom région
regions_noms = {
    "01": "Guadeloupe", "02": "Martinique", "03": "Guyane", "04": "La Réunion",
    "06": "Mayotte", "11": "Île-de-France", "24": "Centre-Val de Loire",
    "27": "Bourgogne-Franche-Comté", "28": "Normandie", "32": "Hauts-de-France",
    "44": "Grand Est", "52": "Pays de la Loire", "53": "Bretagne",
    "75": "Nouvelle-Aquitaine", "76": "Occitanie", "84": "Auvergne-Rhône-Alpes",
    "93": "Provence-Alpes-Côte d'Azur", "94": "Corse",
}
region_nom = regions_noms.get(region_code, region_code)

print()
print(f"  ✓ Commune          : {commune}")
print(f"  ✓ Code INSEE       : {insee}")
print(f"  ✓ Département      : {dpt} - {dpt_nom}")
print(f"  ✓ Région           : {region_nom}")
print(f"  ✓ Bassin DCE       : {bassin}")
print(f"  ✓ Agence de l'eau  : {agence}")
print(f"  ✓ SDAGE            : {sdage}")
print(f"  ✓ Masse d'eau      : {meso_code} — {meso_lib}")
print(f"  ✓ Statut ZRE       : {zre_statut}")
print()

# === Mise à jour des cellules ===
print("Mise à jour du tableur...")

# Bloc Données d'Entrée
ws["C37"] = commune
ws["C38"] = f"{dpt} - {dpt_nom}" if dpt_nom else dpt
ws["F15"] = commune

# Bloc résolution géographique automatique
ws["C112"] = commune
ws["C113"] = insee
ws["C114"] = dpt
ws["C115"] = region_nom
ws["C116"] = round(float(lon), 6)
ws["C117"] = round(float(lat), 6)
ws["C118"] = bassin
ws["C119"] = agence
ws["C120"] = sdage
ws["C121"] = sage
ws["C122"] = meso_code
ws["C123"] = meso_lib
ws["C124"] = zre_statut
ws["C125"] = zre_nappe
ws["C126"] = zre_arrete
ws["C127"] = zre_date

# Code département dans le bloc climatique (C74)
if dpt:
    ws["C74"] = dpt

# Feuille Cadastre & BSS
if "Cadastre & BSS" in wb.sheetnames:
    wbss = wb["Cadastre & BSS"]
    wbss["C6"] = insee
    wbss["C9"] = commune
    wbss["C14"] = round(float(lon), 6)
    wbss["C15"] = round(float(lat), 6)
    if isinstance(ws["C35"].value, (int, float)):
        wbss["C18"] = ws["C35"].value

# Feuille Compléments réglementaires
if "Compléments réglementaires" in wb.sheetnames:
    wcr = wb["Compléments réglementaires"]
    wcr["C21"] = f"À vérifier — commune INSEE {insee} (DDT {dpt})"
    wcr["C23"] = f"À vérifier auprès de la DREAL/DDT {dpt}"
    wcr["C24"] = commune
    wcr["C59"] = f"Vérifier inscription {commune} à la liste ZRE auprès de la DDT {dpt}."
    wcr["D82"] = f"{commune} (INSEE {insee})"

# === Sauvegarde ===
backup = XLSM.with_suffix('.xlsx.backup')
shutil.copy2(XLSM, backup)
print(f"  Sauvegarde : {backup.name}")

wb.save(XLSM)
print(f"  ✓ Tableur mis à jour : {XLSM.name}")
print()
print("=" * 70)
print("  ✓ Terminé — ouvrez (ou rouvrez) le tableur pour voir les résultats")
print("=" * 70)
print()

if sys.platform == 'win32':
    input("Appuyez sur Entrée pour fermer...")
