#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
GMEP — Évaluation des formations lenticulaires par signature topographique.

Méthode :
  1. TPI (Topographic Position Index) sur 3 voisinages (300 m, 1 000 m, 2 000 m)
     via l'API IGN Altimétrie (BDAlti, gratuite, sans clé).
  2. TWI (Topographic Wetness Index) — Beven & Kirkby (1979) approché.
  3. Lithologie superficielle (BDLISA) — utilisée si présente dans
     'Référentiel Aquifères' du classeur (alluvions, colluvions, saprolites).
  4. Densité de stations piézométriques (Hub'Eau) à 5 km — proxy aquifère
     superficiel exploité.

Sortie : indice IPL (Indice de Potentiel Lenticulaire) sur 3.
  IPL ≥ 2 → présomption forte de pièges lenticulaires.

Tous les indicateurs sont injectés dans la feuille
'Topographie & Lenticulaire' du classeur Excel.

Usage :
    python3 topo_lenticulaire.py [chemin_excel]
"""
import math
import json
import sys
import ssl
import urllib.request
import urllib.parse
from pathlib import Path

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# ---------------------------------------------------------------- Constantes
DEFAULT_XLSX = (
    "/home/user/workspace/rabattement_logiciel/"
    "Modelisation_Rabattement_TSN_GMEP.xlsx"
)
SHEET = "Topographie & Lenticulaire"

# ---------------------------------------------------------------- HTTPS ctx
_CTX = ssl.create_default_context()
_CTX.check_hostname = False
_CTX.verify_mode = ssl.CERT_NONE

UA = {"User-Agent": "GMEP-Rabattement/1.0"}


# ---------------------------------------------------------------- Géodésie
def l93_to_wgs84(x, y):
    """Lambert 93 (RGF93) → WGS84 lat/lon (degrés)."""
    n = 0.7256077650
    c = 11754255.426
    xs = 700000.0
    ys = 12655612.050
    e = 0.08181919106  # excentricité GRS80
    dx, dy = x - xs, y - ys
    R = math.sqrt(dx * dx + dy * dy)
    gamma = math.atan(dx / (-dy))
    lon = (gamma / n) + math.radians(3.0)
    lat_iso = -math.log(R / c) / n
    phi = 2 * math.atan(math.exp(lat_iso)) - math.pi / 2
    for _ in range(20):
        phi_new = (
            2
            * math.atan(
                math.exp(lat_iso)
                * ((1 + e * math.sin(phi)) / (1 - e * math.sin(phi))) ** (e / 2)
            )
            - math.pi / 2
        )
        if abs(phi_new - phi) < 1e-12:
            break
        phi = phi_new
    return math.degrees(phi), math.degrees(lon)


# ---------------------------------------------------------------- API IGN
def fetch_altitudes_ign(coords_l93):
    """Récupère altitudes pour une liste de (X,Y) Lambert 93. Retourne liste de Z (m NGF)."""
    coords_wgs = [l93_to_wgs84(x, y) for (x, y) in coords_l93]
    lons = "|".join(f"{c[1]:.6f}" for c in coords_wgs)
    lats = "|".join(f"{c[0]:.6f}" for c in coords_wgs)
    url = (
        "https://data.geopf.fr/altimetrie/1.0/calcul/alti/rest/elevation.json"
        f"?lon={lons}&lat={lats}&resource=ign_rge_alti_wld&delimiter=|"
    )
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=25, context=_CTX) as r:
        data = json.loads(r.read())
    return [e["z"] for e in data["elevations"]]


# ---------------------------------------------------------------- API Hub'Eau
def count_piezo_nearby(lon, lat, half_deg=0.05):
    """Nombre de stations piézométriques Hub'Eau dans une BBOX ±half_deg degrés (~5 km)."""
    url = (
        "https://hubeau.eaufrance.fr/api/v1/niveaux_nappes/stations"
        f"?format=json&size=200"
        f"&bbox={lon-half_deg},{lat-half_deg},{lon+half_deg},{lat+half_deg}"
    )
    try:
        req = urllib.request.Request(url, headers=UA)
        with urllib.request.urlopen(req, timeout=15, context=_CTX) as r:
            d = json.loads(r.read())
        return d.get("count", 0)
    except Exception:
        return None


# ---------------------------------------------------------------- BDLISA local
def lookup_bdlisa_lithologies(wb, X, Y):
    """
    Retourne (n_aquifères_présents, [lithologies superficielles trouvées]).
    Utilise la feuille 'Référentiel Aquifères' déjà présente dans le classeur :
      - colonnes AA/AB/AC/AD = bbox L93 de chaque aquifère
      - colonne D = lithologie principale
      - colonne G = profondeur du toit min (m)
    Lithologies « lenticulaires » : alluv*, colluv*, saprolite*, sable*, gravier*, limon*, lentil*
    """
    if "Référentiel Aquifères" not in wb.sheetnames:
        return 0, []
    ws = wb["Référentiel Aquifères"]
    KW = ("alluv", "colluv", "saprolite", "sable", "gravier", "limon",
          "lentil", "molasse", "fluviatil", "terrass")
    n_present = 0
    lithos_lent = []
    for r in range(5, ws.max_row + 1):
        try:
            xmin = float(ws[f"AA{r}"].value)
            xmax = float(ws[f"AB{r}"].value)
            ymin = float(ws[f"AC{r}"].value)
            ymax = float(ws[f"AD{r}"].value)
        except (TypeError, ValueError):
            continue
        if xmin <= X <= xmax and ymin <= Y <= ymax:
            n_present += 1
            litho = ws[f"D{r}"].value or ""
            top = ws[f"G{r}"].value
            try:
                top_f = float(top) if top is not None else None
            except (TypeError, ValueError):
                top_f = None
            litho_low = str(litho).lower()
            # Lenticulaire = lithologie « meuble » ET toit ≤ 30 m (proche surface)
            if any(k in litho_low for k in KW) and (top_f is None or top_f <= 30):
                aqu_name = ws[f"A{r}"].value or "?"
                lithos_lent.append(f"{aqu_name} ({litho[:50]}, toit {top_f or '?'} m)")
    return n_present, lithos_lent


# ---------------------------------------------------------------- Calculs TPI/TWI
def compute_topo_indicators(X, Y):
    """
    Récupère 25 altitudes (3×3 à 300 m + 8 à 1 km + 8 à 2 km),
    puis calcule TPI et TWI.
    """
    pts = []
    # grille 3×3 à 300 m
    for dy in (-300, 0, 300):
        for dx in (-300, 0, 300):
            pts.append((X + dx, Y + dy))
    # couronne 1 000 m (8 azimuts)
    for ang in range(0, 360, 45):
        rad = math.radians(ang)
        pts.append((X + 1000 * math.cos(rad), Y + 1000 * math.sin(rad)))
    # couronne 2 000 m (8 azimuts)
    for ang in range(0, 360, 45):
        rad = math.radians(ang)
        pts.append((X + 2000 * math.cos(rad), Y + 2000 * math.sin(rad)))
    z_all = fetch_altitudes_ign(pts)
    z_center = z_all[4]
    z_grid8 = [z_all[i] for i in range(9) if i != 4]
    z_1000 = z_all[9:17]
    z_2000 = z_all[17:25]

    mean_grid = sum(z_grid8) / 8
    mean_1000 = sum(z_1000) / 8
    mean_2000 = sum(z_2000) / 8
    tpi_300 = z_center - mean_grid
    tpi_1000 = z_center - mean_1000
    tpi_2000 = z_center - mean_2000

    # Pente moyenne (Horn-like) sur la grille 3×3
    slopes = []
    for i, z in enumerate(z_grid8):
        # i=0,1,2 → y=-300 ; i=5,6,7 → y=+300 ; etc.
        idx = i if i < 4 else i + 1  # vrai indice dans z_all
        col = idx % 3 - 1
        row = idx // 3 - 1
        dist = math.sqrt(col * col + row * row) * 300
        slopes.append(abs(z - z_center) / dist if dist > 0 else 0.0)
    slope_mean = sum(slopes) / len(slopes)
    slope_rad = math.atan(max(slope_mean, 1e-4))

    # SCA proxy : surface où z > z_center sur les 8 points 1 km
    above = sum(1 for z in z_1000 if z > z_center)
    sca = (math.pi * 1000 ** 2) * (above / 8)
    twi = math.log(max(sca, 100) / math.tan(slope_rad))

    return {
        "z_center": z_center,
        "z_neighbors_300": z_grid8,
        "z_1000": z_1000,
        "z_2000": z_2000,
        "tpi_300": tpi_300,
        "tpi_1000": tpi_1000,
        "tpi_2000": tpi_2000,
        "slope_deg": math.degrees(slope_rad),
        "sca_m2": sca,
        "twi": twi,
    }


# ---------------------------------------------------------------- IPL composite
def compute_ipl(tpi_1000, twi, n_litho_lent, n_piezo):
    """
    IPL ∈ [0..3] (entier) — Indice de Potentiel Lenticulaire.

    +1 si TPI(1000m) ≤ -1 m       (puits en cuvette / dépression)
    +1 si TWI ≥ 8                 (forte tendance à accumulation)
    +1 si lithologie lenticulaire BDLISA présente OU densité piézo ≥ 5/5km²
    """
    score = 0
    if tpi_1000 <= -1.0:
        score += 1
    if twi >= 8.0:
        score += 1
    if n_litho_lent >= 1 or (n_piezo is not None and n_piezo >= 5):
        score += 1
    return score


# ---------------------------------------------------------------- Excel
HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
HEADER_FONT = Font(bold=True, color="FFFFFF", size=11)
SECTION_FILL = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")
SECTION_FONT = Font(bold=True, color="1F4E79", size=11)
INFO_FILL = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def build_sheet(wb, X, Y, indi, n_aqu, lithos_lent, n_piezo, ipl):
    if SHEET in wb.sheetnames:
        del wb[SHEET]
    ws = wb.create_sheet(SHEET)
    # Largeurs colonnes
    widths = {"A": 3, "B": 38, "C": 16, "D": 14, "E": 60}
    for k, v in widths.items():
        ws.column_dimensions[k].width = v

    # Titre
    ws["B2"] = "TOPOGRAPHIE & FORMATIONS LENTICULAIRES"
    ws["B2"].font = Font(bold=True, size=14, color="1F4E79")
    ws.merge_cells("B2:E2")
    ws["B3"] = (
        "Évaluation automatique des pièges hydrogéologiques "
        "lenticulaires par signature topographique IGN BDAlti, "
        "indice TWI (Beven & Kirkby 1979) et lithologie BDLISA."
    )
    ws["B3"].font = Font(italic=True, color="595959")
    ws.merge_cells("B3:E3")

    row = 5
    # === Section 1 : COORDONNÉES ===
    ws[f"B{row}"] = "POINT PROJET (référence cellules Données d'Entrée)"
    ws[f"B{row}"].fill = SECTION_FILL
    ws[f"B{row}"].font = SECTION_FONT
    ws.merge_cells(f"B{row}:E{row}")
    row += 1
    for label, formula, unit, desc in [
        ("X Lambert 93 (m)", "='Données d''Entrée'!C33", "m", "RGF93/EPSG:2154 — Axe Est"),
        ("Y Lambert 93 (m)", "='Données d''Entrée'!C34", "m", "RGF93/EPSG:2154 — Axe Nord"),
        ("Altitude tête puits (m NGF)", f"={indi['z_center']}", "m", "API IGN BDAlti — vérifie cohérence saisie"),
    ]:
        ws[f"B{row}"] = label
        ws[f"C{row}"] = formula
        ws[f"D{row}"] = unit
        ws[f"E{row}"] = desc
        ws[f"E{row}"].font = Font(italic=True, color="595959")
        row += 1

    row += 1
    # === Section 2 : ALTITUDES VOISINES ===
    ws[f"B{row}"] = "ALTITUDES VOISINES (m NGF) — API IGN BDAlti (résolution 5 m)"
    ws[f"B{row}"].fill = SECTION_FILL
    ws[f"B{row}"].font = SECTION_FONT
    ws.merge_cells(f"B{row}:E{row}")
    row += 1
    # Grille 3×3
    ws[f"B{row}"] = "Grille 3×3 à 300 m (NW, N, NE / W, centre, E / SW, S, SE)"
    ws[f"B{row}"].font = Font(bold=True)
    row += 1
    z_all_grid = list(indi["z_neighbors_300"])
    z_all_grid.insert(4, indi["z_center"])  # remettre le centre
    labels_grid = ["NW", "N", "NE", "W", "Centre", "E", "SW", "S", "SE"]
    for lbl, z in zip(labels_grid, z_all_grid):
        ws[f"B{row}"] = f"  {lbl}"
        ws[f"C{row}"] = round(z, 2)
        ws[f"C{row}"].number_format = "0.00"
        ws[f"D{row}"] = "m NGF"
        if lbl == "Centre":
            ws[f"B{row}"].font = Font(bold=True)
            ws[f"C{row}"].font = Font(bold=True)
        row += 1
    # Couronnes 1000 et 2000 m
    for radius_m, zlist in [(1000, indi["z_1000"]), (2000, indi["z_2000"])]:
        ws[f"B{row}"] = f"Couronne {radius_m} m — moyenne 8 azimuts (N à NW par 45°)"
        ws[f"B{row}"].font = Font(bold=True)
        row += 1
        ws[f"B{row}"] = f"  Min / Moyenne / Max ({radius_m} m)"
        ws[f"C{row}"] = f"{min(zlist):.2f} / {sum(zlist)/8:.2f} / {max(zlist):.2f}"
        ws[f"D{row}"] = "m NGF"
        row += 1

    row += 1
    # === Section 3 : INDICATEURS ===
    ws[f"B{row}"] = "INDICATEURS HYDROGÉOMORPHOLOGIQUES"
    ws[f"B{row}"].fill = SECTION_FILL
    ws[f"B{row}"].font = SECTION_FONT
    ws.merge_cells(f"B{row}:E{row}")
    row += 1
    # En-tête tableau
    for col, hdr in zip(("B", "C", "D", "E"), ("Indicateur", "Valeur", "Unité", "Interprétation")):
        ws[f"{col}{row}"] = hdr
        ws[f"{col}{row}"].fill = HEADER_FILL
        ws[f"{col}{row}"].font = HEADER_FONT
        ws[f"{col}{row}"].alignment = Alignment(horizontal="center")
    row += 1

    def interp_tpi(t):
        if t > 1.0:   return "Crête / sommet — drainage gravitaire dominant"
        if t > -1.0:  return "Position intermédiaire — pente régulière"
        if t > -3.0:  return "Léger creux / vallon — accumulation possible"
        return "Cuvette / talweg — accumulation marquée d'eau"

    def interp_twi(w):
        if w < 5:  return "Drainage rapide — zone exportatrice"
        if w < 8:  return "Tendance modérée à humidité"
        if w < 12: return "Forte tendance à accumulation d'eau"
        return "Très forte accumulation — zone humide / piège lenticulaire probable"

    rows_data = [
        ("TPI 300 m (z_centre − moyenne 8 voisins)", indi["tpi_300"], "m", interp_tpi(indi["tpi_300"])),
        ("TPI 1 000 m", indi["tpi_1000"], "m", interp_tpi(indi["tpi_1000"])),
        ("TPI 2 000 m", indi["tpi_2000"], "m", interp_tpi(indi["tpi_2000"])),
        ("Pente moyenne grille 3×3", indi["slope_deg"], "°", "Pente locale Horn-like"),
        ("SCA (Specific Catchment Area)", indi["sca_m2"], "m²", "Surface drainante amont approchée"),
        ("TWI = ln(SCA / tan β)", indi["twi"], "—", interp_twi(indi["twi"])),
        ("Aquifères BDLISA présents au point", n_aqu, "—", "Compte des entités hydrogéologiques nationales"),
        ("Lithologies lenticulaires (toit ≤ 30 m)", len(lithos_lent), "—",
         "; ".join(lithos_lent)[:120] if lithos_lent else "Aucune formation meuble superficielle proche"),
        ("Stations piézométriques Hub'Eau (≤ 5 km)", n_piezo if n_piezo is not None else "n/d", "—",
         "Densité piézo = preuve indirecte d'aquifère exploitable"),
    ]
    fmt_map = {"m": "0.00", "°": "0.00", "m²": "#,##0", "—": "0.00"}
    for label, val, unit, interp in rows_data:
        ws[f"B{row}"] = label
        if isinstance(val, (int, float)):
            ws[f"C{row}"] = val
            ws[f"C{row}"].number_format = fmt_map.get(unit, "0.00")
        else:
            ws[f"C{row}"] = val
        ws[f"D{row}"] = unit
        ws[f"E{row}"] = interp
        ws[f"E{row}"].font = Font(italic=True, color="595959")
        for col in ("B", "C", "D", "E"):
            ws[f"{col}{row}"].border = BORDER
        row += 1

    row += 1
    # === Section 4 : IPL synthèse ===
    ws[f"B{row}"] = "INDICE DE POTENTIEL LENTICULAIRE (IPL)"
    ws[f"B{row}"].fill = SECTION_FILL
    ws[f"B{row}"].font = SECTION_FONT
    ws.merge_cells(f"B{row}:E{row}")
    row += 1
    # Critères avec formules dynamiques (relire valeurs depuis cellules ci-dessus)
    # On stocke les 3 critères en formules pour qu'ils restent vivants si l'utilisateur change
    # les valeurs (mais en pratique elles sont injectées par script).
    # Pour rester dans l'esprit "tout vit dans Excel", on met aussi les formules de seuil :
    #   IPL_a = IF(TPI1000 <= -1; 1; 0)
    #   IPL_b = IF(TWI >= 8; 1; 0)
    #   IPL_c = IF(OR(N_litho_lent >= 1; N_piezo >= 5); 1; 0)
    # Adresses estimées (basé sur l'ordre des lignes ajoutées) — on récupère dynamiquement.
    # Ici on simplifie en injectant les valeurs.
    crits = [
        ("Critère a — TPI 1 000 m ≤ −1 m (cuvette)", 1 if indi["tpi_1000"] <= -1.0 else 0),
        ("Critère b — TWI ≥ 8 (forte humidité)", 1 if indi["twi"] >= 8.0 else 0),
        ("Critère c — Litho lenticulaire ou ≥ 5 piézos à 5 km",
         1 if (len(lithos_lent) >= 1 or (n_piezo is not None and n_piezo >= 5)) else 0),
    ]
    for label, val in crits:
        ws[f"B{row}"] = label
        ws[f"C{row}"] = val
        ws[f"D{row}"] = "/ 1"
        for col in ("B", "C", "D"):
            ws[f"{col}{row}"].border = BORDER
        row += 1
    ws[f"B{row}"] = "IPL TOTAL"
    ws[f"B{row}"].font = Font(bold=True, size=12)
    ws[f"C{row}"] = ipl
    ws[f"C{row}"].font = Font(bold=True, size=12)
    ws[f"D{row}"] = "/ 3"
    if ipl >= 2:
        fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        diag = "PRÉSOMPTION FORTE de pièges lenticulaires — surcouche V_lent activée"
    elif ipl == 1:
        fill = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
        diag = "Présomption modérée — pas de surcouche, vigilance terrain"
    else:
        fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
        diag = "Pas de signature lenticulaire détectée"
    ws[f"E{row}"] = diag
    for col in ("B", "C", "D", "E"):
        ws[f"{col}{row}"].fill = fill
        ws[f"{col}{row}"].border = BORDER
    ipl_row = row  # mémoriser pour Calculs!V_lent
    row += 2

    # === Section 5 : V_lenticulaire ===
    ws[f"B{row}"] = "VOLUME LENTICULAIRE ADDITIF (m³/an)"
    ws[f"B{row}"].fill = SECTION_FILL
    ws[f"B{row}"].font = SECTION_FONT
    ws.merge_cells(f"B{row}:E{row}")
    row += 1
    ws[f"B{row}"] = "Surface lenticulaire estimée (m²)"
    ws[f"C{row}"] = (
        # surface lenticulaire = moitié de SCA si IPL≥2, sinon 0
        f"=IF(C{ipl_row}>=2, {indi['sca_m2']:.0f}*0.5, 0)"
    )
    ws[f"C{row}"].number_format = "#,##0"
    ws[f"D{row}"] = "m²"
    ws[f"E{row}"] = "≈ 50 % du bassin versant à 1 km contributif si IPL ≥ 2"
    surf_row = row
    row += 1
    ws[f"B{row}"] = "Épaisseur saturée moyenne lentilles"
    ws[f"C{row}"] = 1.5
    ws[f"C{row}"].number_format = "0.0"
    ws[f"D{row}"] = "m"
    ws[f"E{row}"] = "Hypothèse forfaitaire conservatrice (lentilles minces 1-3 m)"
    ws[f"E{row}"].font = Font(italic=True, color="595959")
    epai_row = row
    row += 1
    ws[f"B{row}"] = "Porosité efficace"
    ws[f"C{row}"] = 0.10
    ws[f"C{row}"].number_format = "0.00"
    ws[f"D{row}"] = "—"
    ws[f"E{row}"] = "Sables/limons saprolitiques typiques (BDLISA)"
    ws[f"E{row}"].font = Font(italic=True, color="595959")
    poro_row = row
    row += 1
    ws[f"B{row}"] = "Recharge annuelle effective"
    ws[f"C{row}"] = "='Données d''Entrée'!C79/1000"
    ws[f"C{row}"].number_format = "0.000"
    ws[f"D{row}"] = "m/an"
    ws[f"E{row}"] = "Reprend pluie efficace R des Données d'Entrée"
    rech_row = row
    row += 1
    ws[f"B{row}"] = "V_lent annuel (m³/an)"
    ws[f"B{row}"].font = Font(bold=True)
    ws[f"C{row}"] = (
        f"=C{surf_row}*C{epai_row}*C{poro_row}+C{surf_row}*C{rech_row}"
    )
    ws[f"C{row}"].number_format = "#,##0"
    ws[f"C{row}"].font = Font(bold=True, color="1F4E79")
    ws[f"D{row}"] = "m³/an"
    ws[f"E{row}"] = "Stock initial (S × ép × n) + recharge annuelle (S × R)"
    vlent_row = row
    row += 2

    # === Section 6 : Méthodologie ===
    ws[f"B{row}"] = "MÉTHODOLOGIE & SOURCES"
    ws[f"B{row}"].fill = SECTION_FILL
    ws[f"B{row}"].font = SECTION_FONT
    ws.merge_cells(f"B{row}:E{row}")
    row += 1
    refs = [
        "TPI : Weiss A. (2001). Topographic position and landforms analysis. ESRI User Conf.",
        "TWI : Beven K. & Kirkby M.J. (1979). A physically based, variable contributing area model of basin hydrology.",
        "Altimétrie : IGN BDAlti / RGE Alti (résolution 5 m) — API Géoplateforme.",
        "BDLISA : BRGM/Eaufrance — Référentiel hydrogéologique national (RP-67489-FR).",
        "Hub'Eau : API piézométrie nationale — densité de captages comme proxy d'aquifère exploité.",
        "Formules : V_lent = S × (ép × n + R) ; appliqué uniquement si IPL ≥ 2.",
    ]
    for r in refs:
        ws[f"B{row}"] = "  • " + r
        ws[f"B{row}"].font = Font(italic=True, color="595959", size=9)
        ws.merge_cells(f"B{row}:E{row}")
        row += 1

    return vlent_row, ipl_row


# ---------------------------------------------------------------- Wire to Calculs
def wire_to_calculs(wb, vlent_addr_full):
    """Ajoute V_lent au volume aquifère et au diagnostic plancher dans 'Calculs'."""
    ws = wb["Calculs"]

    # Trouver C49 (V_pluie) — V_aquif_total = V_aquif + V_pluie + V_lent
    # Cellule C84 dans diagnostic = V_aquif + pluie ; on l'enrichit avec V_lent
    # Lecture actuelle C84 :
    cur_84 = ws["C84"].value or ""
    # On reconstruit proprement
    ws["C84"] = f"=C48+C49+'{SHEET}'!{vlent_addr_full}"
    ws["B84"] = "Volume disponible (V_aquif + V_pluie + V_lent)"
    # Mettre à jour message dynamique B87
    ws["B87"] = (
        '=IF(C86="AQUIFÈRE",'
        '"Régime aquifère : V_an piloté par physique Theis/Dupuit (volume disponible > plancher)",'
        '"Régime PLANCHER : aquifère insuffisant, plancher chantier 5 m³/j appliqué")'
    )

    # Ajouter une ligne récap V_lent dans la zone de récap volumes (B73-81 si présente)
    # Placement libre : on ajoute en B89 / B90 pour info
    ws["B89"] = "Apport lenticulaire (V_lent)"
    ws["C89"] = f"='{SHEET}'!{vlent_addr_full}"
    ws["C89"].number_format = "#,##0"
    ws["D89"] = "m³/an"
    ws["E89"] = "Surcouche additive si IPL ≥ 2 (sinon 0)"
    ws["E89"].font = Font(italic=True, color="595959")


# ---------------------------------------------------------------- Main
def main(path):
    print(f"→ Ouverture {path}")
    wb = openpyxl.load_workbook(path)
    de = wb["Données d'Entrée"]
    X = float(de["C33"].value)
    Y = float(de["C34"].value)
    print(f"  Coords L93 : ({X}, {Y})")
    lat, lon = l93_to_wgs84(X, Y)
    print(f"  WGS84      : ({lat:.4f}, {lon:.4f})")

    print("→ Calcul TPI/TWI (25 altitudes IGN)…")
    indi = compute_topo_indicators(X, Y)
    print(f"  TPI 300m={indi['tpi_300']:+.2f}  1000m={indi['tpi_1000']:+.2f}  2000m={indi['tpi_2000']:+.2f}")
    print(f"  TWI={indi['twi']:.2f}  pente={indi['slope_deg']:.2f}°")

    print("→ Lookup BDLISA local (Référentiel Aquifères)…")
    n_aqu, lithos_lent = lookup_bdlisa_lithologies(wb, X, Y)
    print(f"  Aquifères présents : {n_aqu}")
    print(f"  Lithos lenticulaires : {len(lithos_lent)}")

    print("→ Hub'Eau piézométrie (≤ 5 km)…")
    n_piezo = count_piezo_nearby(lon, lat, 0.05)
    print(f"  Stations piézo : {n_piezo}")

    ipl = compute_ipl(indi["tpi_1000"], indi["twi"], len(lithos_lent), n_piezo)
    print(f"→ IPL composite = {ipl}/3")

    print("→ Construction feuille 'Topographie & Lenticulaire'…")
    vlent_row, ipl_row = build_sheet(wb, X, Y, indi, n_aqu, lithos_lent, n_piezo, ipl)
    vlent_addr = f"C{vlent_row}"
    print(f"  V_lent adresse: '{SHEET}'!{vlent_addr}")

    print("→ Branchement sur Calculs (C84 + V_lent)…")
    wire_to_calculs(wb, vlent_addr)

    wb.save(path)
    print(f"✓ Sauvegardé : {path}")
    return ipl, indi


if __name__ == "__main__":
    arg = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_XLSX
    main(arg)
