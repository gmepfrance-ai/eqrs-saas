#!/usr/bin/env python3
"""Ajoute des boutons cliquables sur F33 et F34 (à droite de X et Y Lambert 93).
Le clic déclenche Worksheet_FollowHyperlink (patché dans le binaire VBA) → MettreAJourGeographie.
"""
import zipfile, shutil, re, os

SRC = "Modelisation_Rabattement_TSN_GMEP.xlsx"
TMP = "/tmp/add_geo_btn"

if os.path.exists(TMP):
    shutil.rmtree(TMP)
os.makedirs(TMP)

with zipfile.ZipFile(SRC, 'r') as z:
    z.extractall(TMP)

# === Modifier sheet3.xml : ajouter hyperliens internes sur F33 et F34 ===
with open(f"{TMP}/xl/worksheets/sheet3.xml", encoding='utf-8') as f:
    s3 = f.read()

# Trouver les cellules F33 et F34 actuelles : <c r="F33" s="422" t="n"></c>
# Les remplacer pour ajouter du texte cliquable
old_f33 = '<c r="F33" s="422" t="n"></c>'
new_f33 = '<c r="F33" s="422" t="inlineStr"><is><t>&#9654;  CLIQUEZ POUR ACTIVER</t></is></c>'
assert old_f33 in s3, "F33 introuvable"
s3 = s3.replace(old_f33, new_f33)

old_f34 = '<c r="F34" s="422" t="n"></c>'
new_f34 = '<c r="F34" s="422" t="inlineStr"><is><t>&#9654;  CLIQUEZ POUR ACTIVER</t></is></c>'
assert old_f34 in s3, "F34 introuvable"
s3 = s3.replace(old_f34, new_f34)

# Ajouter un bloc <hyperlinks> à la fin de sheetData (avant </worksheet> ou avant <dataValidations>)
# Vérifier s'il existe déjà un bloc <hyperlinks>
hyperlinks_block = '''<hyperlinks><hyperlink ref="F33" location="'Donn&#233;es d''Entr&#233;e'!F33" display="&#9654;  CLIQUEZ POUR ACTIVER"/><hyperlink ref="F34" location="'Donn&#233;es d''Entr&#233;e'!F34" display="&#9654;  CLIQUEZ POUR ACTIVER"/></hyperlinks>'''

if '<hyperlinks>' in s3:
    # Insérer dans le bloc existant
    s3 = s3.replace('<hyperlinks>', '<hyperlinks><hyperlink ref="F33" location="\'Donn&#233;es d\'\'Entr&#233;e\'!F33" display="&#9654;  CLIQUEZ POUR ACTIVER"/><hyperlink ref="F34" location="\'Donn&#233;es d\'\'Entr&#233;e\'!F34" display="&#9654;  CLIQUEZ POUR ACTIVER"/>')
else:
    # Ajouter avant <dataValidations> ou avant </worksheet>
    if '<dataValidations' in s3:
        s3 = s3.replace('<dataValidations', hyperlinks_block + '<dataValidations')
    else:
        s3 = s3.replace('</worksheet>', hyperlinks_block + '</worksheet>')

with open(f"{TMP}/xl/worksheets/sheet3.xml", 'w', encoding='utf-8') as f:
    f.write(s3)

# === Modifier sheet3.xml.rels — pas besoin (hyperliens internes, pas externes) ===

# === Modifier B41 pour rester un bouton cliquable aussi ===
# Optionnel — on garde le bandeau informatif actuel, mais on peut aussi le rendre cliquable.
# Ajouter l'hyperlien interne sur B41 vers B41 lui-même (déclenchera FollowHyperlink)
if '<hyperlink ref="B41"' not in s3:
    s3_b41 = s3.replace('display="&#9654;  CLIQUEZ POUR ACTIVER"/>',
                         'display="&#9654;  CLIQUEZ POUR ACTIVER"/><hyperlink ref="B41" location="\'Donn&#233;es d\'\'Entr&#233;e\'!B41" display="MISE A JOUR GEOGRAPHIE"/>',
                         1)
    with open(f"{TMP}/xl/worksheets/sheet3.xml", 'w', encoding='utf-8') as f:
        f.write(s3_b41)

# === Reconstruction xlsx ===
if os.path.exists(SRC):
    os.remove(SRC)

with zipfile.ZipFile(SRC, 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(TMP):
        for file in files:
            fp = os.path.join(root, file)
            arc = os.path.relpath(fp, TMP)
            z.write(fp, arc)

print(f"✓ {SRC} reconstruit avec boutons F33/F34 cliquables (+ B41 cliquable)")
