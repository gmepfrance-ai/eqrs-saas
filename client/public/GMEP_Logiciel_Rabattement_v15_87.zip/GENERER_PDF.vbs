' ================================================================
'  G.M.E.P -- Generer le PDF (v15.57)
'  Script VBS autonome -- double-clic = recalcul + sauvegarde +
'                          generation PDF + ouverture PDF
'  Aucune copie vers C:\GMEP, aucune boite OK/Annuler
' ================================================================
Option Explicit

Dim WshShell, FSO, ScriptFolder
Set WshShell = CreateObject("WScript.Shell")
Set FSO      = CreateObject("Scripting.FileSystemObject")
ScriptFolder = FSO.GetParentFolderName(WScript.ScriptFullName)

' ----------------------------------------------------------------
' 1. Verifier presence du script Python
' ----------------------------------------------------------------
Dim PythonScript
PythonScript = ScriptFolder & "\generate_rapport_loi_eau.py"
If Not FSO.FileExists(PythonScript) Then
    MsgBox "generate_rapport_loi_eau.py introuvable dans :" & vbCrLf & _
           ScriptFolder & vbCrLf & vbCrLf & _
           "Decompressez le ZIP complet avant de lancer ce script.", _
           vbCritical, "G.M.E.P -- Fichier manquant"
    WScript.Quit 1
End If

' ----------------------------------------------------------------
' 2. Si Excel est ouvert : forcer RECALCUL COMPLET + SAUVEGARDE
'    puis FERMER Excel proprement
'    Cela garantit que le .xlsx sur disque contient les valeurs
'    a jour de TOUTES les formules avant que Python ne le lise.
' ----------------------------------------------------------------
On Error Resume Next
Dim xlApp0, wb0, savedPath
savedPath = ""
Set xlApp0 = GetObject(, "Excel.Application")
If Not IsNull(xlApp0) And Not IsEmpty(xlApp0) Then
    ' Forcer le mode de calcul automatique (au cas ou il aurait ete passe en manuel)
    xlApp0.Calculation = -4105  ' xlCalculationAutomatic
    xlApp0.CalculateFullRebuild
    xlApp0.CalculateUntilAsyncQueriesDone
    For Each wb0 In xlApp0.Workbooks
        If InStr(LCase(wb0.Name), "rabattement") > 0 Or _
           InStr(LCase(wb0.Name), "modelisation") > 0 Then
            savedPath = wb0.FullName
            ' Forcer le recalcul puis la sauvegarde du classeur metier
            wb0.Application.CalculateFullRebuild
            wb0.Save
            wb0.Close False
        End If
    Next
    If xlApp0.Workbooks.Count = 0 Then
        xlApp0.Quit
    End If
    Set xlApp0 = Nothing
    WScript.Sleep 2000
End If
On Error GoTo 0

' ATTENTE ACTIVE -- on attend que TOUS les verrous ~$ disparaissent
' (Excel + OneDrive peuvent mettre 10-15 sec a liberer le fichier)
Dim attemptCount, anyLock, lockFx
For attemptCount = 1 To 30
    anyLock = False
    On Error Resume Next
    For Each lockFx In FSO.GetFolder(ScriptFolder).Files
        If Left(lockFx.Name, 2) = "~$" Then
            anyLock = True
            ' Tentative suppression directe du verrou
            FSO.DeleteFile lockFx.Path, True
        End If
    Next
    Err.Clear
    On Error GoTo 0
    If Not anyLock Then Exit For
    WScript.Sleep 1000
Next

' ----------------------------------------------------------------
' 3. Trouver le fichier Excel (le plus recent, en ignorant ~$ et USER_UPLOAD)
' ----------------------------------------------------------------
Dim ExcelFile, fx, maxDate
ExcelFile = ""
maxDate = #1/1/2000#
For Each fx In FSO.GetFolder(ScriptFolder).Files
    Dim ext, nm
    ext = LCase(Right(fx.Name, 5))
    nm = fx.Name
    ' IGNORER les fichiers verrouilles temporaires (~$...) et USER_UPLOAD
    If Left(nm, 2) <> "~$" And InStr(UCase(nm), "USER_UPLOAD") = 0 Then
        If ext = ".xlsx" Or ext = ".xlsm" Then
            If fx.DateLastModified > maxDate Then
                maxDate = fx.DateLastModified
                ExcelFile = fx.Path
            End If
        End If
    End If
Next

If ExcelFile = "" Then
    MsgBox "Aucun fichier Excel (.xlsx) trouve dans :" & vbCrLf & _
           ScriptFolder, vbCritical, "G.M.E.P -- Excel manquant"
    WScript.Quit 1
End If

' Verifier une derniere fois que le fichier n'est pas verrouille
' (au cas ou un ~$ existerait toujours apres la fermeture d'Excel)
Dim LockPath
LockPath = ScriptFolder & "\~$" & FSO.GetFileName(ExcelFile)
If FSO.FileExists(LockPath) Then
    ' Tentative de suppression du verrou orphelin
    On Error Resume Next
    FSO.DeleteFile LockPath, True
    On Error GoTo 0
End If

' ----------------------------------------------------------------
' 3-bis. FORCER LE RECALCUL des formules en arriere-plan
'        On ouvre le fichier dans une instance Excel invisible,
'        on declenche CalculateFullRebuild, on sauvegarde et on ferme.
'        Ainsi les valeurs en cache (data_only) lues par Python sont
'        TOUJOURS coherentes avec les dernieres saisies utilisateur.
' ----------------------------------------------------------------
On Error Resume Next
Dim xlBg, wbBg
Set xlBg = CreateObject("Excel.Application")
If Not IsNull(xlBg) And Not IsEmpty(xlBg) Then
    xlBg.Visible = False
    xlBg.DisplayAlerts = False
    xlBg.AutomationSecurity = 3  ' msoAutomationSecurityForceDisable (bloque macros)
    xlBg.AskToUpdateLinks = False
    Set wbBg = xlBg.Workbooks.Open(ExcelFile, 0, False)  ' UpdateLinks=0, ReadOnly=False
    If Not IsNull(wbBg) And Not IsEmpty(wbBg) Then
        xlBg.Calculation = -4105  ' xlCalculationAutomatic
        xlBg.CalculateFullRebuild
        xlBg.CalculateUntilAsyncQueriesDone
        wbBg.Save
        wbBg.Close False
    End If
    xlBg.Quit
    Set wbBg = Nothing
    Set xlBg = Nothing
    WScript.Sleep 1500
    ' Attendre eventuels verrous residuels apres l'instance invisible
    Dim k, anyLock2, lockFx2
    For k = 1 To 20
        anyLock2 = False
        For Each lockFx2 In FSO.GetFolder(ScriptFolder).Files
            If Left(lockFx2.Name, 2) = "~$" Then
                anyLock2 = True
                FSO.DeleteFile lockFx2.Path, True
            End If
        Next
        If Not anyLock2 Then Exit For
        WScript.Sleep 500
    Next
End If
Err.Clear
On Error GoTo 0

' ----------------------------------------------------------------
' 4. Trouver Python
' ----------------------------------------------------------------
Dim PythonExe : PythonExe = ""

' a) Versions utilisateur dans LOCALAPPDATA
Dim v, p, LocalApp
LocalApp = WshShell.ExpandEnvironmentStrings("%LOCALAPPDATA%")
For Each v In Array("313","312","311","310","39","38")
    p = LocalApp & "\Programs\Python\Python" & v & "\python.exe"
    If FSO.FileExists(p) Then PythonExe = p : Exit For
Next

' b) Versions machine dans Program Files
If PythonExe = "" Then
    For Each v In Array("313","312","311","310","39","38")
        p = "C:\Program Files\Python" & v & "\python.exe"
        If FSO.FileExists(p) Then PythonExe = p : Exit For
        p = "C:\Program Files (x86)\Python" & v & "\python.exe"
        If FSO.FileExists(p) Then PythonExe = p : Exit For
    Next
End If

' c) Registre
If PythonExe = "" Then
    Dim ver
    For Each ver In Array("3.13","3.12","3.11","3.10","3.9")
        On Error Resume Next
        p = WshShell.RegRead("HKCU\Software\Python\PythonCore\" & ver & "\InstallPath\ExecutablePath")
        If Err.Number = 0 And p <> "" And FSO.FileExists(p) Then
            Err.Clear : On Error GoTo 0
            PythonExe = p : Exit For
        End If
        Err.Clear
        p = WshShell.RegRead("HKLM\Software\Python\PythonCore\" & ver & "\InstallPath\ExecutablePath")
        If Err.Number = 0 And p <> "" And FSO.FileExists(p) Then
            Err.Clear : On Error GoTo 0
            PythonExe = p : Exit For
        End If
        Err.Clear : On Error GoTo 0
    Next
End If

' d) PATH (where python, evite WindowsApps)
If PythonExe = "" Then
    On Error Resume Next
    Dim oExec, line
    Set oExec = WshShell.Exec("where python")
    If Err.Number = 0 Then
        Do While Not oExec.StdOut.AtEndOfStream
            line = Trim(oExec.StdOut.ReadLine())
            If InStr(LCase(line),"windowsapps") = 0 And FSO.FileExists(line) Then
                PythonExe = line : Exit Do
            End If
        Loop
    End If
    Err.Clear : On Error GoTo 0
End If

If PythonExe = "" Then
    MsgBox "Python n'est pas installe sur cet ordinateur." & vbCrLf & vbCrLf & _
           "Telechargez et installez Python depuis :" & vbCrLf & _
           "https://www.python.org/downloads/" & vbCrLf & vbCrLf & _
           "ATTENTION : cocher 'Add python.exe to PATH' a l'installation.", _
           vbCritical, "G.M.E.P -- Python manquant"
    WScript.Quit 1
End If

' ----------------------------------------------------------------
' 5. Preparer fichier .cmd et log dans %TEMP%
' ----------------------------------------------------------------
Dim TmpDir, CmdFile, LogFile, fCmd
TmpDir = WshShell.ExpandEnvironmentStrings("%TEMP%")
Dim TS
TS = Replace(Replace(Replace(CStr(Now), "/", ""), ":", ""), " ", "_")
CmdFile = TmpDir & "\gmep_generer_" & TS & ".cmd"
LogFile = TmpDir & "\gmep_log_" & TS & ".txt"

Set fCmd = FSO.CreateTextFile(CmdFile, True, False)
fCmd.WriteLine "@echo off"
fCmd.WriteLine "chcp 65001 > nul"
fCmd.WriteLine "title G.M.E.P  --  Generation du PDF en cours..."
fCmd.WriteLine "color 1F"
fCmd.WriteLine "set PYTHONUTF8=1"
fCmd.WriteLine "set PYTHONIOENCODING=utf-8:replace"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo ================================================================"
fCmd.WriteLine "echo   G.M.E.P  --  Generation du Dossier Loi sur l'Eau"
fCmd.WriteLine "echo ================================================================"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo   Dossier : " & ScriptFolder
fCmd.WriteLine "echo   Excel   : " & FSO.GetFileName(ExcelFile)
fCmd.WriteLine "echo   Python  : " & PythonExe
fCmd.WriteLine "echo   Log     : " & LogFile
fCmd.WriteLine "echo."
fCmd.WriteLine "echo   Verification des modules Python..."
fCmd.WriteLine """" & PythonExe & """ -c ""import openpyxl, reportlab, PIL, matplotlib, requests"" 2>nul"
fCmd.WriteLine "if errorlevel 1 ("
fCmd.WriteLine "    echo   Installation des modules manquants..."
fCmd.WriteLine "    """ & PythonExe & """ -m pip install --quiet openpyxl reportlab Pillow matplotlib requests"
fCmd.WriteLine ")"
fCmd.WriteLine "echo   Modules : OK"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo ================================================================"
fCmd.WriteLine "echo   Generation en cours (30 a 90 secondes)..."
fCmd.WriteLine "echo   NE FERMEZ PAS cette fenetre."
fCmd.WriteLine "echo ================================================================"
fCmd.WriteLine "echo."
fCmd.WriteLine "cd /d """ & ScriptFolder & """"
REM Attente preventive supplementaire pour laisser Excel/OneDrive liberer le fichier
fCmd.WriteLine "echo   Attente de liberation du fichier (5 sec)..."
fCmd.WriteLine "timeout /t 5 /nobreak > nul 2>&1"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo   Lancement de Python..."
fCmd.WriteLine "echo."
REM Lance Python : sortie redirigee vers fichier log ET affichee a l'ecran via type apres.
REM On utilise 2>&1 pour capturer aussi les erreurs.
fCmd.WriteLine """" & PythonExe & """ -X utf8 -u """ & PythonScript & """ """ & ExcelFile & """ > """ & LogFile & """ 2>&1"
fCmd.WriteLine "set PYRET=%ERRORLEVEL%"
fCmd.WriteLine "REM Afficher le log a l'ecran pour que l'utilisateur voie ce qui s'est passe"
fCmd.WriteLine "type """ & LogFile & """"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo ================================================================"
fCmd.WriteLine "if exist ""Dossier_Declaration_Loi_Eau_GMEP.pdf"" goto :SUCCES"
fCmd.WriteLine "goto :ERREUR"
fCmd.WriteLine ""
fCmd.WriteLine ":SUCCES"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo   PDF genere avec succes."
fCmd.WriteLine "echo ================================================================"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo   Ouverture du PDF dans 2 secondes..."
fCmd.WriteLine "timeout /t 2 /nobreak > nul"
fCmd.WriteLine "start """" """ & ScriptFolder & "\Dossier_Declaration_Loi_Eau_GMEP.pdf"""
fCmd.WriteLine "timeout /t 3 /nobreak > nul"
fCmd.WriteLine "exit /b 0"
fCmd.WriteLine ""
fCmd.WriteLine ":ERREUR"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo   *** ERREUR : aucun PDF n'a ete cree. ***"
fCmd.WriteLine "echo   Code retour Python : %PYRET%"
fCmd.WriteLine "echo   Log complet : " & LogFile
fCmd.WriteLine "echo ================================================================"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo   Le log d'erreur va s'ouvrir dans le Bloc-notes."
fCmd.WriteLine "echo   APPUYEZ SUR UNE TOUCHE pour continuer..."
fCmd.WriteLine "pause > nul"
fCmd.WriteLine "start notepad.exe """ & LogFile & """"
fCmd.WriteLine "echo."
fCmd.WriteLine "echo   APPUYEZ SUR UNE TOUCHE pour fermer cette fenetre..."
fCmd.WriteLine "pause > nul"
fCmd.WriteLine "exit /b 1"
fCmd.Close

' ----------------------------------------------------------------
' 6. Lancer le .cmd (fenetre visible, attendre la fin)
' ----------------------------------------------------------------
Dim ret
ret = WshShell.Run("""" & CmdFile & """", 1, True)

' Nettoyer le .cmd temporaire (mais GARDER le log pour debug)
On Error Resume Next
FSO.DeleteFile CmdFile
On Error GoTo 0

WScript.Quit ret
