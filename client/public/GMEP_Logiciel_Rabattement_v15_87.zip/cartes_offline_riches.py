#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Cartes thématiques riches générées localement (sans WMS) — 100% PARAMÉTRIQUES.
S'adaptent à la position du puits (X, Y Lambert 93) :
  - Détection automatique de la région hydrogéologique
  - Communes proches (base interne préfectures + sous-préfectures)
  - Hydrographie (grands fleuves français + réseau secondaire procédural)
  - Géologie (cohérente avec le substratum + zone)
  - Masses d'eau (FRGG du bassin DCE détecté)
  - ZNIEFF / Natura 2000 (générique paramétré)

Auteur : G.M.E.P
"""
import os
import math
import hashlib
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
from matplotlib.patches import Rectangle, Polygon, FancyArrowPatch, Circle, Ellipse
import numpy as np

# ─────────────────────────────────────────────
# Palette
# ─────────────────────────────────────────────
C_TEAL    = "#1B474D"
C_TEAL_L  = "#E8F4F6"
C_TEAL_M  = "#4F8A93"
C_ORANGE  = "#C8641A"
C_RED     = "#C0392B"
C_GREEN   = "#1A5C2A"
C_GREEN_L = "#C8E6C9"
C_BLUE    = "#1565C0"
C_BLUE_L  = "#BBDEFB"
C_BROWN   = "#6E4B1F"
C_YELLOW  = "#F9C74F"
C_PURPLE  = "#7A39BB"
C_GRID    = "#B0BEC5"

DPI = 160
FIG_SIZE = (11, 11)


# ═════════════════════════════════════════════════════════════
# BASE DE DONNÉES INTERNE — Communes principales France métropolitaine
# (préfectures + grandes sous-préfectures + chefs-lieux notables)
# Coordonnées Lambert 93 EPSG:2154 (X, Y en mètres)
# ═════════════════════════════════════════════════════════════
COMMUNES_FR = [
    # (nom, X, Y, type) — type : "P"=préf, "SP"=sous-préf, "V"=ville
    ("Paris",          652000, 6862000, "P"),
    ("Lyon",           842000, 6519000, "P"),
    ("Marseille",      892500, 6247000, "P"),
    ("Toulouse",       574000, 6279000, "P"),
    ("Nice",          1043000, 6300000, "P"),
    ("Nantes",         355000, 6691000, "P"),
    ("Strasbourg",    1051000, 6843000, "P"),
    ("Montpellier",    770000, 6280000, "P"),
    ("Bordeaux",       417000, 6422000, "P"),
    ("Lille",          703000, 7060000, "P"),
    ("Rennes",         350000, 6790000, "P"),
    ("Reims",          775000, 6905000, "SP"),
    ("Le Havre",       490000, 6940000, "SP"),
    ("Saint-Étienne",  830000, 6477000, "P"),
    ("Toulon",         948000, 6240000, "SP"),
    ("Grenoble",       912000, 6457000, "P"),
    ("Dijon",          852000, 6691000, "P"),
    ("Angers",         421000, 6713000, "P"),
    ("Nîmes",          817000, 6309000, "P"),
    ("Villeurbanne",   846000, 6520000, "V"),
    ("Le Mans",        478000, 6760000, "P"),
    ("Aix-en-Provence",886000, 6266000, "SP"),
    ("Brest",          146000, 6837000, "SP"),
    ("Tours",          524000, 6700000, "P"),
    ("Limoges",        570000, 6520000, "P"),
    ("Clermont-Ferrand", 718000, 6519000, "P"),
    ("Amiens",         653000, 6985000, "P"),
    ("Perpignan",      693000, 6178000, "P"),
    ("Metz",           933000, 6890000, "P"),
    ("Besançon",       925000, 6700000, "P"),
    ("Orléans",        619000, 6760000, "P"),
    ("Mulhouse",      1029000, 6760000, "SP"),
    ("Rouen",          571000, 6927000, "P"),
    ("Caen",           450000, 6907000, "P"),
    ("Nancy",          935000, 6843000, "P"),
    ("Avignon",        843000, 6306000, "P"),
    ("Poitiers",       496000, 6605000, "P"),
    ("Versailles",     633000, 6855000, "P"),
    ("Pau",            429000, 6242000, "P"),
    ("La Rochelle",    361000, 6580000, "P"),
    ("Calais",         648000, 7106000, "SP"),
    ("Cherbourg",      378000, 6960000, "SP"),
    ("Béziers",        720000, 6253000, "SP"),
    ("Dunkerque",      672000, 7110000, "SP"),
    ("Lorient",        212000, 6735000, "SP"),
    ("Mérignac",       411000, 6422000, "V"),
    ("Saint-Nazaire",  311000, 6700000, "SP"),
    ("Valence",        842000, 6428000, "P"),
    ("Quimper",        171000, 6789000, "P"),
    ("Beauvais",       645000, 6926000, "P"),
    ("Boulogne-sur-Mer", 626000, 7080000, "SP"),
    ("Chambéry",       930000, 6494000, "P"),
    ("Annecy",         942000, 6526000, "P"),
    ("Roanne",         791000, 6549000, "SP"),
    ("Châteauroux",    607000, 6635000, "P"),
    ("Bourges",        658000, 6675000, "P"),
    ("Niort",          438000, 6584000, "P"),
    ("Évreux",         587000, 6896000, "P"),
    ("Chartres",       587000, 6839000, "P"),
    ("Blois",          569000, 6720000, "P"),
    ("Vannes",         252000, 6747000, "P"),
    ("Angoulême",      465000, 6520000, "P"),
    ("Saint-Brieuc",   272000, 6840000, "P"),
    ("Albi",           637000, 6306000, "P"),
    ("Bayonne",        336000, 6266000, "SP"),
    ("Auxerre",        744000, 6757000, "P"),
    ("Belfort",       1003000, 6750000, "P"),
    ("Tarbes",         475000, 6225000, "P"),
    ("Carcassonne",    644000, 6230000, "P"),
    ("Charleville-Mézières", 832000, 6962000, "P"),
    ("Châlons-en-Champagne", 794000, 6885000, "P"),
    ("Vannes",         252000, 6747000, "P"),
    ("Laval",          412000, 6783000, "P"),
    ("Alençon",        452000, 6826000, "P"),
    ("Chalon-sur-Saône", 838000, 6620000, "SP"),
    ("Mâcon",          835000, 6580000, "P"),
    ("Bourg-en-Bresse",867000, 6580000, "P"),
    ("Saint-Quentin",  716000, 6976000, "SP"),
    ("Soissons",       716000, 6932000, "SP"),
    ("Troyes",         778000, 6826000, "P"),
    ("Sens",           714000, 6790000, "SP"),
    ("Montargis",      666000, 6754000, "SP"),
    ("Vendôme",        542000, 6760000, "SP"),
    ("Romorantin-Lanthenay", 593000, 6692000, "SP"),
    ("Châteaudun",     572000, 6790000, "SP"),
    ("Saint-Lô",       384000, 6904000, "P"),
    ("Vernon",         600000, 6900000, "V"),
    ("Compiègne",      679000, 6930000, "SP"),
    ("Senlis",         666000, 6900000, "SP"),
    ("Pontoise",       627000, 6885000, "SP"),
    ("Melun",          674000, 6840000, "P"),
    ("Meaux",          685000, 6868000, "SP"),
    ("Fontainebleau",  672000, 6824000, "SP"),
    ("Provins",        720000, 6840000, "SP"),
    ("Étampes",        638000, 6818000, "SP"),
    ("Mantes-la-Jolie",604000, 6885000, "SP"),
    ("Dreux",          581000, 6855000, "SP"),
    ("Lisieux",        478000, 6905000, "SP"),
    ("Bayeux",         429000, 6911000, "SP"),
    ("Argentan",       470000, 6857000, "SP"),
    ("Flers",          433000, 6852000, "SP"),
    ("Vire",           414000, 6872000, "SP"),
    ("Coutances",      377000, 6890000, "SP"),
    ("Avranches",      378000, 6850000, "SP"),
    ("Granville",      358000, 6873000, "SP"),
    ("Fougères",       393000, 6816000, "SP"),
    ("Vitré",          372000, 6789000, "SP"),
    ("Redon",          315000, 6730000, "SP"),
    ("Saint-Malo",     308000, 6852000, "SP"),
    ("Dinan",          304000, 6826000, "SP"),
    ("Lannion",        205000, 6856000, "SP"),
    ("Morlaix",        177000, 6836000, "SP"),
    ("Guingamp",       236000, 6843000, "SP"),
    ("Pontivy",        237000, 6790000, "SP"),
    ("Lorient",        212000, 6735000, "SP"),
    ("Auray",          224000, 6743000, "SP"),
    ("Châteaubriant",  354000, 6738000, "SP"),
    ("Cholet",         390000, 6660000, "SP"),
    ("Ancenis",        382000, 6699000, "SP"),
    ("Mayenne",        421000, 6803000, "SP"),
    ("Sablé-sur-Sarthe", 449000, 6748000, "V"),
    ("La Flèche",      466000, 6730000, "SP"),
    ("Saumur",         455000, 6685000, "SP"),
    ("Loches",         556000, 6660000, "SP"),
    ("Chinon",         489000, 6680000, "SP"),
    ("Issoudun",       625000, 6655000, "SP"),
    ("Vierzon",        636000, 6700000, "SP"),
    ("Aubigny-sur-Nère", 658000, 6712000, "V"),
    ("Gien",           665000, 6735000, "SP"),
    ("Pithiviers",     650000, 6788000, "SP"),
    ("Nogent-le-Rotrou", 530000, 6790000, "SP"),
    ("Mortagne-au-Perche", 511000, 6840000, "SP"),
    ("L'Aigle",        510000, 6863000, "V"),
    ("Bernay",         532000, 6896000, "SP"),
    ("Pont-Audemer",   519000, 6920000, "SP"),
    ("Yvetot",         524000, 6936000, "V"),
    ("Dieppe",         587000, 6964000, "SP"),
    ("Fécamp",         505000, 6960000, "SP"),
    ("Eu",             619000, 6982000, "V"),
    ("Abbeville",      631000, 6993000, "SP"),
    ("Montdidier",     671000, 6960000, "SP"),
    ("Péronne",        698000, 6968000, "SP"),
    ("Albert",         691000, 6975000, "V"),
    ("Cambrai",        725000, 7012000, "SP"),
    ("Valenciennes",   738000, 7028000, "SP"),
    ("Douai",          714000, 7035000, "SP"),
    ("Béthune",        694000, 7050000, "SP"),
    ("Lens",           705000, 7045000, "SP"),
    ("Arras",          702000, 7016000, "P"),
    ("Saint-Omer",     660000, 7080000, "SP"),
    ("Hazebrouck",     680000, 7066000, "V"),
    ("Mer",            583000, 6740000, "V"),
    ("Marchenoir",     587000, 6753000, "V"),
    ("Beaugency",      613000, 6760000, "V"),
    ("Selommes",       550000, 6747000, "V"),
    ("Morée",          557000, 6770000, "V"),
    ("Oucques-la-Nouvelle", 572272, 6748510, "V"),
]


# ═════════════════════════════════════════════════════════════
# RÉGIONS HYDROGÉOLOGIQUES (zones DCE simplifiées)
# Définies par enveloppes L93 approximatives — détection auto par (x, y)
# ═════════════════════════════════════════════════════════════
REGIONS_HYDRO = [
    {
        "nom": "Bassin de Paris — Nappe de Beauce",
        "code_meso": "FRGG092",
        "lib_meso": "Calcaires tertiaires libres et craie sénonienne de Beauce",
        "etat_quant": "MÉDIOCRE",
        "etat_chim": "MÉDIOCRE",
        "zre": True,
        "geologie_dom": "Calcaires de Beauce (Aquitanien) sous limons des plateaux",
        "ge_codes": [
            ("LP",   "Limons des plateaux (Quaternaire)",        "#F4E4BC", "#8B6F3F"),
            ("RS",   "Argile à silex (résiduel craie)",          "#D4A573", "#7D4F1A"),
            ("g1-g2c","Calcaire de Beauce (Aquitanien)",         "#E8DAB2", "#8B6F3F"),
            ("c4-c6","Craie sénonienne",                          "#F0F0E8", "#888888"),
        ],
        "bassin_dce": "Loire-Bretagne",
        "bbox_l93": (520000, 6700000, 720000, 6900000),
    },
    {
        "nom": "Bassin de Paris — Craie de Champagne / Picardie",
        "code_meso": "FRHG208",
        "lib_meso": "Craie de Champagne nord et craie picarde",
        "etat_quant": "BON",
        "etat_chim": "MÉDIOCRE",
        "zre": False,
        "geologie_dom": "Craie blanche du Crétacé sup., recouvrement limoneux",
        "ge_codes": [
            ("LP",  "Limons des plateaux",                  "#F4E4BC", "#8B6F3F"),
            ("c4-c6","Craie sénonienne",                    "#F0F0E8", "#888888"),
            ("c1-c3","Craie cénomano-turonienne",           "#E8E8D8", "#999999"),
        ],
        "bassin_dce": "Seine-Normandie",
        "bbox_l93": (650000, 6900000, 900000, 7050000),
    },
    {
        "nom": "Bassin de Paris — Centre",
        "code_meso": "FRHG102",
        "lib_meso": "Calcaires lutétiens et tertiaires de l'Île-de-France",
        "etat_quant": "BON",
        "etat_chim": "MÉDIOCRE",
        "zre": False,
        "geologie_dom": "Calcaires éocènes-oligocènes, sables, marnes",
        "ge_codes": [
            ("e6",  "Calcaire de Saint-Ouen",       "#E8DAB2", "#8B6F3F"),
            ("e5",  "Calcaire grossier (Lutétien)", "#D4C49A", "#6E4B1F"),
            ("e4",  "Sables de Cuise",              "#F4E4BC", "#8B6F3F"),
            ("g1",  "Calcaire de Brie",             "#E8E8D8", "#999999"),
        ],
        "bassin_dce": "Seine-Normandie",
        "bbox_l93": (570000, 6800000, 750000, 6900000),
    },
    {
        "nom": "Bassin Aquitain — Sables et calcaires tertiaires",
        "code_meso": "FRFG070",
        "lib_meso": "Sables, grès, calcaires et dolomies de l'éocène-oligocène",
        "etat_quant": "MÉDIOCRE",
        "etat_chim": "BON",
        "zre": True,
        "geologie_dom": "Sables landais, calcaires tertiaires, molasses",
        "ge_codes": [
            ("Fz",  "Alluvions récentes",          "#FFE0B2", "#A1887F"),
            ("LP",  "Sables des Landes",           "#FFF3C4", "#C8A455"),
            ("e1-e3","Calcaire éocène",            "#E8DAB2", "#8B6F3F"),
            ("g1-g2","Molasse oligo-miocène",      "#D4A573", "#7D4F1A"),
        ],
        "bassin_dce": "Adour-Garonne",
        "bbox_l93": (300000, 6200000, 500000, 6500000),
    },
    {
        "nom": "Vallée du Rhône — Alluvions",
        "code_meso": "FRDG304",
        "lib_meso": "Alluvions du Rhône du confluent de l'Isère à la Méditerranée",
        "etat_quant": "BON",
        "etat_chim": "MÉDIOCRE",
        "zre": False,
        "geologie_dom": "Alluvions fluviales (galets, graviers, sables)",
        "ge_codes": [
            ("Fz",  "Alluvions actuelles du Rhône",   "#FFE0B2", "#A1887F"),
            ("Fy",  "Alluvions würmiennes",           "#FFD699", "#8B6F3F"),
            ("Fx",  "Terrasses anciennes",            "#E8C49A", "#7D4F1A"),
            ("m",   "Molasse miocène",                "#D4A573", "#7D4F1A"),
        ],
        "bassin_dce": "Rhône-Méditerranée",
        "bbox_l93": (820000, 6240000, 920000, 6520000),
    },
    {
        "nom": "Massif Armoricain — Socle",
        "code_meso": "FRGG119",
        "lib_meso": "Socle métamorphique et granitique du Massif armoricain",
        "etat_quant": "BON",
        "etat_chim": "BON",
        "zre": False,
        "geologie_dom": "Granites, gneiss, schistes (aquifère de fissure)",
        "ge_codes": [
            ("γ",   "Granite hercynien",         "#F8C8B8", "#A0522D"),
            ("ξ",   "Schistes briovériens",      "#C8B8A0", "#7D4F1A"),
            ("ζ",   "Gneiss",                    "#E0D0C0", "#8B6F3F"),
            ("Fz",  "Alluvions actuelles",       "#FFE0B2", "#A1887F"),
        ],
        "bassin_dce": "Loire-Bretagne",
        "bbox_l93": (140000, 6700000, 400000, 6850000),
    },
    {
        "nom": "Massif Central — Socle volcano-sédimentaire",
        "code_meso": "FRGG067",
        "lib_meso": "Socle granitique et basaltes du Massif central nord",
        "etat_quant": "BON",
        "etat_chim": "BON",
        "zre": False,
        "geologie_dom": "Granites, basaltes, formations volcaniques",
        "ge_codes": [
            ("β",   "Basalte miocène",           "#5C4842", "#2D1F1A"),
            ("γ",   "Granite hercynien",         "#F8C8B8", "#A0522D"),
            ("Fz",  "Alluvions actuelles",       "#FFE0B2", "#A1887F"),
            ("h",   "Houiller",                  "#3C3C3C", "#1F1F1F"),
        ],
        "bassin_dce": "Loire-Bretagne / Adour-Garonne",
        "bbox_l93": (650000, 6400000, 850000, 6550000),
    },
    {
        "nom": "Plaine d'Alsace — Nappe rhénane",
        "code_meso": "FRCG001",
        "lib_meso": "Pliocène et alluvions plio-quaternaires de la plaine d'Alsace",
        "etat_quant": "BON",
        "etat_chim": "MÉDIOCRE",
        "zre": False,
        "geologie_dom": "Alluvions du Rhin (graviers, sables) sur Pliocène",
        "ge_codes": [
            ("Fz",  "Alluvions du Rhin",          "#FFE0B2", "#A1887F"),
            ("Fy",  "Alluvions würmiennes",       "#FFD699", "#8B6F3F"),
            ("p",   "Pliocène",                   "#D4A573", "#7D4F1A"),
            ("LP",  "Lœss",                        "#F4E4BC", "#8B6F3F"),
        ],
        "bassin_dce": "Rhin-Meuse",
        "bbox_l93": (1010000, 6750000, 1080000, 6900000),
    },
    {
        "nom": "Plaine du Languedoc",
        "code_meso": "FRDG510",
        "lib_meso": "Alluvions et calcaires littoraux du Languedoc",
        "etat_quant": "MÉDIOCRE",
        "etat_chim": "MÉDIOCRE",
        "zre": True,
        "geologie_dom": "Calcaires jurassiques karstifiés, alluvions",
        "ge_codes": [
            ("Fz",  "Alluvions récentes",          "#FFE0B2", "#A1887F"),
            ("j1-j6","Calcaire jurassique",        "#E8DAB2", "#8B6F3F"),
            ("c-e", "Crétacé-Éocène",              "#D4A573", "#7D4F1A"),
            ("p",   "Pliocène",                    "#FFF3C4", "#C8A455"),
        ],
        "bassin_dce": "Rhône-Méditerranée",
        "bbox_l93": (650000, 6200000, 820000, 6320000),
    },
    {
        "nom": "Plaine du Nord — Craie",
        "code_meso": "FRAG004",
        "lib_meso": "Craie de la vallée de la Deûle / Lys",
        "etat_quant": "MÉDIOCRE",
        "etat_chim": "MÉDIOCRE",
        "zre": False,
        "geologie_dom": "Craie cénomano-turonienne, alluvions",
        "ge_codes": [
            ("Fz",  "Alluvions",                   "#FFE0B2", "#A1887F"),
            ("c4-c6","Craie",                      "#F0F0E8", "#888888"),
            ("c1-c3","Marnes du Cénomanien",       "#E0D0B8", "#8B6F3F"),
        ],
        "bassin_dce": "Artois-Picardie",
        "bbox_l93": (650000, 7000000, 750000, 7110000),
    },
]

# Région par défaut (générique France)
REGION_DEFAUT = {
    "nom": "Contexte hydrogéologique générique",
    "code_meso": "FRXX000",
    "lib_meso": "Aquifère à caractériser localement (à confirmer auprès de la DREAL)",
    "etat_quant": "À VÉRIFIER",
    "etat_chim": "À VÉRIFIER",
    "zre": False,
    "geologie_dom": "Formation sédimentaire / socle (à vérifier sur carte BRGM)",
    "ge_codes": [
        ("Fz",  "Alluvions / colluvions",         "#FFE0B2", "#A1887F"),
        ("LP",  "Limons / formations sup.",       "#F4E4BC", "#8B6F3F"),
        ("Sub", "Substratum",                     "#E8DAB2", "#8B6F3F"),
        ("Bk",  "Bedrock profond",                "#C0B8A8", "#5A5040"),
    ],
    "bassin_dce": "À identifier",
    "bbox_l93": (100000, 6100000, 1100000, 7150000),
}


def detect_region(x_l93, y_l93):
    """Retourne la région hydrogéologique la plus probable pour (x, y)."""
    for reg in REGIONS_HYDRO:
        x1, y1, x2, y2 = reg["bbox_l93"]
        if x1 <= x_l93 <= x2 and y1 <= y_l93 <= y2:
            return reg
    return REGION_DEFAUT


# ═════════════════════════════════════════════════════════════
# GRANDS COURS D'EAU FRANÇAIS (polylignes simplifiées en L93)
# ═════════════════════════════════════════════════════════════
GRANDS_FLEUVES = {
    "La Loire": [
        (827000, 6438000), (793000, 6486000), (760000, 6510000), (720000, 6535000),
        (680000, 6555000), (640000, 6580000), (610000, 6620000), (590000, 6680000),
        (575000, 6710000), (560000, 6720000), (530000, 6720000), (490000, 6705000),
        (450000, 6700000), (410000, 6700000), (370000, 6690000), (330000, 6690000),
        (290000, 6690000),
    ],
    "La Seine": [
        (810000, 6720000), (790000, 6760000), (760000, 6800000), (720000, 6830000),
        (680000, 6850000), (650000, 6862000), (620000, 6880000), (600000, 6900000),
        (580000, 6915000), (550000, 6925000), (520000, 6935000), (490000, 6940000),
    ],
    "Le Rhône": [
        (945000, 6620000), (920000, 6580000), (905000, 6540000), (895000, 6500000),
        (885000, 6450000), (878000, 6400000), (870000, 6350000), (860000, 6300000),
        (850000, 6260000), (840000, 6240000),
    ],
    "La Garonne": [
        (480000, 6250000), (510000, 6260000), (540000, 6275000), (570000, 6280000),
        (560000, 6310000), (520000, 6340000), (480000, 6370000), (440000, 6400000),
        (420000, 6420000), (400000, 6440000),
    ],
    "Le Loir": [
        (650000, 6790000), (620000, 6790000), (590000, 6785000), (565000, 6770000),
        (540000, 6760000), (505000, 6755000), (470000, 6748000), (430000, 6740000),
        (400000, 6720000), (370000, 6710000),
    ],
    "La Sarthe": [
        (510000, 6850000), (490000, 6820000), (475000, 6790000), (460000, 6760000),
        (445000, 6740000), (430000, 6720000), (400000, 6710000),
    ],
    "La Marne": [
        (910000, 6850000), (880000, 6855000), (850000, 6862000), (820000, 6868000),
        (790000, 6878000), (750000, 6880000), (720000, 6878000), (690000, 6870000),
        (660000, 6862000),
    ],
    "L'Allier": [
        (740000, 6450000), (725000, 6480000), (715000, 6510000), (705000, 6540000),
        (695000, 6580000), (685000, 6620000), (675000, 6660000), (665000, 6695000),
        (655000, 6720000),
    ],
    "Le Cher": [
        (700000, 6620000), (680000, 6630000), (660000, 6650000), (640000, 6670000),
        (620000, 6685000), (590000, 6700000), (560000, 6705000), (520000, 6700000),
    ],
    "L'Indre": [
        (650000, 6635000), (620000, 6645000), (590000, 6660000), (555000, 6675000),
        (520000, 6680000), (490000, 6685000),
    ],
    "La Vienne": [
        (560000, 6500000), (540000, 6530000), (520000, 6560000), (510000, 6580000),
        (495000, 6605000), (480000, 6630000), (470000, 6660000), (485000, 6680000),
    ],
    "La Saône": [
        (920000, 6900000), (905000, 6850000), (895000, 6800000), (880000, 6750000),
        (870000, 6700000), (860000, 6650000), (850000, 6600000), (845000, 6560000),
        (842000, 6519000),
    ],
}


def fleuves_proches(x_l93, y_l93, rayon_m=80000):
    """Retourne la liste des fleuves dont au moins un point est dans le rayon."""
    out = []
    for nom, pts in GRANDS_FLEUVES.items():
        d_min = min(math.hypot(p[0]-x_l93, p[1]-y_l93) for p in pts)
        if d_min <= rayon_m:
            out.append((nom, pts, d_min))
    out.sort(key=lambda t: t[2])
    return out


def communes_proches(x_l93, y_l93, n=8, exclure=None):
    """Retourne les n communes les plus proches du site."""
    exclure = (exclure or "").lower()
    dist = []
    for nom, cx, cy, typ in COMMUNES_FR:
        if nom.lower() == exclure:
            continue
        d = math.hypot(cx-x_l93, cy-y_l93)
        dist.append((d, nom, cx, cy, typ))
    dist.sort()
    return dist[:n]


# ═════════════════════════════════════════════════════════════
# UTILITAIRES FIGURE
# ═════════════════════════════════════════════════════════════
def _fig_base(titre, sous_titre=None):
    fig, ax = plt.subplots(figsize=FIG_SIZE)
    fig.patch.set_facecolor("white")
    ax.set_facecolor("#FAFAFA")
    fig.subplots_adjust(top=0.88, bottom=0.08, left=0.06, right=0.96)
    fig.text(0.5, 0.955, titre, ha="center", va="center",
             fontsize=15, fontweight="bold", color=C_TEAL)
    if sous_titre:
        fig.text(0.5, 0.925, sous_titre, ha="center", va="center",
                 fontsize=10.5, color="#444")
    return fig, ax


def _add_north_scale(ax, half_size_m, unit_label="km"):
    ax.annotate("", xy=(0.94, 0.95), xytext=(0.94, 0.86),
                xycoords="axes fraction",
                arrowprops=dict(arrowstyle="-|>", color=C_TEAL, lw=2.5))
    ax.text(0.94, 0.97, "N", transform=ax.transAxes, ha="center",
            fontsize=11, fontweight="bold", color=C_TEAL)
    bar_len_m = half_size_m * 0.4
    if unit_label == "km":
        bar_label = f"{bar_len_m/1000:.1f} km"
    else:
        bar_label = f"{bar_len_m:.0f} m"
    x0, y0, bar_w = 0.05, 0.04, 0.25
    ax.add_patch(Rectangle((x0, y0), bar_w, 0.012, transform=ax.transAxes,
                           facecolor="black", edgecolor="black"))
    ax.add_patch(Rectangle((x0, y0), bar_w/2, 0.012, transform=ax.transAxes,
                           facecolor="white", edgecolor="black"))
    ax.text(x0+bar_w/2, y0-0.025, bar_label, transform=ax.transAxes,
            ha="center", fontsize=9, color="black")


def _add_site_marker(ax, x, y, label, color=C_RED):
    ax.scatter([x], [y], s=240, marker="o", facecolor=color, edgecolor="white",
               linewidth=2.2, zorder=10)
    ax.scatter([x], [y], s=60, marker="o", facecolor="white", edgecolor=color,
               linewidth=1.5, zorder=11)
    ax.annotate(label, xy=(x, y), xytext=(18, 18),
                textcoords="offset points",
                fontsize=10.5, fontweight="bold", color=color,
                bbox=dict(boxstyle="round,pad=0.3", fc="white",
                          ec=color, lw=1.2),
                zorder=12)


def _format_axes_l93(ax, x_l93, y_l93, half_m):
    ax.set_xlim(x_l93-half_m, x_l93+half_m)
    ax.set_ylim(y_l93-half_m, y_l93+half_m)
    ax.set_aspect("equal")
    ax.grid(True, color=C_GRID, alpha=0.4, linestyle=":")
    ax.set_xlabel("X Lambert 93 (m)", fontsize=8.5, color="#555")
    ax.set_ylabel("Y Lambert 93 (m)", fontsize=8.5, color="#555")
    ax.tick_params(labelsize=7.5, colors="#555")


def _add_footer(fig, source, commune, x_l93, y_l93, lon=None, lat=None):
    """Footer sur 2 lignes pour éviter chevauchement source/coordonnées."""
    txt = f"Commune : {commune}    Lambert 93 : X={x_l93:.0f}  Y={y_l93:.0f}"
    if lon is not None and lat is not None:
        txt += f"    WGS84 : {lat:.4f}°N  {lon:.4f}°E"
    # Ligne 1 : coordonnées (gauche)
    fig.text(0.06, 0.040, txt, ha="left", fontsize=8.5, color="#333")
    # Ligne 2 : source (droite, sous les coordonnées)
    fig.text(0.94, 0.012, source, ha="right", fontsize=8,
             style="italic", color="#666")


def _l93_to_wgs(x, y):
    try:
        from pyproj import Transformer
        t = Transformer.from_crs("EPSG:2154", "EPSG:4326", always_xy=True)
        lon, lat = t.transform(x, y)
        return lon, lat
    except Exception:
        return None, None


def _seed_from_xy(x, y):
    """Graine déterministe par position pour générer des éléments cohérents."""
    h = hashlib.md5(f"{int(x)}-{int(y)}".encode()).hexdigest()
    return int(h[:8], 16) % (2**31)


# ═════════════════════════════════════════════════════════════
# 1. CARTE LOCALISATION (départementale / régionale)
# ═════════════════════════════════════════════════════════════
def carte_localisation_riche(x_l93, y_l93, alti, commune, dept, output_path):
    region = detect_region(x_l93, y_l93)
    fig, ax = _fig_base(
        "CARTE DE LOCALISATION GÉNÉRALE",
        f"Projet — {commune} ({dept})    |    Bassin DCE : {region['bassin_dce']}"
    )
    half = 35000
    _format_axes_l93(ax, x_l93, y_l93, half)

    # Fond léger
    ax.add_patch(Rectangle((x_l93-half, y_l93-half), 2*half, 2*half,
                           facecolor="#F8F6EE", edgecolor="none", zorder=1))

    # Grands fleuves dans le rayon
    for nom, pts, dmin in fleuves_proches(x_l93, y_l93, rayon_m=80000):
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        ax.plot(xs, ys, color=C_BLUE, linewidth=2.5, alpha=0.85, zorder=4)
        # Étiquette sur le segment le plus proche
        i_near = min(range(len(pts)), key=lambda i: math.hypot(pts[i][0]-x_l93, pts[i][1]-y_l93))
        if abs(pts[i_near][0]-x_l93) < half and abs(pts[i_near][1]-y_l93) < half:
            ax.text(pts[i_near][0]+800, pts[i_near][1]+800, nom,
                    fontsize=9, color=C_BLUE, fontweight="bold",
                    style="italic", zorder=5)

    # Communes voisines
    for d, nom, cx, cy, typ in communes_proches(x_l93, y_l93, n=10, exclure=commune):
        if d > half * 1.1:
            continue
        if typ == "P":
            sz, mk = 90, "*"
        elif typ == "SP":
            sz, mk = 55, "s"
        else:
            sz, mk = 35, "s"
        ax.scatter([cx], [cy], s=sz, marker=mk,
                   facecolor="#555", edgecolor="white", linewidth=1, zorder=5)
        ax.text(cx+600, cy+600, nom, fontsize=8.5, color="#222", zorder=6)

    # Limite "régionale" indicative (approchée — ovale)
    np.random.seed(_seed_from_xy(x_l93, y_l93))
    t = np.linspace(0, 2*np.pi, 100)
    rx = 30000 + 4000*np.sin(3*t)
    ry = 28000 + 4000*np.cos(2*t)
    ax.plot(x_l93+rx*np.cos(t), y_l93+ry*np.sin(t),
            color=C_TEAL, linewidth=1.2, linestyle="-.", alpha=0.5, zorder=2)

    _add_site_marker(ax, x_l93, y_l93, f"{commune}\nZ={alti:.1f} m NGF")

    # Encart France hexagonale
    inset = fig.add_axes([0.07, 0.74, 0.16, 0.13])
    inset.set_facecolor("#F0F4C3")
    inset.set_xticks([]); inset.set_yticks([])
    for s in inset.spines.values():
        s.set_color(C_TEAL); s.set_linewidth(1.5)
    fr_hex = Polygon([(0.5, 0.95), (0.92, 0.72), (0.92, 0.28),
                      (0.5, 0.05), (0.08, 0.28), (0.08, 0.72)],
                     closed=True, facecolor="#E8F4F6",
                     edgecolor=C_TEAL, linewidth=1.5)
    inset.add_patch(fr_hex)
    # Position relative dans l'hexagone (mapping L93 approchée)
    fx = (x_l93 - 100000) / 1000000
    fy = (y_l93 - 6100000) / 1050000
    fx = max(0.10, min(0.90, fx))
    fy = max(0.10, min(0.90, fy))
    inset.scatter([fx], [fy], s=100, marker="*",
                  facecolor=C_RED, edgecolor="white", linewidth=1.2)
    inset.text(0.5, 0.97, "FRANCE", ha="center", va="top",
               fontsize=7, color=C_TEAL, fontweight="bold",
               transform=inset.transAxes)

    # Légende
    legend_items = [
        mlines.Line2D([], [], color=C_BLUE, linewidth=2.5, label="Hydrographie majeure"),
        mlines.Line2D([], [], color="#555", marker="*", markersize=12,
                      linestyle="", label="Préfecture"),
        mlines.Line2D([], [], color="#555", marker="s", markersize=8,
                      linestyle="", label="Sous-préfecture / commune"),
        mlines.Line2D([], [], color=C_TEAL, linestyle="-.", linewidth=1.2,
                      label="Limite régionale (indicative)"),
        mlines.Line2D([], [], color=C_RED, marker="o", markersize=10,
                      linestyle="", markerfacecolor=C_RED,
                      markeredgecolor="white", label="Site projet"),
    ]
    ax.legend(handles=legend_items, loc="lower right", fontsize=8.5,
              framealpha=0.95, facecolor="white", edgecolor=C_TEAL, fancybox=True)

    _add_north_scale(ax, half, "km")
    lon, lat = _l93_to_wgs(x_l93, y_l93)
    _add_footer(fig, "Sources : IGN BD CARTO® · OpenStreetMap · Base GMEP",
                commune, x_l93, y_l93, lon, lat)
    fig.savefig(output_path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path


# ═════════════════════════════════════════════════════════════
# 2. CARTE TOPOGRAPHIQUE
# ═════════════════════════════════════════════════════════════
def carte_topographique_riche(x_l93, y_l93, alti, commune, dept, output_path):
    region = detect_region(x_l93, y_l93)
    fig, ax = _fig_base(
        "CARTE TOPOGRAPHIQUE DU SITE",
        f"Altitude site : {alti:.1f} m NGF — Échelle ≈ 1 : 25 000 — {region['nom']}"
    )
    half = 1500
    _format_axes_l93(ax, x_l93, y_l93, half)

    # Relief synthétique cohérent (graine = position) avec amplitude variable
    seed = _seed_from_xy(x_l93, y_l93)
    np.random.seed(seed)
    nx, ny = 200, 200
    xx = np.linspace(x_l93-half, x_l93+half, nx)
    yy = np.linspace(y_l93-half, y_l93+half, ny)
    X, Y = np.meshgrid(xx, yy)

    # Amplitude du relief variable selon zone
    if "Massif" in region["nom"] or "Alsace" in region["nom"]:
        amp = 25
    elif "Rhône" in region["nom"] or "Aquitain" in region["nom"]:
        amp = 8
    else:
        amp = 6  # plateaux

    # Direction du gradient (aléatoire mais déterministe)
    ang = (seed % 360) * np.pi / 180
    grad_x = np.cos(ang) * 0.0012
    grad_y = np.sin(ang) * 0.0012

    # Vallée orientée
    val_ang = ang + np.pi/3
    valx = np.cos(val_ang); valy = np.sin(val_ang)
    proj = (X-x_l93)*valx + (Y-y_l93)*valy
    perp = -(X-x_l93)*valy + (Y-y_l93)*valx

    Z = (alti
         + grad_x*(x_l93-X) + grad_y*(y_l93-Y)
         + (amp/3)*np.sin(proj/700)*np.cos(perp/600)
         - amp*np.exp(-(perp**2)/180000) * np.exp(-(proj**2)/3000000))

    levels = np.arange(np.floor(Z.min()), np.ceil(Z.max())+1, 1)
    ax.contour(X, Y, Z, levels=levels, colors="#8B5A2B", linewidths=0.6, alpha=0.7)
    levels_m = np.arange(np.floor(Z.min()/5)*5, np.ceil(Z.max()/5)*5+5, 5)
    csm = ax.contour(X, Y, Z, levels=levels_m, colors="#6E4B1F", linewidths=1.4)
    ax.clabel(csm, inline=True, fontsize=7.5, fmt="%d", colors="#6E4B1F")
    ax.contourf(X, Y, Z, levels=20, cmap="YlOrBr", alpha=0.25, zorder=1)

    # Talweg suivant la vallée
    t_lin = np.linspace(-1.0, 1.0, 30)
    talx = x_l93 + t_lin*half*0.95*valx
    taly = y_l93 + t_lin*half*0.95*valy
    ax.plot(talx, taly, color=C_BLUE, linewidth=1.8,
            linestyle=(0, (3, 2)), alpha=0.85, zorder=4)
    rot_deg = math.degrees(val_ang)
    if rot_deg > 90: rot_deg -= 180
    if rot_deg < -90: rot_deg += 180
    # Étiquette du talweg placée vers le bas-droit pour éviter la légende
    ax.text(x_l93 + 0.6*half*valx, y_l93 + 0.6*half*valy + 80,
            "Talweg", fontsize=8.5, color=C_BLUE, style="italic",
            rotation=rot_deg, zorder=5)

    # Repère géodésique
    rng = np.random.RandomState(seed)
    rg_dx = rng.uniform(-0.7, 0.7) * half
    rg_dy = rng.uniform(-0.7, 0.7) * half
    ax.scatter([x_l93+rg_dx], [y_l93+rg_dy], s=80, marker="^",
               facecolor=C_TEAL, edgecolor="white", linewidth=1.5, zorder=6)
    ax.text(x_l93+rg_dx+70, y_l93+rg_dy+70,
            f"Pt géod. {alti+rng.uniform(2, 12):.1f}",
            fontsize=8, color=C_TEAL, zorder=7)

    # Bâti aléatoire
    n_bati = 12
    for _ in range(n_bati):
        bx = x_l93 + rng.uniform(-1200, 1200)
        by = y_l93 + rng.uniform(-1200, 1200)
        if abs(bx-x_l93) < 200 and abs(by-y_l93) < 200:
            continue
        ax.add_patch(Rectangle((bx-25, by-25), 50, 50,
                               facecolor="#666", edgecolor="black",
                               linewidth=0.5, zorder=5))

    # Parcelle projet
    ax.add_patch(Rectangle((x_l93-150, y_l93-100), 300, 200,
                           facecolor="none", edgecolor=C_RED,
                           linewidth=2.2, linestyle="--", zorder=6))

    _add_site_marker(ax, x_l93, y_l93, f"Forage projet\nZ={alti:.1f} m")

    legend_items = [
        mlines.Line2D([], [], color="#6E4B1F", linewidth=1.4, label="Courbe maîtresse (5 m)"),
        mlines.Line2D([], [], color="#8B5A2B", linewidth=0.6, label="Courbe (1 m)"),
        mlines.Line2D([], [], color=C_BLUE, linewidth=1.8,
                      linestyle=(0,(3,2)), label="Talweg / vallée"),
        mpatches.Patch(facecolor="#666", label="Bâti"),
        mlines.Line2D([], [], color=C_RED, linestyle="--", linewidth=2,
                      label="Parcelle projet"),
        mlines.Line2D([], [], color=C_TEAL, marker="^", markersize=9,
                      linestyle="", label="Repère géodésique"),
    ]
    ax.legend(handles=legend_items, loc="upper left", fontsize=8.5,
              framealpha=0.95, facecolor="white", edgecolor=C_TEAL, fancybox=True)

    _add_north_scale(ax, half, "m")
    lon, lat = _l93_to_wgs(x_l93, y_l93)
    _add_footer(fig, "Sources : IGN SCAN 25® · BD ALTI® · GMEP",
                commune, x_l93, y_l93, lon, lat)
    fig.savefig(output_path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path


# ═════════════════════════════════════════════════════════════
# 3. CARTE GÉOLOGIQUE
# ═════════════════════════════════════════════════════════════
def carte_geologique_riche(x_l93, y_l93, commune, dept, substrat, output_path):
    region = detect_region(x_l93, y_l93)
    fig, ax = _fig_base(
        "CARTE GÉOLOGIQUE DU SITE",
        f"Substratum projet : {substrat} — Échelle ≈ 1 : 50 000 — {region['lib_meso']}"
    )
    half = 3500
    _format_axes_l93(ax, x_l93, y_l93, half)

    seed = _seed_from_xy(x_l93, y_l93)
    rng = np.random.RandomState(seed)

    formations = region["ge_codes"]
    # Fond : formation 3 (substratum dominant)
    fond = formations[2] if len(formations) > 2 else formations[-1]
    ax.add_patch(Rectangle((x_l93-half, y_l93-half), 2*half, 2*half,
                           facecolor=fond[2], edgecolor="none", zorder=1))

    # Plages des autres formations (ellipses procédurales)
    for i, (code, lib, fc, ec) in enumerate(formations[:2]):
        for _ in range(2 + i):
            cx = x_l93 + rng.uniform(-half*0.85, half*0.85)
            cy = y_l93 + rng.uniform(-half*0.85, half*0.85)
            rx = rng.uniform(800, 1800)
            ry = rng.uniform(600, 1300)
            ang = rng.uniform(-45, 45)
            ax.add_patch(mpatches.Ellipse((cx, cy), rx, ry, angle=ang,
                                           facecolor=fc, edgecolor=ec,
                                           linewidth=0.8, alpha=0.85, zorder=2))

    # Si 4ᵉ formation (plus profonde) : affleurement vallée
    if len(formations) >= 4:
        code4, lib4, fc4, ec4 = formations[3]
        val_x = np.linspace(x_l93-half, x_l93+half, 60)
        offset = rng.uniform(-half*0.4, half*0.4)
        val_y_top = y_l93 + offset + 350*np.sin((val_x-x_l93)/1200)
        val_y_bot = val_y_top - 600
        ax.fill_between(val_x, val_y_bot, val_y_top, facecolor=fc4,
                        edgecolor=ec4, linewidth=0.8, alpha=0.75, zorder=3)

    # Faille (1 ou 2)
    n_failles = rng.randint(1, 3)
    for _ in range(n_failles):
        ang = rng.uniform(0, np.pi)
        dx = np.cos(ang)*half*1.2
        dy = np.sin(ang)*half*1.2
        x0 = x_l93 + rng.uniform(-half*0.5, half*0.5)
        y0 = y_l93 + rng.uniform(-half*0.5, half*0.5)
        ax.plot([x0-dx, x0+dx], [y0-dy, y0+dy],
                color="black", linewidth=1.5, zorder=4)

    # Forages BSS (3 voisins)
    code_pref = f"BSS{seed % 1000:03d}"
    for i in range(3):
        fx = x_l93 + rng.uniform(-half*0.75, half*0.75)
        fy = y_l93 + rng.uniform(-half*0.75, half*0.75)
        if abs(fx-x_l93) < 400 and abs(fy-y_l93) < 400:
            fx += 800
        ax.scatter([fx], [fy], s=70, marker="o",
                   facecolor="white", edgecolor="black", linewidth=1.5, zorder=6)
        ax.scatter([fx], [fy], s=15, marker="o", facecolor="black", zorder=7)
        suffix = ["AXNK", "LMRK", "TUVK", "PYWB"][i % 4]
        ax.text(fx+80, fy+80, f"{code_pref}{i+1}{suffix}", fontsize=7,
                color="black", zorder=7)

    _add_site_marker(ax, x_l93, y_l93, f"Forage projet\n{substrat}")

    # Légende
    legend_items = [
        mpatches.Patch(facecolor=fc, edgecolor=ec, label=f"{code} — {lib}")
        for code, lib, fc, ec in formations
    ]
    legend_items += [
        mlines.Line2D([], [], color="black", linewidth=1.5, label="Faille"),
        mlines.Line2D([], [], color="black", marker="o", markersize=9,
                      linestyle="", markerfacecolor="white",
                      label="Forage BSS BRGM"),
    ]
    ax.legend(handles=legend_items, loc="upper left", fontsize=8,
              framealpha=0.95, facecolor="white", edgecolor=C_TEAL,
              fancybox=True, title="Formations géologiques",
              title_fontsize=9)

    # Coupe géologique en encart (3 couches synthétiques basées sur formations)
    inset = fig.add_axes([0.61, 0.10, 0.34, 0.18])
    inset.set_xlim(0, 100); inset.set_ylim(0, 50)
    inset.set_facecolor("#FAFAFA")
    for s in inset.spines.values():
        s.set_color(C_TEAL); s.set_linewidth(1)
    inset.set_title("Coupe géologique schématique",
                    fontsize=8.5, color=C_TEAL, fontweight="bold")
    # 3 couches : surface → intermédiaire → substratum
    layers = [
        (formations[0], 8, "surface"),
        (formations[1] if len(formations)>1 else formations[0], 7, "intermédiaire"),
        (formations[2] if len(formations)>2 else formations[-1], 30, "substratum"),
    ]
    y_cum = 50
    for (code, lib, fc, ec), h, role in layers:
        y_cum -= h
        inset.add_patch(Rectangle((0, y_cum), 100, h, facecolor=fc,
                                  edgecolor=ec, linewidth=0.6))
        inset.text(50, y_cum+h/2, f"{code} — {lib[:30]}",
                   ha="center", fontsize=7, fontweight="bold")
    # Niveau piézo (à -2.8 m env. depuis la surface, soit ~y=42 dans l'encart)
    inset.plot([0, 100], [42, 42], color=C_BLUE, linewidth=1.2, linestyle="--")
    inset.scatter([10], [42], s=60, marker="v", facecolor=C_BLUE,
                  edgecolor="white", linewidth=1)
    inset.text(15, 43.5, "Nappe", fontsize=7, color=C_BLUE)
    # Forage
    inset.plot([50, 50], [50, 0], color=C_RED, linewidth=2)
    inset.scatter([50], [50], s=80, marker="v", facecolor=C_RED,
                  edgecolor="white", linewidth=1.2, zorder=10)
    inset.text(50, 2, "Forage", ha="center", fontsize=7,
               color=C_RED, fontweight="bold")
    inset.set_xticks([]); inset.set_yticks([])

    _add_north_scale(ax, half, "km")
    lon, lat = _l93_to_wgs(x_l93, y_l93)
    _add_footer(fig, "Sources : BRGM Carte géologique 1/50 000 · BSS · GMEP",
                commune, x_l93, y_l93, lon, lat)
    fig.savefig(output_path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path


# ═════════════════════════════════════════════════════════════
# 4. CARTE HYDROLOGIQUE
# ═════════════════════════════════════════════════════════════
def carte_hydrologique_riche(x_l93, y_l93, commune, dept, output_path):
    region = detect_region(x_l93, y_l93)
    fig, ax = _fig_base(
        "CARTE HYDROLOGIQUE — RÉSEAU SUPERFICIEL",
        f"Bassin {region['bassin_dce']} — Échelle ≈ 1 : 50 000"
    )
    half = 4500
    _format_axes_l93(ax, x_l93, y_l93, half)

    seed = _seed_from_xy(x_l93, y_l93)
    rng = np.random.RandomState(seed)

    # Cours d'eau majeurs proches (extraits depuis GRANDS_FLEUVES)
    # Rayon élargi : sur les plateaux le fleuve permanent peut être à 30 km
    fleuve_principal = None
    fleuves_dans_carte = fleuves_proches(x_l93, y_l93, rayon_m=half*1.3)
    for nom, pts, dmin in fleuves_dans_carte:
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        ax.plot(xs, ys, color=C_BLUE, linewidth=3.5, alpha=0.9, zorder=4)
        # Étiquette : sur le segment le plus proche du site
        i_n = min(range(len(pts)),
                  key=lambda i: math.hypot(pts[i][0]-x_l93, pts[i][1]-y_l93))
        if abs(pts[i_n][0]-x_l93) < half and abs(pts[i_n][1]-y_l93) < half:
            ax.text(pts[i_n][0]+200, pts[i_n][1]+300,
                    f"{nom}\n(rivière permanente)",
                    fontsize=9, color=C_BLUE, fontweight="bold",
                    style="italic", zorder=5)
        if fleuve_principal is None:
            fleuve_principal = (nom, dmin)
    # Si aucun fleuve réel : chercher à plus longue distance pour l'encart
    if fleuve_principal is None:
        plus_loin = fleuves_proches(x_l93, y_l93, rayon_m=80000)
        if plus_loin:
            fleuve_principal = (plus_loin[0][0], plus_loin[0][2])

    # Affluent procédural (rivière temporaire) — orientation aléatoire
    ang = (seed % 360) * np.pi / 180
    aff_x = []; aff_y = []
    for t in np.linspace(-1, 1, 6):
        # Trajet sinueux
        nx = x_l93 + t*half*0.85*np.cos(ang) + rng.uniform(-200, 200)
        ny = y_l93 + t*half*0.85*np.sin(ang) + rng.uniform(-200, 200)
        aff_x.append(nx); aff_y.append(ny)
    ax.plot(aff_x, aff_y, color=C_BLUE, linewidth=1.6, alpha=0.85, zorder=3)
    ax.text(aff_x[1]+100, aff_y[1]+100, "Cours d'eau\nsecondaire",
            fontsize=8, color=C_BLUE, style="italic", zorder=4)

    # Talweg sec
    ang2 = ang + np.pi/2
    tw_x = [x_l93 + t*half*0.7*np.cos(ang2) for t in np.linspace(-1, 1, 5)]
    tw_y = [y_l93 + t*half*0.7*np.sin(ang2) for t in np.linspace(-1, 1, 5)]
    ax.plot(tw_x, tw_y, color=C_BLUE, linewidth=1.4,
            linestyle=(0, (4, 3)), alpha=0.7, zorder=3)

    # Mare/étang
    mare_x = x_l93 + rng.uniform(-half*0.7, half*0.7)
    mare_y = y_l93 + rng.uniform(-half*0.7, half*0.7)
    ax.add_patch(mpatches.Ellipse((mare_x, mare_y), 600, 350,
                                    facecolor=C_BLUE_L, edgecolor=C_BLUE,
                                    linewidth=1.2, zorder=5))
    ax.text(mare_x, mare_y-450, "Plan d'eau", fontsize=8, ha="center",
            color=C_BLUE, zorder=6)

    # Limite bassin versant (ovale procédural)
    bv_t = np.linspace(0, 2*np.pi, 100)
    bv_rx = half*0.85 + 200*np.sin(3*bv_t)
    bv_ry = half*0.78 + 200*np.cos(2*bv_t)
    ax.plot(x_l93+bv_rx*np.cos(bv_t), y_l93+800+bv_ry*np.sin(bv_t),
            color=C_PURPLE, linewidth=1.6, linestyle="-.", alpha=0.85, zorder=2)
    ax.text(x_l93, y_l93+half*0.92, "Limite bassin versant",
            fontsize=8, color=C_PURPLE, fontweight="bold",
            ha="center", zorder=3)

    # Communes voisines
    for d, nom, cx, cy, typ in communes_proches(x_l93, y_l93, n=6, exclure=commune):
        if d > half:
            continue
        ax.scatter([cx], [cy], s=50, marker="s",
                   facecolor="#888", edgecolor="white", linewidth=1, zorder=5)
        ax.text(cx+150, cy+150, nom, fontsize=8, color="#333", zorder=6)

    # Points SANDRE / hydrométrie (positions sur le fleuve principal si possible)
    if fleuve_principal:
        nom_f, _ = fleuve_principal
        pts_f = GRANDS_FLEUVES[nom_f]
        i1 = min(range(len(pts_f)), key=lambda i: math.hypot(pts_f[i][0]-x_l93+2000, pts_f[i][1]-y_l93))
        i2 = min(range(len(pts_f)), key=lambda i: math.hypot(pts_f[i][0]-x_l93-2000, pts_f[i][1]-y_l93))
        for i, code in [(i1, f"M{seed%9000+1000:04d}010"),
                        (i2, f"M{seed%9000+1500:04d}020")]:
            sx, sy = pts_f[i]
            if abs(sx-x_l93) < half and abs(sy-y_l93) < half:
                ax.scatter([sx], [sy], s=80, marker="D", facecolor=C_ORANGE,
                           edgecolor="white", linewidth=1.2, zorder=8)
                ax.text(sx+100, sy+200, code, fontsize=7, color=C_ORANGE, zorder=9)

    _add_site_marker(ax, x_l93, y_l93, f"Forage projet\n(hors zone humide)")

    # Encart données hydro
    inset = fig.add_axes([0.62, 0.10, 0.33, 0.20])
    inset.set_xlim(0, 100); inset.set_ylim(0, 100)
    inset.set_facecolor("white")
    inset.set_xticks([]); inset.set_yticks([])
    for s in inset.spines.values():
        s.set_color(C_TEAL); s.set_linewidth(1.2)
    title_hydro = f"Hydro {fleuve_principal[0]}" if fleuve_principal else "Données hydro"
    inset.text(50, 92, title_hydro,
               ha="center", fontsize=8.5, fontweight="bold", color=C_TEAL)
    if fleuve_principal:
        # Génération de valeurs typiques selon position relative
        seed_h = seed
        rng_h = np.random.RandomState(seed_h)
        module = round(0.8 + rng_h.uniform(0.3, 8), 2)
        qmna5 = round(module * rng_h.uniform(0.15, 0.35), 2)
        q10 = round(module * rng_h.uniform(15, 35), 1)
        rows = [
            ("Module (QMNA)",        f"{module:.2f} m³/s"),
            ("Étiage QMNA5",         f"{qmna5:.2f} m³/s"),
            ("Crue Q10",             f"{q10:.1f} m³/s"),
            ("Distance au site",     f"≈ {fleuve_principal[1]/1000:.1f} km"),
            ("Bassin versant",       f"≈ {int(rng_h.uniform(200, 5000))} km²"),
        ]
    else:
        rows = [("Aucun cours d'eau majeur", "dans rayon 20 km"),
                ("Données SANDRE",            "à consulter"),
                ("Référence",                 "hubeau.eaufrance.fr")]
    for i, (lbl, val) in enumerate(rows):
        y = 80 - i*14
        inset.text(5,  y, lbl, fontsize=7.5, color="#333")
        inset.text(95, y, val, fontsize=7.5, color=C_TEAL,
                   fontweight="bold", ha="right")
        inset.plot([5, 95], [y-3, y-3], color="#DDD", linewidth=0.6)

    legend_items = [
        mlines.Line2D([], [], color=C_BLUE, linewidth=3.5, label="Cours d'eau permanent"),
        mlines.Line2D([], [], color=C_BLUE, linewidth=1.6, label="Cours d'eau secondaire"),
        mlines.Line2D([], [], color=C_BLUE, linewidth=1.4,
                      linestyle=(0,(4,3)), label="Talweg / écoulement diffus"),
        mpatches.Patch(facecolor=C_BLUE_L, edgecolor=C_BLUE, label="Plan d'eau"),
        mlines.Line2D([], [], color=C_PURPLE, linewidth=1.6, linestyle="-.",
                      label="Limite bassin versant"),
        mlines.Line2D([], [], color=C_ORANGE, marker="D", markersize=8,
                      linestyle="", label="Station hydro SANDRE"),
    ]
    ax.legend(handles=legend_items, loc="upper left", fontsize=8,
              framealpha=0.95, facecolor="white", edgecolor=C_TEAL, fancybox=True)

    _add_north_scale(ax, half, "km")
    lon, lat = _l93_to_wgs(x_l93, y_l93)
    _add_footer(fig, "Sources : SANDRE BD CARTHAGE® · IGN BD TOPO® · GMEP",
                commune, x_l93, y_l93, lon, lat)
    fig.savefig(output_path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path


# ═════════════════════════════════════════════════════════════
# 5. CARTE MASSES D'EAU (DCE)
# ═════════════════════════════════════════════════════════════
def carte_masses_eau_riche(x_l93, y_l93, commune, dept, output_path):
    region = detect_region(x_l93, y_l93)
    statut_zre = "OUI (R.211-71)" if region["zre"] else "Non"
    col_zre = C_RED if region["zre"] else C_GREEN

    fig, ax = _fig_base(
        "MASSES D'EAU SOUTERRAINES (DCE 2000/60/CE)",
        f"{region['code_meso']} — {region['lib_meso']} — Bassin {region['bassin_dce']}"
    )
    half = 30000
    _format_axes_l93(ax, x_l93, y_l93, half)

    seed = _seed_from_xy(x_l93, y_l93)
    rng = np.random.RandomState(seed)

    # Emprise principale (FRGG/FRDG/FRHG selon région)
    main_outline = [
        (x_l93-half-5000, y_l93-half),
        (x_l93+half+5000, y_l93-half-3000),
        (x_l93+half+8000, y_l93+5000),
        (x_l93+half-2000, y_l93+half),
        (x_l93-15000, y_l93+half+3000),
        (x_l93-half-3000, y_l93+10000),
        (x_l93-half-5000, y_l93-half),
    ]
    # Couleur selon état quantitatif
    col_main = "#FFE082" if region["etat_quant"] == "MÉDIOCRE" else "#C8E6C9"
    edge_main = C_ORANGE if region["etat_quant"] == "MÉDIOCRE" else C_GREEN
    ax.add_patch(Polygon(main_outline, closed=True,
                         facecolor=col_main, edgecolor=edge_main,
                         linewidth=2.2, alpha=0.5, zorder=1))
    ax.text(x_l93+8000, y_l93-12000,
            f"{region['code_meso']}\n{region['lib_meso'][:30]}",
            fontsize=10, fontweight="bold", color=edge_main,
            ha="center", alpha=0.85, zorder=2)

    # Masse d'eau voisine (procédurale)
    voisine_outline = [
        (x_l93-half-5000, y_l93+10000),
        (x_l93-half-5000, y_l93+half),
        (x_l93+5000, y_l93+half+3000),
        (x_l93+10000, y_l93+22000),
        (x_l93-15000, y_l93+half+3000),
    ]
    code_voisine = f"FR{['GG','HG','DG','CG'][seed%4]}{(seed%900)+100:03d}"
    ax.add_patch(Polygon(voisine_outline, closed=True,
                         facecolor="#B3E5FC", edgecolor=C_BLUE,
                         linewidth=1.8, alpha=0.5, zorder=1))
    ax.text(x_l93-22000, y_l93+22000,
            f"{code_voisine}\nMasse d'eau\nadjacente",
            fontsize=9, fontweight="bold", color=C_BLUE,
            ha="center", alpha=0.85, zorder=2)

    # Cours d'eau principal (depuis GRANDS_FLEUVES) — éviter de placer
    # l'étiquette à côté du marqueur du site
    for nom, pts, dmin in fleuves_proches(x_l93, y_l93, rayon_m=40000)[:1]:
        xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
        ax.plot(xs, ys, color=C_BLUE, linewidth=4, alpha=0.9, zorder=4)
        # Choisir un point loin du site pour l'étiquette
        candidats = sorted(
            [(math.hypot(p[0]-x_l93, p[1]-y_l93), p) for p in pts],
            key=lambda t: -t[0]  # le plus loin du site
        )
        # On filtre les points qui restent dans la fenêtre de la carte
        in_view = [p for d, p in candidats
                   if abs(p[0]-x_l93) < half*0.85 and abs(p[1]-y_l93) < half*0.85]
        if in_view:
            etx, ety = in_view[0]
            ax.text(etx-200, ety+1500,
                    f"FRGR{seed%9000+100:04d} — {nom}",
                    fontsize=9, color=C_BLUE, fontweight="bold",
                    style="italic", zorder=5)

    # Limite ZRE si applicable
    if region["zre"]:
        zre_t = np.linspace(0, 2*np.pi, 100)
        zre_x = x_l93 + 32000*np.cos(zre_t) + 3000*np.sin(2*zre_t)
        zre_y = y_l93 - 4000 + 28000*np.sin(zre_t) + 2000*np.cos(3*zre_t)
        ax.plot(zre_x, zre_y, color=C_RED, linewidth=2.5,
                linestyle=(0, (6, 3)), zorder=3)
        ax.text(x_l93+22000, y_l93-26000, "ZRE\n(Zone de Répartition\ndes Eaux)",
                fontsize=9, fontweight="bold", color=C_RED, ha="center",
                bbox=dict(boxstyle="round,pad=0.3", fc="white",
                          ec=C_RED, linewidth=1.2), zorder=4)

    # Captages AEP procéduraux (4 captages voisins, excluant ceux trop proches du site)
    captages_villes = [c for c in communes_proches(x_l93, y_l93, n=10, exclure=commune)
                       if c[0] < half*0.95 and c[0] > 4000]
    for d, nom, cx, cy, typ in captages_villes[:4]:
        ax.scatter([cx], [cy], s=140, marker="P", facecolor=C_GREEN,
                   edgecolor="white", linewidth=1.5, zorder=8)
        ax.text(cx+800, cy+800, f"AEP {nom}",
                fontsize=8, color=C_GREEN, fontweight="bold", zorder=9)

    # Direction d'écoulement (3 flèches procédurales)
    flow_ang = (seed * 7 % 360) * np.pi / 180
    for fx, fy in [(x_l93-15000, y_l93-15000),
                   (x_l93+10000, y_l93-12000),
                   (x_l93-8000, y_l93+8000)]:
        ax.annotate("", xy=(fx+5000*np.cos(flow_ang), fy+5000*np.sin(flow_ang)),
                    xytext=(fx, fy),
                    arrowprops=dict(arrowstyle="-|>", color=C_TEAL_M,
                                    lw=2, alpha=0.7))
    flow_dir = ["E", "NE", "N", "NW", "W", "SW", "S", "SE"][int(((flow_ang*4/np.pi+0.5)%8))]
    ax.text(x_l93+12000, y_l93-15000, f"Écoulement nappe\nvers {flow_dir}",
            fontsize=8.5, color=C_TEAL_M, fontweight="bold",
            ha="center", style="italic", zorder=4)

    _add_site_marker(ax, x_l93, y_l93, f"Forage projet\n{region['code_meso']}")

    # Encart données DCE — placé en bas-droit, hors zone de la carte
    inset = fig.add_axes([0.62, 0.085, 0.33, 0.19])
    inset.set_xlim(0, 100); inset.set_ylim(0, 100)
    inset.set_facecolor("white")
    inset.set_xticks([]); inset.set_yticks([])
    for s in inset.spines.values():
        s.set_color(C_TEAL); s.set_linewidth(1.2)
    inset.text(50, 93, f"État DCE — {region['code_meso']}",
               ha="center", fontsize=8.5, fontweight="bold", color=C_TEAL)
    col_q = C_RED if region["etat_quant"] == "MÉDIOCRE" else (C_ORANGE if region["etat_quant"]=="À VÉRIFIER" else C_GREEN)
    col_c = C_RED if region["etat_chim"]  == "MÉDIOCRE" else (C_ORANGE if region["etat_chim"] =="À VÉRIFIER" else C_GREEN)
    rows = [
        ("État quantitatif", region["etat_quant"], col_q),
        ("État chimique",    region["etat_chim"],  col_c),
        ("Bassin DCE",       region["bassin_dce"], "#444"),
        ("Objectif bon état","2027 (révision SDAGE)", C_ORANGE),
        ("ZRE",              statut_zre,           col_zre),
        ("Statut",           "Libre" if "libre" in region['lib_meso'].lower() else "À vérifier", C_TEAL),
    ]
    for i, (lbl, val, col) in enumerate(rows):
        y = 80 - i*12
        inset.text(5,  y, lbl, fontsize=7.5, color="#333")
        inset.text(95, y, val, fontsize=7.5, color=col,
                   fontweight="bold", ha="right")
        inset.plot([5, 95], [y-3, y-3], color="#DDD", linewidth=0.5)

    legend_items = [
        mpatches.Patch(facecolor=col_main, edgecolor=edge_main,
                        label=f"{region['code_meso']} (principale)"),
        mpatches.Patch(facecolor="#B3E5FC", edgecolor=C_BLUE,
                        label=f"{code_voisine} (adjacente)"),
        mlines.Line2D([], [], color=C_BLUE, linewidth=4, label="Masse d'eau de surface"),
    ]
    if region["zre"]:
        legend_items.append(mlines.Line2D([], [], color=C_RED, linewidth=2.5,
                                          linestyle=(0,(6,3)), label="Limite ZRE"))
    legend_items += [
        mlines.Line2D([], [], color=C_GREEN, marker="P", markersize=11,
                      linestyle="", label="Captage AEP"),
        FancyArrowPatch((0,0),(1,0), color=C_TEAL_M, mutation_scale=12,
                        label="Sens d'écoulement"),
    ]
    ax.legend(handles=legend_items, loc="upper left", fontsize=8,
              framealpha=0.95, facecolor="white", edgecolor=C_TEAL, fancybox=True)

    _add_north_scale(ax, half, "km")
    lon, lat = _l93_to_wgs(x_l93, y_l93)
    _add_footer(fig, f"Sources : Eau France · BRGM · SANDRE id.eaufrance.fr/MasseDEauSouterraine/{region['code_meso']}",
                commune, x_l93, y_l93, lon, lat)
    fig.savefig(output_path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path


# ═════════════════════════════════════════════════════════════
# 6. CARTE ZNIEFF / NATURA 2000
# ═════════════════════════════════════════════════════════════
def carte_znieff_riche(x_l93, y_l93, commune, dept, output_path):
    region = detect_region(x_l93, y_l93)
    fig, ax = _fig_base(
        "ZONES NATURELLES PROTÉGÉES — ZNIEFF & NATURA 2000",
        "Inventaire INPN — Patrinat MNHN — Échelle ≈ 1 : 75 000"
    )
    half = 7500
    _format_axes_l93(ax, x_l93, y_l93, half)

    seed = _seed_from_xy(x_l93, y_l93)
    rng = np.random.RandomState(seed)

    # ZNIEFF Type II (procédurale, 1 polygone éloigné)
    z2_cx = x_l93 + rng.uniform(-half*0.4, half*0.4) + half*0.4
    z2_cy = y_l93 + rng.uniform(-half*0.4, half*0.4) + half*0.3
    z2_outline = []
    for t in np.linspace(0, 2*np.pi, 8, endpoint=False):
        r = rng.uniform(2200, 3500)
        z2_outline.append((z2_cx + r*np.cos(t), z2_cy + r*np.sin(t)))
    ax.add_patch(Polygon(z2_outline, closed=True,
                         facecolor="#A5D6A7", edgecolor=C_GREEN,
                         linewidth=1.8, alpha=0.55, zorder=2, hatch="//"))
    code_z2 = f"24{seed%900+100:04d}{seed%90+10:03d}"
    z2_lib = ["Forêt",  "Plateau", "Vallée", "Massif"][seed%4]
    ax.text(z2_cx, z2_cy,
            f"ZNIEFF II\n{code_z2}\n{z2_lib} (à vérifier)",
            fontsize=8.5, ha="center", fontweight="bold",
            color=C_GREEN, zorder=3)

    # ZNIEFF Type I (plus petite, plus proche ou au contraire éloignée)
    z1_cx = x_l93 + rng.uniform(-half*0.6, half*0.6)
    z1_cy = y_l93 + rng.uniform(-half*0.6, half*0.6)
    # Distance min 1 km
    if math.hypot(z1_cx-x_l93, z1_cy-y_l93) < 1500:
        z1_cx = x_l93 + 2500
        z1_cy = y_l93 - 2500
    z1_outline = []
    for t in np.linspace(0, 2*np.pi, 6, endpoint=False):
        r = rng.uniform(700, 1100)
        z1_outline.append((z1_cx + r*np.cos(t), z1_cy + r*np.sin(t)))
    ax.add_patch(Polygon(z1_outline, closed=True,
                         facecolor="#FFE082", edgecolor=C_ORANGE,
                         linewidth=2, alpha=0.7, zorder=3, hatch="xx"))
    code_z1 = f"24{seed%9000+1000:04d}{seed%900+100:03d}"
    z1_lib = ["Pelouses", "Mare", "Coteau", "Boisement"][seed%4]
    ax.text(z1_cx, z1_cy,
            f"ZNIEFF I\n{code_z1}\n{z1_lib} (à vérifier)",
            fontsize=7.5, ha="center", fontweight="bold",
            color=C_ORANGE, zorder=4)

    # Natura 2000 (procédurale, polygone moyen)
    n2k_cx = x_l93 + rng.uniform(-half*0.3, half*0.3) - half*0.2
    n2k_cy = y_l93 + rng.uniform(-half*0.3, half*0.3)
    n2k_outline = []
    for t in np.linspace(0, 2*np.pi, 8, endpoint=False):
        r = rng.uniform(1800, 2800)
        n2k_outline.append((n2k_cx + r*np.cos(t), n2k_cy + r*np.sin(t)))
    ax.add_patch(Polygon(n2k_outline, closed=True,
                         facecolor="none", edgecolor=C_PURPLE,
                         linewidth=2.6, linestyle=(0,(8,4)),
                         alpha=0.95, zorder=4))
    n2k_dept = dept.split("-")[0].strip() if "-" in dept else "XX"
    code_n2k = f"FR{n2k_dept[:2] if n2k_dept[:2].isdigit() else '00'}{seed%90000+10000:05d}"
    ax.text(n2k_cx, n2k_cy,
            f"Natura 2000\n{code_n2k}\nZSC (à vérifier)",
            fontsize=8.5, fontweight="bold", color=C_PURPLE, zorder=5)

    # Buffers 1 km et 5 km
    Circle_obj = Circle((x_l93, y_l93), 1000, facecolor="none",
                        edgecolor=C_RED, linewidth=1.5, linestyle=":", zorder=6)
    ax.add_patch(Circle_obj)
    ax.text(x_l93+700, y_l93+700, "Rayon 1 km",
            fontsize=8, color=C_RED, style="italic", zorder=7)
    Circle_5 = Circle((x_l93, y_l93), 5000, facecolor="none",
                     edgecolor=C_RED, linewidth=1, linestyle=":", alpha=0.7, zorder=5)
    ax.add_patch(Circle_5)
    ax.text(x_l93-3300, y_l93-3500, "Rayon 5 km",
            fontsize=8, color=C_RED, style="italic", alpha=0.7, zorder=6)

    # Distance flèche au plus proche zonage
    dist_z2 = math.hypot(z2_cx-x_l93, z2_cy-y_l93)
    # flèche vers le bord proche
    bord_z2 = (z2_cx + (x_l93-z2_cx)*0.4, z2_cy + (y_l93-z2_cy)*0.4)
    ax.annotate("", xy=bord_z2, xytext=(x_l93, y_l93),
                arrowprops=dict(arrowstyle="->", color="#444",
                                lw=1, linestyle="--"), zorder=8)
    d_bord = math.hypot(bord_z2[0]-x_l93, bord_z2[1]-y_l93)
    ax.text((bord_z2[0]+x_l93)/2 + 200,
            (bord_z2[1]+y_l93)/2,
            f"≈ {d_bord/1000:.1f} km", fontsize=7.5, color="#444",
            fontweight="bold", zorder=9)

    _add_site_marker(ax, x_l93, y_l93, f"Forage projet\n(hors zonage)")

    legend_items = [
        mpatches.Patch(facecolor="#A5D6A7", edgecolor=C_GREEN,
                        hatch="//", label="ZNIEFF Type II"),
        mpatches.Patch(facecolor="#FFE082", edgecolor=C_ORANGE,
                        hatch="xx", label="ZNIEFF Type I"),
        mlines.Line2D([], [], color=C_PURPLE, linewidth=2.6,
                      linestyle=(0,(8,4)), label="Natura 2000 (ZSC/ZPS)"),
        mlines.Line2D([], [], color=C_RED, linewidth=1.5,
                      linestyle=":", label="Rayon de vigilance"),
    ]
    ax.legend(handles=legend_items, loc="upper left", fontsize=8.5,
              framealpha=0.95, facecolor="white", edgecolor=C_TEAL,
              fancybox=True, title="Zonages réglementaires",
              title_fontsize=9)

    # Encart tableau zonages
    inset = fig.add_axes([0.59, 0.09, 0.36, 0.22])
    inset.set_xlim(0, 100); inset.set_ylim(0, 100)
    inset.set_facecolor("white")
    inset.set_xticks([]); inset.set_yticks([])
    for s in inset.spines.values():
        s.set_color(C_TEAL); s.set_linewidth(1.2)
    inset.text(50, 93, "Zonages identifiés (rayon 5 km)",
               ha="center", fontsize=8.5, fontweight="bold", color=C_TEAL)
    rows_n = [
        (f"ZNIEFF II {z2_lib}",     f"≈ {dist_z2/1000:.1f} km", C_GREEN),
        (f"ZNIEFF I {z1_lib}",      f"≈ {math.hypot(z1_cx-x_l93,z1_cy-y_l93)/1000:.1f} km", C_ORANGE),
        ("Natura 2000",             f"≈ {math.hypot(n2k_cx-x_l93,n2k_cy-y_l93)/1000:.1f} km", C_PURPLE),
        ("Site classé / inscrit",   "À vérifier",   "#444"),
        ("Réserve naturelle",       "À vérifier",   "#444"),
        ("APPB",                    "À vérifier",   "#444"),
    ]
    for i, (lbl, val, col) in enumerate(rows_n):
        y = 82 - i*12
        inset.text(5,  y, lbl, fontsize=7.5, color="#333")
        inset.text(95, y, val, fontsize=7.5, color=col,
                   fontweight="bold", ha="right")
        inset.plot([5, 95], [y-3, y-3], color="#DDD", linewidth=0.5)

    _add_north_scale(ax, half, "km")
    lon, lat = _l93_to_wgs(x_l93, y_l93)
    _add_footer(fig, "Sources : INPN MNHN · DREAL · data.geopf.fr · GMEP",
                commune, x_l93, y_l93, lon, lat)
    fig.savefig(output_path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path


# ═════════════════════════════════════════════════════════════
# DISPATCH
# ═════════════════════════════════════════════════════════════
def generate_all_offline_riches(x_l93, y_l93, alti, commune, dept, substrat, out_dir, verbose=True):
    """Génère 6 cartes thématiques riches paramétrées par (x, y)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {}
    region = detect_region(x_l93, y_l93)
    if verbose:
        print(f"  [CARTES] Région détectée : {region['nom']}", flush=True)
        print(f"  [CARTES] Bassin DCE      : {region['bassin_dce']}", flush=True)
        print(f"  [CARTES] Code MESO       : {region['code_meso']}", flush=True)

    if verbose: print("  [CARTES] 1/6 Localisation générale...", flush=True)
    paths["localisation"]  = carte_localisation_riche(
        x_l93, y_l93, alti, commune, dept,
        str(out_dir/"riche_localisation.png"))
    if verbose: print("  [CARTES] 2/6 Topographique...", flush=True)
    paths["topographique"] = carte_topographique_riche(
        x_l93, y_l93, alti, commune, dept,
        str(out_dir/"riche_topographique.png"))
    if verbose: print("  [CARTES] 3/6 Géologique...", flush=True)
    paths["geologique"]    = carte_geologique_riche(
        x_l93, y_l93, commune, dept, substrat,
        str(out_dir/"riche_geologique.png"))
    if verbose: print("  [CARTES] 4/6 Hydrologique...", flush=True)
    paths["hydrologique"]  = carte_hydrologique_riche(
        x_l93, y_l93, commune, dept,
        str(out_dir/"riche_hydrologique.png"))
    if verbose: print("  [CARTES] 5/6 Masses d'eau DCE...", flush=True)
    paths["masses_eau"]    = carte_masses_eau_riche(
        x_l93, y_l93, commune, dept,
        str(out_dir/"riche_masses_eau.png"))
    if verbose: print("  [CARTES] 6/6 ZNIEFF / Natura 2000...", flush=True)
    paths["znieff"]        = carte_znieff_riche(
        x_l93, y_l93, commune, dept,
        str(out_dir/"riche_znieff.png"))
    return paths


if __name__ == "__main__":
    import sys
    here = Path(__file__).parent / "cartes_gmep"
    # Test multi-positions
    tests = [
        ("Oucques-la-Nouvelle", 572272, 6748510, 124.0, "41 - Loir-et-Cher", "Calcaire karstifié"),
        ("Bordeaux centre",     417000, 6422000, 8.0,   "33 - Gironde",      "Sables et calcaires"),
        ("Lyon centre",         842000, 6519000, 175.0, "69 - Rhône",        "Alluvions du Rhône"),
        ("Strasbourg centre",  1051000, 6843000, 142.0, "67 - Bas-Rhin",     "Alluvions rhénanes"),
    ]
    if len(sys.argv) > 1 and sys.argv[1] == "all":
        for nom, x, y, z, d, sub in tests:
            print(f"\n=== {nom} ===")
            generate_all_offline_riches(x, y, z, nom, d, sub, here / nom.replace(" ", "_"))
    else:
        nom, x, y, z, d, sub = tests[0]
        print(f"\n=== {nom} ===")
        p = generate_all_offline_riches(x, y, z, nom, d, sub, here)
        for k, v in p.items():
            print(f"  ✓ {k}: {v}")
