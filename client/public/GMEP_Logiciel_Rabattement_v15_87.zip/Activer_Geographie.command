#!/bin/bash
# GMEP - Activation Geographie (macOS)
cd "$(dirname "$0")"

echo ""
echo "======================================================================"
echo "  GMEP — Mise à jour automatique de la géographie"
echo "======================================================================"
echo ""

# === Recherche Python 3 ===
PYTHON=""
for cmd in python3 python; do
    if command -v "$cmd" >/dev/null 2>&1; then
        PYTHON="$cmd"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo "Python 3 n'est pas installé sur ce poste."
    echo ""
    echo "Lancez d'abord INSTALLER.command pour installer Python automatiquement,"
    echo "ou téléchargez Python depuis https://www.python.org/downloads/"
    echo ""
    read -p "Appuyez sur Entrée pour fermer..."
    exit 1
fi

# === Lancement script ===
"$PYTHON" "$(dirname "$0")/activer_geographie.py"
RC=$?

if [ $RC -ne 0 ]; then
    echo ""
    echo "ERREUR : le script s'est terminé avec le code $RC."
    read -p "Appuyez sur Entrée pour fermer..."
    exit $RC
fi

exit 0
