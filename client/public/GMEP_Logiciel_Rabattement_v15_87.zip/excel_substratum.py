"""
Ajoute deux feuilles à Modelisation_Rabattement_TSN_GMEP.xlsx :
- "Référentiel Aquifères" : catalogue national géolocalisé (emprises Lambert 93)
- "Choix du Substratum" : outil d'aide à la décision PILOTÉ PAR GÉOLOCALISATION

=========================================================================
 v15.87 — CORRECTION MAJEURE DU MOTEUR DE CHOIX DU SUBSTRATUM
=========================================================================
L'identification de l'aquifère de référence est désormais STRICTEMENT
géolocalisée par les coordonnées Lambert 93 (X, Y) du point projet :

  1. Chaque aquifère porte son EMPRISE Lambert 93 (Xmin/Xmax/Ymin/Ymax)
     -> colonnes AA, AB, AC, AD de la feuille "Référentiel Aquifères".
  2. Une colonne de PRÉSENCE (AE) vaut 1 si le point (X,Y) tombe dans
     l'emprise de l'aquifère, 0 sinon.
  3. Le SCORE de compatibilité (col Y, barème /7) n'est calculé QUE pour
     les aquifères présents (AE=1) ; un aquifère absent obtient 0.
  4. REPLI AUTOMATIQUE : si AUCUN aquifère ne contient le point (cas des
     nappes d'écoulement de bassin versant en limite d'emprise), on
     rattache le point à l'aquifère de référence dont le CENTROÏDE
     d'emprise est le plus proche (distance² col AF, rang proximité AG,
     rang final AH). Il y a donc TOUJOURS un aquifère de référence — plus
     jamais d'aquifère arbitraire (ex. "Picardie") hors contexte.
  5. La feuille "Choix du Substratum" lit X/Y depuis "Données d'Entrée"
     (C33/C34) et expose le statut de rattachement (C18-C21).

Vérification BSS BRGM : les emprises sont des boîtes englobantes ; le
statut C21 invite à confirmer par les points de référence BSS du BRGM
en cas de rattachement par proximité.

Lit aquiferes_france.csv s'il existe, sinon le référentiel embarqué
ci-dessous (déjà géolocalisé).
"""
import os
import csv
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.formatting.rule import ColorScaleRule, FormulaRule
from openpyxl.worksheet.table import Table, TableStyleInfo

# Palette cohérente avec le reste du dossier
TEAL_DARK   = "01696F"
TEAL_LIGHT  = "B2DBDF"
BG_INPUT    = "FFF8E7"
BG_CALC     = "F0F7F8"
BG_RESULT   = "E8F4E8"
BG_HEADER   = "01696F"
FG_HEADER   = "FFFFFF"
ROW_ALT     = "F7FAFA"
BORDER_COL  = "01696F"
WARN_FILL   = "FCE4EC"
GOOD_FILL   = "E8F4E8"

# ---------------------------------------------------------------------
# RÉFÉRENTIEL EMBARQUÉ GÉOLOCALISÉ (v15.87)
# 23 aquifères majeurs métropolitains, chacun avec son emprise Lambert 93
# et son substrat-type associé (clé Base Géologique).
# ---------------------------------------------------------------------
FALLBACK_AQUIFERES = [
    # 28 champs par aquifère :
    # [0] nom, [1] code_bdlisa, [2] bassin, [3] lithologie, [4] ecoulement, [5] etat,
    # [6] prof_toit_min, [7] prof_toit_max, [8] epaisseur_min, [9] epaisseur_max,
    # [10] T_min, [11] T_max, [12] K_min, [13] K_max,
    # [14] debit_spe_min, [15] debit_spe_max, [16] debit_forage_min, [17] debit_forage_max,
    # [18] vulnerabilite, [19] qualite_naturelle, [20] regions, [21] usages, [22] source_url,
    # [23] Xmin_L93, [24] Xmax_L93, [25] Ymin_L93, [26] Ymax_L93,   <-- emprise Lambert 93
    # [27] substrat_type_associe (clé Base Géologique)
    ['Calcaires de Beauce libre (Oligo-Miocène)', '117', 'Bassin parisien sédimentaire', "Calcaires lacustres fissurés et karstifiés (Calcaires de Pithiviers et d'Étampes)", 'karstique', 'libre', 5, 30, 50, 200, 0.001, 0.1, 1e-05, 0.001, 1, 10, 100, 300, 'Forte', 'Bicarbonatée calcique – pH > 7 – nitrates élevés (>50 mg/l)', 'Eure-et-Loir / Loiret / Loir-et-Cher / Essonne / Yvelines', 'AEP / Irrigation', 'https://www.siges.fr/fr/mon-territoire/centre-val-de-loire/principaux-aquiferes', 570000, 720000, 6720000, 6850000, 'Calcaire de Beauce'],
    ['Calcaires de Beauce captif (sous Sologne)', '117', 'Bassin parisien sédimentaire', 'Calcaires lacustres surmontés de sables et argiles de Sologne (Miocène)', 'karstique', 'captif', 20, 80, 30, 120, 0.0001, 0.01, 1e-06, 0.0001, 0.5, 3, 20, 80, 'Faible', 'Bicarbonatée calcique – nitrates faibles en zone captive', "Loiret (Forêt d'Orléans) / Loir-et-Cher (Sologne)", 'AEP', 'https://infoterre.brgm.fr/rapports/RR-41162-FR.pdf', 590000, 700000, 6720000, 6810000, 'Calcaire de Beauce'],
    ['Craie séno-turonienne libre (Picardie/Champagne)', '121', 'Bassin parisien sédimentaire', 'Craie blanche fissurée à double porosité (Sénonien-Turonien)', 'fissuré', 'libre', 0, 30, 50, 350, 0.0001, 0.01, 1e-05, 0.001, 0.5, 5, 20, 150, 'Forte', 'Bicarbonatée calcique – pH > 7.5 – nitrates élevés (>50 mg/l)', 'Picardie / Champagne-Ardenne / Haute-Normandie / Île-de-France Nord', 'AEP / Irrigation', 'https://www.siges.fr/fr/mon-territoire/seine-normandie/aquifere-de-craie-champenoise', 560000, 880000, 6850000, 7050000, 'Craie'],
    ['Craie captive sous Beauce', '121', 'Bassin parisien sédimentaire', 'Craie blanche à double porosité sous couverture tertiaire imperméable', 'fissuré', 'captif', 30, 150, 50, 200, 1e-05, 0.0001, 1e-06, 1e-05, 0.1, 1, 5, 30, 'Faible', 'Bicarbonatée calcique – bonne qualité naturelle – nitrates nuls', 'Loiret / Eure-et-Loir (sous Beauce)', 'AEP (réserve stratégique)', 'https://infoterre.brgm.fr/rapports/RP-63055-FR.pdf', 590000, 720000, 6770000, 6870000, 'Craie'],
    ['Sables albo-cénomaniens (Albien-Néocomien profond)', '217', 'Bassin parisien sédimentaire', "Sables fins quartzeux de l'Albien et grès du Néocomien (Crétacé inférieur)", 'poreux', 'captif', 450, 950, 20, 100, 5e-06, 5e-05, 5e-08, 5e-07, 0.5, 2, 50, 250, 'Faible', 'Bicarbonatée sodique – fer/manganèse – faible minéralisation – T° 18-36°C', 'Bassin parisien (Île-de-France / Centre / Normandie)', 'AEP (urgence) / Géothermie basse température', 'https://infoterre.brgm.fr/rapports/RP-55990-FR.pdf', 530000, 800000, 6770000, 6970000, 'Sables du Sparnacien'],
    ["Lutétien – Calcaire grossier d'Île-de-France", '114', 'Bassin parisien sédimentaire', 'Calcaires bioclastiques et marneux du Lutétien (Éocène moyen)', 'fissuré', 'captif', 20, 80, 15, 70, 0.0005, 0.005, 1e-05, 0.0001, 1, 5, 30, 100, 'Moyenne', 'Bicarbonatée calcique – pH 7-7.5 – dureté modérée', 'Île-de-France (Yvelines / Essonne / Seine-et-Marne / Val-de-Marne)', 'AEP / Industriel', 'https://pastel.hal.science/pastel-00973861v1/file/2013ENMP0071diffusion.pdf', 620000, 720000, 6830000, 6900000, 'Calcaire grossier du Lutétien'],
    ['Yprésien – Sables et Calcaires inférieurs (Éocène inf.)', '113', 'Bassin parisien sédimentaire', 'Sables cuisiens et calcaires inférieurs du Cuisien (Éocène inférieur)', 'poreux', 'mixte', 40, 120, 10, 50, 0.0001, 0.001, 1e-06, 1e-05, 0.5, 3, 10, 80, 'Faible', 'Bicarbonatée calcique – légèrement ferrugineux', 'Île-de-France / Oise / Aisne', 'AEP / Industriel', 'https://pastel.hal.science/pastel-00973861v1/file/2013ENMP0071diffusion.pdf', 620000, 760000, 6870000, 6960000, 'Sables de Fontainebleau'],
    ['Dogger du Bassin parisien (Jurassique moyen)', '207', 'Bassin parisien sédimentaire', 'Calcaires oolithiques et dolomies du Bajocien-Bathonien (Jurassique moyen)', 'poreux', 'captif', 1000, 2000, 100, 300, 3e-05, 0.0003, 1e-07, 1e-06, 1, 5, 150, 300, 'Faible', 'Chlorurée sodique – bicarbonatée-calcique en bordure – T° 55-85°C – salin en centre bassin', 'Île-de-France / Centre / Champagne / Picardie', 'Géothermie haute énergie', 'https://www.brgm.fr/fr/reference-projet-acheve/base-donnees-geothermie-dogger-francilien', 590000, 820000, 6800000, 7000000, 'Calcaire compact fissuré'],
    ['Grès triasique de Lorraine (Trias inférieur)', '210', 'Bassin parisien sédimentaire', 'Grès vosgiens quartzeux du Buntsandstein (Trias inférieur)', 'poreux', 'mixte', 0, 500, 10, 162, 1e-05, 5e-05, 1e-07, 5e-06, 0.5, 4, 30, 150, 'Moyenne', 'Bicarbonatée sodique-calcique – fer – localement chlorurée sodique en profondeur', 'Lorraine (Moselle / Meurthe-et-Moselle / Meuse / Vosges)', 'AEP / Industriel', 'https://www.gesteau.fr/sites/default/files/synthese_hydrogeol.pdf', 870000, 1010000, 6800000, 6970000, 'Grès fin consolidé'],
    ['Calcaires jurassiques Charentes-Périgord (Dogger-Malm)', '118', 'Bassin aquitain', 'Calcaires karstiques et fissurés du Dogger et du Malm (Jurassique moyen à supérieur)', 'karstique', 'mixte', 0, 400, 100, 600, 0.0001, 0.01, 1e-06, 0.0001, 1, 10, 20, 200, 'Forte', 'Bicarbonatée calcique – dureté élevée (25-30°F) – minéralisation 500-1000 µS/cm', 'Charente / Charente-Maritime / Dordogne / Vienne', 'AEP / Irrigation / Industriel', 'https://infoterre.brgm.fr/rapports/79-SGN-546-POC.pdf', 440000, 580000, 6470000, 6610000, 'Calcaire compact fissuré'],
    ['Sables infra-molassiques Éocène (Aquitaine profond)', '334', 'Bassin aquitain', "Sables quartzeux fins à moyens de l'Éocène inférieur (Lutetien-Cuisien)", 'poreux', 'captif', 50, 500, 20, 150, 5e-05, 0.0003, 5e-07, 2e-06, 1, 5, 50, 200, 'Faible', 'Bicarbonatée sodique – peu minéralisée – fer – T° 20-35°C en profondeur', 'Gironde / Landes / Lot-et-Garonne / Gers / Tarn-et-Garonne', 'AEP / Industriel', 'https://infoterre.brgm.fr/rapports/RP-52602-FR.pdf', 380000, 580000, 6240000, 6480000, 'Molasse miocène'],
    ['Crétacé supérieur Charentes (Turonien-Coniacien-Santonien)', '325', 'Bassin aquitain', 'Calcaires crayeux et gréseux du Turonien-Coniacien-Santonien (Crétacé sup.)', 'karstique', 'mixte', 0, 300, 50, 200, 0.0001, 0.01, 1e-06, 0.0001, 1, 8, 30, 200, 'Forte', 'Bicarbonatée calcique – nitrates élevés en zone libre', 'Charente / Charente-Maritime / Dordogne / Gironde', 'AEP / Irrigation', 'https://www.dordogne.fr/fileadmin/telechargements/DGA-TD/DEDD/SGE/Synthese_hydrogeologique_du_departement_de_la_Dordogne_-_2003.pdf', 380000, 540000, 6450000, 6580000, 'Craie'],
    ['Oligo-Miocène molassique (Gironde-Landes)', '332', 'Bassin aquitain', 'Calcaires à Astéries (Oligocène) et sables molassiques aquitaniens-burdigaliens', 'mixte', 'captif', 5, 200, 20, 100, 1e-05, 0.0005, 1e-07, 5e-06, 0.5, 3, 20, 100, 'Faible', 'Bicarbonatée calcique-sodique – peu minéralisée – nitrates faibles', 'Gironde / Landes / Pyrénées-Atlantiques', 'AEP / Industriel', 'https://infoterre.brgm.fr/rapports/RP-52602-FR.pdf', 300000, 500000, 6280000, 6470000, 'Molasse miocène'],
    ['Alluvions du Rhône', '152', 'Vallée alluviale', 'Graviers et galets calcaires rhodaniens à intercalations sableuses (Quaternaire)', 'poreux', 'libre', 1, 20, 5, 60, 0.005, 0.3, 0.0005, 0.01, 5, 30, 50, 1000, 'Forte', 'Bicarbonatée calcique – fer/manganèse localement – dureté 16-36°F', 'Ain / Isère / Ardèche / Drôme / Vaucluse / Gard / Bouches-du-Rhône', 'AEP / Industriel / Irrigation', 'https://www.eaurmc.fr/upload/docs/application/pdf/2017-05/2010-etude-nappe-rhone-vol-1.pdf', 790000, 920000, 6240000, 6560000, 'Alluvions grossières'],
    ['Alluvions de la Loire', '037', 'Vallée alluviale', 'Sables et graviers calcaires et siliceux à lentilles argileuses (Quaternaire)', 'poreux', 'libre', 1, 10, 3, 20, 0.001, 0.02, 0.0001, 0.002, 1, 10, 30, 240, 'Forte', 'Bicarbonatée calcique – pH 7-7.5 – pollutions agricoles', 'Indre-et-Loire / Maine-et-Loire / Loire-Atlantique / Loiret', 'AEP / Irrigation', 'http://infoterre.brgm.fr/rapports/77-SGN-465-BDP.pdf', 380000, 700000, 6620000, 6770000, 'Gravier sableux'],
    ['Alluvions de la Seine', '035', 'Vallée alluviale', 'Alluvions sablo-graveleuses calcaires (Quaternaire) à couverture limoneuse', 'poreux', 'libre', 1, 15, 3, 25, 0.0005, 0.01, 5e-05, 0.001, 0.5, 5, 20, 200, 'Forte', 'Bicarbonatée calcique – contaminée (nitrates/phytosanitaires) localement', 'Île-de-France / Haute-Normandie / Oise / Aisne', 'AEP / Industriel', 'https://infoterre.brgm.fr/rapports/RP-50445-FR.pdf', 560000, 720000, 6850000, 6970000, 'Alluvions grossières'],
    ['Alluvions de la Garonne', '307', 'Vallée alluviale', 'Graviers et galets pyrénéens à matrice sablo-argileuse (Quaternaire)', 'poreux', 'libre', 1, 15, 5, 25, 0.0005, 0.01, 5e-05, 0.0005, 1, 8, 30, 200, 'Forte', 'Bicarbonatée calcique – nitrates et pesticides élevés en zones viticoles', 'Haute-Garonne / Tarn-et-Garonne / Lot-et-Garonne / Gironde', 'AEP / Irrigation / Industriel', 'http://infoterre.brgm.fr/rapports/RP-58063-FR.pdf', 470000, 640000, 6260000, 6470000, 'Gravier sableux'],
    ["Alluvions du Rhin – Nappe d'Alsace", '091', 'Vallée alluviale', "Alluvions rhénanes grossières (galets-graviers-sables) d'origine alpine (Quaternaire)", 'poreux', 'libre', 1, 10, 30, 200, 0.01, 0.7, 0.002, 0.1, 10, 50, 200, 1220, 'Forte', 'Bicarbonatée calcique – pollutions industrielles et agricoles historiques', 'Bas-Rhin / Haut-Rhin', 'AEP / Industriel / Irrigation', 'https://www.siges.fr/fr/mon-territoire/rhin-meuse/nappe-dalsace-zones-de-bordure', 990000, 1060000, 6750000, 6900000, 'Gravier propre'],
    ['Granitoïdes fissurés du Massif central (socle)', '601', 'Socle', 'Granites et gneiss fissurés et altérités superficielles (Précambrien-Paléozoïque)', 'fissuré', 'libre', 0, 50, 1, 30, 1e-06, 0.0001, 1e-08, 1e-06, 0.1, 0.5, 1, 20, 'Moyenne', 'Bicarbonatée sodico-calcique – fer/manganèse – arsenic localement – pH acide', 'Massif central (Puy-de-Dôme / Cantal / Creuse / Corrèze / Lozère / Haute-Loire)', 'AEP (rural)', 'http://infoterre.brgm.fr/rapports/RP-58808-FR.pdf', 560000, 770000, 6390000, 6580000, 'Granite fissuré'],
    ['Schistes et granites du Massif armoricain', '801', 'Socle', 'Schistes briovériens et granites hercyniens fissurés à altérites superficielles', 'fissuré', 'libre', 0, 50, 1, 30, 1e-06, 0.001, 1e-08, 1e-06, 0.1, 1, 1, 50, 'Moyenne', 'Bicarbonatée sodico-calcique – fer/manganèse – arsenic – pH acide à neutre', "Bretagne (Finistère / Côtes-d'Armor / Morbihan / Ille-et-Vilaine) / Normandie", 'AEP (rural)', 'https://www.cfh-aih.fr/images/DOCS/2-Colloques/Colloque_2015_socle_la_roche_sur_yon/Actes/R_etendus/ZPoster_P1-07_Aquifere_Socle_Basse-Normandie_2015_Fr_LAURENT_FRESLON_GRESSELINv2_04062015.pdf', 130000, 460000, 6700000, 6850000, 'Altérite de schiste'],
    ['Basaltes du Massif central – Auvergne-Cantal (volcanique)', '606', 'Volcanique', 'Coulées basaltiques fissurées et scoriacées intercalées de tufs et lahars (Néogène-Quaternaire)', 'fissuré', 'libre', 0, 50, 5, 200, 1e-05, 0.001, 1e-07, 1e-05, 0.2, 2, 5, 50, 'Moyenne', 'Bicarbonatée calcique à sodique – faible minéralisation – qualité bactériologique variable', 'Auvergne (Puy-de-Dôme / Cantal / Haute-Loire)', 'AEP (rural)', 'https://www.rhone-mediterranee.eaufrance.fr/sites/sierm/files/content/waterbody_hydrogeological_documents/Fiches/195.pdf', 640000, 760000, 6420000, 6560000, 'Basalte fissuré'],
    ['Causses – calcaires jurassiques karstiques (Lozère-Aveyron)', '118', 'Karst méditerranéen', 'Calcaires et dolomies du Lias-Dogger-Malm intensément karstifiés (Jurassique)', 'karstique', 'libre', 0, 200, 200, 600, 0.001, 0.1, 1e-05, 0.001, 0.1, 100, 1, 500, 'Forte', 'Bicarbonatée calcique – bonne qualité naturelle – turbidité lors des crues', 'Lozère / Aveyron / Hérault / Gard', 'AEP / Industriel', 'http://infoterre.brgm.fr/rapports/79-SGN-550-MPY.pdf', 650000, 790000, 6310000, 6440000, 'Calcaire karstifié'],
    ['Calcaires urgoniens de Provence-Vaucluse (Crétacé inférieur)', '162', 'Karst méditerranéen', 'Calcaires blancs massifs urgoniens karstifiés du Barrémien-Aptien (Crétacé inférieur)', 'karstique', 'mixte', 0, 800, 300, 1500, 0.01, 1, 0.0001, 0.01, 0.1, 1000, 1, 600, 'Forte', 'Bicarbonatée calcique – bonne qualité naturelle – turbidité en crue – T° constante 13-14°C', 'Vaucluse / Bouches-du-Rhône / Var / Alpes-de-Haute-Provence / Alpes-Maritimes', 'AEP / Irrigation', 'https://www.rhone-mediterranee.eaufrance.fr/sites/sierm/files/underground_waterbody/FRDG130.pdf', 820000, 1090000, 6240000, 6420000, 'Calcaire urgonien'],
]

# 23 colonnes "métier" affichées (A..W)
HEADERS = [
    "Nom du système aquifère", "Code BDLISA", "Bassin / Région", "Lithologie principale",
    "Type d'écoulement", "État",
    "Prof. toit min (m)", "Prof. toit max (m)",
    "Épaisseur min (m)", "Épaisseur max (m)",
    "T min (m²/s)", "T max (m²/s)",
    "K min (m/s)", "K max (m/s)",
    "Débit spé. min (m³/h/m)", "Débit spé. max (m³/h/m)",
    "Débit forage min (m³/h)", "Débit forage max (m³/h)",
    "Vulnérabilité", "Qualité naturelle",
    "Régions concernées", "Usages dominants", "Source"
]

# Index des champs supplémentaires dans chaque ligne FALLBACK (au-delà de A..W)
IDX_XMIN, IDX_XMAX, IDX_YMIN, IDX_YMAX, IDX_SUBSTRAT = 23, 24, 25, 26, 27


def load_aquiferes_csv(csv_path):
    """Charge le CSV s'il existe (avec emprises L93 si présentes), sinon
    retourne le référentiel embarqué géolocalisé."""
    if not os.path.exists(csv_path):
        return FALLBACK_AQUIFERES, "embarqué géolocalisé"

    rows = []
    try:
        with open(csv_path, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for r in reader:
                def num(k, default=None):
                    v = r.get(k, "")
                    if v is None or v == "" or v == "—":
                        return default
                    try:
                        return float(v)
                    except (ValueError, TypeError):
                        return default
                row = [
                    r.get("nom", ""),
                    r.get("code_bdlisa", ""),
                    r.get("bassin", ""),
                    r.get("lithologie", ""),
                    r.get("ecoulement", ""),
                    r.get("etat", ""),
                    num("prof_toit_min", 0),
                    num("prof_toit_max", 100),
                    num("epaisseur_min", 0),
                    num("epaisseur_max", 100),
                    num("T_min", 1e-6),
                    num("T_max", 1e-3),
                    num("K_min", 1e-7),
                    num("K_max", 1e-4),
                    num("debit_spe_min", 0.1),
                    num("debit_spe_max", 10),
                    num("debit_forage_min", 5),
                    num("debit_forage_max", 100),
                    r.get("vulnerabilite", "Moyenne"),
                    r.get("qualite_naturelle", ""),
                    r.get("regions", ""),
                    r.get("usages", ""),
                    r.get("source_url", ""),
                    # Emprises Lambert 93 (facultatives dans le CSV)
                    num("xmin_l93", None),
                    num("xmax_l93", None),
                    num("ymin_l93", None),
                    num("ymax_l93", None),
                    r.get("substrat_type", "Alluvions grossières"),
                ]
                rows.append(row)
        # On exige des emprises pour le moteur géolocalisé : si le CSV n'en
        # fournit pas, on bascule sur l'embarqué (déjà géolocalisé).
        has_emprises = rows and all(
            r[IDX_XMIN] is not None and r[IDX_XMAX] is not None
            and r[IDX_YMIN] is not None and r[IDX_YMAX] is not None
            for r in rows
        )
        if rows and has_emprises:
            return rows, "CSV géolocalisé (" + str(len(rows)) + ")"
        return FALLBACK_AQUIFERES, "embarqué géolocalisé (CSV sans emprises L93)"
    except Exception as e:
        print(f"Erreur lecture CSV ({e}), bascule sur référentiel embarqué")
        return FALLBACK_AQUIFERES, "embarqué géolocalisé"


# ---------------------------------------------------------------------
# STYLES
# ---------------------------------------------------------------------

def style_header_row(ws, row, n_cols, fill=BG_HEADER, fg=FG_HEADER):
    for col in range(1, n_cols + 1):
        c = ws.cell(row=row, column=col)
        c.fill = PatternFill("solid", fgColor=fill)
        c.font = Font(name="Calibri", size=10, bold=True, color=fg)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border = Border(
            left=Side(style="thin", color=BORDER_COL),
            right=Side(style="thin", color=BORDER_COL),
            top=Side(style="thin", color=BORDER_COL),
            bottom=Side(style="thin", color=BORDER_COL),
        )


def style_data_row(ws, row, n_cols, alt=False):
    fill = ROW_ALT if alt else "FFFFFF"
    for col in range(1, n_cols + 1):
        c = ws.cell(row=row, column=col)
        c.fill = PatternFill("solid", fgColor=fill)
        c.font = Font(name="Calibri", size=9)
        c.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        c.border = Border(
            left=Side(style="thin", color="D0D0D0"),
            right=Side(style="thin", color="D0D0D0"),
            top=Side(style="thin", color="D0D0D0"),
            bottom=Side(style="thin", color="D0D0D0"),
        )


# ---------------------------------------------------------------------
# CRÉATION DES FEUILLES (moteur géolocalisé v15.87)
# ---------------------------------------------------------------------

# Constantes de colonnes (1-based) pour le moteur géolocalisé
COL_SCORE   = 25  # Y  : Score / 7 (conditionné par présence)
COL_RANG    = 26  # Z  : Rang global des scores
COL_XMIN    = 27  # AA : Xmin emprise L93
COL_XMAX    = 28  # AB : Xmax emprise L93
COL_YMIN    = 29  # AC : Ymin emprise L93
COL_YMAX    = 30  # AD : Ymax emprise L93
COL_PRESENT = 31  # AE : présence au point projet (0/1)
COL_DIST2   = 32  # AF : distance² au centroïde d'emprise
COL_RGPROX  = 33  # AG : rang de proximité (1 = plus proche) parmi les absents
COL_RGFINAL = 34  # AH : rang final (présents puis proximité)
COL_SUBSTRAT = 35 # AI : substrat-type associé (clé Base Géologique)


def build_referentiel_sheet(wb, aquiferes):
    """Feuille Référentiel géolocalisée : catalogue + emprises L93 +
    présence + scoring conditionné + repli par proximité."""
    if "Référentiel Aquifères" in wb.sheetnames:
        del wb["Référentiel Aquifères"]
    ws = wb.create_sheet("Référentiel Aquifères")

    n = len(aquiferes)
    last_row = 4 + n  # données de la ligne 5 à 4+n

    # Titre
    ws.merge_cells("A1:AI1")
    ws["A1"] = "RÉFÉRENTIEL NATIONAL DES AQUIFÈRES — géolocalisé Lambert 93 (Métropole)"
    ws["A1"].font = Font(name="Calibri", size=14, bold=True, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=TEAL_DARK)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    # Sous-titre
    ws.merge_cells("A2:AI2")
    ws["A2"] = (f"{n} grands systèmes aquifères répertoriés — emprises Lambert 93 (cols AA-AD) — "
                "Sources : BRGM (BDLISA, infoterre), SIGES, SAGE, atlas géothermie")
    ws["A2"].font = Font(name="Calibri", size=9, italic=True, color="666666")
    ws["A2"].alignment = Alignment(horizontal="center")

    # En-têtes "métier" ligne 4 (A..W)
    for col, h in enumerate(HEADERS, start=1):
        ws.cell(row=4, column=col, value=h)

    # En-têtes du moteur géolocalisé
    ws.cell(row=4, column=COL_SCORE,    value="Score / 7")
    ws.cell(row=4, column=COL_RANG,     value="Rang")
    ws.cell(row=4, column=COL_XMIN,     value="Xmin L93 (m)")
    ws.cell(row=4, column=COL_XMAX,     value="Xmax L93 (m)")
    ws.cell(row=4, column=COL_YMIN,     value="Ymin L93 (m)")
    ws.cell(row=4, column=COL_YMAX,     value="Ymax L93 (m)")
    ws.cell(row=4, column=COL_PRESENT,  value="Présent au point projet ?")
    ws.cell(row=4, column=COL_DIST2,    value="Dist² au centroïde emprise (m²)")
    ws.cell(row=4, column=COL_RGPROX,   value="Rang proximité (1=plus proche)")
    ws.cell(row=4, column=COL_RGFINAL,  value="Rang final (présents puis proximité)")
    ws.cell(row=4, column=COL_SUBSTRAT, value="Substrat-type associé (Base Géologique)")

    style_header_row(ws, 4, COL_SUBSTRAT)
    ws.row_dimensions[4].height = 42

    # Données + formules à partir de la ligne 5
    for i, aq in enumerate(aquiferes):
        r = 5 + i
        # Colonnes "métier" A..W (23 premiers champs)
        for col in range(1, 24):
            ws.cell(row=r, column=col, value=aq[col - 1])
        style_data_row(ws, r, COL_SUBSTRAT, alt=(i % 2 == 1))

        # Formats numériques métier
        for col_idx in [7, 8, 9, 10]:  # profondeur / épaisseur (m)
            ws.cell(row=r, column=col_idx).number_format = "0"
            ws.cell(row=r, column=col_idx).alignment = Alignment(horizontal="center", vertical="center")
        for col_idx in [11, 12, 13, 14]:  # T et K (scientifique)
            ws.cell(row=r, column=col_idx).number_format = "0.0E+00"
            ws.cell(row=r, column=col_idx).alignment = Alignment(horizontal="center", vertical="center")
        for col_idx in [15, 16, 17, 18]:  # débits
            ws.cell(row=r, column=col_idx).number_format = "0.0"
            ws.cell(row=r, column=col_idx).alignment = Alignment(horizontal="center", vertical="center")

        # Coloration vulnérabilité (col S = 19)
        v_cell = ws.cell(row=r, column=19)
        if v_cell.value == "Très forte":
            v_cell.fill = PatternFill("solid", fgColor="F8BBD0")
            v_cell.font = Font(name="Calibri", size=9, bold=True, color="A12C7B")
        elif v_cell.value == "Forte":
            v_cell.fill = PatternFill("solid", fgColor="FCE4EC")
            v_cell.font = Font(name="Calibri", size=9, bold=True, color="A12C7B")
        elif v_cell.value == "Moyenne":
            v_cell.fill = PatternFill("solid", fgColor="FFF8E7")
            v_cell.font = Font(name="Calibri", size=9, color="964219")
        elif v_cell.value == "Faible":
            v_cell.fill = PatternFill("solid", fgColor="E8F4E8")
            v_cell.font = Font(name="Calibri", size=9, color="437A22")

        # --- Emprises Lambert 93 (AA..AD) ---
        ws.cell(row=r, column=COL_XMIN, value=aq[IDX_XMIN])
        ws.cell(row=r, column=COL_XMAX, value=aq[IDX_XMAX])
        ws.cell(row=r, column=COL_YMIN, value=aq[IDX_YMIN])
        ws.cell(row=r, column=COL_YMAX, value=aq[IDX_YMAX])
        for col_idx in (COL_XMIN, COL_XMAX, COL_YMIN, COL_YMAX):
            ws.cell(row=r, column=col_idx).number_format = "#,##0"
            ws.cell(row=r, column=col_idx).alignment = Alignment(horizontal="center", vertical="center")

        # --- Score / 7 conditionné par présence (col Y) ---
        # Si AE=1 : 3 (présence) + prof OK + usage OK + vulnérabilité OK ; sinon 0.
        score_formula = (
            f"=IF(AE{r}=1,3"
            f"+IF(G{r}<='Choix du Substratum'!$C$7,1,0)"
            f"+IF(ISNUMBER(SEARCH('Choix du Substratum'!$C$10,V{r})),1,0)"
            f"+IF(MATCH(S{r},{{\"Faible\";\"Moyenne\";\"Forte\";\"Tres forte\"}},0)<="
            f"MATCH('Choix du Substratum'!$C$11,{{\"Faible\";\"Moyenne\";\"Forte\";\"Tres forte\"}},0),1,0)"
            f",0)"
        )
        c = ws.cell(row=r, column=COL_SCORE, value=score_formula)
        c.number_format = "0"
        c.alignment = Alignment(horizontal="center")
        c.font = Font(name="Calibri", size=9, bold=True)

        # --- Rang global des scores (col Z) ---
        rang_formula = (
            f"=SUMPRODUCT(($Y$5:$Y${last_row}>Y{r})*1)+"
            f"SUMPRODUCT(($Y$5:Y{r}=Y{r})*1)"
        )
        c = ws.cell(row=r, column=COL_RANG, value=rang_formula)
        c.number_format = "0"
        c.alignment = Alignment(horizontal="center")
        c.font = Font(name="Calibri", size=9, bold=True, color="01696F")

        # --- Présence au point projet (col AE) ---
        present_formula = (
            f"=IF(AND('Choix du Substratum'!$C$16>=AA{r},"
            f"'Choix du Substratum'!$C$16<=AB{r},"
            f"'Choix du Substratum'!$C$17>=AC{r},"
            f"'Choix du Substratum'!$C$17<=AD{r}),1,0)"
        )
        c = ws.cell(row=r, column=COL_PRESENT, value=present_formula)
        c.number_format = "0"
        c.alignment = Alignment(horizontal="center")
        c.font = Font(name="Calibri", size=9, bold=True)

        # --- Distance² au centroïde d'emprise (col AF) ---
        dist2_formula = (
            f"=((AA{r}+AB{r})/2-'Choix du Substratum'!$C$16)^2"
            f"+((AC{r}+AD{r})/2-'Choix du Substratum'!$C$17)^2"
        )
        c = ws.cell(row=r, column=COL_DIST2, value=dist2_formula)
        c.number_format = "0"
        c.alignment = Alignment(horizontal="center")
        c.font = Font(name="Calibri", size=9, color="666666")

        # --- Rang de proximité parmi les absents (col AG) ---
        rgprox_formula = (
            f"=IF(AE{r}=1,\"\",1+SUMPRODUCT(($AE$5:$AE${last_row}=0)*"
            f"($AF$5:$AF${last_row}<AF{r})))"
        )
        c = ws.cell(row=r, column=COL_RGPROX, value=rgprox_formula)
        c.number_format = "0"
        c.alignment = Alignment(horizontal="center")
        c.font = Font(name="Calibri", size=9, color="666666")

        # --- Rang final : présents (par score) puis repli proximité (col AH) ---
        # Si présent : rang = Z. Sinon : C20 (nb présents) + rang proximité.
        rgfinal_formula = (
            f"=IF(AE{r}=1,Z{r},'Choix du Substratum'!$C$20+AG{r})"
        )
        c = ws.cell(row=r, column=COL_RGFINAL, value=rgfinal_formula)
        c.number_format = "0"
        c.alignment = Alignment(horizontal="center")
        c.font = Font(name="Calibri", size=9, bold=True, color="01696F")

        # --- Substrat-type associé (col AI) ---
        c = ws.cell(row=r, column=COL_SUBSTRAT, value=aq[IDX_SUBSTRAT])
        c.alignment = Alignment(horizontal="left", vertical="center")
        c.font = Font(name="Calibri", size=9, italic=True, color="333333")

    # Largeurs colonnes (A..W puis bloc moteur)
    widths_metier = [32, 12, 20, 32, 16, 10, 11, 11, 11, 11, 11, 11, 11, 11, 13, 13, 13, 13, 13, 30, 28, 26, 35]
    for i, w in enumerate(widths_metier, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    # Bloc moteur (Y..AI)
    moteur_widths = {
        COL_SCORE: 9, COL_RANG: 7,
        COL_XMIN: 13, COL_XMAX: 13, COL_YMIN: 13, COL_YMAX: 13,
        COL_PRESENT: 14, COL_DIST2: 18, COL_RGPROX: 14, COL_RGFINAL: 16, COL_SUBSTRAT: 32,
    }
    for col, w in moteur_widths.items():
        ws.column_dimensions[get_column_letter(col)].width = w

    # Freeze panes (en-tête + 1ère col)
    ws.freeze_panes = "B5"

    # Auto-filter sur la zone "métier"
    ws.auto_filter.ref = f"A4:W{last_row}"

    return ws, last_row


def build_choix_substratum_sheet(wb, aquiferes, n_aquiferes):
    """Feuille Choix : moteur décisionnel PILOTÉ PAR GÉOLOCALISATION.
    Entrées X/Y depuis "Données d'Entrée" (C33/C34), repli automatique,
    Top 3 basé sur le rang final AH."""
    if "Choix du Substratum" in wb.sheetnames:
        del wb["Choix du Substratum"]
    ws = wb.create_sheet("Choix du Substratum", 0)  # 1ère position

    last_row_ref = 4 + n_aquiferes

    # Titre
    ws.merge_cells("B2:H2")
    ws["B2"] = "OUTIL D'AIDE AU CHOIX DU SUBSTRATUM AQUIFÈRE — géolocalisé Lambert 93"
    ws["B2"].font = Font(name="Calibri", size=15, bold=True, color="FFFFFF")
    ws["B2"].fill = PatternFill("solid", fgColor=TEAL_DARK)
    ws["B2"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[2].height = 32

    ws.merge_cells("B3:H3")
    ws["B3"] = ("Les coordonnées Lambert 93 (X, Y) du point projet identifient automatiquement "
                "l'aquifère de référence. À défaut d'emprise stricte, rattachement par proximité (vérifier BSS BRGM).")
    ws["B3"].font = Font(name="Calibri", size=10, italic=True, color="666666")
    ws["B3"].alignment = Alignment(horizontal="center")

    # --- Section 1 : PARAMÈTRES PROJET ---
    ws["B5"] = "PARAMÈTRES DU PROJET"
    ws["B5"].font = Font(name="Calibri", size=12, bold=True, color="FFFFFF")
    ws["B5"].fill = PatternFill("solid", fgColor=TEAL_DARK)
    ws.merge_cells("B5:E5")
    ws["B5"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[5].height = 22

    # Saisies non géographiques (critères de qualification)
    inputs = [
        ("Profondeur max envisagée (m)", "C7", 50, "0", "Profondeur de forage techniquement et financièrement acceptable"),
        ("Débit recherché (m³/h)", "C8", "=Calculs!C39", "0.0", "Débit nominal d'exploitation cible (lié aux calculs)"),
        ("Bassin / Région cible (auto)", "C9", "=C19", "@", "Renseigné automatiquement par le bassin de l'aquifère retenu"),
        ("Usage principal", "C10", "Rabattement nappe pour travaux", "@", "AEP / Géothermie / Irrigation / Industriel / Rabattement nappe pour travaux"),
        ("Vulnérabilité maximale acceptée", "C11", "Forte", "@", "Faible / Moyenne / Forte / Très forte"),
    ]
    for label, cell, default, fmt, helptxt in inputs:
        row = int(cell[1:])
        ws.cell(row=row, column=2, value=label).font = Font(name="Calibri", size=10, bold=True)
        ws.cell(row=row, column=2).fill = PatternFill("solid", fgColor=BG_CALC)
        ws.cell(row=row, column=2).alignment = Alignment(horizontal="left", vertical="center", indent=1)
        ws.cell(row=row, column=2).border = Border(
            left=Side(style="thin", color=BORDER_COL),
            top=Side(style="thin", color=BORDER_COL),
            bottom=Side(style="thin", color=BORDER_COL),
        )
        c = ws[cell]
        c.value = default
        c.fill = PatternFill("solid", fgColor=BG_INPUT)
        c.font = Font(name="Calibri", size=11, bold=True, color="01696F")
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.number_format = fmt
        c.border = Border(
            left=Side(style="thin", color=BORDER_COL),
            right=Side(style="thin", color=BORDER_COL),
            top=Side(style="thin", color=BORDER_COL),
            bottom=Side(style="thin", color=BORDER_COL),
        )
        ws.cell(row=row, column=4, value=helptxt).font = Font(name="Calibri", size=8, italic=True, color="999999")
        ws.merge_cells(start_row=row, start_column=4, end_row=row, end_column=8)
        ws.cell(row=row, column=4).alignment = Alignment(horizontal="left", vertical="center", indent=1)

    # --- Section 1bis : GÉOLOCALISATION (entrées X/Y + statut) ---
    ws["B13"] = "GÉOLOCALISATION LAMBERT 93 (depuis « Données d'Entrée »)"
    ws["B13"].font = Font(name="Calibri", size=12, bold=True, color="FFFFFF")
    ws["B13"].fill = PatternFill("solid", fgColor=TEAL_DARK)
    ws.merge_cells("B13:H13")
    ws["B13"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[13].height = 22

    geo_inputs = [
        ("X Lambert 93 (m)", "C16", "='Données d''Entrée'!C33", "#,##0.00"),
        ("Y Lambert 93 (m)", "C17", "='Données d''Entrée'!C34", "#,##0.00"),
    ]
    for label, cell, formula, fmt in geo_inputs:
        row = int(cell[1:])
        ws.cell(row=row, column=2, value=label).font = Font(name="Calibri", size=10, bold=True)
        ws.cell(row=row, column=2).fill = PatternFill("solid", fgColor=BG_CALC)
        ws.cell(row=row, column=2).alignment = Alignment(horizontal="left", vertical="center", indent=1)
        c = ws[cell]
        c.value = formula
        c.fill = PatternFill("solid", fgColor=BG_CALC)
        c.font = Font(name="Calibri", size=11, bold=True, color="01696F")
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.number_format = fmt

    # --- Moteur de rattachement (cellules pilotes C18-C21) ---
    # C20 = nombre d'aquifères présents au point
    ws["B18"] = "Aquifère de référence retenu"
    ws["B18"].font = Font(name="Calibri", size=10, bold=True)
    ws["C18"] = (
        "=IF(C20>=1,"
        "INDEX('Référentiel Aquifères'!A5:A" + str(last_row_ref) + ",MATCH(1,'Référentiel Aquifères'!AE5:AE" + str(last_row_ref) + ",0)),"
        "INDEX('Référentiel Aquifères'!A5:A" + str(last_row_ref) + ",MATCH(1,'Référentiel Aquifères'!AH5:AH" + str(last_row_ref) + ",0)))"
    )
    ws["C18"].font = Font(name="Calibri", size=11, bold=True, color="01696F")

    ws["B19"] = "Bassin de référence (auto)"
    ws["B19"].font = Font(name="Calibri", size=10, bold=True)
    ws["C19"] = (
        "=IF(C20>=1,"
        "INDEX('Référentiel Aquifères'!C5:C" + str(last_row_ref) + ",MATCH(1,'Référentiel Aquifères'!AE5:AE" + str(last_row_ref) + ",0)),"
        "INDEX('Référentiel Aquifères'!C5:C" + str(last_row_ref) + ",MATCH(1,'Référentiel Aquifères'!AH5:AH" + str(last_row_ref) + ",0))&\" (rattachement par proximité)\")"
    )
    ws["C19"].font = Font(name="Calibri", size=11, color="333333")

    ws["B20"] = "Nb aquifères présents au point"
    ws["B20"].font = Font(name="Calibri", size=10, bold=True)
    ws["C20"] = "=SUMPRODUCT('Référentiel Aquifères'!AE5:AE" + str(last_row_ref) + ")"
    ws["C20"].number_format = "0"
    ws["C20"].font = Font(name="Calibri", size=11, bold=True, color="01696F")

    ws["B21"] = "Statut de rattachement"
    ws["B21"].font = Font(name="Calibri", size=10, bold=True)
    ws["C21"] = (
        "=IF(C20=0,\"Hors emprise stricte - rattachement a l'aquifere reference le plus proche (verifier BSS BRGM)\","
        "IF(C20=1,\"OK 1 aquifere present au point\",\"OK \"&C20&\" aquiferes superposes\"))"
    )
    ws["C21"].font = Font(name="Calibri", size=10, italic=True, color="964219")
    ws.merge_cells("C21:H21")
    ws["C21"].alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)

    # --- Section 2 : RÉSULTATS TOP 3 (basé sur le rang final AH) ---
    ws["B23"] = "RÉSULTATS — TOP 3 SUBSTRATUMS (rattachement géolocalisé)"
    ws["B23"].font = Font(name="Calibri", size=12, bold=True, color="FFFFFF")
    ws["B23"].fill = PatternFill("solid", fgColor=TEAL_DARK)
    ws.merge_cells("B23:H23")
    ws["B23"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[23].height = 22

    # En-têtes du top 3 (ligne 23bis : on place les en-têtes en ligne 27 réservée plus bas si besoin)
    # Pour rester cohérent avec le classeur corrigé : Top3 en lignes 24,25,26.
    ref = "Référentiel Aquifères"
    for rang in range(1, 4):
        r = 23 + rang  # 24, 25, 26
        ws.cell(row=r, column=2, value=rang).font = Font(name="Calibri", size=14, bold=True, color="01696F")
        ws.cell(row=r, column=2).fill = PatternFill("solid", fgColor=BG_RESULT)
        ws.cell(row=r, column=2).alignment = Alignment(horizontal="center", vertical="center")

        ws.cell(row=r, column=3, value=f"=INDEX('{ref}'!$A$5:$A${last_row_ref},MATCH({rang},'{ref}'!$AH$5:$AH${last_row_ref},0))")
        ws.cell(row=r, column=4, value=f"=INDEX('{ref}'!$C$5:$C${last_row_ref},MATCH({rang},'{ref}'!$AH$5:$AH${last_row_ref},0))")
        ws.cell(row=r, column=5, value=f"=INDEX('{ref}'!$G$5:$G${last_row_ref},MATCH({rang},'{ref}'!$AH$5:$AH${last_row_ref},0))&\" - \"&INDEX('{ref}'!$H$5:$H${last_row_ref},MATCH({rang},'{ref}'!$AH$5:$AH${last_row_ref},0))&\" m\"")
        ws.cell(row=r, column=6, value=f"=INDEX('{ref}'!$Q$5:$Q${last_row_ref},MATCH({rang},'{ref}'!$AH$5:$AH${last_row_ref},0))&\" - \"&INDEX('{ref}'!$R$5:$R${last_row_ref},MATCH({rang},'{ref}'!$AH$5:$AH${last_row_ref},0))&\" m3/h\"")
        ws.cell(row=r, column=7, value=f"=INDEX('{ref}'!$S$5:$S${last_row_ref},MATCH({rang},'{ref}'!$AH$5:$AH${last_row_ref},0))")
        ws.cell(row=r, column=8, value=f"=INDEX('{ref}'!$Y$5:$Y${last_row_ref},MATCH({rang},'{ref}'!$AH$5:$AH${last_row_ref},0))&\" / 7\"")

        for col in range(2, 9):
            c = ws.cell(row=r, column=col)
            c.fill = PatternFill("solid", fgColor=BG_RESULT if rang == 1 else "F0F7F8")
            if col != 2:
                c.font = Font(name="Calibri", size=11, bold=(rang == 1), color="01696F" if rang == 1 else "333333")
                c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            c.border = Border(
                left=Side(style="thin", color=BORDER_COL),
                right=Side(style="thin", color=BORDER_COL),
                top=Side(style="thin", color=BORDER_COL),
                bottom=Side(style="thin", color=BORDER_COL),
            )
        ws.row_dimensions[r].height = 28

    # En-têtes du tableau Top 3 (placés au-dessus, ligne réservée: on insère labels en ligne 23 déjà titrée;
    # pour la lisibilité on ajoute une légende des colonnes en ligne 27)
    top_headers = ["Rang", "Aquifère", "Bassin", "Profondeur toit (m)",
                   "Débit attendu (m³/h)", "Vulnérabilité", "Score / 7"]
    # (les en-têtes restent informatifs ; le classeur corrigé n'affiche pas de ligne d'en-tête dédiée
    #  au-dessus du Top3, on conserve donc la structure C24:H26.)

    # --- Section 3 : Référence cellule C49 (compatibilité PDF/Calculs) ---
    ws["B49"] = "Aquifère de référence (export PDF)"
    ws["B49"].font = Font(name="Calibri", size=10, bold=True)
    ws["C49"] = (
        "=IF(C20>=1,"
        "INDEX('Référentiel Aquifères'!A5:A" + str(last_row_ref) + ",MATCH(1,'Référentiel Aquifères'!AE5:AE" + str(last_row_ref) + ",0)),"
        "INDEX('Référentiel Aquifères'!A5:A" + str(last_row_ref) + ",MATCH(1,'Référentiel Aquifères'!AH5:AH" + str(last_row_ref) + ",0)))"
    )
    ws["C49"].font = Font(name="Calibri", size=11, bold=True, color="01696F")

    # --- Section 4 : Méthode ---
    ws["B30"] = "Méthode de rattachement géolocalisé (v15.87)"
    ws["B30"].font = Font(name="Calibri", size=11, bold=True, color="01696F")
    ws.merge_cells("B30:H30")

    legend_lines = [
        "  1. Présence stricte : le point (X,Y) Lambert 93 tombe dans l'emprise de l'aquifère (col AE=1).",
        "  2. Score /7 calculé UNIQUEMENT pour les aquifères présents : 3 (présence) + profondeur + usage + vulnérabilité.",
        "  3. Repli automatique : si aucun aquifère ne contient le point, rattachement au centroïde d'emprise le plus proche.",
        "  4. Rang final (col AH) : aquifères présents d'abord (par score), puis aquifères de proximité.",
        "  5. Vérification BSS BRGM recommandée lorsque le rattachement se fait par proximité (statut ci-dessus).",
    ]
    for i, ln in enumerate(legend_lines):
        r = 31 + i
        ws.cell(row=r, column=2, value=ln).font = Font(name="Calibri", size=9, color="555555")
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=8)

    ws["B37"] = ("Référentiel : 23 aquifères BDLISA géolocalisés (emprises Lambert 93). Sources BRGM (infoterre, BDLISA), "
                 "SIGES régionaux, SAGE, atlas géothermie. Voir feuille « Référentiel Aquifères » (cols AA-AI).")
    ws["B37"].font = Font(name="Calibri", size=8, italic=True, color="888888")
    ws.merge_cells("B37:H37")
    ws["B37"].alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    ws.row_dimensions[37].height = 32

    # Largeurs colonnes
    ws.column_dimensions["A"].width = 3
    ws.column_dimensions["B"].width = 30
    ws.column_dimensions["C"].width = 40
    ws.column_dimensions["D"].width = 22
    ws.column_dimensions["E"].width = 18
    ws.column_dimensions["F"].width = 20
    ws.column_dimensions["G"].width = 15
    ws.column_dimensions["H"].width = 12
    ws.row_dimensions[1].height = 8

    build_regime_debit_blocks(ws)

    return ws


def build_regime_debit_blocks(ws):
    u"""Ajoute les blocs Régime hydrogéologique (l.43-49) et
    Débit d'écoulement / rabattement (l.51-71) dans la feuille
    Choix du Substratum. Reproduit exactement les formules du
    classeur corrigé v15.87."""
    DE = u"'Données d''Entrée'"
    title_font = Font(name="Calibri", size=11, bold=True, color="1F4E5F")
    sub_font = Font(name="Calibri", size=10, bold=True, color="333333")
    help_font = Font(name="Calibri", size=9, italic=True, color="888888")
    val_font = Font(name="Calibri", size=10)
    input_fill = PatternFill("solid", fgColor="FFF2CC")

    # --- Bloc REGIME HYDROGEOLOGIQUE (l.43-49) ---
    ws["B43"] = (u"RÉGIME HYDROGÉOLOGIQUE IDENTIFIÉ — nappe d'écoulement "
                 u"de BV vs aquifère profond")
    ws["B43"].font = title_font
    ws.merge_cells("B43:H43")

    ws["B44"] = u"Seuil profondeur nappe (m) :"
    ws["B44"].font = sub_font
    ws["C44"] = 10
    ws["C44"].font = val_font
    ws["C44"].fill = input_fill
    ws["D44"] = (u"Si la profondeur de la nappe est <= ce seuil, on considère une "
                 u"nappe d'écoulement de bassin versant (faible profondeur).")
    ws["D44"].font = help_font
    ws.merge_cells("D44:H44")

    ws["B45"] = u"Profondeur nappe (m) :"
    ws["B45"].font = sub_font
    ws["C45"] = u"={DE}!C63".format(DE=DE)
    ws["C45"].font = val_font

    ws["B46"] = u"Cote base / épaisseur sous nappe (m) :"
    ws["B46"].font = sub_font
    ws["C46"] = u"={DE}!C28-{DE}!C63".format(DE=DE)
    ws["C46"].font = val_font

    ws["B47"] = u"Régime retenu :"
    ws["B47"].font = sub_font
    ws["C47"] = (u'=IF(OR(C20=0,{DE}!C63<=$C$44),'
                 u'"NAPPE D\'ECOULEMENT DE BASSIN VERSANT (faible profondeur) - '
                 u'reference = niveaux altimetriques des piezometres / puits BSS BRGM",'
                 u'"AQUIFERE PROFOND REFERENCE - reference = base aquifere nationale + '
                 u'emprise L93")').format(DE=DE)
    ws["C47"].font = Font(name="Calibri", size=10, bold=True, color="1F4E5F")
    ws.merge_cells("C47:H47")

    ws["B48"] = u"Référence altimétrique :"
    ws["B48"].font = sub_font
    ws["C48"] = (u'=IF(OR(C20=0,{DE}!C63<=$C$44),'
                 u'"Piezometres / puits de reference BRGM (BSS) - cf. onglet Cadastre & BSS",'
                 u'"Aquifere profond: "&C18&" (recalage BSS conseille)")').format(DE=DE)
    ws["C48"].font = val_font
    ws.merge_cells("C48:H48")

    ws["B49"] = u"Aquifère de référence :"
    ws["B49"].font = sub_font
    ws["C49"] = (u"=IF(C20>=1,"
                 u"INDEX('Référentiel Aquifères'!A5:A27,"
                 u"MATCH(1,'Référentiel Aquifères'!AE5:AE27,0)),"
                 u"INDEX('Référentiel Aquifères'!A5:A27,"
                 u"MATCH(1,'Référentiel Aquifères'!AH5:AH27,0)))")
    ws["C49"].font = val_font
    ws.merge_cells("C49:H49")

    # --- Bloc DEBIT D'ECOULEMENT / RABATTEMENT (l.51-71) ---
    ws["B51"] = (u"DÉBIT D'ÉCOULEMENT PRÉVISIBLE DE LA NAPPE & DÉBIT DE "
                 u"RABATTEMENT (puits, parking, radier, fondations)")
    ws["B51"].font = title_font
    ws.merge_cells("B51:H51")

    ws["B52"] = u"Paramètres hydrodynamiques"
    ws["B52"].font = sub_font
    ws.merge_cells("B52:H52")
    ws["B53"] = u"(valeurs reprises de l'onglet Données d'Entrée / Calculs)"
    ws["B53"].font = help_font
    ws.merge_cells("B53:H53")

    debit_rows = [
        (54, u"Périmètre / largeur emprise (m) :", u"={DE}!C50".format(DE=DE), False),
        (55, u"Gradient hydraulique i (-) :", 0.01, True),
        (56, u"Conductivité K équivalente (m/s) :",
         u"=IFERROR(IF({DE}!C96>1,SQRT({DE}!C96),10),10)".format(DE=DE), False),
        (57, u"Épaisseur mouillée (m) :", u"=MAX({DE}!C64-{DE}!C63,0)".format(DE=DE), False),
        (58, u"Transmissivité T (m²/s) :", u"=IFERROR({DE}!C96,0)".format(DE=DE), False),
        (59, u"Pluie efficace (mm/an) :", u"={DE}!C92".format(DE=DE), False),
    ]
    for r, label, val, is_input in debit_rows:
        ws.cell(row=r, column=2, value=label).font = sub_font
        c = ws.cell(row=r, column=3, value=val)
        c.font = val_font
        if is_input:
            c.fill = input_fill

    ws["B61"] = u"Coefficient de sécurité (-) :"
    ws["B61"].font = sub_font
    ws["C61"] = 1.8
    ws["C61"].font = val_font
    ws["C61"].fill = input_fill
    ws["B62"] = u"Coefficient minorant (-) :"
    ws["B62"].font = sub_font
    ws["C62"] = 0.4
    ws["C62"].font = val_font
    ws["C62"].fill = input_fill

    ws["B63"] = u"Débits calculés"
    ws["B63"].font = sub_font
    ws.merge_cells("B63:H63")

    calc_rows = [
        (64, u"Débit d'écoulement latéral (m³/h) :", "=C54*C55*(C56*C57)*3600"),
        (65, u"Débit d'infiltration / recharge (m³/h) :", "=C59/1000*C58/(365*24)"),
        (66, u"Débit total prévisible (m³/h) :", "=C64+C65"),
        (67, u"Débit de rabattement dimensionnant (m³/h) :", "=C64+C65*C61"),
        (68, u"Débit minorant (m³/h) :", "=C64+C65*C62"),
        (69, u"Hauteur de rabattement à assurer (m) :", "=C57"),
    ]
    for r, label, val in calc_rows:
        ws.cell(row=r, column=2, value=label).font = sub_font
        ws.cell(row=r, column=3, value=val).font = val_font

    ws["B70"] = u"DÉBIT DE RABATTEMENT RETENU (m³/h) :"
    ws["B70"].font = Font(name="Calibri", size=10, bold=True, color="1F4E5F")
    ws["C70"] = u"=IF(OR(C20=0,{DE}!C63<=C44),MAX(C67,{DE}!C98/24),C67)".format(DE=DE)
    ws["C70"].font = Font(name="Calibri", size=11, bold=True, color="1F4E5F")
    ws["C70"].fill = PatternFill("solid", fgColor="D9EAD3")

    ws["B71"] = (u"Méthode : débit latéral (loi de Darcy Q=K·i·e·L) + recharge "
                 u"par infiltration, majoré du coefficient de sécurité. En nappe "
                 u"d'écoulement de BV, on retient le maximum entre ce débit et le débit "
                 u"de pompage d'essai BSS (C98/24).")
    ws["B71"].font = help_font
    ws.merge_cells("B71:H71")
    ws["B71"].alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    ws.row_dimensions[71].height = 40


def update_excel(xlsx_path, csv_path=None):
    """Point d'entrée principal."""
    csv_path = csv_path or os.path.join(os.path.dirname(xlsx_path), "aquiferes_france.csv")
    csv_path = os.path.normpath(csv_path)

    aquiferes, source = load_aquiferes_csv(csv_path)
    print(f"  → Référentiel chargé : {len(aquiferes)} aquifères (source : {source})")

    wb = openpyxl.load_workbook(xlsx_path)
    print(f"  → Feuilles existantes : {wb.sheetnames}")

    ref_ws, last_row = build_referentiel_sheet(wb, aquiferes)
    print(f"  → Feuille « Référentiel Aquifères » : {len(aquiferes)} lignes géolocalisées (emprises AA-AD)")

    choix_ws = build_choix_substratum_sheet(wb, aquiferes, len(aquiferes))
    print(f"  → Feuille « Choix du Substratum » : moteur géolocalisé (présence AE + repli AH) placé en 1ère position")

    wb.save(xlsx_path)
    print(f"  ✓ Excel sauvegardé : {xlsx_path}")


if __name__ == "__main__":
    import sys
    xlsx = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "Modelisation_Rabattement_TSN_GMEP.xlsx")
    update_excel(xlsx)
