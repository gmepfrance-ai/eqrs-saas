#!/bin/bash
# ================================================================
#  G.M.E.P -- Generer le PDF (Mac) - VERSION DIRECTE v15.52
# ================================================================
#  Execute Python DIRECTEMENT dans le dossier courant.
#  Aucune copie, aucune boite de dialogue,
#  fenetre Terminal visible pendant toute la generation.
# ================================================================

# Se placer dans le dossier du script (gere les espaces)
cd "$(dirname "$0")" || exit 1

clear
echo ""
echo "================================================================"
echo "  G.M.E.P  --  Generation du Dossier Loi sur l'Eau"
echo "================================================================"
echo ""
echo "  Dossier de travail : $(pwd)"
echo ""

# ----------------------------------------------------------------
# Verifier que le fichier Python existe
# ----------------------------------------------------------------
if [ ! -f "generate_rapport_loi_eau.py" ]; then
    echo "  [ERREUR] generate_rapport_loi_eau.py introuvable dans :"
    echo "  $(pwd)"
    echo ""
    echo "  Verifiez que vous avez bien decompresse le ZIP complet."
    echo ""
    read -p "Appuyez sur Entree pour fermer..."
    exit 1
fi

# ----------------------------------------------------------------
# Trouver le fichier Excel le plus recent
# ----------------------------------------------------------------
EXCEL_FILE=$(ls -t *.xlsx *.xlsm 2>/dev/null | head -n 1)
if [ -z "$EXCEL_FILE" ]; then
    echo "  [ERREUR] Aucun fichier .xlsx trouve dans le dossier."
    echo ""
    read -p "Appuyez sur Entree pour fermer..."
    exit 1
fi

echo "  Fichier Excel detecte  : $EXCEL_FILE"
echo ""

# ----------------------------------------------------------------
# Chercher Python
# ----------------------------------------------------------------
PYTHON=""
for cmd in python3 /usr/local/bin/python3 /opt/homebrew/bin/python3 /usr/bin/python3 python; do
    if command -v "$cmd" > /dev/null 2>&1; then
        PYTHON="$cmd"
        break
    fi
done

if [ -z "$PYTHON" ]; then
    echo "  [ERREUR] Python n'est pas installe."
    echo "  Lancez INSTALLER.command pour l'installer."
    echo ""
    read -p "Appuyez sur Entree pour fermer..."
    exit 1
fi

echo "  Python detecte         : $PYTHON"
echo ""

# ----------------------------------------------------------------
# Verifier/installer les modules Python necessaires
# ----------------------------------------------------------------
echo "  Verification des modules Python..."
"$PYTHON" -c "import openpyxl, reportlab, PIL, matplotlib, requests" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "  Installation des modules manquants..."
    "$PYTHON" -m pip install --quiet openpyxl reportlab Pillow matplotlib requests
    if [ $? -ne 0 ]; then
        echo "  [ERREUR] Echec de l'installation des modules."
        read -p "Appuyez sur Entree pour fermer..."
        exit 1
    fi
fi
echo "  Modules : OK"
echo ""

# Forcer UTF-8
export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8:replace

# ----------------------------------------------------------------
# Lancer Python (fenetre visible, pas de redirection)
# ----------------------------------------------------------------
echo "================================================================"
echo "  Lancement de la generation du PDF..."
echo "  Duree estimee : 30 a 90 secondes. NE FERMEZ PAS cette fenetre."
echo "================================================================"
echo ""

"$PYTHON" -X utf8 -u "generate_rapport_loi_eau.py" "$EXCEL_FILE"
PYRET=$?

echo ""
echo "================================================================"

if [ $PYRET -ne 0 ]; then
    echo "  [ERREUR] La generation a echoue (code $PYRET)."
    echo "  Lisez les messages ci-dessus pour identifier la cause."
    echo "================================================================"
    echo ""
    read -p "Appuyez sur Entree pour fermer..."
    exit $PYRET
fi

# ----------------------------------------------------------------
# Verifier et ouvrir le PDF
# ----------------------------------------------------------------
PDF_FILE="Dossier_Declaration_Loi_Eau_GMEP.pdf"
if [ ! -f "$PDF_FILE" ]; then
    echo "  [ERREUR] Le PDF $PDF_FILE n'a pas ete cree."
    echo "================================================================"
    echo ""
    read -p "Appuyez sur Entree pour fermer..."
    exit 1
fi

echo "  PDF genere avec succes : $(pwd)/$PDF_FILE"
echo "================================================================"
echo ""
echo "  Ouverture du PDF dans 2 secondes..."
sleep 2
open "$PDF_FILE"

exit 0
