"""Construit le tableur .xlsm avec macros VBA pré-installées.

VERSION SANS ASPOSE (v15.19+) :
- Manipulation directe de l'archive ZIP du .xlsx (zipfile pur)
- Injection du vbaProject.bin pré-compilé (vbaProject_template.bin)
- AUCUN filigrane Aspose, AUCUNE feuille parasite "Evaluation Warning"
- Macros VBA : GMEP_Geo (résolution Lambert93→Commune), Worksheet_Change C33/C34,
  Worksheet_FollowHyperlink Sommaire, Ouvrir_PDF, Lancer_Generation

Sortie : Modelisation_Rabattement_TSN_GMEP.xlsm
"""
import os
import re
import shutil
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
SRC_XLSX = os.path.join(HERE, "Modelisation_Rabattement_TSN_GMEP.xlsx")
DST_XLSM = os.path.join(HERE, "Modelisation_Rabattement_TSN_GMEP.xlsm")
VBA_TEMPLATE = os.path.join(HERE, "vbaProject_template.bin")

# Mapping nom de feuille → codeName VBA (référencé par vbaProject.bin)
# IMPORTANT : doit correspondre à ce que le vbaProject.bin attend.
# - "Sommaire" → Sheet2  (Worksheet_FollowHyperlink pour Ouvrir_PDF)
# - "Données d'Entrée" → Sheet3 (Worksheet_Change sur C33/C34)
# Les autres feuilles ont des codeNames Sheet1/4/5/... non utilisés par les handlers.
SHEET_CODENAMES = {
    "Choix du Substratum":        "Sheet1",
    "Sommaire":                   "Sheet2",
    "Données d'Entrée":           "Sheet3",
    "Calculs":                    "Sheet4",
    "Analyse Sensibilité":        "Sheet5",
    "Profil Rabattement":         "Sheet6",
    "Base Géologique":            "Sheet7",
    "Climat":                     "Sheet8",
    "Compléments réglementaires": "Sheet9",
    "Cadastre & BSS":             "Sheet10",
    "Référentiel Aquifères":      "Sheet11",
    "Topographie & Lenticulaire": "Sheet12",
}


def _patch_content_types(xml_str: str) -> str:
    """Modifie [Content_Types].xml :
    - workbook.xml : passe en macroEnabled.main
    - ajoute Override pour vbaProject.bin
    """
    # 1) Change le ContentType du workbook
    xml_str = xml_str.replace(
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml',
        'application/vnd.ms-excel.sheet.macroEnabled.main+xml',
    )
    # 2) Ajoute Override vbaProject.bin si absent
    if 'vbaProject.bin' not in xml_str:
        injection = (
            '<Override PartName="/xl/vbaProject.bin" '
            'ContentType="application/vnd.ms-office.vbaProject"/>'
        )
        xml_str = xml_str.replace('</Types>', injection + '</Types>')
    return xml_str


def _patch_workbook_rels(xml_str: str) -> str:
    """Ajoute la relation vers xl/vbaProject.bin dans workbook.xml.rels."""
    if 'vbaProject.bin' in xml_str:
        return xml_str
    # Trouve le plus grand rId pour générer un nouveau
    existing_ids = re.findall(r'Id="rId(\d+)"', xml_str)
    next_id = max((int(x) for x in existing_ids), default=0) + 1
    rel = (
        f'<Relationship Id="rId{next_id}" '
        'Type="http://schemas.microsoft.com/office/2006/relationships/vbaProject" '
        'Target="vbaProject.bin"/>'
    )
    return xml_str.replace('</Relationships>', rel + '</Relationships>')


def _patch_workbook_xml(xml_str: str) -> str:
    """Ajoute codeName="ThisWorkbook" sur <workbookPr> (uniquement).
    Ne touche PAS à <workbookProtection> ou autres balises préfixées workbook.
    """
    if '<workbookPr' in xml_str:
        # Recherche précise : <workbookPr ...> ou <workbookPr .../>
        m = re.search(r'<workbookPr\b([^/>]*?)(/?)>', xml_str)
        if m and 'codeName=' not in m.group(0):
            attrs = m.group(1)
            slash = m.group(2)
            new_tag = f'<workbookPr{attrs} codeName="ThisWorkbook"{slash}>'
            xml_str = xml_str[:m.start()] + new_tag + xml_str[m.end():]
    else:
        # Ajoute après <workbook ...>
        xml_str = re.sub(
            r'(<workbook[^>]*>)',
            r'\1<workbookPr codeName="ThisWorkbook"/>',
            xml_str,
            count=1,
        )
    return xml_str


def _patch_sheet_codename(xml_str: str, codename: str) -> str:
    """Ajoute codeName="..." sur <sheetPr> de la feuille (ou le crée).
    Précis : ne matche QUE <sheetPr ...>, pas <sheetProtection> etc.
    """
    m = re.search(r'<sheetPr\b([^/>]*?)(/?)>', xml_str)
    if m:
        if 'codeName=' in m.group(0):
            return xml_str  # déjà présent
        attrs = m.group(1)
        slash = m.group(2)
        new_tag = f'<sheetPr{attrs} codeName="{codename}"{slash}>'
        xml_str = xml_str[:m.start()] + new_tag + xml_str[m.end():]
    else:
        # Insère <sheetPr codeName="..."/> juste après <worksheet ...>
        xml_str = re.sub(
            r'(<worksheet\b[^>]*>)',
            rf'\1<sheetPr codeName="{codename}"/>',
            xml_str,
            count=1,
        )
    return xml_str


def _extract_sheet_order(workbook_xml: str) -> list:
    """Renvoie la liste des (sheet_name, r:id) dans l'ordre du workbook.xml.
    Tolère l'ordre arbitraire des attributs et la présence éventuelle de
    xmlns:r="..." sur la balise <sheet>.
    """
    result = []
    # <sheet ...> ou <sheet .../>, exclut <sheets>. Espace obligatoire après 'sheet'.
    for sheet_tag in re.finditer(r'<sheet\s[^>]*/?>', workbook_xml):
        tag = sheet_tag.group(0)
        m_name = re.search(r'\bname="([^"]+)"', tag)
        m_rid  = re.search(r'\br:id="([^"]+)"', tag)
        if m_name and m_rid:
            # Décode les entités XML basiques (&amp; etc.)
            name = m_name.group(1).replace('&amp;', '&').replace('&apos;', "'")
            result.append((name, m_rid.group(1)))
    return result


def _rels_target_map(rels_xml: str) -> dict:
    """Renvoie {rId: target_path_relatif_xl} pour les sheets de workbook.xml.rels.
    Tolère l'ordre arbitraire des attributs et les targets absolus (/xl/...)
    aussi bien que relatifs (worksheets/...).
    """
    out = {}
    for tag in re.finditer(r'<Relationship\s[^>]*/?>', rels_xml):
        s = tag.group(0)
        if 'worksheet' not in s:
            continue
        m_id  = re.search(r'\bId="([^"]+)"', s)
        m_tgt = re.search(r'\bTarget="([^"]+)"', s)
        if not (m_id and m_tgt):
            continue
        tgt = m_tgt.group(1)
        # Normalise en relatif depuis xl/
        tgt = tgt.lstrip('/')
        if tgt.startswith('xl/'):
            tgt = tgt[3:]
        out[m_id.group(1)] = tgt
    return out


def build():
    print(f"[1/5] Source : {SRC_XLSX}")
    if not os.path.exists(SRC_XLSX):
        raise FileNotFoundError(SRC_XLSX)
    if not os.path.exists(VBA_TEMPLATE):
        raise FileNotFoundError(
            f"Template VBA introuvable : {VBA_TEMPLATE}\n"
            "  → Extraire xl/vbaProject.bin depuis une ancienne version du .xlsm\n"
            "    et le placer ici."
        )

    # Lit toutes les parties du .xlsx source
    with zipfile.ZipFile(SRC_XLSX, "r") as src:
        parts = {name: src.read(name) for name in src.namelist()}

    print(f"[2/5] {len(parts)} fichiers extraits du .xlsx")

    # 1) Modifie [Content_Types].xml
    ct_path = "[Content_Types].xml"
    if ct_path in parts:
        parts[ct_path] = _patch_content_types(
            parts[ct_path].decode("utf-8")
        ).encode("utf-8")
        print(f"[3/5] [Content_Types].xml patché (macroEnabled + vbaProject)")

    # 2) Modifie xl/_rels/workbook.xml.rels
    rels_path = "xl/_rels/workbook.xml.rels"
    if rels_path in parts:
        parts[rels_path] = _patch_workbook_rels(
            parts[rels_path].decode("utf-8")
        ).encode("utf-8")
        print(f"[3/5] workbook.xml.rels patché (vbaProject)")

    # 3) Modifie xl/workbook.xml — ajout codeName="ThisWorkbook"
    wb_path = "xl/workbook.xml"
    workbook_xml_str = parts[wb_path].decode("utf-8")
    workbook_xml_str = _patch_workbook_xml(workbook_xml_str)
    parts[wb_path] = workbook_xml_str.encode("utf-8")

    # 4) Détermine quelle feuille XML correspond à chaque nom (via workbook + rels)
    sheet_order = _extract_sheet_order(workbook_xml_str)
    rels_map = _rels_target_map(parts[rels_path].decode("utf-8"))

    print(f"[4/5] Injection codeName sur les feuilles VBA :")
    patched_count = 0
    for sheet_name, rid in sheet_order:
        codename = SHEET_CODENAMES.get(sheet_name)
        if not codename:
            continue
        target = rels_map.get(rid)
        if not target:
            print(f"  ⚠ {sheet_name} : rId {rid} introuvable dans rels")
            continue
        full_path = "xl/" + target
        if full_path not in parts:
            print(f"  ⚠ {sheet_name} : fichier {full_path} absent")
            continue
        xml_str = parts[full_path].decode("utf-8")
        xml_str = _patch_sheet_codename(xml_str, codename)
        parts[full_path] = xml_str.encode("utf-8")
        print(f"  ✓ {sheet_name:30s} → codeName={codename} ({target})")
        patched_count += 1

    # 5) Injecte vbaProject.bin
    with open(VBA_TEMPLATE, "rb") as f:
        parts["xl/vbaProject.bin"] = f.read()
    print(f"[5/5] vbaProject.bin injecté ({len(parts['xl/vbaProject.bin'])} octets)")

    # Écrit le .xlsm
    if os.path.exists(DST_XLSM):
        os.remove(DST_XLSM)
    with zipfile.ZipFile(DST_XLSM, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as dst:
        for name, content in parts.items():
            dst.writestr(name, content)

    size = os.path.getsize(DST_XLSM)
    print(f"[ok] {DST_XLSM}")
    print(f"     Taille : {size:,} octets")
    print(f"     Sans Aspose : pas de filigrane, pas d'onglet parasite")


if __name__ == "__main__":
    build()
