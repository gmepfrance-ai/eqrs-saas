@echo off
chcp 65001 >nul
title GMEP - Activation Geographie
cd /d "%~dp0"

echo.
echo ======================================================================
echo   GMEP - Mise a jour automatique de la geographie
echo ======================================================================
echo.

REM === Verification Python ===
where python >nul 2>nul
if errorlevel 1 (
    echo Python n'est pas installe sur ce poste.
    echo.
    echo Lancez d'abord INSTALLER.bat pour installer Python automatiquement,
    echo ou telechargez Python depuis https://www.python.org/downloads/
    echo.
    pause
    exit /b 1
)

REM === Lancement script ===
python "%~dp0activer_geographie.py"
set RC=%ERRORLEVEL%

if %RC% NEQ 0 (
    echo.
    echo ERREUR : le script s'est termine avec le code %RC%.
    pause
    exit /b %RC%
)

exit /b 0
