#!/bin/bash
# GMEP - Installation macOS (une seule fois)
cd "$(dirname "$0")"

echo "===================================================================="
echo "  GMEP - INSTALLATION (macOS)"
echo "===================================================================="
echo ""
echo "  Suppression du marquage de quarantaine..."

# Retire l'attribut quarantine récursivement
xattr -dr com.apple.quarantine . 2>/dev/null

echo "  OK"
echo ""
echo "  Ouverture du tableur..."

open "Modelisation_Rabattement_TSN_GMEP.xlsx"

echo ""
echo "===================================================================="
echo "  TERMINÉ"
echo "===================================================================="
echo ""
echo "  Si Excel demande l'activation des macros :"
echo "    Excel > Préférences > Sécurité et confidentialité"
echo "    → Activer toutes les macros"
echo ""
sleep 3
