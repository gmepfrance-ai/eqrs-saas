"""
GMEP v15.82 — Note Technique Forage G.M.E.P
Script Python pour générer un PDF 3 pages : dossier technique sondage
Fichier : Note_Technique_Forage_G_M_E_P_Exemple.pdf
"""
import math
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.colors import HexColor, black, white, grey
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak,
                                 Table, TableStyle, HRFlowable, KeepTogether)
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.graphics.shapes import Drawing, Rect, String, Line, Polygon
from reportlab.lib import colors

OUTPUT = "/tmp/v1582/Note_Technique_Forage_G_M_E_P_Exemple.pdf"

# ─── Données exemple (correspondant aux données du tableur exemples) ──────────
DATA = {
    "nom_forage":       "Forage F1",
    "adresse_rue":      "195 rue de Claye",
    "cp_ville":         "77400 THORIGNY SUR MARNE",
    "date_forage":      "10/06/2025",
    "x_l93":            678658,
    "y_l93":            6866259,
    "z_alt":            100.26,
    "ns":               2.0,
    "ff":               4.0,
    "prof_forage":      10.0,
    "r_puits":          0.056,
    "q_max":            0.0106,
    "rabattement":      2.0,
    "arrivee_eau":      2.60,
    "code_bss":         "BSS001XXXXX",
    "maître_oeuvre":    "G.M.E.P — Ingénierie Hydrogéologique",
    "entreprise":       "G.M.E.P",
    "layers": [
        {"de": 0.0,  "a": 2.0,  "litho": "Argile sableuse",         "K": 5e-9,  "e_sat": 0.0,  "Q_i": 0.0},
        {"de": 2.0,  "a": 3.0,  "litho": "Marne argileuse",         "K": 1e-8,  "e_sat": 1.0,  "Q_i": 0.0000482},
        {"de": 3.0,  "a": 5.0,  "litho": "Marno-calcaire fissuré",  "K": 1e-6,  "e_sat": 2.0,  "Q_i": 0.009602},
        {"de": 5.0,  "a": 8.0,  "litho": "Calcaire karstique",      "K": 5e-5,  "e_sat": 0.0,  "Q_i": 0.0},
        {"de": 8.0,  "a": 10.0, "litho": "Socle cristallin",        "K": 1e-8,  "e_sat": 0.0,  "Q_i": 0.0},
    ],
    "arrivees_eau": [
        {"prof": 2.60, "debit": 0.0106, "litho": "Marne argileuse → Marno-calcaire"},
    ],
}

# ─── Colors ───────────────────────────────────────────────────────────────────
NAVY    = HexColor("#0D3761")
TEAL    = HexColor("#01696F")
BLUE    = HexColor("#1565C0")
DARK    = HexColor("#28251D")
GREY    = HexColor("#7A7974")
LGREY   = HexColor("#F7F6F2")
ORANGE  = HexColor("#DA7101")
GREEN   = HexColor("#2E7D32")
RED     = HexColor("#B22222")
LITHO_COLORS = {
    "Argile":         HexColor("#A0522D"),
    "Limon":          HexColor("#DEB887"),
    "Sable fin":      HexColor("#F5DEB3"),
    "Sable moyen":    HexColor("#DAA520"),
    "Sable grossier": HexColor("#CD853F"),
    "Gravier":        HexColor("#808080"),
    "Calcaire":       HexColor("#D4D0B0"),
    "Craie":          HexColor("#FFFFF0"),
    "Grès":           HexColor("#BC8F5F"),
    "Altérite":       HexColor("#A0826D"),
    "Socle":          HexColor("#696969"),
    "Remblai":        HexColor("#778899"),
    "Marne":          HexColor("#B8B0C8"),
}

def get_litho_color(litho_name):
    """Returns color based on lithology keyword match."""
    litho_lower = litho_name.lower()
    if "argile" in litho_lower: return LITHO_COLORS["Argile"]
    if "limon" in litho_lower:  return LITHO_COLORS["Limon"]
    if "sable fin" in litho_lower: return LITHO_COLORS["Sable fin"]
    if "sable" in litho_lower:  return LITHO_COLORS["Sable moyen"]
    if "gravier" in litho_lower: return LITHO_COLORS["Gravier"]
    if "craie" in litho_lower:  return LITHO_COLORS["Craie"]
    if "calcaire" in litho_lower: return LITHO_COLORS["Calcaire"]
    if "grès" in litho_lower:   return LITHO_COLORS["Grès"]
    if "socle" in litho_lower or "cristallin" in litho_lower: return LITHO_COLORS["Socle"]
    if "marne" in litho_lower:  return LITHO_COLORS["Marne"]
    if "altérite" in litho_lower or "alterite" in litho_lower: return LITHO_COLORS["Altérite"]
    if "remblai" in litho_lower: return LITHO_COLORS["Remblai"]
    return HexColor("#CCCCCC")

# ─── Styles ───────────────────────────────────────────────────────────────────
styles = getSampleStyleSheet()

def S(name, parent="Normal", **kw):
    return ParagraphStyle(name, parent=styles[parent], **kw)

sH1    = S("sH1", fontSize=13, textColor=NAVY, fontName="Helvetica-Bold", spaceBefore=12, spaceAfter=5)
sH2    = S("sH2", fontSize=11, textColor=TEAL, fontName="Helvetica-Bold", spaceBefore=8, spaceAfter=3)
sBody  = S("sBody", fontSize=9.5, textColor=DARK, fontName="Helvetica", leading=13, spaceAfter=4, alignment=TA_JUSTIFY)
sBold  = S("sBold", fontSize=9.5, textColor=DARK, fontName="Helvetica-Bold", spaceAfter=3)
sNote  = S("sNote", fontSize=8, textColor=GREY, fontName="Helvetica", leading=11, spaceAfter=3, leftIndent=10)
sCenter = S("sCenter", fontSize=9, textColor=DARK, fontName="Helvetica", alignment=TA_CENTER)
sFooter = S("sFooter", fontSize=7.5, textColor=GREY, fontName="Helvetica")

def SP(h=3):
    return Spacer(1, h*mm)

mm = cm / 10

def HR():
    return HRFlowable(width="100%", thickness=1, color=NAVY, spaceAfter=4, spaceBefore=4)

def P(text, style=None):
    return Paragraph(text, style or sBody)

def table_style(header_color=NAVY):
    return TableStyle([
        ('BACKGROUND',  (0, 0), (-1, 0),  header_color),
        ('TEXTCOLOR',   (0, 0), (-1, 0),  white),
        ('FONTNAME',    (0, 0), (-1, 0),  'Helvetica-Bold'),
        ('FONTSIZE',    (0, 0), (-1, 0),  8.5),
        ('FONTNAME',    (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE',    (0, 1), (-1, -1), 8.5),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [white, HexColor("#EEF4FB")]),
        ('GRID',        (0, 0), (-1, -1), 0.4, HexColor("#CCCCCC")),
        ('VALIGN',      (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING',  (0, 0), (-1, -1), 3),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
        ('LEFTPADDING', (0, 0), (-1, -1), 5),
        ('RIGHTPADDING', (0, 0), (-1, -1), 5),
    ])

# ─── Header/Footer ────────────────────────────────────────────────────────────
def on_page(c, doc, page_title=""):
    c.saveState()
    W, H = A4
    c.setFillColor(NAVY)
    c.rect(0, H-28, W, 28, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(1.5*cm, H-19, f"G.M.E.P — Note Technique Forage — {DATA['nom_forage']} — v15.82")
    c.setFont("Helvetica", 8)
    c.drawRightString(W - 1.5*cm, H-19, "Document propriétaire G.M.E.P")
    # Footer — deux lignes pour éviter chevauchement
    c.setFillColor(LGREY)
    c.rect(0, 0, W, 40, fill=1, stroke=0)
    # Ligne du haut : coordonnées Lambert-93 (centré)
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 7.5)
    c.drawCentredString(W/2, 26, f"Lambert-93 métrique   Long.: {DATA['x_l93']}   Lat.: {DATA['y_l93']}   Alt.: +{DATA['z_alt']} m NGF")
    # Ligne du bas : document propriétaire à gauche, n° page à droite
    c.setFillColor(GREY)
    c.setFont("Helvetica", 7.5)
    c.drawString(1.5*cm, 11, "G.M.E.P — Coupe Géologique G.M.E.P — Document propriétaire — gmep.france@gmail.com")
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 9)
    c.drawRightString(W - 1.5*cm, 11, f"Page {doc.page} / 3")
    c.restoreState()

# ─── PAGE 1 : Dossier Technique ────────────────────────────────────────────────
def build_page1(story, data):
    story.append(P(f"DOSSIER TECHNIQUE — SONDAGE {data['nom_forage']}", sH1))
    story.append(HR())
    
    # En-tête identité
    id_data = [
        ["Champ", "Valeur"],
        ["Entreprise / Maître d'œuvre", data["maître_oeuvre"]],
        ["Référence du forage", data["nom_forage"]],
        ["Code BSS BRGM", data["code_bss"]],
        ["Adresse du projet", f"{data['adresse_rue']} — {data['cp_ville']}"],
        ["Date d'exécution du forage", data["date_forage"]],
    ]
    t = Table(id_data, colWidths=[6*cm, 11*cm])
    t.setStyle(table_style())
    story.append(KeepTogether([t]))
    story.append(SP(4))
    
    story.append(P("Localisation géographique — Coordonnées Lambert 93", sH2))
    geo_data = [
        ["Paramètre", "Valeur", "Référence"],
        ["X Lambert 93",              f"{data['x_l93']:,} m",         "EPSG:2154 — RGF93"],
        ["Y Lambert 93",              f"{data['y_l93']:,} m",         "EPSG:2154 — RGF93"],
        ["Z altitude terrain naturel", f"+{data['z_alt']} m NGF",     "NGF-IGN69"],
        ["Commune",                   data["cp_ville"],                "INSEE — Code postal"],
    ]
    t = Table(geo_data, colWidths=[6*cm, 5*cm, 6*cm])
    t.setStyle(table_style(TEAL))
    story.append(KeepTogether([t]))
    story.append(SP(4))
    
    story.append(P("Paramètres hydrauliques principaux", sH2))
    hyd_data = [
        ["Paramètre", "Valeur", "Unité", "Méthode"],
        ["Niveau statique (NS) mesuré",    f"{data['ns']:.2f}",        "m/TN",   "Mesure terrain avant pompage"],
        ["Fond de fouille (FF)",            f"{data['ff']:.2f}",        "m/TN",   "Plan projet — profondeur cible"],
        ["Rabattement requis (s = FF−NS)",  f"{data['rabattement']:.2f}", "m",    "Calculé : FF − NS"],
        ["Profondeur totale forée",          f"{data['prof_forage']:.1f}", "m/TN", "Rapport de forage"],
        ["Rayon du puits (r)",              f"{data['r_puits']*1000:.0f}", "mm",  "Diamètre intérieur / 2"],
        ["Q total multicouche (Mode B)",    f"{data['q_max']:.4f}",     "m³/h",   "Forchheimer/Dupuit — G.M.E.P v15.82"],
        ["Volume annuel estimé",            f"{data['q_max']*24*365:.0f}", "m³/an", "Q × 24h × 365j"],
    ]
    t = Table(hyd_data, colWidths=[6*cm, 3*cm, 2.5*cm, 5.5*cm])
    t.setStyle(table_style(NAVY))
    story.append(KeepTogether([t]))
    story.append(SP(4))
    
    v_annuel = data['q_max'] * 24 * 365
    if v_annuel >= 200000:
        iota_str = "AUTORISATION IOTA R.214-1 — Rubrique 1.1.2.0"
        iota_color = RED
    elif v_annuel >= 10000:
        iota_str = "DÉCLARATION IOTA R.214-1 — Rubrique 1.1.2.0"
        iota_color = ORANGE
    else:
        iota_str = "HORS NOMENCLATURE IOTA R.214-1"
        iota_color = GREEN
    
    story.append(P(f"<b>Statut réglementaire IOTA R.214-1 :</b> <font color='#{iota_color.hexval()[2:]}'>{iota_str}</font>", sBold))
    story.append(SP(2))
    story.append(P(
        f"<i>Note : Ce document est généré par le logiciel GMEP Rabattement de Nappe v15.82 — "
        f"Module Coupe Géologique G.M.E.P propriétaire. Toutes les valeurs sont issues de la "
        f"modélisation Forchheimer/Dupuit multicouche. Référence : Forchheimer (1898), "
        f"Dupuit (1863), Darcy (1856).</i>", sNote))

# ─── PAGE 2 : Tronçons Lithologie + Arrivées d'eau ────────────────────────────
def build_page2(story, data):
    story.append(P(f"TRONÇONS DE L'OUVRAGE — SONDAGE {data['nom_forage']}", sH1))
    story.append(HR())
    
    story.append(P("Tableau Lithologique — Coupe Géologique G.M.E.P", sH2))
    story.append(P(
        "Les tronçons ci-dessous sont définis par le module Coupe Géologique G.M.E.P du logiciel "
        "GMEP Rabattement v15.82. Chaque couche contribue au débit total selon sa conductivité "
        "hydraulique k<sub>i</sub> et son épaisseur saturée e<sub>sat,i</sub>.", sBody))
    
    litho_data = [
        ["N°", "De (m)", "À (m)", "Lithologie", "K (m/s)", "e_sat (m)", "Q_i (m³/h)", "Saturée?"],
    ]
    for i, layer in enumerate(data["layers"], 1):
        sat = "OUI" if layer["de"] < data["ff"] and layer["a"] > data["ns"] else "NON"
        litho_data.append([
            str(i),
            f"{layer['de']:.2f}",
            f"{layer['a']:.2f}",
            layer["litho"],
            f"{layer['K']:.2e}",
            f"{layer['e_sat']:.3f}",
            f"{layer['Q_i']:.6f}",
            sat,
        ])
    # Total row
    q_total = sum(l["Q_i"] for l in data["layers"])
    litho_data.append(["", "", "", "TOTAL", "", "", f"{q_total:.6f}", ""])
    
    t = Table(litho_data, colWidths=[1*cm, 1.8*cm, 1.8*cm, 4.5*cm, 2.5*cm, 1.8*cm, 2.2*cm, 1.8*cm])
    ts = table_style(NAVY)
    ts.add('BACKGROUND', (0, len(litho_data)-1), (-1, len(litho_data)-1), HexColor("#D4EDDA"))
    ts.add('FONTNAME', (0, len(litho_data)-1), (-1, len(litho_data)-1), 'Helvetica-Bold')
    t.setStyle(ts)
    story.append(KeepTogether([t]))
    story.append(SP(5))
    
    story.append(P("Arrivées d'eau constatées", sH2))
    ae_data = [
        ["Profondeur (m/TN)", "Débit estimé (m³/h)", "Couche lithologique", "Observation"],
    ]
    for ae in data["arrivees_eau"]:
        ae_data.append([
            f"{ae['prof']:.2f}",
            f"{ae['debit']:.4f}",
            ae["litho"],
            "↘ Première arrivée d'eau constatée lors du forage",
        ])
    t = Table(ae_data, colWidths=[3.5*cm, 3.5*cm, 5*cm, 5.5*cm])
    t.setStyle(table_style(BLUE))
    story.append(KeepTogether([t]))
    story.append(SP(4))
    
    story.append(P(
        "<b>Méthode de calcul :</b> Q<sub>i</sub> = 2π · k<sub>i</sub> · e<sub>sat,i</sub> · s / ln(R/r) × 3600 "
        f"avec s = {data['rabattement']:.2f} m, R (Sichardt) = 3000·s·√K<sub>max</sub>, "
        f"r = {data['r_puits']} m.", sBold))
    story.append(P(
        "<i>Références : Dupuit J. (1863), Forchheimer P. (1898), Darcy H. (1856), "
        "Domenico P.A. & Schwartz F.W. (1990). Logiciel GMEP Rabattement v15.82 — "
        "Module propriétaire Coupe Géologique G.M.E.P.</i>", sNote))

# ─── PAGE 3 : Coupe Lithologique Graphique ────────────────────────────────────
def build_page3_canvas(c, data):
    """Dessine la coupe lithologique graphique à l'échelle sur une page."""
    W, H = A4
    
    # Header
    c.setFillColor(NAVY)
    c.rect(0, H-28, W, 28, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 10)
    c.drawString(1.5*cm, H-19, f"COUPE LITHOLOGIQUE GRAPHIQUE — {data['nom_forage']} — v15.82")
    c.setFont("Helvetica", 8)
    c.drawRightString(W - 1.5*cm, H-19, "Coupe Géologique G.M.E.P — Document propriétaire")
    
    # Drawing area setup
    marg_left = 2.5*cm
    marg_right = 2*cm
    marg_top = H - 32 - 1.5*cm
    marg_bot = 3*cm
    
    draw_H = marg_top - marg_bot
    max_depth = data["prof_forage"]
    scale = draw_H / max_depth  # pixels per meter
    
    col_coupe_x = marg_left + 1*cm
    col_coupe_w = 2.5*cm
    col_annulaire_x = col_coupe_x + col_coupe_w + 0.3*cm
    col_annulaire_w = 1.5*cm
    col_venues_x = col_annulaire_x + col_annulaire_w + 0.3*cm
    col_venues_w = 2*cm
    col_qi_x = col_venues_x + col_venues_w + 0.2*cm
    col_qi_w = 2.5*cm
    col_comment_x = col_qi_x + col_qi_w + 0.3*cm
    
    # Y-axis label
    c.saveState()
    c.rotate(90)
    c.setFont("Helvetica-Bold", 8)
    c.setFillColor(DARK)
    c.drawCentredString(marg_top/2 + marg_bot/2, -marg_left + 0.8*cm, "Profondeur / TN (m)")
    c.restoreState()
    
    # Column headers — placés au-dessus du dessin pour ne pas être recouverts par les rectangles lithologiques
    header_y = marg_top + 0.7*cm
    col_headers = [
        (col_coupe_x,      col_coupe_w,    "Coupe",         NAVY),
        (col_annulaire_x,  col_annulaire_w, "Annulaire",    HexColor("#37474F")),
        (col_venues_x,     col_venues_w,    "Venues d'eau", BLUE),
        (col_qi_x,         col_qi_w,        "Qi (m³/h)",    GREEN),
    ]
    for (x, w, label, color) in col_headers:
        c.setFillColor(color)
        c.rect(x, header_y - 0.5*cm, w, 0.5*cm, fill=1, stroke=0)
        c.setFillColor(white)
        c.setFont("Helvetica-Bold", 7)
        c.drawCentredString(x + w/2, header_y - 0.35*cm, label)
    
    # Draw layers
    for layer in data["layers"]:
        y_top = marg_top - layer["de"] * scale
        y_bot = marg_top - layer["a"] * scale
        height = y_top - y_bot
        if height <= 0:
            continue
        
        litho_color = get_litho_color(layer["litho"])
        c.setFillColor(litho_color)
        c.setStrokeColor(HexColor("#888888"))
        c.setLineWidth(0.3)
        c.rect(col_coupe_x, y_bot, col_coupe_w, height, fill=1, stroke=1)
        
        # Layer label — full label si la couche est assez haute
        if height > 12:
            c.setFillColor(black)
            c.setFont("Helvetica", 7)
            label = layer["litho"]
            # Si trop long pour la colonne, on raccourcit avec ellipse
            max_chars = 24
            if len(label) > max_chars:
                label = label[:max_chars-1] + "…"
            c.drawCentredString(col_coupe_x + col_coupe_w/2, y_bot + height/2 - 3, label)
        
        # Depth labels on Y axis
        c.setFillColor(DARK)
        c.setFont("Helvetica", 7)
        c.setStrokeColor(HexColor("#AAAAAA"))
        c.setLineWidth(0.3)
        c.line(col_coupe_x - 0.3*cm, y_top, col_coupe_x, y_top)
        c.drawRightString(col_coupe_x - 0.4*cm, y_top - 3, f"{layer['de']:.1f}")
    
    # Last layer bottom depth
    last = data["layers"][-1]
    y_bot_last = marg_top - last["a"] * scale
    c.setFillColor(DARK)
    c.setFont("Helvetica", 7)
    c.setStrokeColor(HexColor("#AAAAAA"))
    c.setLineWidth(0.3)
    c.line(col_coupe_x - 0.3*cm, y_bot_last, col_coupe_x, y_bot_last)
    c.drawRightString(col_coupe_x - 0.4*cm, y_bot_last - 3, f"{last['a']:.1f}")
    
    # Annulaire (remplissage graphique simplifié)
    c.setFillColor(HexColor("#B0BEC5"))
    c.setStrokeColor(HexColor("#666666"))
    c.setLineWidth(0.3)
    annul_depth = min(data["prof_forage"], 5.0)
    y_annul_top = marg_top
    y_annul_bot = marg_top - annul_depth * scale
    c.rect(col_annulaire_x, y_annul_bot, col_annulaire_w, y_annul_top - y_annul_bot, fill=1, stroke=1)
    c.setFillColor(DARK)
    c.setFont("Helvetica", 6.5)
    c.drawCentredString(col_annulaire_x + col_annulaire_w/2, y_annul_bot + 5, "Bentonite")
    
    # Niveau statique (NS) — ligne bleue tiretée avec ▽
    y_ns = marg_top - data["ns"] * scale
    c.setStrokeColor(BLUE)
    c.setLineWidth(1.5)
    c.setDash(5, 3)
    c.line(col_coupe_x - 0.8*cm, y_ns, col_coupe_x + col_coupe_w + 1*cm, y_ns)
    c.setDash()
    c.setFillColor(BLUE)
    c.setFont("Helvetica-Bold", 8)
    c.drawString(col_coupe_x + col_coupe_w + 1.1*cm, y_ns - 3, f"▽ n.s. = {data['ns']:.2f} m")
    # Blue triangle symbol
    c.setFillColor(BLUE)
    p = c.beginPath()
    p.moveTo(col_coupe_x - 0.8*cm, y_ns)
    p.lineTo(col_coupe_x - 1.3*cm, y_ns - 5)
    p.lineTo(col_coupe_x - 1.3*cm, y_ns + 5)
    p.close()
    c.drawPath(p, fill=1, stroke=0)
    
    # Arrivée d'eau — flèche bleue foncée
    ae_depth = data["arrivee_eau"]
    y_ae = marg_top - ae_depth * scale
    c.setStrokeColor(HexColor("#0056B3"))
    c.setLineWidth(1.5)
    c.setDash(3, 2)
    c.line(col_coupe_x - 0.5*cm, y_ae, col_venues_x + col_venues_w + 0.3*cm, y_ae)
    c.setDash()
    c.setFillColor(HexColor("#0056B3"))
    c.setFont("Helvetica-Bold", 8)
    c.drawString(col_venues_x + col_venues_w + 0.4*cm, y_ae - 3,
                 f"↘ arrivée d'eau {ae_depth:.2f} m")
    # Qi values for saturated layers
    for layer in data["layers"]:
        if layer["Q_i"] > 0:
            y_mid = marg_top - (layer["de"] + layer["a"]) / 2 * scale
            # Water drop symbol in venues column
            c.setFillColor(BLUE)
            c.circle(col_venues_x + col_venues_w/2, y_mid, 4, fill=1, stroke=0)
            c.setFillColor(white)
            c.setFont("Helvetica-Bold", 6)
            c.drawCentredString(col_venues_x + col_venues_w/2, y_mid - 2, "●")
            # Qi value
            c.setFillColor(GREEN)
            c.setFont("Helvetica-Bold", 7)
            c.drawString(col_qi_x + 2, y_mid - 3, f"{layer['Q_i']:.5f}")
    
    # FF — ligne rouge tiretée
    y_ff = marg_top - data["ff"] * scale
    c.setStrokeColor(RED)
    c.setLineWidth(1.5)
    c.setDash(4, 2)
    c.line(col_coupe_x, y_ff, col_coupe_x + col_coupe_w + 0.5*cm, y_ff)
    c.setDash()
    c.setFillColor(RED)
    c.setFont("Helvetica-Bold", 8)
    c.drawString(col_coupe_x + col_coupe_w + 0.6*cm, y_ff - 3, f"FF = {data['ff']:.2f} m")
    
    # Zone saturée (NS→FF) hachurée bleue
    y_ns_pos = marg_top - data["ns"] * scale
    y_ff_pos = marg_top - data["ff"] * scale
    if y_ns_pos > y_ff_pos:
        c.setFillColor(HexColor("#1565C022"))
        c.rect(col_coupe_x, y_ff_pos, col_coupe_w, y_ns_pos - y_ff_pos, fill=1, stroke=0)
    
    # Échelle (1/20 approximatif)
    c.setFont("Helvetica-Oblique", 7.5)
    c.setFillColor(GREY)
    c.drawString(col_comment_x, marg_top + 0.1*cm - 0.3*cm, "Échelle graphique")
    # Scale bar
    scale_bar_length = 1.0 * scale  # 1 meter on paper
    c.setStrokeColor(DARK)
    c.setLineWidth(1)
    scale_x = col_comment_x
    scale_y = marg_top - 0.5*cm
    c.line(scale_x, scale_y, scale_x + scale_bar_length, scale_y)
    c.line(scale_x, scale_y - 3, scale_x, scale_y + 3)
    c.line(scale_x + scale_bar_length, scale_y - 3, scale_x + scale_bar_length, scale_y + 3)
    c.setFont("Helvetica", 7)
    c.drawCentredString(scale_x + scale_bar_length/2, scale_y - 10, "1 m")
    
    # Total Q legend box
    legend_y = marg_bot - 0.2*cm
    q_total = sum(l["Q_i"] for l in data["layers"])
    c.setFillColor(HexColor("#E3F0FF"))
    c.roundRect(col_coupe_x, legend_y, W - col_coupe_x - marg_right, 0.6*cm, 4, fill=1, stroke=1)
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 8)
    c.drawCentredString(W/2, legend_y + 8, 
        f"Q total multicouche = {q_total:.4f} m³/h — s = {data['rabattement']:.2f} m — NS = {data['ns']:.2f} m/TN")
    
    # Footer — deux lignes pour éviter chevauchement
    c.setFillColor(LGREY)
    c.rect(0, 0, W, 40, fill=1, stroke=0)
    # Ligne du haut : Lambert-93 (centré)
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 7.5)
    c.drawCentredString(W/2, 26, 
        f"Lambert-93 métrique   Long.: {data['x_l93']}   Lat.: {data['y_l93']}   Alt.: +{data['z_alt']} m NGF")
    # Ligne du bas : document propriétaire à gauche, n° page à droite
    c.setFillColor(GREY)
    c.setFont("Helvetica", 7.5)
    c.drawString(1.5*cm, 11, "Coupe Géologique G.M.E.P — Document propriétaire — gmep.france@gmail.com")
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 9)
    c.drawRightString(W - 1.5*cm, 11, "Page 3 / 3")

# ─── Build PDF ────────────────────────────────────────────────────────────────
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate

class ThreePageDoc(BaseDocTemplate):
    def __init__(self, filename, **kwargs):
        super().__init__(filename, **kwargs)
        self.page_count = 0

doc = SimpleDocTemplate(
    OUTPUT,
    pagesize=A4,
    title=f"Note Technique Forage G.M.E.P — {DATA['nom_forage']} — v15.82",
    author="G.M.E.P",
    subject="Coupe Géologique G.M.E.P — Document propriétaire",
    leftMargin=2*cm, rightMargin=2*cm,
    topMargin=2.5*cm, bottomMargin=2.2*cm,
)

story = []

# Page 1
build_page1(story, DATA)
story.append(PageBreak())

# Page 2
build_page2(story, DATA)
story.append(PageBreak())

# Page 3 — coupe graphique : aucun flowable (dessin entièrement en canvas)
# Un Spacer minimal force la page à exister sans superposer de paragraph
story.append(Spacer(1, 1))

_page3_drawn = [False]

def on_page_combined(c, doc):
    if doc.page == 3 and not _page3_drawn[0]:
        # Clear the story content on page 3 - draw graphic coupe
        c.saveState()
        build_page3_canvas(c, DATA)
        c.restoreState()
        _page3_drawn[0] = True
    elif doc.page < 3:
        on_page(c, doc)

doc.build(story, onFirstPage=on_page_combined, onLaterPages=on_page_combined)
print(f"PDF généré : {OUTPUT}")

import os
size_kb = os.path.getsize(OUTPUT) / 1024
print(f"Taille : {size_kb:.0f} Ko")
