# RAPPORT DE VALIDATION — GMEP Rabattement de Nappe v15.82
**Date :** 28 mai 2026  
**Ingénieur :** Éric Azulay — G.M.E.P Géotechnique Milieu Environnement Protection  
**Référence :** GMEP-VALID-v15.82  

---

## 1. RÉSUMÉ DES CORRECTIONS v15.82

### Bug #1 — Q_i = 0 dans le tableau lithologie (cellules J27:J41)

**Cause racine :**  
La cellule C45 (Rayon d'influence Sichardt) utilisait la formule :
```
=3000*C44*SQRT(SUMPRODUCT(MAX(IFERROR(F27:F41*1,0))))
```
La combinaison `SUMPRODUCT(MAX(...))` n'est **pas** une formule matricielle validée par Ctrl+Shift+Enter dans Excel. En dehors de ce mode CSE (Ctrl+Shift+Enter), `MAX(IFERROR(F27:F41*1,0))` est évalué comme `MAX()` d'un seul scalaire (le premier élément de plage), pas le maximum de la plage entière. Le résultat retourné était `0` ou `#VALEUR!`, ce qui rendait le terme `LN(C45/C20) = LN(0/r)` indéfini, forçant toutes les formules `Q_i` à retourner `0` via le `IFERROR`.

**Correction v15.82 :**
```
C45 = =IFERROR(IF(C44>0,3000*C44*SQRT(MAX(F27:F41)),0),0)
```
`MAX(F27:F41)` est une fonction native Excel qui parcourt la plage sans avoir besoin du mode CSE. Les cellules vides ou en erreur sont naturellement ignorées.

**Correction C47 (T_eq) :**
```
C47 = =IFERROR(SUMPRODUCT(IFERROR(F27:F41*1,0),IFERROR(I27:I41*1,0)),0)
```

---

## 2. VALIDATION CALCUL Q_i — CAS OUCQUES

### 2.1 Paramètres du site

| Paramètre | Valeur |
|-----------|--------|
| Commune | Oucques-la-Nouvelle (41171) |
| Référence parcelle | AC 0007 |
| Niveau statique NS | 1,70 m/TN |
| Fond de fouille FF | 2,80 m/TN |
| Rabattement s = FF − NS | **1,10 m** |
| Rayon puits r | 0,056 m |
| Altitude tête puits (TN) | 125,50 m NGF |

### 2.2 Tableau lithologique (3 couches saisies)

| N° | Libellé | De (m) | À (m) | K (m/s) | Saturée ? | e_sat (m) |
|----|---------|--------|-------|---------|-----------|-----------|
| 1 | Remblai hétérogène | 0,00 | 1,20 | 1×10⁻⁵ | **NON** | 0,00 |
| 2 | Marno-calcaire fissuré | 1,20 | 2,80 | 1×10⁻⁶ | **OUI** | **1,10** |
| 3 | Calcaire de Beauce | 2,80 | 3,00 | 5×10⁻⁴ | **NON** | 0,00 |

**Justification saturation :**
- Couche 1 : À = 1,20 m < NS = 1,70 m → NON saturée ✓
- Couche 2 : De = 1,20 m < FF = 2,80 m ET À = 2,80 m > NS = 1,70 m → OUI, e_sat = MIN(2,80 ; 2,80) − MAX(1,20 ; 1,70) = 2,80 − 1,70 = **1,10 m** ✓
- Couche 3 : De = 2,80 m = FF → pas d'intersection au-dessus de FF → NON saturée ✓

### 2.3 Calcul du rayon d'influence Sichardt

```
K_max = MAX(K_1, K_2, K_3) = MAX(1×10⁻⁵, 1×10⁻⁶, 5×10⁻⁴) = 5×10⁻⁴ m/s
       (Calcaire de Beauce — couche 3)

R_Sichardt = 3000 × s × √(K_max)
           = 3000 × 1,10 × √(5×10⁻⁴)
           = 3300 × 0,02236
           = 73,79 m
```

### 2.4 Calcul des débits par couche (formule Forchheimer/Dupuit)

Formule appliquée : `Q_i = 2π × K_i × e_sat_i × s / ln(R/r) × 3600` [m³/h]

Terme logarithmique commun :
```
ln(R/r) = ln(73,79 / 0,056) = ln(1317,7) = 7,184
```

| Couche | K_i (m/s) | e_sat_i (m) | s (m) | ln(R/r) | Q_i (m³/h) |
|--------|-----------|-------------|-------|---------|------------|
| Remblai hétérogène | 1×10⁻⁵ | 0,00 | 1,10 | 7,184 | **0,00000** |
| Marno-calcaire fissuré | 1×10⁻⁶ | 1,10 | 1,10 | 7,184 | **0,00381** |
| Calcaire de Beauce | 5×10⁻⁴ | 0,00 | 1,10 | 7,184 | **0,00000** |

**Calcul détaillé Q_2 (couche saturée) :**
```
Q_2 = 2π × 1×10⁻⁶ × 1,10 × 1,10 / 7,184 × 3600
    = 2π × 1,21×10⁻⁶ × 3600 / 7,184
    = 2π × 4,354×10⁻³ / 7,184
    = 2π × 6,060×10⁻⁴
    = 3,808×10⁻³ m³/h
    ≈ 0,00381 m³/h
```

### 2.5 Bilan et classification IOTA

| Grandeur | Valeur |
|----------|--------|
| **Q_total** | **≈ 0,00381 m³/h** (versus 0 m³/h en v15.81) |
| V_jour | 0,00381 × 24 = 0,0915 m³/j |
| **V_annuel** | 0,00381 × 24 × 365 = **33,4 m³/an** |
| Classification IOTA R.214-1 | **HORS NOMENCLATURE** (< 10 000 m³/an) |

> Le correctif C45 fait passer Q_total de 0 m³/h (v15.81, formule matricielle défaillante) à ~0,004 m³/h (v15.82, formule MAX native). La classification reste HORS NOMENCLATURE, ce qui est cohérent avec les faibles perméabilités interceptées.

---

## 3. CORRECTION PDF — COUPE FORAGE RÉELLE

### 3.1 Comportement antérieur (v15.81)

Le PDF « Dossier de déclaration Loi sur l'Eau » affichait une coupe lithologique **régionale projetée** basée sur des hypothèses BRGM de la Petite Beauce :
- Limons / Argile à silex (0−4 m)
- Sables et argiles de l'Orléanais (4−14 m)
- Marnes (14−18 m)
- Calcaires de Beauce / Stampien (18 m → profond)

Ces données ne correspondaient PAS à la coupe saisie par l'utilisateur dans l'onglet Coupe Géologique G.M.E.P.

### 3.2 Comportement v15.82

Le module `coupe_lithologique.py` a été entièrement réécrit :

**Nouvelle fonction principale :** `schema_coupe_forage_reelle()`

**Source des données :**
- Cellules B27:J41 de l'onglet `Coupe_Geologique` (couches réelles saisies)
- C11 → altitude TN (m NGF)
- C18 → NS (niveau statique, m/TN)
- C19 → FF (fond de fouille, m/TN)
- C17 → profondeur totale forée (m)
- C12 → profondeur arrivée d'eau constatée (m/TN)

**Fonctionnalités graphiques :**
- Hachures lithologiques adaptatives selon la famille de roche (Argile : obliques, Sable : points, Calcaire : briques, Marne : horizontales, Remblai : vagues, Socle : croix)
- Cotes NGF annotées à droite pour chaque interface de couche
- Repère NS (triangle bleu ▽ avec ligne tiretée bleue) et FF (ligne rouge tireté-point)
- Flèche d'arrivée d'eau constatée (si C12 renseigné)
- Schéma tubage (rectangle fond blanc, bordure anthracite, eau en bleu)
- Axe vertical gauche « Profondeur / TN (m) »
- Axe vertical droit « Cote (m NGF) »

**Fonction `lire_coupe_xlsm()` :**
- Lit l'onglet `Coupe_Geologique` du xlsm
- Si le fichier trouvé est un `.xlsx` sans cet onglet, cherche automatiquement le `.xlsm` adjacent
- Résout les valeurs K via la table `_GMEP_Listes_v79` (VLOOKUP local)
- Recalcule e_sat localement si la valeur cache est nulle

### 3.3 Cas de test v15.82 — Coupe Oucques

Données lues depuis `Modelisation_Rabattement_TSN_GMEP.xlsm` :
```
z_tn = 125,50 m NGF | NS = 1,70 m | FF = 2,80 m
Couche 1 : Remblai hétérogène  0,00→1,20 m, K=1e-5, e_sat=0,00 m ← non saturée
Couche 2 : Marno-calcaire fissuré 1,20→2,80 m, K=1e-6, e_sat=1,10 m ← saturée
Couche 3 : Calcaire de Beauce 2,80→3,00 m, K=5e-4, e_sat=0,00 m ← non saturée
```

---

## 4. CONTRÔLES QUALITÉ

### 4.1 Grep G€SF0R (zéro occurrence attendue)

```bash
grep -r "G€SF0R" /tmp/v1582/ --include="*.py" --include="*.html" --include="*.txt" --include="*.md"
```
Résultat : **0 occurrence** ✓

### 4.2 Module propriétaire

Toutes les références à la "Coupe Géologique" portent la mention :
> "Coupe Géologique G.M.E.P — Module propriétaire"

### 4.3 Invariants préservés

| Invariant | Statut |
|-----------|--------|
| Modèle IOTA R.214-1 (seuils 10 000 / 200 000 m³/an) | ✓ Inchangé |
| Formule Forchheimer/Dupuit multicouche | ✓ Inchangée |
| 42 lithologies _GMEP_Listes_v79 | ✓ Préservées |
| Code VBA xlsm (vbaProject.bin) | ✓ Non modifié (keep_vba=True) |
| Tarifs : EQRS 245€/mois, TSN 850€/an, Rabattement 1100€/an | ✓ Gelés |
| Références BRGM, IGN, EPA 2004, ANSES 2018, INERIS | ✓ Inchangées |

---

## 5. LIVRABLES v15.82

| Fichier | Description | Taille |
|---------|-------------|--------|
| `Modelisation_Rabattement_TSN_GMEP.xlsm` | C45 corrigé + données test Oucques | ~2,5 Mo |
| `rabattement-tool.html` | Version v15.82 (calcul JS déjà correct) | ~230 Ko |
| `generate_rapport_loi_eau.py` | Coupe réelle depuis Coupe_Geologique | ~297 Ko |
| `coupe_lithologique.py` | Réécriture complète v15.82 | ~20 Ko |
| `Note_Methodologique_v15_82.pdf` | Section 2.6 R_Sichardt ajoutée | ~29 Ko |
| `Note_Technique_Forage_G_M_E_P_Exemple.pdf` | Labels v15.82 | ~10 Ko |
| `Dossier_Declaration_Loi_Eau_GMEP.pdf` | Coupe réelle intégrée | ~5 Mo |
| `RAPPORT_VALIDATION_GMEP_Rabattement_v15.82.md` | Ce fichier | — |
| `NOTES_v15.82.txt` | Changelog | — |

---

## 6. CONTACTS

**Éric AZULAY** — Ingénieur Hydrogéologue  
**G.M.E.P — Géotechnique Milieu Environnement Protection**  
9 rue de la Marne, 79400 Saint-Maixent-l'École  
gmep.france@gmail.com

---
*Coupe Géologique G.M.E.P — Module propriétaire — © G.M.E.P 2026*
