@echo off
REM ================================================================
REM  G.M.E.P -- Generer le PDF (Windows) - v15.62b
REM  Compatible chemins avec apostrophes/espaces/accents/OneDrive.
REM ================================================================

setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1

REM Se placer dans le dossier du script (gere apostrophes, espaces, OneDrive)
pushd "%~dp0" >nul

color 1F
title G.M.E.P - Generation du PDF v15.62b

REM Log de secours sur le bureau
set "LOG=%USERPROFILE%\Desktop\GMEP_DerniereExecution.log"
> "%LOG%" echo === GMEP Generation PDF - %DATE% %TIME% ===
>> "%LOG%" echo Dossier : %CD%
>> "%LOG%" echo.

echo.
echo ================================================================
echo   G.M.E.P  --  Generation du Dossier Loi sur l'Eau  (v15.62b)
echo ================================================================
echo.
echo   Dossier de travail : %CD%
echo   Log de secours     : %LOG%
echo.

REM ----------------------------------------------------------------
REM 1) Verifier le script Python
REM ----------------------------------------------------------------
if not exist "generate_rapport_loi_eau.py" (
    echo  [ERREUR] generate_rapport_loi_eau.py introuvable dans :
    echo  %CD%
    >> "%LOG%" echo [ERREUR] generate_rapport_loi_eau.py introuvable
    echo.
    pause
    popd >nul
    exit /b 1
)

REM ----------------------------------------------------------------
REM 2) Chercher le fichier Excel (sans for /f pour eviter apostrophes)
REM ----------------------------------------------------------------
set "EXCEL_FILE="
if exist "Modelisation_Rabattement_TSN_GMEP.xlsm" set "EXCEL_FILE=Modelisation_Rabattement_TSN_GMEP.xlsm"
if not defined EXCEL_FILE if exist "Modelisation_Rabattement_TSN_GMEP.xlsx" set "EXCEL_FILE=Modelisation_Rabattement_TSN_GMEP.xlsx"

if not defined EXCEL_FILE (
    echo  [ERREUR] Aucun fichier Modelisation_Rabattement_TSN_GMEP.xls* trouve.
    >> "%LOG%" echo [ERREUR] Aucun fichier Excel
    pause
    popd >nul
    exit /b 1
)

echo   Fichier Excel detecte  : !EXCEL_FILE!
>> "%LOG%" echo Fichier Excel : !EXCEL_FILE!
echo.

REM ----------------------------------------------------------------
REM 3) Chercher Python (sans for /f sur where)
REM ----------------------------------------------------------------
set "PYTHON_EXE="

if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYTHON_EXE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYTHON_EXE if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PYTHON_EXE if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
if not defined PYTHON_EXE if exist "C:\Program Files\Python313\python.exe" set "PYTHON_EXE=C:\Program Files\Python313\python.exe"
if not defined PYTHON_EXE if exist "C:\Program Files\Python312\python.exe" set "PYTHON_EXE=C:\Program Files\Python312\python.exe"
if not defined PYTHON_EXE if exist "C:\Program Files\Python311\python.exe" set "PYTHON_EXE=C:\Program Files\Python311\python.exe"
if not defined PYTHON_EXE if exist "C:\Program Files\Python310\python.exe" set "PYTHON_EXE=C:\Program Files\Python310\python.exe"

if not defined PYTHON_EXE (
    echo  [ERREUR] Python n'est pas installe sur ce PC.
    echo.
    echo  Installer Python depuis https://www.python.org/downloads/
    echo  Cocher "Add Python to PATH" pendant l'installation.
    >> "%LOG%" echo [ERREUR] Python introuvable
    echo.
    pause
    popd >nul
    exit /b 1
)

echo   Python detecte         : !PYTHON_EXE!
>> "%LOG%" echo Python : !PYTHON_EXE!

REM ----------------------------------------------------------------
REM 4) Verifier/installer les modules Python
REM ----------------------------------------------------------------
echo   Verification des modules Python...
"!PYTHON_EXE!" -c "import openpyxl, reportlab, PIL, matplotlib, requests" >nul 2>&1
if errorlevel 1 (
    echo   Installation des modules manquants ^(1-2 minutes^)...
    "!PYTHON_EXE!" -m pip install --quiet openpyxl reportlab Pillow matplotlib requests
    if errorlevel 1 (
        echo  [ERREUR] Echec installation des modules Python.
        >> "%LOG%" echo [ERREUR] pip install a echoue
        pause
        popd >nul
        exit /b 1
    )
)
echo   Modules : OK
>> "%LOG%" echo Modules : OK
echo.

REM ----------------------------------------------------------------
REM 5) UTF-8
REM ----------------------------------------------------------------
set PYTHONUTF8=1
set PYTHONIOENCODING=utf-8:replace

REM ----------------------------------------------------------------
REM 6) Fermer Excel s'il est ouvert (PowerShell — robuste apostrophes)
REM ----------------------------------------------------------------
echo   Fermeture d'Excel et liberation du fichier...
>> "%LOG%" echo Fermeture Excel...

powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $xl = [Runtime.InteropServices.Marshal]::GetActiveObject('Excel.Application'); if ($xl) { foreach ($wb in @($xl.Workbooks)) { if ($wb.Name -match 'Rabattement|Modelisation') { $wb.Save(); $wb.Close($false) } }; if ($xl.Workbooks.Count -eq 0) { $xl.Quit() }; [Runtime.InteropServices.Marshal]::ReleaseComObject($xl) | Out-Null } } catch {}" >nul 2>&1

REM Supprimer les verrous orphelins ~$ dans le dossier courant
if exist "~$*.xls*" del /q "~$*.xls*" >nul 2>&1

REM Attente OneDrive
ping -n 4 127.0.0.1 >nul 2>&1
>> "%LOG%" echo Excel ferme et verrous nettoyes.

REM ----------------------------------------------------------------
REM 7) Lancer Python EN DIRECT (sortie console + log)
REM ----------------------------------------------------------------
echo.
echo ================================================================
echo   Lancement de la generation du PDF...
echo   Duree estimee : 30 a 90 secondes. NE FERMEZ PAS cette fenetre.
echo ================================================================
echo.

>> "%LOG%" echo.
>> "%LOG%" echo === SORTIE PYTHON ===

REM Sortie directe a l'ecran ET dans le log via PowerShell Tee-Object
"!PYTHON_EXE!" -X utf8 -u "generate_rapport_loi_eau.py" "!EXCEL_FILE!" 2>&1
set "PYRET=!ERRORLEVEL!"

>> "%LOG%" echo === FIN SORTIE PYTHON (code !PYRET!) ===

echo.
echo ================================================================

if not "!PYRET!"=="0" (
    echo  [ERREUR] La generation a echoue ^(code !PYRET!^).
    echo  Voir le log : %LOG%
    echo ================================================================
    >> "%LOG%" echo [ERREUR] Python code !PYRET!
    echo.
    pause
    popd >nul
    exit /b !PYRET!
)

REM ----------------------------------------------------------------
REM 8) Verifier que le PDF a bien ete genere
REM ----------------------------------------------------------------
set "PDF_FILE=Dossier_Declaration_Loi_Eau_GMEP.pdf"
if not exist "!PDF_FILE!" (
    echo  [ERREUR] Le PDF !PDF_FILE! n'a pas ete cree.
    >> "%LOG%" echo [ERREUR] PDF non genere
    echo ================================================================
    echo.
    pause
    popd >nul
    exit /b 1
)

echo  PDF genere avec succes : %CD%\!PDF_FILE!
>> "%LOG%" echo [OK] PDF genere : %CD%\!PDF_FILE!
echo ================================================================
echo.
echo  Ouverture du PDF dans 2 secondes...
ping -n 3 127.0.0.1 >nul 2>&1

start "" "%CD%\!PDF_FILE!"

echo.
echo  Generation terminee. Fermeture automatique dans 5 secondes...
ping -n 6 127.0.0.1 >nul 2>&1

popd >nul
exit /b 0
