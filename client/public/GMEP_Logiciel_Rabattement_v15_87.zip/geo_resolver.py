# -*- coding: utf-8 -*-
"""
geo_resolver.py — Résolution géographique automatique à partir de X/Y Lambert 93
================================================================================
À partir des coordonnées Lambert 93 (X, Y) d'un projet de forage, ce module
résout automatiquement TOUS les paramètres réglementaires et hydrogéologiques
du dossier Loi sur l'Eau :

  • Commune (nom, code INSEE)
  • Département (numéro, nom)
  • Région administrative
  • Bassin DCE (Loire-Bretagne, Seine-Normandie, Rhône-Méditerranée, etc.)
  • Agence de l'eau et SDAGE applicable
  • Masse d'eau souterraine (code SANDRE FRGGxxx + libellé)
  • Entités hydrogéologiques BDLISA
  • Statut ZRE (Zone de Répartition des Eaux) — par référentiel embarqué
  • Coordonnées WGS84 (lat, lon) pour cartographie

Sources :
  • API geo.api.gouv.fr (commune par lat/lon)
  • API hubeau.eaufrance.fr (qualité nappes — masse d'eau souterraine, bassin DCE)
  • Référentiel ZRE embarqué (liste officielle AELB + autres bassins)

Cache local pour limiter les appels API. Repli gracieux en cas d'absence réseau.
"""
from __future__ import annotations
import json
import os
import urllib.request
import urllib.error
from typing import Optional

try:
    from pyproj import Transformer
    _HAS_PYPROJ = True
except ImportError:
    _HAS_PYPROJ = False

CACHE_FILE = os.path.join(os.path.dirname(__file__), ".geo_cache.json")
HTTP_TIMEOUT = 12
USER_AGENT = "GMEP-LoiSurEau/1.0 (gmep.france@gmail.com)"

# ─────────────────────────────────────────────────────────────────────────────
# RÉFÉRENTIEL ZRE — Liste officielle des communes en Zone de Répartition des Eaux
# ─────────────────────────────────────────────────────────────────────────────
# Sources :
#   AELB — Liste officielle ZRE Nappe de Beauce (mise à jour 30/12/2024)
#         arrêté préfectoral n°2006-272-3 et arrêté DREAL Centre-Val de Loire n°23.001 du 03/01/2023
#   AERMC — ZRE Crau, Astien, Plio-quaternaire de la Crau (arrêté du 19/12/2003)
#   AESN — ZRE Beauce nord, Champigny, Albien-Néocomien
#   AEAG — ZRE Astérien, Plio-quaternaire de l'Hérault
#   AEAP — Pas de ZRE actives recensées
#   AERM — ZRE Plaine d'Alsace (arrêté du 11/04/2017)
#
# Format : {code_INSEE: {"nappe": "Nom de la nappe", "arrete": "Référence arrêté",
#                         "bassin": "Loire-Bretagne", "date_maj": "30/12/2024"}}
#
# Pour Oucques-la-Nouvelle (41171 — fusion 2019 de Baigneaux 41010,
# Beauvilliers 41014, Oucques 41170, Sainte-Gemmes 41216) :

ZRE_REGISTRY = {
    # ─────── BASSIN LOIRE-BRETAGNE — Nappe de Beauce ───────
    # Liste 2024 (extrait — communes 41 / 45 / 28 / 91 concernées par la Beauce)
    # Loir-et-Cher (41) — communes ZRE Beauce
    "41171": {"nappe": "Nappe de Beauce",
              "arrete": "Arrêté préfectoral n°2006-272-3 + DREAL Centre-Val de Loire n°23.001 (03/01/2023)",
              "bassin": "Loire-Bretagne",
              "agence_eau": "Agence de l'Eau Loire-Bretagne (AELB)",
              "sdage": "SDAGE Loire-Bretagne 2022-2027",
              "sage": "SAGE Nappe de Beauce et milieux aquatiques associés",
              "date_maj": "30/12/2024",
              "communes_deleguees": ["Baigneaux", "Beauvilliers", "Oucques", "Sainte-Gemmes"]},
    # Note : la liste complète Beauce (~600 communes) peut être ajoutée ultérieurement
    # via un CSV externe. Pour l'instant, on définit Oucques-la-Nouvelle + un échantillon
    # représentatif. Les autres communes ZRE peuvent être détectées par le bassin DCE
    # et l'emprise géographique de la nappe (fallback ci-dessous).

    # Eure-et-Loir (28) — exemples emblématiques Beauce
    "28085": {"nappe": "Nappe de Beauce", "arrete": "Arrêté DREAL CVL n°23.001 (03/01/2023)",
              "bassin": "Loire-Bretagne", "agence_eau": "AELB",
              "sdage": "SDAGE Loire-Bretagne 2022-2027", "sage": "SAGE Nappe de Beauce",
              "date_maj": "30/12/2024", "communes_deleguees": []},  # Chartres (exemple)
    "28250": {"nappe": "Nappe de Beauce", "arrete": "Arrêté DREAL CVL n°23.001 (03/01/2023)",
              "bassin": "Loire-Bretagne", "agence_eau": "AELB",
              "sdage": "SDAGE Loire-Bretagne 2022-2027", "sage": "SAGE Nappe de Beauce",
              "date_maj": "30/12/2024", "communes_deleguees": []},  # Janville-en-Beauce

    # Loiret (45) — exemples
    "45234": {"nappe": "Nappe de Beauce", "arrete": "Arrêté DREAL CVL n°23.001 (03/01/2023)",
              "bassin": "Loire-Bretagne", "agence_eau": "AELB",
              "sdage": "SDAGE Loire-Bretagne 2022-2027", "sage": "SAGE Nappe de Beauce",
              "date_maj": "30/12/2024", "communes_deleguees": []},  # Pithiviers

    # Note sur la résolution ZRE par fallback géographique :
    # Si la commune n'est pas dans le registre explicite, on applique une heuristique
    # basée sur le bassin DCE et l'emprise de la nappe (approximation BBox).
}

# Emprises ZRE par bassin DCE (fallback BBox — uniquement pour signaler une
# présomption ZRE quand la commune exacte n'est pas dans le registre)
# Coordonnées Lambert 93 (X, Y)
ZRE_BBOX_FALLBACK = [
    {"nappe": "Nappe de Beauce",
     "bassin": "Loire-Bretagne", "agence_eau": "AELB",
     "sdage": "SDAGE Loire-Bretagne 2022-2027", "sage": "SAGE Nappe de Beauce",
     "xmin": 570000, "xmax": 720000, "ymin": 6720000, "ymax": 6850000,
     "departements": ["28", "45", "41", "91", "77"],
     "presomption": True},
    {"nappe": "Nappe de la Crau (Plio-quaternaire)",
     "bassin": "Rhône-Méditerranée", "agence_eau": "AERMC",
     "sdage": "SDAGE Rhône-Méditerranée 2022-2027", "sage": "SAGE Crau",
     "xmin": 845000, "xmax": 895000, "ymin": 6260000, "ymax": 6300000,
     "departements": ["13"],
     "presomption": True},
    {"nappe": "Plaine d'Alsace (nappe phréatique)",
     "bassin": "Rhin-Meuse", "agence_eau": "AERM",
     "sdage": "SDAGE Rhin-Meuse 2022-2027", "sage": "SAGE Ill-Nappe-Rhin",
     "xmin": 990000, "xmax": 1060000, "ymin": 6750000, "ymax": 6950000,
     "departements": ["67", "68"],
     "presomption": True},
    {"nappe": "Nappe de l'Astien",
     "bassin": "Rhône-Méditerranée", "agence_eau": "AERMC",
     "sdage": "SDAGE Rhône-Méditerranée 2022-2027", "sage": "SAGE Astien",
     "xmin": 720000, "xmax": 760000, "ymin": 6240000, "ymax": 6280000,
     "departements": ["34"],
     "presomption": True},
    {"nappe": "Albien-Néocomien (captif)",
     "bassin": "Seine-Normandie", "agence_eau": "AESN",
     "sdage": "SDAGE Seine-Normandie 2022-2027", "sage": "SAGE Albien",
     "xmin": 600000, "xmax": 720000, "ymin": 6840000, "ymax": 6920000,
     "departements": ["75", "77", "78", "91", "92", "93", "94", "95"],
     "presomption": True},
]

# ─────────────────────────────────────────────────────────────────────────────
# CACHE LOCAL (réduit les appels API)
# ─────────────────────────────────────────────────────────────────────────────
def _load_cache() -> dict:
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def _save_cache(cache: dict) -> None:
    try:
        with open(CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

# ─────────────────────────────────────────────────────────────────────────────
# CONVERSION L93 → WGS84
# ─────────────────────────────────────────────────────────────────────────────
def lambert93_to_wgs84(x: float, y: float) -> tuple[float, float]:
    """Convertit Lambert 93 (X, Y en mètres) en WGS84 (lon, lat en degrés).
    Retourne (lon, lat). Repli analytique si pyproj absent (précision ~5 m)."""
    if _HAS_PYPROJ:
        t = Transformer.from_crs("EPSG:2154", "EPSG:4326", always_xy=True)
        lon, lat = t.transform(x, y)
        return lon, lat
    # Repli analytique (formules IGN — précision ~10 m suffisante pour lookup commune)
    import math
    n = 0.7256077650
    c = 11754255.426
    Xs = 700000.0
    Ys = 12655612.050
    e = 0.0818191910428
    lon0 = math.radians(3.0)
    R = math.hypot(x - Xs, y - Ys)
    g = math.atan((x - Xs) / (Ys - y))
    lon_rad = lon0 + g / n
    lat_iso = -math.log(R / c) / n
    lat = 2 * math.atan(math.exp(lat_iso)) - math.pi / 2
    for _ in range(8):
        lat = 2 * math.atan(((1 + e * math.sin(lat)) / (1 - e * math.sin(lat))) ** (e / 2)
                            * math.exp(lat_iso)) - math.pi / 2
    return math.degrees(lon_rad), math.degrees(lat)

# ─────────────────────────────────────────────────────────────────────────────
# REQUÊTES API
# ─────────────────────────────────────────────────────────────────────────────
def _http_get_json(url: str) -> Optional[dict | list]:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=HTTP_TIMEOUT) as resp:
            return json.loads(resp.read())
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError):
        return None
    except Exception:
        return None

def get_commune_by_coords(lon: float, lat: float, cache: dict | None = None) -> dict:
    """Récupère la commune via geo.api.gouv.fr.
    Retourne {nom, code_insee, code_dpt, code_region, region_nom}."""
    key = f"commune_{lon:.5f}_{lat:.5f}"
    if cache is not None and key in cache:
        return cache[key]
    url = (f"https://geo.api.gouv.fr/communes?lat={lat}&lon={lon}"
           f"&fields=nom,code,codeDepartement,codeRegion&format=json")
    data = _http_get_json(url)
    result = {"nom": "—", "code_insee": "—", "code_dpt": "—", "code_region": "—"}
    if data and isinstance(data, list) and data:
        c = data[0]
        result = {
            "nom": c.get("nom", "—"),
            "code_insee": c.get("code", "—"),
            "code_dpt": c.get("codeDepartement", "—"),
            "code_region": c.get("codeRegion", "—"),
        }
    if cache is not None:
        cache[key] = result
    return result

def get_masse_eau_souterraine(lon: float, lat: float, cache: dict | None = None) -> dict:
    """Récupère la masse d'eau souterraine via Hub'Eau (qualité nappes).
    Retourne {code_sandre, libelle, urn, bassin_dce, code_bassin, bdlisa}."""
    key = f"meso_{lon:.5f}_{lat:.5f}"
    if cache is not None and key in cache:
        return cache[key]
    delta = 0.05
    url = (f"https://hubeau.eaufrance.fr/api/v1/qualite_nappes/stations"
           f"?bbox={lon-delta},{lat-delta},{lon+delta},{lat+delta}&size=10&format=json")
    data = _http_get_json(url)
    result = {
        "code_sandre": "—", "libelle": "—", "urn": "—",
        "bassin_dce": "—", "code_bassin": "—", "bdlisa_codes": [], "bdlisa_noms": [],
    }
    if data and data.get("data"):
        for s in data["data"]:
            codes = s.get("codes_masse_eau_rap") or s.get("codes_masse_eau_edl") or []
            noms = s.get("noms_masse_eau_rap") or s.get("noms_masse_eau_edl") or []
            urns = s.get("urns_masse_eau_rap") or s.get("urns_masse_eau_edl") or []
            if codes:
                result = {
                    "code_sandre": codes[0] if codes else "—",
                    "libelle": noms[0] if noms else "—",
                    "urn": urns[0] if urns else "—",
                    "bassin_dce": s.get("bassin_dce", "—"),
                    "code_bassin": s.get("code_bassin_dce", "—"),
                    "bdlisa_codes": s.get("codes_entite_hg_bdlisa") or [],
                    "bdlisa_noms": s.get("noms_entite_hg_bdlisa") or [],
                }
                break
    if cache is not None:
        cache[key] = result
    return result

# ─────────────────────────────────────────────────────────────────────────────
# RÉSOLUTION ZRE
# ─────────────────────────────────────────────────────────────────────────────
def resolve_zre(code_insee: str, x: float, y: float, code_dpt: str = "") -> dict:
    """Détermine le statut ZRE par registre INSEE puis par fallback BBox."""
    # 1) Lookup direct par INSEE
    if code_insee in ZRE_REGISTRY:
        zre = dict(ZRE_REGISTRY[code_insee])
        zre["statut"] = "CONFIRMÉ"
        zre["source"] = "Registre officiel ZRE par code INSEE"
        return zre
    # 2) Fallback BBox
    for bbox in ZRE_BBOX_FALLBACK:
        if (bbox["xmin"] <= x <= bbox["xmax"] and
            bbox["ymin"] <= y <= bbox["ymax"] and
            (not code_dpt or code_dpt in bbox.get("departements", []))):
            zre = dict(bbox)
            zre["statut"] = "PRÉSOMPTION (à vérifier en mairie/DDT)"
            zre["source"] = f"Emprise géographique {bbox['nappe']}"
            zre["arrete"] = "À vérifier — emprise géographique uniquement"
            return zre
    # 3) Pas de ZRE
    return {
        "statut": "NON ZRE",
        "nappe": "—",
        "arrete": "—",
        "bassin": "—",
        "agence_eau": "—",
        "sdage": "—",
        "sage": "—",
        "date_maj": "—",
        "source": "Aucune ZRE détectée par registre ni emprise",
    }

# ─────────────────────────────────────────────────────────────────────────────
# SDAGE / agence d'eau par bassin DCE
# ─────────────────────────────────────────────────────────────────────────────
SDAGE_BY_BASSIN = {
    "Loire-Bretagne": {"agence": "Agence de l'Eau Loire-Bretagne (AELB)",
                       "sdage": "SDAGE Loire-Bretagne 2022-2027"},
    "Seine-Normandie": {"agence": "Agence de l'Eau Seine-Normandie (AESN)",
                        "sdage": "SDAGE Seine-Normandie 2022-2027"},
    "Rhône-Méditerranée": {"agence": "Agence de l'Eau Rhône-Méditerranée-Corse (AERMC)",
                            "sdage": "SDAGE Rhône-Méditerranée 2022-2027"},
    "Adour-Garonne": {"agence": "Agence de l'Eau Adour-Garonne (AEAG)",
                      "sdage": "SDAGE Adour-Garonne 2022-2027"},
    "Artois-Picardie": {"agence": "Agence de l'Eau Artois-Picardie (AEAP)",
                        "sdage": "SDAGE Artois-Picardie 2022-2027"},
    "Rhin-Meuse": {"agence": "Agence de l'Eau Rhin-Meuse (AERM)",
                   "sdage": "SDAGE Rhin-Meuse 2022-2027"},
}

def _detect_sdage(bassin_dce_libelle: str) -> dict:
    if not bassin_dce_libelle or bassin_dce_libelle == "—":
        return {"agence": "—", "sdage": "—"}
    bl = bassin_dce_libelle.lower()
    if "loire" in bl: return SDAGE_BY_BASSIN["Loire-Bretagne"]
    if "seine" in bl or "normandie" in bl: return SDAGE_BY_BASSIN["Seine-Normandie"]
    if "rhône" in bl or "rhone" in bl or "méditerranée" in bl: return SDAGE_BY_BASSIN["Rhône-Méditerranée"]
    if "adour" in bl or "garonne" in bl: return SDAGE_BY_BASSIN["Adour-Garonne"]
    if "artois" in bl or "picardie" in bl: return SDAGE_BY_BASSIN["Artois-Picardie"]
    if "rhin" in bl or "meuse" in bl: return SDAGE_BY_BASSIN["Rhin-Meuse"]
    return {"agence": "—", "sdage": "—"}

# ─────────────────────────────────────────────────────────────────────────────
# RÉSOLUTION COMPLÈTE
# ─────────────────────────────────────────────────────────────────────────────
def resolve_geo(x_l93: float, y_l93: float, use_cache: bool = True) -> dict:
    """Résolution complète : X/Y Lambert 93 → tous les paramètres réglementaires.

    Retourne un dictionnaire avec les clés :
      x_l93, y_l93, lon_wgs84, lat_wgs84
      commune_nom, code_insee, code_dpt, code_region
      bassin_dce, agence_eau, sdage
      meso_code, meso_libelle, meso_urn, bdlisa_codes, bdlisa_noms
      zre_statut, zre_nappe, zre_arrete, zre_sage, zre_source
      resolution_ok (booléen)
    """
    cache = _load_cache() if use_cache else None
    lon, lat = lambert93_to_wgs84(x_l93, y_l93)

    commune = get_commune_by_coords(lon, lat, cache)
    meso = get_masse_eau_souterraine(lon, lat, cache)
    sdage_info = _detect_sdage(meso.get("bassin_dce", ""))
    zre = resolve_zre(commune.get("code_insee", ""), x_l93, y_l93, commune.get("code_dpt", ""))

    if cache is not None:
        _save_cache(cache)

    # Si ZRE confirmée par registre, ses propres SDAGE/agence/SAGE prévalent
    if zre.get("statut") == "CONFIRMÉ":
        agence_eau = zre.get("agence_eau", sdage_info.get("agence", "—"))
        sdage = zre.get("sdage", sdage_info.get("sdage", "—"))
        sage = zre.get("sage", "—")
    else:
        agence_eau = sdage_info.get("agence", "—")
        sdage = sdage_info.get("sdage", "—")
        sage = zre.get("sage", "—")

    return {
        "x_l93": x_l93,
        "y_l93": y_l93,
        "lon_wgs84": round(lon, 6),
        "lat_wgs84": round(lat, 6),
        # Commune
        "commune_nom": commune["nom"],
        "code_insee": commune["code_insee"],
        "code_dpt": commune["code_dpt"],
        "code_region": commune["code_region"],
        # Bassin / SDAGE
        "bassin_dce": meso["bassin_dce"],
        "agence_eau": agence_eau,
        "sdage": sdage,
        "sage": sage,
        # Masse d'eau souterraine
        "meso_code": meso["code_sandre"],
        "meso_libelle": meso["libelle"],
        "meso_urn": meso["urn"],
        "bdlisa_codes": meso["bdlisa_codes"],
        "bdlisa_noms": meso["bdlisa_noms"],
        # ZRE
        "zre_statut": zre["statut"],
        "zre_nappe": zre.get("nappe", "—"),
        "zre_arrete": zre.get("arrete", "—"),
        "zre_date_maj": zre.get("date_maj", "—"),
        "zre_source": zre.get("source", "—"),
        "zre_communes_deleguees": zre.get("communes_deleguees", []),
        # Drapeau succès
        "resolution_ok": (commune["code_insee"] != "—"),
    }


# ─────────────────────────────────────────────────────────────────────────────
# CLI de test
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    if len(sys.argv) >= 3:
        x, y = float(sys.argv[1]), float(sys.argv[2])
    else:
        # Oucques-la-Nouvelle par défaut
        x, y = 572096.27, 6748503.59
    print(f"\n=== RÉSOLUTION GÉO X={x}, Y={y} (Lambert 93) ===\n")
    result = resolve_geo(x, y)
    for k, v in result.items():
        print(f"  {k}: {v}")
