@echo off
REM GMEP - Ouverture directe du PDF Loi sur l'Eau
REM Double-cliquer pour ouvrir le PDF sans passer par Excel
chcp 65001 >nul
setlocal

set "PDF=%~dp0Dossier_Declaration_Loi_Eau_GMEP.pdf"

if not exist "%PDF%" (
    echo.
    echo Le fichier PDF n'existe pas encore :
    echo   %PDF%
    echo.
    echo Lancez d'abord Generer_PDF.bat pour le creer.
    echo.
    pause
    exit /b 1
)

start "" "%PDF%"
exit /b 0
