"""
Schémas techniques GMEP — v2 lisible
1. Coupe verticale du puits / piézomètre  (format portrait, grande taille)
2. Cône de rabattement                    (format paysage)
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.patches as patches
from matplotlib.lines import Line2D
import numpy as np
import math
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

# ═══════════════════════════════════════════════════════════════
# SCHÉMA 1 — COUPE PIÉZOMÈTRE
# ═══════════════════════════════════════════════════════════════
def draw_piezometre(params: dict, output_path: str):
    diam_int     = float(str(params.get('diam_int',     0.30)).split()[0])
    diam_ext     = float(str(params.get('diam_ext',     0.40)).split()[0])
    profondeur   = float(str(params.get('profondeur',   6.00)).split()[0])
    alt_tete     = float(str(params.get('alt_tete_ngf', 107.5)).split()[0])
    alt_fond     = float(str(params.get('alt_fond_ngf', 101.5)).split()[0])
    ns_m         = float(str(params.get('ns',           2.80)).split()[0])
    fond_fouille = float(str(params.get('fond_fouille', 6.00)).split()[0])
    r_gravier    = float(str(params.get('rayon_gravier',0.25)).split()[0])

    # ── Mise en page : figure très haute, 3 zones ──
    # Zone gauche : légendes/cotes (35%)
    # Zone centre : dessin coupe (30%)
    # Zone droite : cotes numériques (35%)

    fig = plt.figure(figsize=(16, 22))
    fig.patch.set_facecolor('white')

    # Titre
    fig.text(0.5, 0.975, "COUPE SCHÉMATIQUE DU PUITS DE FORAGE / PIÉZOMÈTRE",
             ha='center', va='top', fontsize=14, fontweight='bold', color='#1B474D',
             bbox=dict(boxstyle='round,pad=0.5', fc='#E0F7FA', ec='#1B474D', lw=2))
    fig.text(0.5, 0.955, f"Ø int. = {diam_int*100:.0f} cm  |  Ø ext. = {diam_ext*100:.0f} cm  |"
             f"  Profondeur = {profondeur:.1f} m  |  Alt. tête = {alt_tete:.1f} m NGF",
             ha='center', va='top', fontsize=11, color='#37474F')

    ax = fig.add_axes([0.0, 0.0, 1.0, 0.94])   # toute la zone sous le titre
    ax.set_xlim(0, 16)
    ax.set_ylim(-profondeur - 2.5, 2.5)
    ax.set_aspect('equal')
    ax.axis('off')

    # ── Coordonnées du dessin central ──
    cx = 8.0          # centre horizontal
    ri = 0.8          # rayon intérieur dessin (exagéré pour lisibilité)
    re = 1.2          # rayon extérieur tube
    rg = 2.0          # rayon massif gravillonnaire
    z0 = 0.0          # terrain naturel
    z_bent_bot = -0.7 # bas bentonite
    z_cim_top  =  0.4 # haut cimentation
    z_crep_top = -profondeur * 0.45  # début crépine
    z_fond     = -profondeur

    # ────────── COUCHES GÉOLOGIQUES (fond) ──────────
    # Argile superficielle
    ax.fill_between([cx-7, cx+7], [z0]*2,        [z0-1.8]*2,  color='#D7CCC8', alpha=0.45, zorder=0)
    ax.text(cx-6.5, z0-0.9, "Argile / Limon", fontsize=9.5, color='#6D4C41', style='italic', va='center')

    # Sable aquifère
    ax.fill_between([cx-7, cx+7], [z0-1.8]*2,    [z0-5.0]*2,  color='#FFF9C4', alpha=0.55, zorder=0)
    ax.text(cx-6.5, z0-3.4, "Sable / Graviers\n(nappe aquifère)", fontsize=9.5, color='#6D4C41', style='italic', va='center')

    # Substratum
    ax.fill_between([cx-7, cx+7], [z0-5.0]*2, [z_fond-1.5]*2, color='#CFD8DC', alpha=0.5, zorder=0)
    ax.text(cx-6.5, z_fond-0.7, "Substratum", fontsize=9.5, color='#455A64', style='italic', va='center')

    # Séparations couches
    ax.plot([cx-7, cx+7], [z0-1.8]*2, color='#8D6E63', lw=1.2, ls='--', alpha=0.7, zorder=1)
    ax.plot([cx-7, cx+7], [z0-5.0]*2, color='#90A4AE', lw=1.2, ls='--', alpha=0.7, zorder=1)

    # ────────── TERRAIN NATUREL ──────────
    ax.fill_between([cx-7, cx+7], [z0]*2, [z0+0.25]*2, color='#8D6E63', alpha=0.6, zorder=2)
    ax.axhline(z0, color='#4E342E', lw=2.5, zorder=3)
    ax.text(cx+2.5, z0+0.15, "Terrain naturel (TN)",
            fontsize=10, fontweight='bold', color='#4E342E', va='bottom', zorder=4)

    # ────────── MASSIF GRAVILLONNAIRE ──────────
    # Fond blanc
    ax.fill_between([cx-rg, cx+rg], [z_fond]*2, [z0]*2,
                    color='#FAFAFA', alpha=1.0, zorder=3)
    # Points gravier
    np.random.seed(42)
    pts_x = np.random.uniform(cx-rg+0.05, cx+rg-0.05, 200)
    pts_y = np.random.uniform(z_bent_bot-0.05, z_fond+0.1, 200)
    # masquer les points dans le tube
    mask = (pts_x < cx-re-0.05) | (pts_x > cx+re+0.05)
    ax.scatter(pts_x[mask], pts_y[mask], s=12, c='#FFC107', alpha=0.75, zorder=4)
    ax.scatter(pts_x[~mask], pts_y[~mask], s=12, c='#FFC107', alpha=0.0, zorder=4)

    # Bords massif gravillonnaire
    ax.plot([cx-rg, cx-rg], [z_fond, z0], color='#FF8F00', lw=1.5, ls=':', zorder=5)
    ax.plot([cx+rg, cx+rg], [z_fond, z0], color='#FF8F00', lw=1.5, ls=':', zorder=5)

    # ────────── BOUCHON BENTONITE ──────────
    bent_h = abs(z_bent_bot)  # épaisseur bentonite
    ax.fill_between([cx-rg, cx+rg], [z_bent_bot]*2, [z0]*2,
                    color='#795548', alpha=0.80, zorder=5)
    # Hachures obliques bentonite
    for yh in np.arange(z_bent_bot+0.12, z0, 0.18):
        ax.plot([cx-rg+0.05, cx+rg-0.05], [yh-0.08, yh+0.08],
                color='#4E342E', lw=0.8, zorder=6)
    ax.text(cx, (z_bent_bot+z0)/2, "Bouchon BENTONITE",
            ha='center', va='center', fontsize=10, fontweight='bold',
            color='white', zorder=7,
            bbox=dict(boxstyle='round,pad=0.2', fc='#5D4037', ec='none', alpha=0.7))

    # ────────── CIMENTATION EN TÊTE ──────────
    ax.fill_between([cx-rg-0.1, cx+rg+0.1], [z0]*2, [z_cim_top]*2,
                    color='#9E9E9E', alpha=0.85, zorder=5)
    # Hachures cimentation
    for xh in np.arange(cx-rg, cx+rg, 0.35):
        ax.plot([xh, xh+0.25], [z0+0.02, z_cim_top-0.02],
                color='#616161', lw=0.8, zorder=6)
    ax.text(cx, (z0+z_cim_top)/2, "CIMENTATION EN TÊTE",
            ha='center', va='center', fontsize=10, fontweight='bold',
            color='white', zorder=7,
            bbox=dict(boxstyle='round,pad=0.2', fc='#424242', ec='none', alpha=0.7))

    # ────────── TUBAGE PLEIN ──────────
    # Fond blanc à l'intérieur du tube
    ax.fill_between([cx-ri, cx+ri], [z_fond]*2, [z0]*2,
                    color='white', alpha=1.0, zorder=6)

    for sign in [-1, 1]:
        x_in  = cx + sign * ri
        x_out = cx + sign * re
        ax.fill_betweenx([z_crep_top, z0],
                          [x_in]*2, [x_out]*2,
                          color='#90A4AE', alpha=1.0, zorder=7)
        ax.plot([x_out, x_out], [z_crep_top, z0], color='#37474F', lw=2.5, zorder=8)
        ax.plot([x_in,  x_in],  [z_crep_top, z0], color='#607D8B', lw=1.5, zorder=8)
        # Hachures tubage plein
        for yh in np.arange(z_crep_top+0.15, z0, 0.25):
            ax.plot([x_in+sign*0.02, x_out-sign*0.02], [yh, yh],
                    color='#546E7A', lw=0.7, zorder=9)

    # ────────── TUBAGE CRÉPINE ──────────
    for sign in [-1, 1]:
        x_in  = cx + sign * ri
        x_out = cx + sign * re
        ax.fill_betweenx([z_fond, z_crep_top],
                          [x_in]*2, [x_out]*2,
                          color='#B2EBF2', alpha=0.95, zorder=7)
        ax.plot([x_out, x_out], [z_fond, z_crep_top], color='#00838F', lw=2.5, zorder=8)
        ax.plot([x_in,  x_in],  [z_fond, z_crep_top], color='#00838F', lw=1.5, zorder=8)
        # Fentes crépine
        for yh in np.arange(z_fond+0.15, z_crep_top, 0.22):
            ax.plot([x_in+sign*0.02, x_out-sign*0.02], [yh, yh],
                    color='#006064', lw=1.8, zorder=9)

    # Raccord tubage plein / crépine
    for sign in [-1, 1]:
        ax.fill_between([cx+sign*ri, cx+sign*re],
                         [z_crep_top-0.12]*2, [z_crep_top+0.12]*2,
                         color='#546E7A', zorder=9)

    # Fond du puits
    ax.fill_between([cx-ri, cx+ri], [z_fond-0.12]*2, [z_fond]*2,
                    color='#546E7A', alpha=0.9, zorder=9)
    ax.plot([cx-re, cx+re], [z_fond]*2, color='#263238', lw=3.5, zorder=10)

    # ────────── NIVEAU STATIQUE ──────────
    ns_y = -ns_m
    ax.fill_between([cx-ri, cx+ri], [z_fond]*2, [ns_y]*2,
                    color='#81D4FA', alpha=0.55, zorder=6)
    ax.plot([cx-7, cx+7], [ns_y]*2,
            color='#0277BD', lw=2.5, ls='--', zorder=11, alpha=0.9)
    # Symbole eau
    for xw in [cx-5, cx-3, cx+3, cx+5]:
        ax.text(xw, ns_y+0.1, '~~~', fontsize=12, color='#0277BD',
                ha='center', va='bottom', zorder=12)

    # ────────── COTATION GAUCHE — hauteurs ──────────
    cot_x = cx - 5.5
    arrow_kw = dict(arrowstyle='<->', color='#1B474D', lw=2.0,
                    mutation_scale=16)

    def cote(y1, y2, label, x_pos, color='#1B474D', fontsize=10):
        ax.annotate('', xy=(x_pos, y1), xytext=(x_pos, y2),
                    arrowprops=dict(arrowstyle='<->', color=color,
                                    lw=2.0, mutation_scale=14), zorder=12)
        ax.plot([x_pos-0.15, x_pos+0.15], [y1]*2, color=color, lw=1.2, zorder=12)
        ax.plot([x_pos-0.15, x_pos+0.15], [y2]*2, color=color, lw=1.2, zorder=12)
        ax.text(x_pos - 0.3, (y1+y2)/2, label,
                ha='right', va='center', fontsize=fontsize,
                color=color, fontweight='bold', zorder=12,
                bbox=dict(boxstyle='round,pad=0.3', fc='white',
                           ec=color, alpha=0.9, lw=1.0))

    # Profondeur totale
    cote(z_fond, z0,        f"Prof. totale\n{profondeur:.1f} m",
         cot_x, '#1B474D', 10)
    # Niveau statique
    cote(ns_y, z0,          f"NS = {ns_m:.2f} m/TN\nAlt. {alt_tete-ns_m:.2f} m NGF",
         cx-4.0, '#0277BD', 9)
    # Zone crépine
    cote(z_fond, z_crep_top,
         f"Crépine\n{abs(z_fond-z_crep_top):.1f} m",
         cot_x+1.2, '#006064', 9)
    # Tubage plein
    cote(z_crep_top, z0,
         f"Tubage plein\n{abs(z_crep_top):.1f} m",
         cot_x+1.2, '#37474F', 9)
    # Bentonite
    cote(z_bent_bot, z0,
         f"Bentonite\n{abs(z_bent_bot):.1f} m",
         cx-2.8, '#5D4037', 9)

    # ────────── COTATION DROITE — diamètres ──────────
    cot_dx = cx + 3.5

    def cote_h(x1, x2, y_pos, label, color='#37474F', fontsize=10):
        ax.annotate('', xy=(x2, y_pos), xytext=(x1, y_pos),
                    arrowprops=dict(arrowstyle='<->', color=color,
                                    lw=2.0, mutation_scale=14), zorder=12)
        ax.plot([x1]*2, [y_pos-0.1, y_pos+0.1], color=color, lw=1.2, zorder=12)
        ax.plot([x2]*2, [y_pos-0.1, y_pos+0.1], color=color, lw=1.2, zorder=12)
        ax.text((x1+x2)/2, y_pos+0.22, label,
                ha='center', va='bottom', fontsize=fontsize,
                color=color, fontweight='bold', zorder=12,
                bbox=dict(boxstyle='round,pad=0.3', fc='white',
                           ec=color, alpha=0.9, lw=1.0))

    # Ø intérieur
    cote_h(cx-ri, cx+ri, z_fond-0.5,
           f"Ø int. = {diam_int*100:.0f} cm", '#607D8B', 10)
    # Ø extérieur tube
    cote_h(cx-re, cx+re, z_fond-1.1,
           f"Ø ext. tube = {diam_ext*100:.0f} cm", '#37474F', 10)
    # Ø avec massif gravillonnaire
    cote_h(cx-rg, cx+rg, z_fond-1.7,
           f"Ø avec massif = {r_gravier*2*100:.0f} cm", '#E65100', 10)

    # ────────── ALTIMÉTRIES NGF (droite) ──────────
    ax_right = cx + 5.5
    # Cas dégénéré : NS ≈ FF → fusion d'un seul label combiné
    _fouille_au_dessus_piez = (fond_fouille - ns_m) <= 0.05
    if _fouille_au_dessus_piez:
        ngf_items = [
            (z_cim_top, f"Haut cimentation : {alt_tete + z_cim_top:.1f} m NGF",   '#616161'),
            (z0,        f"Tête ouvrage : {alt_tete:.1f} m NGF",                    '#4E342E'),
            (ns_y,      f"NS = Fond fouille : {alt_tete - ns_m:.2f} m NGF\n(hors d'eau)", '#C62828'),
            (z_fond,    f"Fond forage : {alt_fond:.1f} m NGF",                     '#263238'),
        ]
    else:
        ngf_items = [
            (z_cim_top, f"Haut cimentation : {alt_tete + z_cim_top:.1f} m NGF",   '#616161'),
            (z0,        f"Tête ouvrage : {alt_tete:.1f} m NGF",                    '#4E342E'),
            (ns_y,      f"NS : {alt_tete - ns_m:.2f} m NGF",                       '#0277BD'),
            (-fond_fouille, f"Fond fouille : {alt_tete - fond_fouille:.2f} m NGF", '#E65100'),
            (z_fond,    f"Fond forage : {alt_fond:.1f} m NGF",                     '#263238'),
        ]
    for y_ngf, label_ngf, col_ngf in ngf_items:
        ax.plot([cx+re+0.1, ax_right-0.1], [y_ngf]*2,
                color=col_ngf, lw=1.2, ls=':', zorder=11, alpha=0.8)
        ax.plot([ax_right-0.1], [y_ngf], 'o',
                color=col_ngf, ms=5, zorder=12)
        ax.text(ax_right + 0.15, y_ngf, label_ngf,
                ha='left', va='center', fontsize=9.5,
                color=col_ngf, fontweight='bold', zorder=12,
                bbox=dict(boxstyle='round,pad=0.25', fc='white',
                           ec=col_ngf, alpha=0.92, lw=0.8))

    # ────────── LÉGENDE ──────────
    legend_items = [
        mpatches.Patch(color='#795548', label='Bouchon bentonite (≥ 2 m)'),
        mpatches.Patch(color='#FFF9C4', ec='#FFC107', label='Massif gravillonnaire siliceux (2-4 mm)'),
        mpatches.Patch(color='#9E9E9E', label='Cimentation en tête'),
        mpatches.Patch(color='#90A4AE', ec='#37474F', label='Tubage plein (PVC / acier inox)'),
        mpatches.Patch(color='#B2EBF2', ec='#00838F', label='Tubage crépine (fentes)'),
        mpatches.Patch(color='#81D4FA', alpha=0.7, label='Eau souterraine / nappe'),
        Line2D([0],[0], color='#0277BD', lw=2.5, ls='--', label='Niveau statique (NS)'),
    ]
    leg = ax.legend(handles=legend_items,
                    loc='lower center', fontsize=9.5,
                    framealpha=0.95, edgecolor='#1B474D',
                    ncol=2,
                    bbox_to_anchor=(0.5, -0.13),
                    title='  LÉGENDE  ', title_fontsize=10,
                    borderpad=0.8, handlelength=1.8, columnspacing=1.5)
    leg.get_title().set_fontweight('bold')
    leg.get_title().set_color('#1B474D')

    plt.savefig(output_path, dpi=250, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    plt.close()
    print(f"Schéma piézomètre : {output_path}")
    return output_path


# ═══════════════════════════════════════════════════════════════
# SCHÉMA 2 — CÔNE DE RABATTEMENT
# ═══════════════════════════════════════════════════════════════
def draw_cone_rabattement(params: dict, output_path: str):
    ns_m         = float(str(params.get('ns',           2.80)).split()[0])
    fond_fouille = float(str(params.get('fond_fouille', 6.00)).split()[0])
    rayon_inf    = float(str(params.get('rayon_inf',   10.00)).split()[0])
    profondeur   = float(str(params.get('profondeur',  6.00)).split()[0])
    diam_int     = float(str(params.get('diam_int',    0.30)).split()[0])
    diam_ext     = float(str(params.get('diam_ext',    0.40)).split()[0])
    T            = float(str(params.get('T',           1.5e-4)).split()[0])
    Q            = float(str(params.get('Q',           2.29/3600)).split()[0])
    alt_tete     = float(str(params.get('alt_tete_ngf',107.5)).split()[0])

    r_w      = diam_int / 2
    R        = rayon_inf
    h_static = profondeur - ns_m
    s_max    = fond_fouille - ns_m
    h_dyn_w  = max(h_static - s_max, 0.05)

    r_vals = np.linspace(r_w, R, 400)
    h2_w   = max(h_dyn_w**2, 0.001)
    if T > 0 and Q > 0:
        h2 = h2_w + (Q / (math.pi * T)) * np.log(r_vals / r_w)
        h2 = np.clip(h2, 0, (h_static + 0.1)**2)
        h  = np.sqrt(h2)
    else:
        h = np.full_like(r_vals, h_static)
    niveau_eau = profondeur - h  # profondeur depuis TN

    fig, ax = plt.subplots(figsize=(18, 10))
    fig.patch.set_facecolor('white')

    x_max  = R * 1.35
    y_top  = 1.2
    y_bot  = -profondeur - 2.2
    ax.set_xlim(-x_max, x_max)
    ax.set_ylim(y_bot, y_top + 0.6)
    ax.axis('off')

    # Titre
    ax.text(0, y_top+0.52,
            "SCHÉMA DU CÔNE DE RABATTEMENT — COUPE VERTICALE (Méthode Dupuit-Thiem)",
            ha='center', va='center', fontsize=13, fontweight='bold', color='#1B474D',
            bbox=dict(boxstyle='round,pad=0.45', fc='#E0F7FA', ec='#1B474D', lw=2))

    # ─── Couches ───
    ax.fill_between([-x_max, x_max], [-ns_m]*2,        [0]*2,
                    color='#D7CCC8', alpha=0.35, zorder=0)
    ax.fill_between([-x_max, x_max], [-profondeur-1]*2, [-ns_m]*2,
                    color='#FFF9C4', alpha=0.5, zorder=0)
    ax.text( x_max*0.72, -ns_m/2,     "Zone non saturée",   fontsize=9,  color='#6D4C41', style='italic')
    ax.text( x_max*0.72, -profondeur*0.7, "Aquifère\n(nappe libre)", fontsize=9, color='#827717', style='italic')

    # ─── TN ───
    ax.fill_between([-x_max, x_max], [0]*2, [y_top*0.6]*2,
                    color='#8D6E63', alpha=0.2, zorder=1)
    ax.axhline(0, color='#5D4037', lw=3.0, zorder=5)
    ax.text(x_max*0.5, 0.08, "Terrain Naturel (TN)", fontsize=10.5,
            fontweight='bold', color='#4E342E', zorder=6)

    # ─── Substratum ───
    ax.fill_between([-x_max, x_max], [y_bot]*2, [-profondeur-0.2]*2,
                    color='#B0BEC5', alpha=0.55, zorder=0)
    ax.plot([-x_max, x_max], [-profondeur]*2, color='#90A4AE',
            lw=1.5, ls='--', zorder=1, alpha=0.7)

    # ─── Surface piézométrique ───
    cone_x = np.concatenate([-r_vals[::-1], r_vals])
    cone_y = np.concatenate([-niveau_eau[::-1], -niveau_eau])
    ns_ext_l = np.array([-x_max, -R])
    ns_ext_r = np.array([ R,  x_max])

    ax.fill_between(cone_x, cone_y, [-profondeur-0.5]*(len(cone_x)),
                    color='#B3E5FC', alpha=0.55, zorder=2)
    ax.fill_between(ns_ext_l, [-ns_m]*2, [-profondeur-0.5]*2,
                    color='#B3E5FC', alpha=0.55, zorder=2)
    ax.fill_between(ns_ext_r, [-ns_m]*2, [-profondeur-0.5]*2,
                    color='#B3E5FC', alpha=0.55, zorder=2)

    ax.plot(cone_x, cone_y, color='#0277BD', lw=3.0, zorder=6, label='Surface piézométrique')
    ax.plot(ns_ext_l, [-ns_m]*2, color='#0277BD', lw=3.0, zorder=6)
    ax.plot(ns_ext_r, [-ns_m]*2, color='#0277BD', lw=3.0, zorder=6)

    # ─── Niveaux ───
    # Cas dégénéré : fond de fouille ≈ niveau statique → fouille hors d'eau, fusion des labels
    _fouille_au_dessus = (fond_fouille - ns_m) <= 0.05  # tolérance 5 cm
    ax.plot([-x_max, x_max], [-ns_m]*2, color='#C62828',
            lw=1.8, ls='--', zorder=4, alpha=0.8)
    if _fouille_au_dessus:
        # Un seul label fusionné (NS = FF) - cas hors nomenclature
        ax.text( x_max*0.42, -ns_m - 0.25,
                 f"NS = Niveau cible = {ns_m:.2f} m/TN  —  Alt. {alt_tete-ns_m:.2f} m NGF\n"
                 f"(Fouille au-dessus du niveau d'eau — aucun rabattement requis)",
                 fontsize=9.5, color='#C62828', fontweight='bold', zorder=7,
                 bbox=dict(boxstyle='round,pad=0.3', fc='#FFF8E1', ec='#E65100', lw=1.2, alpha=0.92))
    else:
        ax.plot([-x_max, x_max], [-fond_fouille]*2, color='#E65100',
                lw=1.8, ls=':', zorder=4, alpha=0.8)
        ax.text( x_max*0.52, -ns_m - 0.18,
                 f"Niveau statique (NS) = {ns_m:.2f} m/TN  —  Alt. {alt_tete-ns_m:.2f} m NGF",
                 fontsize=9.5, color='#C62828', fontweight='bold', zorder=7)
        ax.text( x_max*0.52, -fond_fouille - 0.20,
                 f"Niveau dynamique visé = {fond_fouille:.2f} m/TN  —  Alt. {alt_tete-fond_fouille:.2f} m NGF",
                 fontsize=9.5, color='#E65100', fontweight='bold', zorder=7)

    # ─── Puits ───
    ri = 0.25; re = 0.38
    ax.fill_betweenx([-profondeur, 0], [-re]*2, [-ri]*2, color='#607D8B', zorder=7)
    ax.fill_betweenx([-profondeur, 0], [ ri]*2, [ re]*2, color='#607D8B', zorder=7)
    ax.plot([-re,-re], [-profondeur, 0], color='#263238', lw=2.5, zorder=8)
    ax.plot([ re, re], [-profondeur, 0], color='#263238', lw=2.5, zorder=8)
    ax.plot([-re,  re], [-profondeur]*2, color='#263238', lw=3.5, zorder=8)
    # Eau dans puits
    y_eau_p = -(profondeur - h_dyn_w)
    ax.fill_between([-ri, ri], [-profondeur]*2, [y_eau_p]*2,
                    color='#0288D1', alpha=0.6, zorder=6)
    ax.plot([-ri, ri], [y_eau_p]*2, color='#0288D1', lw=2.0, zorder=9)
    # Pompe
    ax.add_patch(patches.FancyBboxPatch((-0.18, -0.5), 0.36, 0.38,
                 boxstyle="round,pad=0.04", fc='#78909C', ec='#263238', lw=2, zorder=10))
    ax.text(0, -0.31, "P", ha='center', va='center', fontsize=11,
            fontweight='bold', color='white', zorder=11)
    ax.plot([0, 0], [0, y_top*0.55], color='#263238', lw=3.5, zorder=10)
    ax.annotate('', xy=(0.5, y_top*0.5), xytext=(0, y_top*0.5),
                arrowprops=dict(arrowstyle='->', color='#263238', lw=2.5), zorder=10)
    ax.text(0.6, y_top*0.5, "Refoulement", fontsize=10, color='#263238',
            va='center', fontweight='bold', zorder=11)

    # ─── Cotations ───
    # Rabattement
    s_w = fond_fouille - ns_m
    ax.annotate('', xy=(re+0.4, -fond_fouille), xytext=(re+0.4, -ns_m),
                arrowprops=dict(arrowstyle='<->', color='#E65100', lw=2.5,
                                mutation_scale=16), zorder=11)
    ax.plot([re+0.25, re+0.55], [-ns_m]*2,        color='#E65100', lw=1.2, zorder=11)
    ax.plot([re+0.25, re+0.55], [-fond_fouille]*2, color='#E65100', lw=1.2, zorder=11)
    ax.text(re+0.65, -(ns_m+fond_fouille)/2,
            f"Rabattement\ns = {s_w:.2f} m",
            fontsize=10, color='#E65100', va='center', fontweight='bold', zorder=12,
            bbox=dict(boxstyle='round,pad=0.3', fc='white', ec='#E65100', alpha=0.92))

    # Rayon d'influence
    ax.annotate('', xy=(R, y_bot+0.5), xytext=(0, y_bot+0.5),
                arrowprops=dict(arrowstyle='<->', color='#1B474D', lw=2.5,
                                mutation_scale=16), zorder=11)
    ax.plot([R,  R],  [y_bot+0.35, -ns_m], color='#1B474D', lw=1.5, ls=':', zorder=4)
    ax.plot([-R, -R], [y_bot+0.35, -ns_m], color='#1B474D', lw=1.5, ls=':', zorder=4)
    ax.text(R/2, y_bot+0.65,
            f"Rayon d'influence R = {R:.1f} m",
            ha='center', fontsize=11, color='#1B474D', fontweight='bold', zorder=12,
            bbox=dict(boxstyle='round,pad=0.3', fc='white', ec='#1B474D', alpha=0.92))

    # Profondeur totale
    ax.annotate('', xy=(-x_max+0.6, -profondeur), xytext=(-x_max+0.6, 0),
                arrowprops=dict(arrowstyle='<->', color='#546E7A', lw=2.2,
                                mutation_scale=15), zorder=11)
    ax.plot([-x_max+0.45, -x_max+0.75], [-profondeur]*2, color='#546E7A', lw=1.2, zorder=11)
    ax.plot([-x_max+0.45, -x_max+0.75], [0]*2,           color='#546E7A', lw=1.2, zorder=11)
    ax.text(-x_max+0.9, -profondeur/2,
            f"Profondeur\ntotale\n{profondeur:.1f} m",
            fontsize=10, color='#37474F', va='center', fontweight='bold', zorder=12,
            bbox=dict(boxstyle='round,pad=0.3', fc='white', ec='#546E7A', alpha=0.92))

    # ─── Légende ───
    legend_items = [
        mpatches.Patch(color='#B3E5FC', alpha=0.7, label='Zone saturée (aquifère)'),
        mpatches.Patch(color='#D7CCC8', alpha=0.5, label='Zone non saturée'),
        Line2D([0],[0], color='#0277BD', lw=3.0, label='Surface piézométrique'),
        Line2D([0],[0], color='#C62828', lw=2.0, ls='--', label='Niveau statique (NS)'),
        Line2D([0],[0], color='#E65100', lw=2.0, ls=':', label='Niveau dynamique visé'),
        Line2D([0],[0], color='#1B474D', lw=1.5, ls=':', label="Rayon d'influence (R)"),
        mpatches.Patch(color='#607D8B', label='Puits / tube de captage'),
    ]
    leg = ax.legend(handles=legend_items, loc='lower left', fontsize=9.5,
                    framealpha=0.95, edgecolor='#1B474D',
                    ncol=2, title='  LÉGENDE  ', title_fontsize=10,
                    borderpad=0.8, handlelength=1.8, columnspacing=1.2)
    leg.get_title().set_fontweight('bold')
    leg.get_title().set_color('#1B474D')

    plt.tight_layout(pad=0.5)
    plt.savefig(output_path, dpi=250, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    plt.close()
    print(f"Schéma cône : {output_path}")
    return output_path


# ═══════════════════════════════════════════════════════════════
# SCHÉMA 3 — COUPE CONCEPTUELLE PUITS + 2 PIÉZOMÈTRES
# ═══════════════════════════════════════════════════════════════
def draw_schema_piezometres(params: dict, output_path: str):
    """
    Schéma conceptuel en coupe transversale :
      - Puits de pompage central
      - Piézomètre P1 à 5 m du puits
      - Piézomètre P2 à 10 m du puits
      - Niveaux piézométriques calculés par Theis (NS, NS_P1, NS_P2)
      - Altimétries NGF sur chaque ouvrage
      - Rabattements annotés + surface piézométrique
    """
    import math

    # ── Paramètres ──
    r_puits   = float(str(params.get('diam_int',    0.30)).split()[0]) / 2.0   # rayon intérieur
    r_ext     = float(str(params.get('diam_ext',    0.40)).split()[0]) / 2.0
    profondeur= float(str(params.get('profondeur',  6.00)).split()[0])
    alt_tete  = float(str(params.get('alt_tete_ngf',107.5)).split()[0])
    NS_m      = float(str(params.get('ns',           2.80)).split()[0])   # m/TN
    FF_m      = float(str(params.get('fond_fouille', 6.00)).split()[0])   # m/TN
    T_v       = float(params.get('T',  3.2e-3))
    S_v       = float(params.get('S',  0.05))
    Q_m3s     = float(params.get('Q',  21.35/3600.0))                    # m³/s
    t_s       = float(params.get('t_s', 86400.0))                        # secondes
    R_inf     = float(str(params.get('rayon_inf', 10.0)).split()[0])

    dist_P1   = 5.0    # m
    dist_P2   = 10.0   # m

    # ── Fonction de puits Wu(u) ──
    def _Wu(u):
        if u <= 0: return 0.0
        try:
            if u < 0.02:
                return -0.5772 - math.log(u) + u - u**2/4
            a0,a1,a2,a3,a4 = 0.99999193,-0.24991055,0.05519968,-0.00976004,0.00107857
            b1,b2,b3,b4    = 8.5733287401,18.0590169730,8.6347608925,0.2677737343
            c1,c2,c3,c4    = 9.5733223454,25.6329561486,21.0996530827,3.9584969228
            ex = math.exp(-u)
            return (a0+u*(a1+u*(a2+u*(a3+u*a4))))*(-math.log(u)) + \
                   ex*(b1+u*(b2+u*(b3+u*b4)))/(c1+u*(c2+u*(c3+u*c4)))
        except: return 0.0

    def rabattement_theis(d, Q, T, S, t):
        """Rabattement en m à la distance d du puits."""
        if d <= 0 or T <= 0: return 0.0
        u  = (d**2 * S) / (4 * T * t)
        Wu = _Wu(u)
        return max(0.0, (Q * Wu) / (4 * math.pi * T))

    # Rabattements calculés
    s_puits = FF_m - NS_m                                          # au puits (= s visé)
    s_P1    = rabattement_theis(dist_P1, Q_m3s, T_v, S_v, t_s)   # à 5 m
    s_P2    = rabattement_theis(dist_P2, Q_m3s, T_v, S_v, t_s)   # à 10 m

    # Niveaux dynamiques (profondeur m/TN) = NS + rabattement
    nd_puits = NS_m + s_puits
    nd_P1    = NS_m + s_P1
    nd_P2    = NS_m + s_P2

    # Altimétries NGF (alt_tete - profondeur_m_TN)
    alt_TN     = alt_tete                              # TN ≈ tête ouvrage
    alt_NS     = alt_TN - NS_m                         # NS NGF
    alt_nd_puits = alt_TN - nd_puits                   # ND au puits NGF
    alt_nd_P1    = alt_TN - nd_P1                      # ND à P1 NGF
    alt_nd_P2    = alt_TN - nd_P2                      # ND à P2 NGF
    alt_fond     = alt_TN - profondeur                 # fond NGF

    # ── Mise en page ──
    fig, ax = plt.subplots(figsize=(20, 14))
    fig.patch.set_facecolor('white')
    ax.set_facecolor('#F0F8FF')

    # Dimensions dessin
    x_max    = 16.0
    y_TN     =  0.0
    y_fond   = -profondeur
    y_NS     = -NS_m
    y_nd_pw  = -nd_puits
    y_nd_P1  = -nd_P1
    y_nd_P2  = -nd_P2
    y_bot    = y_fond - 1.5

    ax.set_xlim(-2.5, x_max)
    ax.set_ylim(y_bot - 0.8, 3.5)
    ax.axis('off')

    # ── Titre ──
    ax.text((x_max - 2.5) / 2 - 2.5, 3.2,
            "SCHÉMA CONCEPTUEL — PUITS DE POMPAGE ET PIÉZOMÈTRES DE CONTRÔLE",
            ha='center', va='top', fontsize=13, fontweight='bold', color='#1B2E47',
            bbox=dict(boxstyle='round,pad=0.5', fc='#E3F2FD', ec='#1B474D', lw=2))
    ax.text((x_max - 2.5) / 2 - 2.5, 2.65,
            f"NS = {NS_m:.2f} m/TN  |  s (puits) = {s_puits:.2f} m  |  "
            f"s (P1, {dist_P1:.0f}m) = {s_P1:.2f} m  |  s (P2, {dist_P2:.0f}m) = {s_P2:.2f} m  |  "
            f"Q = {Q_m3s*3600:.2f} m³/h  |  T = {T_v:.2e} m²/s",
            ha='center', va='top', fontsize=9.5, color='#37474F')

    # ── COUCHES GÉOLOGIQUES ──
    # Zone non saturée (NS → TN)
    ax.fill_between([-2, x_max], [y_TN]*2, [y_NS]*2,
                    color='#D7CCC8', alpha=0.45, zorder=0)
    # Zone saturée (fond → NS)
    ax.fill_between([-2, x_max], [y_NS]*2, [y_fond]*2,
                    color='#B3E5FC', alpha=0.45, zorder=0)
    # Substratum
    ax.fill_between([-2, x_max], [y_fond]*2, [y_bot]*2,
                    color='#CFD8DC', alpha=0.7, zorder=0)
    for xh in np.arange(-2.0, x_max, 0.6):
        ax.plot([xh, xh+0.4], [y_fond-0.25, y_bot+0.25],
                color='#90A4AE', lw=0.8, alpha=0.6, zorder=1)

    # Labels couches
    ax.text(-1.8, y_NS/2 + 0.1, "Zone\nnon\nsaturée",
            fontsize=8, color='#6D4C41', style='italic', va='center', ha='left')
    ax.text(-1.8, (y_NS + y_fond)/2, "Zone\nsaturée\n(aquifère)",
            fontsize=8, color='#01579B', style='italic', va='center', ha='left')
    ax.text(-1.8, y_fond - 0.65, "Substratum",
            fontsize=8, color='#455A64', style='italic', va='center', ha='left')

    # ── TERRAIN NATUREL ──
    ax.fill_between([-2, x_max], [y_TN]*2, [y_TN + 0.15]*2,
                    color='#8D6E63', alpha=0.7, zorder=2)
    ax.axhline(y_TN, color='#4E342E', lw=2.5, zorder=3)

    # ── Séparation couches ──
    ax.plot([-2, x_max], [y_fond]*2, color='#90A4AE', lw=1.5, ls='--', alpha=0.7, zorder=2)
    ax.plot([-2, x_max], [y_NS]*2,   color='#0277BD', lw=1.5, ls='--', alpha=0.5, zorder=2)

    # ── Positions horizontales (en m dans le dessin, axe mis à l'échelle) ──
    # puits à x=0, P1 à x=5, P2 à x=10
    x_pw = 0.0
    x_P1 = dist_P1
    x_P2 = dist_P2
    rp   = 0.18   # rayon visuel du puits/piezo

    # ── SURFACE PIÉZOMÉTRIQUE (courbe Theis continue) ──
    xx = np.linspace(0.05, x_max - 0.5, 300)
    yy_piezom = []
    for xi in xx:
        if xi < r_puits:
            yy_piezom.append(y_nd_pw)
        else:
            s_xi = rabattement_theis(xi, Q_m3s, T_v, S_v, t_s)
            yy_piezom.append(-(NS_m + s_xi))
    yy_piezom = np.array(yy_piezom)

    # Remplissage eau rabattue entre surface piezo et niveau statique
    ax.fill_between(xx, yy_piezom, np.full_like(xx, y_NS),
                    where=(yy_piezom <= y_NS),
                    color='#81D4FA', alpha=0.30, zorder=3, label='_nolegend_')

    ax.plot(xx, yy_piezom, color='#0277BD', lw=2.5, zorder=8,
            label='Surface piézométrique (Theis)')

    # Niveau statique
    ax.axhline(y_NS, color='#C62828', lw=1.8, ls=(0, (8, 4)), zorder=5,
               label=f'Niveau statique NS = {NS_m:.2f} m/TN  ({alt_NS:.2f} m NGF)')

    # ────────────────────────────────────────────────────────────
    # Fonction pour dessiner un ouvrage (puits ou piézomètre)
    # ────────────────────────────────────────────────────────────
    def _draw_ouvrage(ax, xc, y_fond_ouv, y_nd, y_TN, rp, color_tube,
                      label_top, is_pump=False, z_crepe=None):
        """Dessine un tube avec niveau dynamique intérieur."""
        if z_crepe is None:
            z_crepe = y_fond_ouv + (y_TN - y_fond_ouv) * 0.5

        re = rp * 1.6    # rayon extérieur tube

        # Massif gravillonnaire (si puits de pompage)
        if is_pump:
            rg = rp * 3.5
            ax.fill_between([xc-rg, xc+rg], [y_fond_ouv]*2, [y_TN]*2,
                            color='#FFF9C4', alpha=0.6, zorder=4)
            np.random.seed(7)
            px = np.random.uniform(xc - rg + 0.05, xc + rg - 0.05, 120)
            py = np.random.uniform(y_fond_ouv + 0.05, y_TN - 0.05, 120)
            msk = (px < xc - re - 0.03) | (px > xc + re + 0.03)
            ax.scatter(px[msk], py[msk], s=10, c='#FFC107', alpha=0.7, zorder=5)

        # Tube plein
        for sign in [-1, 1]:
            ax.fill_betweenx([z_crepe, y_TN],
                             [xc + sign*rp]*2, [xc + sign*re]*2,
                             color=color_tube, alpha=0.9, zorder=6)
            ax.plot([xc + sign*re]*2, [z_crepe, y_TN],
                    color='#263238', lw=2.0, zorder=7)
        # Crépine
        for sign in [-1, 1]:
            ax.fill_betweenx([y_fond_ouv, z_crepe],
                             [xc + sign*rp]*2, [xc + sign*re]*2,
                             color='#B2EBF2', alpha=0.9, zorder=6)
            ax.plot([xc + sign*re]*2, [y_fond_ouv, z_crepe],
                    color='#00838F', lw=2.0, zorder=7)
            # fentes
            for yf in np.arange(y_fond_ouv+0.15, z_crepe, 0.20):
                ax.plot([xc+sign*rp+sign*0.02, xc+sign*re-sign*0.02],
                        [yf, yf], color='#006064', lw=1.5, zorder=8)

        # Fond
        ax.fill_between([xc-rp, xc+rp], [y_fond_ouv-0.12]*2, [y_fond_ouv]*2,
                        color='#546E7A', zorder=7)
        ax.plot([xc-re, xc+re], [y_fond_ouv]*2, color='#263238', lw=2.5, zorder=8)

        # Eau intérieure
        ax.fill_between([xc-rp, xc+rp], [y_fond_ouv]*2, [y_nd]*2,
                        color='#81D4FA', alpha=0.65, zorder=7)
        # Ligne ND intérieure
        ax.plot([xc-rp*1.2, xc+rp*1.2], [y_nd]*2,
                color='#01579B', lw=2.0, zorder=9)

        # Tête de l'ouvrage
        ax.fill_between([xc-re*1.3, xc+re*1.3], [y_TN]*2, [y_TN+0.25]*2,
                        color='#546E7A', alpha=0.9, zorder=7)

        # Label nom ouvrage
        ax.text(xc, y_TN + 0.45, label_top,
                ha='center', va='bottom', fontsize=10.5, fontweight='bold',
                color='#1B2E47', zorder=12,
                bbox=dict(boxstyle='round,pad=0.35', fc='white',
                          ec='#1B474D', lw=1.5))

        # Flèche de pompage (puits uniquement)
        if is_pump:
            ax.annotate('', xy=(xc, y_TN + 1.2), xytext=(xc, y_nd + 0.05),
                        arrowprops=dict(arrowstyle='->', color='#C62828',
                                       lw=2.5, mutation_scale=20), zorder=12)
            ax.text(xc + 0.3, y_TN + 0.85, f"Q = {Q_m3s*3600:.1f} m³/h",
                    fontsize=9.5, color='#C62828', fontweight='bold', va='center',
                    zorder=12,
                    bbox=dict(boxstyle='round,pad=0.25', fc='#FFEBEE',
                              ec='#C62828', lw=1.2))

    # ── Dessin puits de pompage ──
    _draw_ouvrage(ax, x_pw, y_fond, y_nd_pw, y_TN, rp * 1.5,
                  color_tube='#90A4AE',
                  label_top='PUITS\nde pompage',
                  is_pump=True,
                  z_crepe=y_fond + (y_TN - y_fond) * 0.45)

    # ── Dessin P1 (5 m) ──
    _draw_ouvrage(ax, x_P1, y_fond + 0.5, y_nd_P1, y_TN, rp * 0.85,
                  color_tube='#A5D6A7',
                  label_top=f'P1\n({dist_P1:.0f} m)',
                  is_pump=False,
                  z_crepe=y_fond + 0.5 + (y_TN - y_fond - 0.5) * 0.45)

    # ── Dessin P2 (10 m) ──
    _draw_ouvrage(ax, x_P2, y_fond + 0.8, y_nd_P2, y_TN, rp * 0.85,
                  color_tube='#A5D6A7',
                  label_top=f'P2\n({dist_P2:.0f} m)',
                  is_pump=False,
                  z_crepe=y_fond + 0.8 + (y_TN - y_fond - 0.8) * 0.45)

    # ─────────────────────────────────────────────────────────────
    # ANNOTATIONS ALTIMÉTRIE — colonne de droite
    # ─────────────────────────────────────────────────────────────
    ann_x = x_max - 0.3   # x colonne annotations
    title_ann_x = x_max - 1.5

    ax.text(title_ann_x, 2.0, "ALTIMÉTRIES (m NGF)",
            ha='center', va='top', fontsize=10, fontweight='bold', color='white',
            bbox=dict(boxstyle='round,pad=0.4', fc='#1B474D', ec='#1B474D', lw=1.5))

    alt_rows = [
        ("Terrain naturel (TN)",    alt_TN,            '#4E342E'),
        ("Niveau statique (NS)",     alt_NS,            '#0277BD'),
        (f"Niveau dynamique — Puits", alt_nd_puits,     '#C62828'),
        (f"Niveau dynamique — P1 ({dist_P1:.0f}m)",  alt_nd_P1, '#2E7D32'),
        (f"Niveau dynamique — P2 ({dist_P2:.0f}m)",  alt_nd_P2, '#2E7D32'),
        ("Fond ouvrage (puits)",    alt_fond,           '#546E7A'),
    ]

    y_ann = 1.45
    for lbl, val, col in alt_rows:
        ax.text(title_ann_x - 2.8, y_ann, lbl,
                ha='left', va='center', fontsize=8.5, color='#37474F', zorder=12)
        ax.text(title_ann_x + 0.3, y_ann, f"{val:.2f} m NGF",
                ha='right', va='center', fontsize=8.5, fontweight='bold',
                color=col, zorder=12,
                bbox=dict(boxstyle='round,pad=0.2', fc='white', ec=col,
                          alpha=0.85, lw=1.0))
        ax.plot([title_ann_x - 2.85, title_ann_x + 0.35], [y_ann - 0.22]*2,
                color='#ECEFF1', lw=0.8, zorder=11)
        y_ann -= 0.48

    # ─────────────────────────────────────────────────────────────
    # ANNOTATIONS RABATTEMENTS — flèches verticales sur chaque ouvrage
    # ─────────────────────────────────────────────────────────────
    def _annot_rabat(ax, xc, y_ns, y_nd, label_s, label_nd, color, offset_x=0.5):
        """Flèche double NS → ND avec label rabattement."""
        if abs(y_nd - y_ns) < 0.05: return
        ax.annotate('', xy=(xc + offset_x, y_nd), xytext=(xc + offset_x, y_ns),
                    arrowprops=dict(arrowstyle='<->', color=color, lw=2.0,
                                    mutation_scale=14), zorder=12)
        ax.plot([xc + offset_x - 0.12, xc + offset_x + 0.12], [y_ns]*2,
                color=color, lw=1.2, zorder=12)
        ax.plot([xc + offset_x - 0.12, xc + offset_x + 0.12], [y_nd]*2,
                color=color, lw=1.2, zorder=12)
        ax.text(xc + offset_x + 0.22, (y_ns + y_nd) / 2,
                label_s,
                ha='left', va='center', fontsize=9, color=color, fontweight='bold',
                zorder=12,
                bbox=dict(boxstyle='round,pad=0.3', fc='white',
                          ec=color, alpha=0.92, lw=1.0))
        # Label ND
        ax.text(xc + offset_x + 0.22, y_nd - 0.15,
                label_nd, ha='left', va='top', fontsize=8, color=color,
                zorder=12)

    _annot_rabat(ax, x_pw, y_NS, y_nd_pw,
                 f"s = {s_puits:.2f} m",
                 f"ND = {alt_nd_puits:.2f} m NGF",
                 '#C62828', offset_x=rp*2.5)

    _annot_rabat(ax, x_P1, y_NS, y_nd_P1,
                 f"s = {s_P1:.2f} m",
                 f"ND = {alt_nd_P1:.2f} m NGF",
                 '#2E7D32', offset_x=rp*1.8)

    _annot_rabat(ax, x_P2, y_NS, y_nd_P2,
                 f"s = {s_P2:.2f} m",
                 f"ND = {alt_nd_P2:.2f} m NGF",
                 '#2E7D32', offset_x=rp*1.8)

    # ─────────────────────────────────────────────────────────────
    # DISTANCES HORIZONTALES (cotes entre ouvrages)
    # ─────────────────────────────────────────────────────────────
    y_dist = y_bot - 0.3
    for x1, x2, dlbl in [(x_pw, x_P1, f"{dist_P1:.1f} m"),
                          (x_P1, x_P2, f"{dist_P2-dist_P1:.1f} m"),
                          (x_pw, x_P2, f"{dist_P2:.1f} m")]:
        y_off = y_dist if (x1==x_pw and x2==x_P2) else y_dist + 0.55
        ax.annotate('', xy=(x2, y_off), xytext=(x1, y_off),
                    arrowprops=dict(arrowstyle='<->', color='#546E7A',
                                    lw=1.8, mutation_scale=13), zorder=11)
        ax.plot([x1]*2, [y_off-0.1, y_off+0.1], color='#546E7A', lw=1.2, zorder=11)
        ax.plot([x2]*2, [y_off-0.1, y_off+0.1], color='#546E7A', lw=1.2, zorder=11)
        ax.text((x1+x2)/2, y_off + 0.17, dlbl,
                ha='center', va='bottom', fontsize=9, color='#546E7A',
                fontweight='bold', zorder=12,
                bbox=dict(boxstyle='round,pad=0.2', fc='white',
                          ec='#90A4AE', alpha=0.9, lw=0.8))

    # ─────────────────────────────────────────────────────────────
    # LÉGENDE
    # ─────────────────────────────────────────────────────────────
    legend_items = [
        mpatches.Patch(color='#B3E5FC', alpha=0.6, label='Zone saturée (aquifère)'),
        mpatches.Patch(color='#D7CCC8', alpha=0.5, label='Zone non saturée'),
        Line2D([0],[0], color='#0277BD', lw=2.5, label='Surface piézométrique (Theis)'),
        Line2D([0],[0], color='#C62828', lw=1.8, ls=(0,(8,4)),
               label=f'Niveau statique  NS = {NS_m:.2f} m/TN  |  {alt_NS:.2f} m NGF'),
        mpatches.Patch(color='#90A4AE', label='Tube plein (puits)'),
        mpatches.Patch(color='#B2EBF2', label='Crépine (zone captante)'),
        mpatches.Patch(color='#A5D6A7', label='Tube piézomètre P1 / P2'),
        Line2D([0],[0], color='#C62828', lw=2.0, marker='^', ms=7,
               label=f'Débit pompage  Q = {Q_m3s*3600:.2f} m³/h'),
    ]
    leg = ax.legend(handles=legend_items, loc='lower right', fontsize=9,
                    framealpha=0.97, edgecolor='#1B474D',
                    ncol=2, title='  LÉGENDE  ', title_fontsize=10,
                    borderpad=0.9, handlelength=1.8, columnspacing=1.2)
    leg.get_title().set_fontweight('bold')
    leg.get_title().set_color('#1B474D')

    # ── Axe NGF à gauche ──
    ax2 = ax.twinx()
    ax2.set_ylim(y_bot - 0.8, 3.5)
    altis = [alt_TN, alt_NS, alt_nd_puits, alt_nd_P1, alt_nd_P2, alt_fond]
    y_pos = [y_TN, y_NS, y_nd_pw, y_nd_P1, y_nd_P2, y_fond]
    ax2.set_yticks(y_pos)
    ax2.set_yticklabels([f"{a:.2f} m NGF" for a in altis], fontsize=8.5)
    ax2.tick_params(axis='y', colors='#37474F', labelsize=8.5)
    ax2.spines['right'].set_color('#37474F')
    ax2.spines['right'].set_linewidth(1.2)
    for side in ['top','left','bottom']:
        ax2.spines[side].set_visible(False)
    ax2.set_ylabel("Altitude (m NGF)", fontsize=10, color='#37474F', labelpad=12)

    plt.tight_layout(pad=0.8)
    plt.savefig(output_path, dpi=200, bbox_inches='tight',
                facecolor='white', edgecolor='none')
    plt.close()
    print(f"Schéma piézomètres : {output_path}")
    return output_path


if __name__ == '__main__':
    params = {
        'diam_int': 0.30, 'diam_ext': 0.40, 'profondeur': 6.0,
        'alt_tete_ngf': 107.5, 'alt_fond_ngf': 101.5,
        'ns': 2.8, 'fond_fouille': 6.0, 'rayon_gravier': 0.25,
        'rayon_inf': 10.0, 'T': 1.5e-4, 'S': 0.1, 'Q': 2.29/3600
    }
    draw_piezometre(params, '/tmp/schema_piezometre.png')
    draw_cone_rabattement(params, '/tmp/schema_cone_rabattement.png')
    print("OK")
