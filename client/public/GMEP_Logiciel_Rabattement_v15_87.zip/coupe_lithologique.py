"""
Coupe lithologique réelle du forage pour le dossier Loi sur l'Eau — v15.83
Génère un schéma vectoriel matplotlib avec les niveaux NGF,
COUCHES RÉELLES saisies dans l'onglet Coupe_Geologique du xlsm.
NE PROJETTE PLUS de coupe régionale BRGM.

Module propriétaire — Coupe Géologique G.M.E.P
"""
import os
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Rectangle
import numpy as np

# ── Palette professionnelle ──────────────────────────────────────────────────
COL_TEAL       = "#01696F"
COL_RED        = "#A12C7B"
COL_EAU_NS     = "#5DA8C7"   # niveau statique
COL_EAU_FF     = "#A63030"   # fond de fouille / FF
COL_FORAGE     = "#37474F"   # tubage

# ── Mapping lithologie → style ────────────────────────────────────────────────
LITHO_STYLES = {
    # famille → (couleur fond, couleur hachure, motif: 'oblique'/'points'/'briques'/'horiz'/'croix'/'vague')
    "Argile":      ("#C8A87A", "#7A5C2E", "oblique"),
    "Limon":       ("#D4C4A8", "#8B7355", "oblique"),
    "Sable":       ("#E8D9A0", "#7A6A3D", "points"),
    "Gravier":     ("#D0C090", "#6B5A30", "points"),
    "Alluvion":    ("#D8C890", "#7A6840", "points"),
    "Marne":       ("#B5A88A", "#5A4E36", "horiz"),
    "Calcaire":    ("#B8C7CF", "#5A6B75", "briques"),
    "Craie":       ("#F0EFE9", "#909090", "briques"),
    "Silex":       ("#C0C8D0", "#607080", "briques"),
    "Grès":        ("#D4B896", "#805030", "briques"),
    "Granite":     ("#D0C8C0", "#706860", "croix"),
    "Schiste":     ("#C8B8A8", "#605040", "croix"),
    "Remblai":     ("#B0BEC5", "#607080", "vague"),
    "Socle":       ("#A0A0A8", "#505058", "croix"),
    "Gneiss":      ("#C8BEB8", "#686460", "croix"),
    "Basalte":     ("#909090", "#404040", "croix"),
    "Tourbe":      ("#8B6914", "#4A3008", "horiz"),
    "Craie blanche":("#F0EFE9", "#909090", "briques"),
    "default":     ("#C0C0C0", "#808080", "horiz"),
}

def _get_litho_style(libelle: str):
    """Retourne (couleur_fond, couleur_hachure, motif) selon le libellé."""
    if not libelle:
        return LITHO_STYLES["default"]
    lib = libelle.lower()
    for key, style in LITHO_STYLES.items():
        if key == "default":
            continue
        if key.lower() in lib:
            return style
    return LITHO_STYLES["default"]

def _draw_hachures(ax, x0, x1, z_bot, z_top, col_hach, motif, rng=None):
    """Dessine les hachures lithologiques selon le motif."""
    if rng is None:
        rng = np.random.default_rng(42)
    height = z_top - z_bot
    if height <= 0:
        return
    if motif == "oblique":
        step_x, step_z = 0.55, max(0.25, height / max(1, int(height / 0.4)))
        for z in np.arange(z_bot + 0.2, z_top - 0.05, step_z):
            for x in np.arange(x0 + 0.1, x1 - 0.15, step_x):
                ax.plot([x, x + 0.22], [z, z + 0.18], color=col_hach, linewidth=0.4, zorder=3)
    elif motif == "points":
        n_pts = max(10, int((x1 - x0) * height * 15))
        xs = rng.uniform(x0 + 0.2, x1 - 0.2, n_pts)
        ys = rng.uniform(z_bot + 0.1, z_top - 0.1, n_pts)
        ax.scatter(xs, ys, s=2, c=col_hach, alpha=0.55, zorder=3)
    elif motif == "briques":
        bw, bh = 1.2, max(0.3, min(0.5, height / 4))
        for j, z in enumerate(np.arange(z_bot + bh / 2, z_top - 0.05, bh)):
            offset = (bw / 2) if j % 2 == 0 else 0
            for x in np.arange(x0 - bw + offset, x1 + bw, bw):
                ax.plot([max(x0, x), min(x1, x + bw)], [z, z], color=col_hach, linewidth=0.3, zorder=3)
                ax.plot([max(x0, x), max(x0, x)], [max(z_bot, z - bh / 2), min(z_top, z + bh / 2)],
                        color=col_hach, linewidth=0.3, zorder=3)
    elif motif == "horiz":
        step_z = max(0.25, height / max(1, int(height / 0.45)))
        for z in np.arange(z_bot + 0.25, z_top - 0.1, step_z):
            for x in np.arange(x0 + 0.3, x1 - 0.3, 1.5):
                ax.plot([x, min(x + 0.9, x1 - 0.1)], [z, z], color=col_hach, linewidth=0.4, zorder=3)
    elif motif == "croix":
        step = max(0.5, min(1.2, height / 3))
        for z in np.arange(z_bot + 0.3, z_top - 0.2, step):
            for x in np.arange(x0 + 0.5, x1 - 0.4, 1.0):
                ax.plot([x - 0.15, x + 0.15], [z, z], color=col_hach, linewidth=0.5, zorder=3)
                ax.plot([x, x], [z - 0.12, z + 0.12], color=col_hach, linewidth=0.5, zorder=3)
    elif motif == "vague":
        step_z = max(0.35, height / max(1, int(height / 0.5)))
        for z in np.arange(z_bot + 0.2, z_top - 0.1, step_z):
            xs = np.linspace(x0 + 0.2, x1 - 0.2, 30)
            ys = z + 0.06 * np.sin(np.linspace(0, 4 * np.pi, 30))
            ax.plot(xs, ys, color=col_hach, linewidth=0.4, alpha=0.7, zorder=3)


def schema_coupe_forage_reelle(out_path,
                                couches,
                                z_tn,
                                z_fond_forage,
                                NS,
                                FF,
                                prof_arrivee_eau=None,
                                commune="",
                                ref_cad=""):
    """
    Dessine la coupe lithologique RÉELLE du forage.

    Parameters
    ----------
    couches : list of dict
        Chaque dict : {"libelle": str, "de": float, "a": float, "K": float, "e_sat": float}
    z_tn   : float  — altitude tête puits NGF (m)
    z_fond_forage : float — altitude fond forage NGF (m)
    NS     : float  — niveau statique (profondeur/TN, m)
    FF     : float  — fond de fouille (profondeur/TN, m)
    prof_arrivee_eau : float or None — profondeur arrivée eau constatée /TN
    commune : str
    ref_cad : str
    """
    rng = np.random.default_rng(42)
    prof_total = z_tn - z_fond_forage  # profondeur totale forée (m)

    # Cotes NGF des niveaux hydrauliques
    z_ns = z_tn - NS    # cote NGF nappe stat.
    z_ff = z_tn - FF    # cote NGF fond fouille

    # Marges graphiques
    z_top_ax = z_tn + max(1.5, prof_total * 0.04)
    z_bot_ax = z_fond_forage - max(1.5, prof_total * 0.05)

    fig, ax = plt.subplots(figsize=(11, 9.5), dpi=140)
    ax.set_ylim(z_bot_ax, z_top_ax)
    ax.set_xlim(0, 12)
    ax.set_aspect("auto")

    # ── Fond blanc ──
    ax.set_facecolor("white")
    fig.patch.set_facecolor("white")

    # ── Dessin des couches réelles ──
    legend_elements = []
    seen_lithos = set()

    for c in couches:
        De = c.get("de", 0.0)
        A  = c.get("a", 0.0)
        lib = c.get("libelle", "—") or "—"
        if A <= De:
            continue
        z_c_top = z_tn - De
        z_c_bot = z_tn - A
        if z_c_bot >= z_top_ax or z_c_top <= z_bot_ax:
            continue

        z_c_top = min(z_c_top, z_top_ax)
        z_c_bot = max(z_c_bot, z_bot_ax)

        col_fond, col_hach, motif = _get_litho_style(lib)

        ax.add_patch(Rectangle((0, z_c_bot), 12, z_c_top - z_c_bot,
                                facecolor=col_fond, edgecolor="#8B8080",
                                linewidth=0.5, zorder=2))
        _draw_hachures(ax, 0, 12, z_c_bot, z_c_top, col_hach, motif, rng)

        # Label lithologie à gauche — décalé pour ne pas chevaucher l'axe profondeur
        # L'axe profondeur étant en (axes, -0.10), on place le texte plus loin
        z_mid = (z_c_top + z_c_bot) / 2
        ax.text(-1.6, z_mid, lib,
                fontsize=8.5, ha="right", va="center",
                color="#2A1E10", fontweight="bold", clip_on=False)

        # Légende
        fam_key = None
        for key in LITHO_STYLES:
            if key != "default" and key.lower() in lib.lower():
                fam_key = key
                break
        legend_key = lib if fam_key is None else fam_key
        if legend_key not in seen_lithos:
            seen_lithos.add(legend_key)
            legend_elements.append(
                mpatches.Patch(facecolor=col_fond, edgecolor="#8B8080",
                                label=lib[:35]))

    # ── Lignes interfaces de couches ──
    for c in couches:
        for depth in [c.get("de"), c.get("a")]:
            if depth is None:
                continue
            z_iface = z_tn - depth
            if z_bot_ax < z_iface < z_top_ax:
                ax.axhline(z_iface, color="#6B5840", linewidth=0.5,
                            linestyle="-", alpha=0.5, zorder=4)

    # ── Niveau statique (NS) ──
    if z_bot_ax < z_ns < z_top_ax:
        ax.fill_between([0, 12], z_bot_ax, z_ns,
                         facecolor=COL_EAU_NS, alpha=0.15, zorder=2)
        ax.axhline(z_ns, color=COL_EAU_NS, linewidth=2.0,
                    linestyle="--", zorder=5)
        for x in [1.5, 5.5, 10.0]:
            ax.plot(x, z_ns + 0.04, marker="v", color=COL_EAU_NS,
                     markersize=8, zorder=6)
        legend_elements.append(
            plt.Line2D([0], [0], color=COL_EAU_NS, lw=2, linestyle="--",
                        label=f"Niveau statique (NS = {NS:.2f} m/TN)"))

    # ── Fond de fouille (FF) ──
    if z_bot_ax < z_ff < z_top_ax:
        ax.axhline(z_ff, color=COL_EAU_FF, linewidth=2.0,
                    linestyle="-.", zorder=5)
        legend_elements.append(
            plt.Line2D([0], [0], color=COL_EAU_FF, lw=2, linestyle="-.",
                        label=f"Fond de fouille (FF = {FF:.2f} m/TN)"))

    # ── Arrivée d'eau constatée ──
    if prof_arrivee_eau is not None:
        z_arrivee = z_tn - prof_arrivee_eau
        if z_bot_ax < z_arrivee < z_top_ax:
            ax.annotate("",
                         xy=(3.5, z_arrivee),
                         xytext=(2.5, z_arrivee + prof_total * 0.06),
                         arrowprops=dict(arrowstyle="->", color="#1F5F8B", lw=1.5),
                         zorder=7)
            ax.text(3.7, z_arrivee,
                     f"Arrivée d'eau\n({prof_arrivee_eau:.2f} m/TN)",
                     fontsize=7.5, color="#1F5F8B", va="center", zorder=7)
            legend_elements.append(
                plt.Line2D([0], [0], color="#1F5F8B", lw=1.5,
                            marker=">", markersize=6,
                            label=f"Arrivée d'eau ({prof_arrivee_eau:.2f} m/TN)"))

    # ── Schéma forage (tubage) ──
    forage_x = 6.0
    forage_w = 0.50
    z_f_bot = max(z_fond_forage, z_bot_ax)
    ax.add_patch(Rectangle((forage_x - forage_w / 2, z_f_bot),
                            forage_w, z_tn - z_f_bot,
                            facecolor="white", edgecolor=COL_FORAGE,
                            linewidth=1.8, zorder=8))
    # Eau dans forage
    if z_ns > z_fond_forage:
        ax.fill_between([forage_x - forage_w / 2 + 0.04,
                          forage_x + forage_w / 2 - 0.04],
                          z_f_bot, z_ns,
                          facecolor=COL_EAU_NS, alpha=0.75, zorder=9)
    # Fond forage (bouchon)
    ax.plot([forage_x - forage_w / 2, forage_x + forage_w / 2],
             [z_f_bot, z_f_bot], color=COL_FORAGE, linewidth=2.5, zorder=9)

    # ── Cotes NGF à droite ──
    # Stratégie anti-chevauchement v15.84 :
    # 1) Repérer toutes les annotations à dessiner (prioritaires d'abord)
    # 2) Ajuster verticalement (y_disp) tout point trop proche de son voisin
    # 3) Tirer un trait connecteur du point réel vers son label décalé
    ax_right = 12.2
    # Pas vertical minimum entre deux étiquettes (en unités m NGF, fonction du zoom)
    z_span = z_top_ax - z_bot_ax
    # ~7.5 pt de police → ~0.020 du span vertical par ligne, on garde une marge
    label_min_step = z_span * 0.035

    # Construire la liste des annotations (priorité décroissante)
    annotations = []
    annotations.append({"z": z_tn,           "label": "Tête puits (TN)",                       "color": "#4A3A20",  "bold": True,  "prio": 0})
    annotations.append({"z": z_fond_forage,  "label": f"Fond forage -{prof_total:.2f} m",        "color": COL_FORAGE, "bold": True,  "prio": 0})
    if z_bot_ax < z_ns < z_top_ax:
        annotations.append({"z": z_ns, "label": f"Niveau statique -NS {NS:.2f} m", "color": COL_EAU_NS, "bold": True, "prio": 1})
    if z_bot_ax < z_ff < z_top_ax:
        annotations.append({"z": z_ff, "label": f"Fond fouille -FF {FF:.2f} m",    "color": COL_EAU_FF, "bold": True, "prio": 1})
    # Interfaces de couches (priorité plus faible — on supprime si chevauchement)
    seen_depths = set()
    for c in couches:
        for depth in [c.get("de"), c.get("a")]:
            if depth is None or depth in seen_depths:
                continue
            seen_depths.add(depth)
            z_iface = z_tn - depth
            if z_iface == z_tn or z_iface == z_fond_forage:
                continue
            if z_bot_ax <= z_iface <= z_top_ax:
                annotations.append({
                    "z": z_iface,
                    "label": f"-{depth:.2f} m/TN",
                    "color": "#555555",
                    "bold": False,
                    "prio": 3,
                })

    # Tri par cote décroissante (haut → bas) pour traitement
    annotations.sort(key=lambda a: -a["z"])

    # Suppression des annotations basse priorité trop proches d'une haute priorité
    kept = []
    for a in sorted(annotations, key=lambda x: (x["prio"], -x["z"])):
        too_close_hi = any(
            k["prio"] < a["prio"] and abs(k["z"] - a["z"]) < label_min_step
            for k in kept
        )
        if too_close_hi:
            continue
        kept.append(a)

    # Tri final par cote décroissante
    kept.sort(key=lambda a: -a["z"])

    # Calcul des positions d'affichage (y_disp) — décalage vertical anti-collision
    # On part de la cote réelle puis on pousse vers le bas si trop près du voisin précédent
    for i, a in enumerate(kept):
        if i == 0:
            a["y_disp"] = a["z"]
        else:
            prev_y = kept[i - 1]["y_disp"]
            a["y_disp"] = min(a["z"], prev_y - label_min_step)

    # Tracé
    def annotate_z(a):
        fs = "bold" if a["bold"] else "normal"
        z_val = a["z"]
        y_disp = a["y_disp"]
        color = a["color"]
        # Trait connecteur du bord du graphe à la position décalée
        ax.plot([12, ax_right - 0.05], [z_val, y_disp],
                color=color, lw=0.5, clip_on=False, zorder=10)
        ax.text(ax_right + 0.1, y_disp,
                f"{z_val:.2f} m NGF",
                fontsize=7.5, color=color, fontweight=fs,
                va="center", ha="left", clip_on=False)
        # Séparateur visuel entre cote NGF et libellé (positions x calées)
        ax.text(ax_right + 2.6, y_disp,
                f"— {a['label']}",
                fontsize=7.5, color=color, fontweight=fs,
                va="center", ha="left", clip_on=False)

    for a in kept:
        annotate_z(a)

    # ── Axes ──
    # Pas de ylabel principal : les ticks NGF sont déjà explicites,
    # et le label se chevauchait avec l'axe profondeur déplacé à gauche.
    ax.set_ylabel("")
    ax.set_xticks([])
    # Ticks NGF en teal pour signature visuelle
    ax.tick_params(axis="y", colors=COL_TEAL, labelsize=8)

    # Axe secondaire profondeur /TN — placé à GAUCHE, sans label vertical
    # pour éviter tout chevauchement.
    ax2 = ax.twinx()
    ax2.set_ylim(z_bot_ax, z_top_ax)
    ax2.yaxis.tick_left()
    ax2.yaxis.set_label_position("left")
    ax2.spines["left"].set_position(("axes", -0.10))
    ax2.spines["right"].set_visible(False)
    ax2.spines["top"].set_visible(False)
    ax2.spines["bottom"].set_visible(False)
    ax2.spines["left"].set_visible(True)
    ax2.spines["left"].set_color("#555555")
    prof_ticks = np.arange(0, prof_total + 2, 1 if prof_total <= 15 else 2)
    z_ticks = [z_tn - p for p in prof_ticks if z_bot_ax <= z_tn - p <= z_top_ax]
    p_ticks_lab = [f"{z_tn - z:.1f} m" for z in z_ticks]
    ax2.set_yticks(z_ticks)
    ax2.set_yticklabels(p_ticks_lab, fontsize=7, color="#555555")
    ax2.tick_params(axis="y", which="both", direction="out", colors="#555555", pad=2)
    # Pas de ylabel sur ax2 — mais légende complète en titre / ticks suffisamment clairs
    ax2.set_ylabel("")
    # Petites annotations discrètes pour indiquer les unités des deux axes Y
    # — placées SOUS le titre pour ne PAS chevaucher.
    fig.text(0.025, 0.83, "Profondeur\n/ TN (m)",
             fontsize=7.5, color="#555555", ha="left", va="top", style="italic")
    fig.text(0.215, 0.83, "Cote\n(m NGF)",
             fontsize=7.5, color=COL_TEAL, ha="left", va="top", fontweight="bold")

    # Titre
    titre_commune = commune if commune else "Forage"
    ref_str = f" — {ref_cad}" if ref_cad else ""
    ax.set_title(
        f"Coupe lithologique forage — {titre_commune}{ref_str}\n"
        f"Coupe Géologique G.M.E.P — données saisies",
        fontsize=11, fontweight="bold", color=COL_TEAL, pad=12)

    # Grille horizontale
    ax.yaxis.set_major_locator(matplotlib.ticker.MultipleLocator(
        1 if prof_total <= 10 else (2 if prof_total <= 30 else 5)))
    ax.grid(axis="y", which="major", linestyle=":", linewidth=0.4,
             color="#AAAAAA", alpha=0.6)
    ax.set_axisbelow(True)

    # Bordure
    for spine in ax.spines.values():
        spine.set_edgecolor("#666666")
        spine.set_linewidth(0.6)

    # Légende
    if legend_elements:
        ax.legend(handles=legend_elements,
                   loc="lower left",
                   bbox_to_anchor=(0.0, -0.20),
                   ncol=min(3, len(legend_elements)),
                   fontsize=7.5,
                   frameon=True,
                   edgecolor="#AAAAAA")

    # Source
    fig.text(0.99, 0.005,
              "Source : données forage saisies — Coupe Géologique G.M.E.P v15.84",
              fontsize=6.5, color="#666666", ha="right", va="bottom", style="italic")

    plt.subplots_adjust(left=0.28, right=0.68, top=0.88, bottom=0.20)
    fig.savefig(out_path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return out_path


def lire_coupe_xlsm(xlsm_path):
    """
    Lit les données de coupe réelle depuis le xlsm (onglet Coupe_Geologique).
    Retourne un dict avec couches, z_tn, NS, FF, r, etc.
    Si le fichier fourni est un .xlsx sans l'onglet Coupe_Geologique,
    tente automatiquement de trouver le .xlsm correspondant.
    """
    import openpyxl, os as _os

    # Si le fichier est un xlsx sans Coupe_Geologique → chercher le xlsm adjacent
    def _open_wb(path):
        keep = path.lower().endswith('.xlsm')
        return openpyxl.load_workbook(path, keep_vba=keep, data_only=True)

    wb = _open_wb(xlsm_path)
    if 'Coupe_Geologique' not in wb.sheetnames:
        # Chercher le .xlsm dans le même répertoire
        base_dir = _os.path.dirname(xlsm_path)
        for fname in _os.listdir(base_dir):
            if fname.lower().endswith('.xlsm') and 'rabattement' in fname.lower():
                candidate = _os.path.join(base_dir, fname)
                try:
                    wb2 = _open_wb(candidate)
                    if 'Coupe_Geologique' in wb2.sheetnames:
                        wb = wb2
                        break
                except Exception:
                    pass
    if 'Coupe_Geologique' not in wb.sheetnames:
        raise KeyError("Worksheet Coupe_Geologique does not exist.")
    ws = wb['Coupe_Geologique']

    def sv(cell_ref, default=None):
        val = ws[cell_ref].value
        if val is None:
            return default
        return val

    def sf(cell_ref, default=0.0):
        val = ws[cell_ref].value
        try:
            return float(val)
        except (TypeError, ValueError):
            return default

    z_tn  = sf("C11", 125.50)
    NS    = sf("C18", 2.80)
    FF    = sf("C19", 4.00)
    r     = sf("C20", 0.056)
    prof  = sf("C17", 10.0)
    arrivee = sf("C12", None) if ws["C12"].value is not None else None
    commune  = sv("C6", "")
    ref_cad  = sv("C7", "")

    # Construire le cache VLOOKUP depuis _GMEP_Listes_v79
    _listes_v79_cache = {}
    if '_GMEP_Listes_v79' in wb.sheetnames:
        _ws_listes = wb['_GMEP_Listes_v79']
        for _r in range(2, 50):
            _a = _ws_listes.cell(_r, 1).value
            _b = _ws_listes.cell(_r, 2).value
            if _a and _b is not None:
                try:
                    _listes_v79_cache[str(_a).strip()] = float(_b)
                except (TypeError, ValueError):
                    pass

    couches = []
    for row in range(27, 42):
        c_de  = ws.cell(row, 3).value   # C = De
        c_a   = ws.cell(row, 4).value   # D = A
        c_lib = ws.cell(row, 5).value   # E = libelle
        c_K   = ws.cell(row, 6).value   # F = K (m/s)
        c_esat = ws.cell(row, 9).value  # I = e_sat

        # Skip rows with merged cells or no data
        if c_de is None and c_a is None and c_lib is None:
            continue
        try:
            de = float(c_de) if c_de is not None else None
            a  = float(c_a)  if c_a  is not None else None
        except (TypeError, ValueError):
            continue
        if de is None or a is None or a <= de:
            continue

        # K peut être une formule (VLOOKUP) non recalculée en data_only
        # → rechercher dans _GMEP_Listes_v79 si K est None/str
        if c_K is not None and not isinstance(c_K, str):
            try:
                K = float(c_K)
            except (TypeError, ValueError):
                K = None
        else:
            K = None
        # Fallback VLOOKUP local depuis _GMEP_Listes_v79
        if K is None and c_lib and '_listes_v79_cache' in dir():
            K = _listes_v79_cache.get(str(c_lib).strip())
        # e_sat = MAX(0, MIN(A, FF) - MAX(De, NS)) pour couche saturée
        # Recalcul local car data_only ne recalcule pas les formules
        e_sat = 0.0
        try:
            if c_esat is not None and not isinstance(c_esat, str):
                e_sat = float(c_esat)
        except (TypeError, ValueError):
            pass
        if e_sat == 0.0:
            # Recalcul Python de e_sat basé sur NS et FF
            _ns_loc = float(ws['C18'].value or 0)
            _ff_loc = float(ws['C19'].value or 0)
            if de < _ff_loc and a > _ns_loc:
                e_sat = max(0.0, min(a, _ff_loc) - max(de, _ns_loc))
            else:
                e_sat = 0.0

        couches.append({
            "libelle": str(c_lib).strip() if c_lib else "",
            "de": de,
            "a": a,
            "K": K,
            "e_sat": e_sat,
        })

    z_fond = z_tn - prof
    return {
        "couches": couches,
        "z_tn": z_tn,
        "z_fond_forage": z_fond,
        "NS": NS,
        "FF": FF,
        "r": r,
        "prof_arrivee_eau": arrivee,
        "commune": commune,
        "ref_cad": ref_cad,
    }


# ── API de compatibilité descendante (ancienne signature) ──────────────────
def schema_coupe_lithologique(out_path,
                               z_tn=125.50,
                               z_fond_actuel=None,
                               z_eau_perchee=None,
                               z_toit_calcaire_min=None,
                               z_toit_calcaire_max=None,
                               z_eau_stampien=None,
                               z_fond_recommande=None,
                               commune="Oucques-la-Nouvelle",
                               ref_cad="41171 AC 0007",
                               couches=None,
                               z_fond_forage=None,
                               NS=None,
                               FF=None,
                               prof_arrivee_eau=None):
    """
    Wrapper de compatibilité.
    Si couches + paramètres réels fournis → coupe réelle (v15.83).
    Sinon → coupe basique avec valeurs par défaut (fallback).
    """
    if z_fond_forage is None:
        z_fond_forage = z_fond_actuel if z_fond_actuel is not None else z_tn - 10.0
    if NS is None:
        NS = z_tn - z_eau_perchee if z_eau_perchee is not None else 2.80
    if FF is None:
        FF = z_tn - z_fond_forage + 1.0  # approximation si non fourni

    # Couches par défaut si non fournies (données exemple Oucques)
    if not couches:
        couches = [
            {"libelle": "Remblai hétérogène", "de": 0.0, "a": 1.20, "K": 1e-5, "e_sat": 0.0},
            {"libelle": "Marno-calcaire fissuré", "de": 1.20, "a": 2.80, "K": 1e-6, "e_sat": 1.10},
            {"libelle": "Calcaire de Beauce", "de": 2.80, "a": 3.00, "K": 5e-4, "e_sat": 0.0},
        ]

    return schema_coupe_forage_reelle(
        out_path=out_path,
        couches=couches,
        z_tn=z_tn,
        z_fond_forage=z_fond_forage,
        NS=NS,
        FF=FF,
        prof_arrivee_eau=prof_arrivee_eau,
        commune=commune,
        ref_cad=ref_cad,
    )


if __name__ == "__main__":
    out = os.path.join(os.path.dirname(__file__), "cartes_gmep", "Coupe_Lithologique_Forage.png")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    schema_coupe_lithologique(out)
    print(f"OK → {out}")
