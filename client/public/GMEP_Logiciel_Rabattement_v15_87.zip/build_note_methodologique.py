"""
GMEP v15.83 — Note Méthodologique PDF
Note_Methodologique_v15_83.pdf
"""
import math
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.colors import HexColor, black, white, grey
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak,
                                 Table, TableStyle, HRFlowable, KeepTogether)
from reportlab.pdfgen import canvas
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase import pdfmetrics

OUTPUT = "/tmp/v1582/Note_Methodologique_v15_83.pdf"

# ─── Colors ───────────────────────────────────────────────────────────────────
NAVY    = HexColor("#1A2B4A")
TEAL    = HexColor("#01696F")
BLUE    = HexColor("#1565C0")
DARK    = HexColor("#28251D")
GREY    = HexColor("#7A7974")
LGREY   = HexColor("#F7F6F2")
ORANGE  = HexColor("#DA7101")
GREEN   = HexColor("#2E7D32")
RED     = HexColor("#B22222")

# ─── Styles ───────────────────────────────────────────────────────────────────
styles = getSampleStyleSheet()

def S(name, parent="Normal", **kw):
    return ParagraphStyle(name, parent=styles[parent], **kw)

sTitle = S("sTitle", "Title", fontSize=26, textColor=white, fontName="Helvetica-Bold",
           alignment=TA_CENTER, spaceAfter=6)
sSub   = S("sSub", fontSize=13, textColor=HexColor("#AAD4D6"), fontName="Helvetica",
           alignment=TA_CENTER, spaceAfter=4)
sH1    = S("sH1", "Heading1", fontSize=14, textColor=NAVY, fontName="Helvetica-Bold",
           spaceBefore=16, spaceAfter=6, borderPad=4)
sH2    = S("sH2", "Heading2", fontSize=12, textColor=TEAL, fontName="Helvetica-Bold",
           spaceBefore=10, spaceAfter=4)
sH3    = S("sH3", "Heading3", fontSize=11, textColor=BLUE, fontName="Helvetica-Bold",
           spaceBefore=8, spaceAfter=3)
sBody  = S("sBody", fontSize=10, textColor=DARK, fontName="Helvetica",
           leading=14, spaceAfter=6, alignment=TA_JUSTIFY)
sBold  = S("sBold", fontSize=10, textColor=DARK, fontName="Helvetica-Bold", spaceAfter=4)
sNote  = S("sNote", fontSize=9, textColor=GREY, fontName="Helvetica",
           leading=12, spaceAfter=4, leftIndent=12, borderPad=4)
sMath  = S("sMath", fontSize=10, textColor=NAVY, fontName="Helvetica-Bold",
           alignment=TA_CENTER, spaceAfter=6, spaceBefore=6,
           backColor=HexColor("#EEF2FF"), borderPad=8, borderRadius=4)
sCaption = S("sCaption", fontSize=9, textColor=GREY, fontName="Helvetica",
             alignment=TA_CENTER, spaceAfter=8)
sFootnote = S("sFootnote", fontSize=8, textColor=GREY, fontName="Helvetica", leading=10)
sToc   = S("sToc", fontSize=10, textColor=DARK, fontName="Helvetica", spaceAfter=4, leftIndent=20)

# ─── Header/Footer callback ───────────────────────────────────────────────────
def on_page(c, doc):
    c.saveState()
    W, H = A4
    # Header bar
    c.setFillColor(NAVY)
    c.rect(0, H-28, W, 28, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 9)
    c.drawString(1.5*cm, H-19, "G.M.E.P — Note Méthodologique v15.83")
    c.setFont("Helvetica", 8)
    c.drawRightString(W - 1.5*cm, H-19, "Modélisation multicouche Forchheimer/Dupuit + Module Coupe Géologique G.M.E.P")
    # Footer
    c.setFillColor(LGREY)
    c.rect(0, 0, W, 32, fill=1, stroke=0)
    c.setFillColor(GREY)
    c.setFont("Helvetica", 8)
    c.drawString(1.5*cm, 14, "GMEP — 9 rue de la Marne, 79400 Saint-Maixent-l'École — gmep.france@gmail.com")
    c.setFillColor(NAVY)
    c.setFont("Helvetica-Bold", 9)
    c.drawRightString(W - 1.5*cm, 14, f"Page {doc.page}")
    c.restoreState()

def on_first_page(c, doc):
    """Cover page — no header/footer"""
    W, H = A4
    # Full navy background
    c.setFillColor(NAVY)
    c.rect(0, 0, W, H, fill=1, stroke=0)
    # Teal accent strip
    c.setFillColor(TEAL)
    c.rect(0, H*0.42, W, 8, fill=1, stroke=0)
    # Logo area
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 36)
    c.drawCentredString(W/2, H*0.68, "G.M.E.P")
    c.setFont("Helvetica", 13)
    c.setFillColor(HexColor("#AAD4D6"))
    c.drawCentredString(W/2, H*0.62, "Géotechnique — Milieu — Environnement — Protection")
    # Title box
    c.setFillColor(TEAL)
    c.roundRect(1.5*cm, H*0.42+16, W-3*cm, 100, 8, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 18)
    c.drawCentredString(W/2, H*0.42+80, "NOTE MÉTHODOLOGIQUE v15.83")
    c.setFont("Helvetica", 13)
    c.drawCentredString(W/2, H*0.42+54, "Modélisation Multicouche Forchheimer/Dupuit")
    c.setFont("Helvetica", 11)
    c.drawCentredString(W/2, H*0.42+30, "Ajout du modèle multicouche au logiciel GMEP Rabattement")
    # Meta info
    meta_y = H*0.35
    c.setFillColor(HexColor("#FFFFFF"))
    c.setFont("Helvetica-Bold", 10)
    c.drawString(2*cm, meta_y, "Auteur :")
    c.setFont("Helvetica", 10)
    c.drawString(5*cm, meta_y, "Eric Azulay — GMEP, 9 rue de la Marne, 79400 Saint-Maixent-l'École")
    c.setFont("Helvetica-Bold", 10)
    c.drawString(2*cm, meta_y-15, "Version :")
    c.setFont("Helvetica", 10)
    c.drawString(5*cm, meta_y-15, "15.79 — 28 mai 2026")
    c.setFont("Helvetica-Bold", 10)
    c.drawString(2*cm, meta_y-30, "Contact :")
    c.setFont("Helvetica", 10)
    c.drawString(5*cm, meta_y-30, "gmep.france@gmail.com — 06.97.73.72.33")
    c.setFont("Helvetica-Bold", 10)
    c.drawString(2*cm, meta_y-45, "SIRET :")
    c.setFont("Helvetica", 10)
    c.drawString(5*cm, meta_y-45, "75309762500010")
    # Disclaimer
    c.setFillColor(HexColor("#AAD4D6"))
    c.setFont("Helvetica", 9)
    c.drawCentredString(W/2, 3*cm, "Modèles ajoutés. Logique IOTA R.214-1 stricte invariante.")
    c.drawCentredString(W/2, 2.5*cm, "Les modèles Theis, Dupuit-Thiem et Domenico sont PRÉSERVÉS.")
    c.setFont("Helvetica-Bold", 8)
    c.setFillColor(white)
    c.drawCentredString(W/2, 1.5*cm, "www.gmep-france.eu")

# ─── Build story ─────────────────────────────────────────────────────────────
story = []
P = Paragraph

def HR(): return HRFlowable(color=TEAL, thickness=1, spaceAfter=8, spaceBefore=4)
def SP(h=0.3): return Spacer(1, h*cm)

def table_style(hdr_bg=NAVY):
    return TableStyle([
        ("BACKGROUND", (0,0), (-1,0), hdr_bg),
        ("TEXTCOLOR",  (0,0), (-1,0), white),
        ("FONTNAME",   (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",   (0,0), (-1,-1), 9),
        ("ALIGN",      (0,0), (-1,-1), "CENTER"),
        ("ALIGN",      (0,1), (0,-1), "LEFT"),
        ("VALIGN",     (0,0), (-1,-1), "MIDDLE"),
        ("GRID",       (0,0), (-1,-1), 0.4, HexColor("#CCCCCC")),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [white, LGREY]),
        ("TOPPADDING",    (0,0), (-1,-1), 4),
        ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ("LEFTPADDING",   (0,0), (-1,-1), 6),
        ("RIGHTPADDING",  (0,0), (-1,-1), 6),
    ])

# ─────────────────────────────────────────────────────────────────────────────
# AFTER COVER: blank page then main body
# ─────────────────────────────────────────────────────────────────────────────
story.append(PageBreak())

# ── SOMMAIRE ─────────────────────────────────────────────────────────────────
story.append(P("SOMMAIRE", sH1))
story.append(HR())
toc_items = [
    ("1", "Limites du modèle v15.78 — Substratum uniforme", "3"),
    ("2", "Approche Forchheimer/Dupuit multicouche — Équations et démonstration", "4"),
    ("2.1", "Formule par couche Q_i", "4"),
    ("2.2", "Additivité des transmissivités", "4"),
    ("2.3", "Rayon d'influence de Sichardt", "5"),
    ("2.4", "Mode A et Mode B", "5"),
    ("3", "Recalage piézométrique terrain", "6"),
    ("4", "Modes de calcul (A : Q→s ; B : s→Q et volume)", "6"),
    ("5", "Validation sur cas Colas Oucques La Nouvelle (41)", "7"),
    ("6", "Références bibliographiques", "8"),
]
for num, titre, pg in toc_items:
    story.append(P(f"<b>{num}</b>   {titre} {'.'*max(1,60-len(num)-len(titre))} {pg}", sToc))
story.append(SP())
story.append(PageBreak())

# ── 1. LIMITES v15.78 ────────────────────────────────────────────────────────
story.append(P("1. Limites identifiées du modèle v15.78 — Substratum uniforme", sH1))
story.append(HR())
story.append(P(
    "La version 15.78 du logiciel GMEP Rabattement de Nappe modélise le rabattement "
    "hydraulique en supposant un <b>substratum aquifère uniforme</b> : une seule formation "
    "géologique est sélectionnée, et ses paramètres hydrogéologiques (K, T, S) sont appliqués "
    "à l'ensemble de la colonne saturée. Cette approche monocouche est adaptée aux terrains "
    "homogènes, mais présente des limitations physiques importantes dans les contextes "
    "stratigraphiques complexes.", sBody))
story.append(P("<b>Limitation principale identifiée par l'ingénieur hydrogéologue :</b>", sBold))
story.append(P(
    "Lorsqu'un forage traverse plusieurs couches géologiques perméables superposées "
    "(par exemple : limon + sable + calcaire fissuré), <b>chacune contribue indépendamment "
    "au débit total par drainance</b>. Le modèle monocouche v15.78 ignore cette "
    "additivité et sous-estime le débit pompable réel.", sBody))
story.append(P("<b>Conséquences pratiques :</b>", sBold))
limits = [
    ["Limitation", "Impact sur le calcul"],
    ["Un seul substrat sélectionnable", "Sous-estimation du débit si plusieurs couches perméables"],
    ["T_ref tabulée (épaisseur typique)", "Peut sur- ou sous-estimer selon l'épaisseur réelle saturée"],
    ["Pas de saisie de coupe lithologique", "Impossible de restituer la stratigraphie réelle"],
    ["Rayon d'influence unifié", "R de Sichardt non adapté à la perméabilité composite"],
    ["Pas de recalage piézo terrain", "NS par défaut non corrigé par la mesure in situ"],
]
t = Table(limits, colWidths=[8*cm, 9*cm])
t.setStyle(table_style())
story.append(KeepTogether([t]))
story.append(SP())
story.append(P(
    "<i>Remarque : Ces limitations sont purement liées au champ d'application du modèle "
    "monocouche. La logique réglementaire IOTA R.214-1, les formules de Theis et "
    "Dupuit-Thiem, et toutes les références normatives restent inchangées.</i>", sNote))
story.append(PageBreak())

# ── 2. APPROCHE MULTICOUCHE ───────────────────────────────────────────────────
story.append(P("2. Approche Forchheimer/Dupuit Multicouche — Équations et démonstration", sH1))
story.append(HR())
story.append(P(
    "Le modèle v15.79 étend l'approche de Dupuit-Thiem à un milieu multicouche en "
    "appliquant le principe de superposition des débits, formalisé par Forchheimer (1898) "
    "et fondé sur la loi de Darcy appliquée à chaque couche individuellement.", sBody))

story.append(P("2.1 Formule par couche — Q<sub>i</sub>", sH2))
story.append(P(
    "Pour chaque couche <i>i</i> traversée par le forage, si la couche est <b>saturée</b> "
    "(profondeur > NS) et <b>perméable</b> (K<sub>i</sub> > 10<sup>-7</sup> m/s), "
    "elle contribue au débit par :", sBody))
story.append(P(
    "Q<sub>i</sub> = 2π · k<sub>i</sub> · e<sub>sat,i</sub> · s / ln(R/r)  ×  3600  [m³/h]",
    sMath))
story.append(P("<b>Avec :</b>", sBold))
params = [
    ["Paramètre", "Symbole", "Unité", "Définition"],
    ["Conductivité hydraulique couche i", "k_i", "m/s", "Base Géologique (42 formations)"],
    ["Épaisseur saturée de la couche i", "e_sat,i", "m", "max(0, min(a_i, FF) − max(de_i, NS))"],
    ["Rabattement requis", "s = FF − NS", "m", "Différence fond fouille / niveau statique"],
    ["Rayon d'influence", "R", "m", "Sichardt : R = 3000·s·√k (voir §2.3)"],
    ["Rayon du puits", "r", "m", "Diamètre intérieur / 2"],
]
t = Table(params, colWidths=[5.5*cm, 2*cm, 2*cm, 7.5*cm])
t.setStyle(table_style(TEAL))
story.append(KeepTogether([t]))
story.append(SP())

story.append(P("2.2 Additivité des transmissivités — Q<sub>total</sub>", sH2))
story.append(P(
    "Par le principe de superposition linéaire (Darcy, 1856), les débits individuels "
    "des couches perméables saturées s'additionnent :", sBody))
story.append(P(
    "Q<sub>total</sub> = Σ Q<sub>i</sub> = 2π · s / ln(R/r)  ×  Σ (k<sub>i</sub> · e<sub>sat,i</sub>)  ×  3600",
    sMath))
story.append(P(
    "La transmissivité équivalente est définie comme :", sBody))
story.append(P(
    "T<sub>éq</sub> = Σ (k<sub>i</sub> · e<sub>sat,i</sub>)  [m²/s]",
    sMath))
story.append(P(
    "Ce résultat est cohérent avec la formule de Dupuit-Thiem appliquée à un aquifère "
    "composite : Q<sub>total</sub> = 2π · T<sub>éq</sub> · s / ln(R/r) × 3600. "
    "<b>La justification physique</b> repose sur l'hypothèse d'équilibre hydraulique de "
    "Dupuit (gradient hydraulique uniforme dans chaque couche, flux horizontal dominant) "
    "et sur l'additivité des conductances en parallèle dans un milieu stratifié horizontal.", sBody))
story.append(P(
    "<i>Référence : Dupuit J. (1863). Études théoriques et pratiques sur le mouvement des "
    "eaux dans les canaux découverts et à travers les terrains perméables. Paris, Dunod. "
    "— Forchheimer P. (1898). Wasserbewegung durch Boden. Z. Ver. Dtsch. Ing., 45, 1782–1788.</i>",
    sNote))

story.append(P("2.3 Rayon d'influence de Sichardt", sH2))
story.append(P(
    "Pour un milieu multicouche, le rayon d'influence est calculé avec la perméabilité "
    "<b>maximale</b> des couches traversées :", sBody))
story.append(P(
    "R<sub>Sichardt</sub> = 3000 · s · √(K<sub>max</sub>)  [m]",
    sMath))
story.append(P(
    "Ce choix conservatif (K_max) assure que le rayon d'influence n'est pas sous-estimé "
    "pour les couches les plus perméables du profil.", sBody))

story.append(P("2.4 Deux modes de calcul", sH2))
modes_data = [
    ["Mode", "Entrées", "Sorties", "Cas d'usage"],
    [P("Mode B<br/>(défaut)", sBody), P("NS, FF, coupe géologique", sBody),
     P("Q_total, Volume,<br/>Statut IOTA", sBody),
     P("Rabattement de fouille —<br/>dimensionnement pompe", sBody)],
    [P("Mode A", sBody), P("Q imposé, coupe géologique", sBody),
     P("Rabattement s_A calculé", sBody),
     P("Vérification si débit pompe connu", sBody)],
]
t = Table(modes_data, colWidths=[2.2*cm, 4*cm, 4.3*cm, 5.5*cm])
t.setStyle(table_style(NAVY))
story.append(KeepTogether([t]))
story.append(SP())
story.append(P("<b>Mode A — Formule inverse :</b>  s<sub>A</sub> = Q · ln(R/r) / (2π · T<sub>éq</sub> · 3600)", sMath))

story.append(P("2.5 Coordonnées Lambert 93 — Synchronisation v15.83", sH2))
story.append(P(
    "Le module <b>Coupe Géologique G.M.E.P</b> (propriétaire v15.83) intègre les champs "
    "de géolocalisation officiels requis pour les dossiers de déclaration ou d'autorisation "
    "IOTA R.214-1 et pour la traçabilité des ouvrages forés. "
    "<b>Nouveauté v15.83 :</b> les coordonnées Lambert 93 X (C33) et Y (C34) de l'onglet "
    "Données d'Entrée sont synchronisées automatiquement vers l'en-tête du module Coupe "
    "Géologique G.M.E.P (C9/C10) via formules de liaison. L'altitude Z est également "
    "synchronisée depuis C35 (Altitude tête puits NGF). Dans l'outil web, les champs X/Y "
    "sont bidirectionnels entre le bloc carte et l'en-tête Coupe.", sBody))
story.append(P(
    "<b>Règle d'or :</b> la cellule C33 (X) et C34 (Y) de l'onglet <b>Données d'Entrée</b> "
    "constituent la source officielle des coordonnées Lambert 93. Toute modification dans "
    "cet onglet déclenche : 1) la mise à jour géographique automatique (commune, département, "
    "cartes IGN/BRGM/ZNIEFF) via la macro VBA Worksheet_Change, 2) la propagation vers "
    "Coupe_Geologique!C9 et C10 via formules de référence.", sBody))
coord_data = [
    ["Champ", "Valeur exemple", "Usage réglementaire"],
    [P("Nom du forage / piézomètre", sBody), P("Forage F1", sBody), P("Identification BSS / BRGM", sBody)],
    [P("Adresse du projet (rue)", sBody), P("195 rue de Claye", sBody), P("Localisation légale de l'ouvrage", sBody)],
    [P("Code postal + Ville", sBody), P("77400 THORIGNY SUR MARNE", sBody), P("Commune cadastrale", sBody)],
    [P("Date du forage", sBody), P("10/06/2025", sBody), P("Date exécution (obligations réglementaires)", sBody)],
    [P("X Lambert 93 (m)", sBody), P("678 658", sBody), P("Coordonnée officielle EPSG:2154 — IGN", sBody)],
    [P("Y Lambert 93 (m)", sBody), P("6 866 259", sBody), P("Coordonnée officielle EPSG:2154 — IGN", sBody)],
    [P("Z altitude TN (m NGF)", sBody), P("100,26", sBody), P("Référence altimétrique NGF-IGN69", sBody)],
    [P("Profondeur arrivée d'eau constatée", sBody), P("2,60 m/TN", sBody), P("Flèche bleue sur la coupe", sBody)],
]
t = Table(coord_data, colWidths=[5*cm, 4.5*cm, 7.5*cm])
t.setStyle(table_style(TEAL))
story.append(KeepTogether([t]))
story.append(SP())
story.append(P(
    "<b>Système de projection Lambert 93 (EPSG:2154) :</b> Le système de projection légal "
    "français depuis le 1er janvier 2001 (arrêté du 26 décembre 2000). Les coordonnées "
    "sont exprimées en mètres dans le référentiel RGF93. La conversion Lambert 93 → WGS84 "
    "est effectuée automatiquement dans l'outil web G.M.E.P par l'algorithme officiel IGN.", sBody))
story.append(P(
    "<b>Flèche d'arrivée d'eau :</b> La profondeur de première arrivée d'eau constatée lors du "
    "forage est matérialisée par une flèche bleue (↘) sur la coupe lithologique graphique, "
    "distincte du niveau statique (▽ NS). Cette distinction est conforme aux prescriptions "
    "des hydrogéologues agréés et aux fiches BSS du BRGM.", sBody))
story.append(P(
    "<i>Référence : IGN (2009). Géodésie — Systèmes de référence terrestres. "
    "La méthode de conversion Lambert 93 ↔ WGS84 est issue de la NTF (Notice Technique "
    "de Fonctionnement) IGN publiée par le Service Géodésie et Métrologie IGN.</i>", sNote))
story.append(PageBreak())

# ── 2.6 CORRECTIF v15.83 — Rayon d'influence Sichardt ────────────────────────
story.append(P("2.6 Correctif v15.83 — Rayon d'influence R_Sichardt", sH2))
story.append(P(
    "<b>Bug identifié en v15.81 :</b> La cellule C45 du classeur xlsm (Rayon d'influence "
    "Sichardt) utilisait la formule matricielle <code>SUMPRODUCT(MAX(IFERROR(F27:F41*1,0)))</code>. "
    "Cette combinaison de fonctions non matricielles imbriquées dans SUMPRODUCT "
    "retournait systématiquement 0 hors mode Ctrl+Shift+Enter (saisie CSE). "
    "Par cascade, R = 0 rendait le terme ln(R/r) indéfini, ce qui forçait "
    "tous les débits Q_i à 0 dans le tableau lithologie.", sBody))
story.append(P(
    "<b>Correction v15.83 (C45) :</b> Remplacement par une formule simple et robuste :",
    sBody))
story.append(P(
    "<font name='Courier' size='9'>C45 = IFERROR(IF(C44&gt;0, 3000*C44*SQRT(MAX(F27:F41)), 0), 0)</font>",
    sMath))
story.append(P(
    "La fonction <b>MAX(F27:F41)</b> retourne nativement K<sub>max</sub> parmi les valeurs "
    "numériques de la plage, en ignorant les cellules vides ou en erreur. "
    "C44 = FF − NS = rabattement s (m). La formule Sichardt appliquée est donc :",
    sBody))
story.append(P(
    "R = 3 000 · s · √(K<sub>max</sub>)  [en mètres, avec K<sub>max</sub> en m/s]",
    sMath))
rsich_data = [
    ["Paramètre", "Valeur (cas Oucques)", "Description"],
    ["NS", "1,70 m/TN", "Niveau statique mesuré"],
    ["FF", "2,80 m/TN", "Fond de fouille projet"],
    ["s = FF − NS", "1,10 m", "Rabattement nécessaire"],
    ["K_max", "5 × 10⁻⁴ m/s", "Calcaire de Beauce (couche 3)"],
    ["R_Sichardt", "3 000 × 1,10 × √(5×10⁻⁴) = 73,8 m", "Rayon d'influence corrigé"],
    ["ln(R/r)", "ln(73,8 / 0,056) = 7,18", "Terme logarithmique"],
    ["Q₂ (Marno-calc.)", "2π × 10⁻⁶ × 1,10 × 1,10 / 7,18 × 3600 = 0,00381 m³/h", "Débit couche saturée"],
    ["Q_total", "≈ 0,004 m³/h", "Versus 0 m³/h en v15.81"],
    ["V_annuel", "≈ 33,5 m³/an", "Hors nomenclature IOTA (< 10 000 m³/an)"],
]
t = Table(rsich_data, colWidths=[3.5*cm, 8*cm, 5.5*cm])
t.setStyle(table_style(TEAL))
story.append(KeepTogether([t]))
story.append(SP())
story.append(P(
    "<b>Cellule C47 (T_eq) :</b> La formule <code>SUMPRODUCT(IFERROR(F27:F41*I27:I41,0))</code> "
    "est remplacée par <code>IFERROR(SUMPRODUCT(IFERROR(F27:F41*1,0),IFERROR(I27:I41*1,0)),0)</code> "
    "pour une robustesse maximale face aux cellules vides ou mixtes (texte/nombre). "
    "Le comportement fonctionnel est identique : T_éq = Σ(K_i × e_sat_i).", sBody))
story.append(P(
    "<b>Coupe PDF — Correctif v15.83 :</b> Le PDF &quot;Dossier de déclaration Loi sur l'Eau&quot; "
    "affichait précédemment une coupe lithologique régionale projetée basée sur des hypothèses "
    "BRGM (Limons, Sables de l'Orléanais, Marnes, Calcaires de Beauce) indépendante de la "
    "saisie utilisateur. En v15.83, la coupe est générée à partir des données RÉELLES saisies "
    "dans l'onglet <b>Coupe Géologique G.M.E.P</b> (couches B27:J41, NS C18, FF C19, "
    "altitude Z TN C11). Les hachures lithologiques, cotes NGF et annotations hydrauliques "
    "reflètent exactement le forage décrit par l'ingénieur.", sBody))
story.append(PageBreak())

# ── 3. RECALAGE PIÉZO ─────────────────────────────────────────────────────────
story.append(P("3. Recalage piézométrique terrain", sH1))
story.append(HR())
story.append(P(
    "Le niveau piézométrique terrain mesuré (NS) est <b>prioritaire sur la valeur BRGM "
    "par défaut</b>. La procédure de recalage est la suivante :", sBody))
steps = [
    ["Étape", "Action", "Source"],
    ["1", P("Mesure du niveau statique NS in situ (piézomètre avant pompage)", sBody), "Terrain"],
    ["2", P("Saisie de NS dans l'onglet Coupe_Geologique, cellule C7 (xlsm)", sBody), "Mesure terrain"],
    ["3", P("NS prend la priorité sur la valeur BRGM dans tous les calculs", sBody), "Automatique"],
    ["4", P("Calcul e_sat,i basé sur NS terrain pour chaque couche", sBody), "Automatique"],
    ["5", P("Vérification : NS terrain cohérent avec la coupe géologique G.M.E.P", sBody), "Ingénieur"],
]
t = Table(steps, colWidths=[1.5*cm, 10*cm, 4.5*cm])
t.setStyle(table_style(TEAL))
story.append(KeepTogether([t]))
story.append(SP())
story.append(P(
    "<b>Outil web (rabattement-tool.html) :</b> le champ 'Niveau statique NS (m)' du "
    "formulaire principal est directement utilisé dans le calcul multicouche. Aucune "
    "interpolation BRGM n'est appliquée si le champ est renseigné manuellement.", sBody))
story.append(P(
    "<i>Recommandation : effectuer la mesure du NS à l'aide d'un sonde de niveau sur "
    "piézomètre de référence, de préférence 24h après le dernier pompage, en régime "
    "naturel non perturbé.</i>", sNote))
story.append(SP())

# ── 4. MODES DE CALCUL ───────────────────────────────────────────────────────
story.append(P("4. Modes de calcul — A : Q→s | B : s→Q et volume", sH1))
story.append(HR())
story.append(P(
    "L'outil v15.79 expose deux modes de calcul complémentaires, accessibles dans "
    "l'onglet <b>Coupe_Geologique</b> du tableur et dans la section Coupe Géologique "
    "Multicouche de l'outil web :", sBody))
story.append(P("<b>Mode B (par défaut) — Rabattement imposé → Débit et Volume calculés :</b>", sBold))
story.append(P(
    "L'ingénieur saisit NS (mesuré terrain) et FF (fond de fouille à assécher). "
    "Le rabattement requis s = FF − NS est calculé. Le modèle multicouche détermine "
    "Q<sub>total</sub> = Σ Q<sub>i</sub> et le volume annuel V = Q<sub>total</sub> × 24 × 365. "
    "Le statut IOTA R.214-1 est calculé automatiquement.", sBody))
story.append(P("<b>Mode A — Débit imposé → Rabattement calculé :</b>", sBold))
story.append(P(
    "Utilisé lorsque la capacité de la pompe est connue (Q imposé). "
    "Le modèle calcule le rabattement résultant s<sub>A</sub> = Q·ln(R/r)/(2π·T<sub>éq</sub>·3600). "
    "Utile pour vérifier qu'un équipement disponible est suffisant.", sBody))
story.append(P(
    "<b>Volumes réglementaires (Mode B) :</b> V<sub>jour</sub> = Q<sub>total</sub> × t<sub>exp</sub>, "
    "V<sub>mois</sub> = V<sub>jour</sub> × 30, V<sub>annuel</sub> = V<sub>jour</sub> × 365. "
    "Seuils IOTA 1.1.2.0 : Hors nomenclature &lt; 10 000 m³/an | Déclaration 10 000–200 000 "
    "| Autorisation ≥ 200 000 m³/an.", sBody))

# ── 4.1 ter ─ DÉCOMPOSITION DU VOLUME JOURNALIER (v15.83) ───────────────────────
story.append(SP(0.5))
story.append(P("4.1 ter — Décomposition du volume journalier (V_aquif + V_pluie)", sH2))
story.append(P(
    "Le volume journalier affiché dans le dossier résultante et dans le rapport Loi sur l'Eau "
    "intègre <b>deux contributions distinctes</b> que cet article détaille pour assurer la "
    "traçabilité complète de la formule :", sBody))

story.append(P("<b>Composante 1 — Apport aquifère (V_aquif) :</b>", sBold))
story.append(P(
    "V<sub>aquif</sub> = Q<sub>cycle</sub> × t<sub>exp</sub> × f<sub>K</sub> &nbsp;[m³/j]", sMath))
story.append(P(
    "Où Q<sub>cycle</sub> = Q<sub>Theis</sub> × η × cycle × η<sub>rec</sub> × f<sub>P</sub> × f<sub>C</sub> "
    "est le débit moyen exploitable corrigé de tous les facteurs multiplicatifs, "
    "t<sub>exp</sub> la durée d'exploitation journalière (h/j) et f<sub>K</sub> le "
    "facteur de correction de la recharge par la perméabilité.", sBody))

story.append(P("<b>Composante 2 — Apport pluvial direct sur la fouille (V_pluie) :</b>", sBold))
story.append(P(
    "V<sub>pluie</sub> = S<sub>fouille</sub> × max(P−ETP ; R) × α / 365 / 1000 &nbsp;[m³/j]", sMath))
story.append(P(
    "Où S<sub>fouille</sub> = π × R<sub>inf</sub>² (m²) est la surface de la fouille "
    "dans la zone d'influence, max(P−ETP ; R) est la pluie efficace locale (mm/an), "
    "α = 0,85 le coefficient de ruissellement standard.", sBody))

story.append(P("<b>Volume journalier total et annuel :</b>", sBold))
story.append(P(
    "V<sub>jour</sub> = V<sub>aquif</sub> + V<sub>pluie</sub> &nbsp;&nbsp;→&nbsp;&nbsp; "
    "V<sub>an</sub> = V<sub>jour</sub> × 365 &nbsp;[m³/an]", sMath))

# Tableau décomposition cas essai approfondissement
story.append(P("<b>Application numérique — cas essai approfondissement (forage 10 m, FF=6 m, Calcaire de Beauce) :</b>", sBold))
decomp_data = [
    ["Composante", "Formule", "Valeur (cas essai)", "Unité"],
    ["Q_Theis brut",   "4πT·s / W(u)", "~2,93 m³/h", "m³/h"],
    ["Q_Theis × η",   "Q_Theis × 0,70", "~2,05 m³/h", "m³/h"],
    ["Q_cycle",        "Q_Theis × η × cycle × η_rec × f_P × f_C", "~2,20 m³/h", "m³/h"],
    ["V_aquif",        "Q_cycle × t_exp × f_K", "~52,9 m³/j", "m³/j"],
    ["V_pluie",        "S_fouille × pluie_eff / 365 / 1000 × 0,85", "~0,25 m³/j", "m³/j"],
    ["V_jour",         "V_aquif + V_pluie", "~53,2 m³/j", "m³/j"],
    ["V_an",           "V_jour × 365", "~19 406 m³/an", "m³/an"],
]
from reportlab.platypus import Table as _Table
decomp_t = _Table(decomp_data, colWidths=[3.5*cm, 6*cm, 4*cm, 2.5*cm])
decomp_t.setStyle(table_style(TEAL))
story.append(KeepTogether([decomp_t]))
story.append(SP())
story.append(P(
    "<b>Note :</b> Le chiffre 19 406 m³/an du cas essai intègre "
    "V<sub>aquif</sub> = 52,9 m³/j (drainance aquifère) + V<sub>pluie</sub> = 0,25 m³/j "
    "(apport pluvial sur la surface de fouille). La contribution pluviale est toujours "
    "minoritaire mais garantit la couverture réglementaire du volume total pompe (y compris "
    "les eaux de ruissellement intercepted par la fouille).", sNote))
story.append(SP(0.5))

story.append(PageBreak())

# ── 5. VALIDATION CAS COLAS ───────────────────────────────────────────────────
story.append(P("5. Validation sur le cas Colas — Oucques La Nouvelle (41)", sH1))
story.append(HR())
story.append(P(
    "Le cas de validation utilise les données réelles du dossier DLE GMEP — Oucques La Nouvelle (41) "
    "(projet SIAEP Région d'Oucques — COLAS France, substrat Marno-calcaire fissuré, "
    "département 41 — ZRE Nappe de Beauce).", sBody))

# Paramètres
story.append(P("<b>Paramètres communs :</b>", sBold))
pdata = [
    ["Paramètre", "Valeur", "Source"],
    ["Niveau statique NS", "1,70 m/TN", "Mesure terrain — exemple terrain Oucques La Nouvelle (41)"],
    ["Fond de fouille FF", "2,80 m/TN", "Plan projet"],
    ["Rabattement requis s = FF−NS", "1,10 m", "Calculé"],
    ["Rayon puits r", "0,056 m", "Ø 112 mm / 2"],
    ["Durée de pompage", "24 heures", "Projet"],
    ["Profondeur totale forage", "5,0 m/TN", "Exemple terrain Oucques La Nouvelle (41)"],
]
t = Table(pdata, colWidths=[6*cm, 4*cm, 6*cm])
t.setStyle(table_style())
story.append(KeepTogether([t]))
story.append(SP())

# Coupe multicouche
story.append(P("<b>Coupe géologique multicouche (v15.79) :</b>", sBold))
cdata = [
    ["N°", "De (m)", "À (m)", "Lithologie", "K (m/s)", "e_sat (m)", "Q_i (m³/h)"],
    ["1", "0,00", "1,70", "Argile sableuse", "5,0e-9", "0,000", "0,000000"],
    ["2", "1,70", "2,80", "Marne argileuse faible", "1,0e-8", "1,100", "0,000053"],
    ["3", "2,80", "5,00", "Marno-calcaire fissuré", "1,0e-6", "2,200", "0,010557"],
    ["", "", "", "TOTAL", "", "", "0,010610"],
]
t = Table(cdata, colWidths=[1*cm, 2*cm, 2*cm, 4.5*cm, 2.5*cm, 2*cm, 2*cm])
t.setStyle(table_style(NAVY))
story.append(KeepTogether([t]))
story.append(SP())

# Résultats comparatifs
story.append(P("<b>Comparaison v15.78 vs v15.79 :</b>", sBold))
cmp_data = [
    ["Paramètre", "v15.78 Monocouche", "v15.79 Multicouche", "Variation"],
    ["Substrat(s)", "1 (Marno-calcaire)", "3 couches G.M.E.P", "—"],
    ["T équivalente (m²/s)", "3,00e-5 (tabulée)", "2,21e-6 (réelle)", "Précision accrue"],
    ["Q Dupuit brut (m³/h)", "0,143962", "0,010610", "T réelle vs T_ref"],
    ["Volume annuel (m³/an)", "499,0", "92,9", "Épaisseur réelle"],
    ["Statut IOTA", P("HORS<br/>NOMENCLATURE", sBody), P("HORS<br/>NOMENCLATURE", sBody), "Invariant"],
]
t = Table(cmp_data, colWidths=[4.5*cm, 4*cm, 4*cm, 3.5*cm])
t.setStyle(table_style(TEAL))
story.append(KeepTogether([t]))
story.append(SP())

story.append(P(
    "<b>Analyse :</b> Le modèle v15.79 calcule le débit avec les épaisseurs RÉELLES saturées "
    "de chaque couche (e_sat,i), contrairement à v15.78 qui utilisait la transmissivité "
    "tabulée T_ref (basée sur une épaisseur typique de 30 m pour le Marno-calcaire). "
    "Cela explique les valeurs de débit différentes.", sBody))
story.append(P(
    "<b>Validation du principe de l'additivité :</b> Dans un scénario à deux couches "
    "perméables distinctes (K<sub>1</sub>=1e-6, e=1,1 m ; K<sub>2</sub>=1e-5, e=2,2 m), "
    "Q<sub>total</sub> multicouche = 0,111 m³/h vs Q<sub>monocouche</sub> K<sub>1</sub> seul "
    "= 0,016 m³/h, soit un <b>facteur 7×</b> — confirmant que traverser plusieurs couches "
    "perméables augmente le débit, conformément à l'observation de l'ingénieur.", sBody))
story.append(P(
    "<b>Conclusion validation :</b> Le modèle v15.79 est physiquement correct et reproduit "
    "le comportement attendu. La logique IOTA R.214-1 est invariante (statut identique "
    "dans les deux cas pour ce site). Les modèles Theis et Dupuit-Thiem originaux "
    "sont préservés et disponibles pour les calculs monocouche habituels.", sBody))
story.append(PageBreak())

# ── 6. RÉFÉRENCES ─────────────────────────────────────────────────────────────
story.append(P("6. Références bibliographiques", sH1))
story.append(HR())
refs = [
    ("<b>Dupuit J. (1863)</b>", 
     "Études théoriques et pratiques sur le mouvement des eaux dans les canaux découverts "
     "et à travers les terrains perméables. Paris, Dunod. 304 p."),
    ("<b>Forchheimer P. (1898)</b>",
     "Wasserbewegung durch Boden. Zeitschrift des Vereines Deutscher Ingenieure, 45, 1782–1788."),
    ("<b>Theis C.V. (1935)</b>",
     "The relation between the lowering of the piezometric surface and the rate and duration "
     "of discharge of a well using groundwater storage. Trans. Am. Geophys. Union, 16, 519–524."),
    ("<b>BRGM (2024)</b>",
     "Infoterre — BDLISA : Base de Données des Limites des Systèmes Aquifères. "
     '<a href="https://infoterre.brgm.fr" color="blue">https://infoterre.brgm.fr</a>'),
    ("<b>Code de l'Environnement (2024)</b>",
     "Articles L.214-1 à L.214-6 et R.214-1 à R.214-56 — Nomenclature IOTA. "
     '<a href="https://www.legifrance.gouv.fr" color="blue">https://www.legifrance.gouv.fr</a>'),
    ("<b>Darcy H. (1856)</b>",
     "Les fontaines publiques de la ville de Dijon. Paris, Dalmont. 647 p."),
    ("<b>EPA (2004)</b>",
     "User's Guide for Evaluating Subsurface Migration of Soil Vapors. EPA/540/1-91/006. "
     '<a href="https://www.epa.gov" color="blue">https://www.epa.gov</a>'),
    ("<b>INERIS (2021)</b>",
     "Guide méthodologique pour l'évaluation des risques sanitaires liés aux nappes "
     "souterraines. "
     '<a href="https://www.ineris.fr" color="blue">https://www.ineris.fr</a>'),
    ("<b>ANSES (2018)</b>",
     "Valeurs toxicologiques de référence — Méthode d'élaboration et recommandations. "
     '<a href="https://www.anses.fr" color="blue">https://www.anses.fr</a>'),
    ("<b>Domenico P.A. & Schwartz F.W. (1990)</b>",
     "Physical and Chemical Hydrogeology. Wiley, New York. 824 p."),
]
for title, text in refs:
    story.append(P(f"{title} — {text}", sBody))
    story.append(SP(0.1))

story.append(SP())
story.append(HR())
story.append(P(
    "<b>Avertissement réglementaire :</b> La présente note est un document technique "
    "interne accompagnant la version 15.79 du logiciel GMEP Rabattement. "
    "Les modèles Theis, Dupuit-Thiem et Domenico sont préservés dans leur intégralité. "
    "La logique IOTA R.214-1 stricte est invariante. "
    "Modèles ajoutés v15.79 : Forchheimer/Dupuit multicouche + recalage piézométrique terrain "
    "+ modes A/B + rendu graphique G.M.E.P — Coupe Géologique G.M.E.P.", sNote))

# ─── Build PDF ────────────────────────────────────────────────────────────────
doc = SimpleDocTemplate(
    OUTPUT,
    pagesize=A4,
    title="Note Méthodologique GMEP v15.83 — Modélisation Multicouche Forchheimer/Dupuit + Module Coupe Géologique G.M.E.P",
    author="Perplexity Computer",
    leftMargin=2*cm, rightMargin=2*cm,
    topMargin=2.5*cm, bottomMargin=2.2*cm,
)

doc.build(story, onFirstPage=on_first_page, onLaterPages=on_page)
print(f"PDF généré : {OUTPUT}")

import os
size_kb = os.path.getsize(OUTPUT) / 1024
print(f"Taille : {size_kb:.0f} Ko")
