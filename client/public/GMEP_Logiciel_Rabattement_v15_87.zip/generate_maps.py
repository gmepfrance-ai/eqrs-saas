#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Générateur de cartes réglementaires — Dossier Loi sur l'Eau Rubrique 1.1.1.0
G.M.E.P

Cartes produites :
  1. Localisation générale  (1:100 000) — IGN + OSM
  2. Topographique du site  (1:25 000)  — IGN PLANIGNV2
  3. Géologique             (1:50 000)  — BRGM 50k
  4. Hydrologique           (1:25 000)  — IGN Hydrographie
  5. Masses d'eau souterraine           — Eau France MDO + BRGM BSS
  6. ZNIEFF / Natura 2000   (1:50 000)  — Patrinat
"""

import io, os, math, warnings
from pathlib import Path

warnings.filterwarnings("ignore")

# ─────────────────────────────────────────────
# IMPORTS OPTIONNELS — fallback si non installés
# ─────────────────────────────────────────────
HAS_REQUESTS = False
HAS_CTX = False
HAS_MPL = False
HAS_PIL = False
HAS_PYPROJ = False

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    pass

try:
    import contextily as ctx
    HAS_CTX = True
except ImportError:
    ctx = None

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    import matplotlib.patheffects as pe
    from matplotlib.patches import FancyArrowPatch
    HAS_MPL = True
except ImportError:
    plt = None
    mpatches = None
    pe = None

try:
    from PIL import Image, ImageDraw
    HAS_PIL = True
except ImportError:
    Image = None
    ImageDraw = None

try:
    from pyproj import Transformer
    HAS_PYPROJ = True
except ImportError:
    Transformer = None

# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────
OUT_DIR = Path(os.path.dirname(os.path.abspath(__file__))) / "cartes_gmep"
OUT_DIR.mkdir(exist_ok=True)

DPI = 150
FIG_SIZE_CM = (18, 18)
FIG_SIZE_IN = (FIG_SIZE_CM[0]/2.54, FIG_SIZE_CM[1]/2.54)

# Palette GMEP
C_TEAL     = "#1B474D"
C_TEAL_L   = "#E8F4F6"
C_ORANGE   = "#C8641A"
C_RED      = "#C0392B"
C_GREEN    = "#1A5C2A"
C_WHITE    = "white"
C_BLACK    = "black"

# Transformers (initialisés seulement si pyproj disponible)
if HAS_PYPROJ:
    T_L93_MERC = Transformer.from_crs("EPSG:2154", "EPSG:3857", always_xy=True)
    T_L93_WGS  = Transformer.from_crs("EPSG:2154", "EPSG:4326", always_xy=True)
else:
    T_L93_MERC = None
    T_L93_WGS  = None

# Sources de tuiles de fond (contextily)
TILE_PLANIGN = {
    "url": "https://data.geopf.fr/wmts?SERVICE=WMTS&REQUEST=GetTile&VERSION=1.0.0"
            "&LAYER=GEOGRAPHICALGRIDSYSTEMS.PLANIGNV2"
            "&STYLE=normal&FORMAT=image/png"
            "&TILEMATRIXSET=PM&TILEMATRIX={z}&TILEROW={y}&TILECOL={x}",
    "max_zoom": 18,
    "attribution": "© IGN Géoportail",
}

if HAS_CTX:
    TILE_OSM = ctx.providers.OpenStreetMap.Mapnik
    TILE_CARTO_LIGHT = ctx.providers.CartoDB.Positron
else:
    TILE_OSM = None
    TILE_CARTO_LIGHT = None


# ─────────────────────────────────────────────
# HELPERS WMS
# ─────────────────────────────────────────────

def check_internet(timeout=5):
    """Vérifie la connexion internet."""
    if not HAS_REQUESTS:
        # Essai avec urllib (bibliothèque standard)
        try:
            import urllib.request
            urllib.request.urlopen("https://data.geopf.fr", timeout=timeout)
            return True
        except Exception:
            return False
    try:
        requests.get("https://data.geopf.fr", timeout=timeout)
        return True
    except Exception:
        return False


def _make_placeholder_image(titre, output_path, x_l93, y_l93, commune):
    """Crée une image PNG minimale sans matplotlib (avec PIL ou écrit un PNG blanc minimal)."""
    if HAS_PIL:
        from PIL import Image as PILImg, ImageDraw as PILDraw, ImageFont as PILFont
        img = PILImg.new("RGB", (900, 700), color=(232, 244, 246))
        draw = PILDraw.Draw(img)
        # Cadre
        draw.rectangle([10, 10, 889, 689], outline=(27, 71, 77), width=4)
        # Titre
        draw.rectangle([20, 20, 879, 90], fill=(27, 71, 77))
        draw.text((450, 55), titre, fill="white", anchor="mm")
        # Message
        draw.rectangle([50, 120, 849, 200], fill=(255, 243, 224), outline=(230, 81, 0), width=2)
        draw.text((450, 160), "CARTE NON DISPONIBLE — Librairies cartographiques non installees",
                  fill=(230, 81, 0), anchor="mm")
        # Coordonnees
        draw.text((450, 280), f"Lambert 93 : X = {x_l93:.0f}   Y = {y_l93:.0f}",
                  fill=(27, 71, 77), anchor="mm")
        draw.text((450, 320), f"Commune : {commune}", fill=(27, 71, 77), anchor="mm")
        draw.text((450, 400),
                  "Pour activer les cartes, installez : pip install matplotlib contextily pyproj Pillow",
                  fill=(100, 100, 100), anchor="mm")
        img.save(output_path)
    else:
        # Ultra-fallback : PNG blanc 1x1
        import struct, zlib
        def _png1x1(path):
            sig = b'\x89PNG\r\n\x1a\n'
            def chunk(t, d):
                c = zlib.crc32(t + d) & 0xffffffff
                return struct.pack('>I', len(d)) + t + d + struct.pack('>I', c)
            ihdr = chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
            idat = chunk(b'IDAT', zlib.compress(b'\x00\xff\xff\xff'))
            iend = chunk(b'IEND', b'')
            with open(path, 'wb') as f:
                f.write(sig + ihdr + idat + iend)
        _png1x1(output_path)


def make_offline_map(x_l93, y_l93, titre, source_txt, output_path, commune="", note=""):
    """Génère une carte de substitution (hors-ligne) avec les coordonnées du site."""
    if not HAS_MPL:
        # Fallback minimal sans matplotlib : créer une image PNG avec PIL ou fichier texte
        _make_placeholder_image(titre, output_path, x_l93, y_l93, commune)
        return output_path

    fig, ax = plt.subplots(figsize=(12, 10))
    fig.patch.set_facecolor('#F5F5F5')
    ax.set_facecolor('#E3F2FD')
    ax.set_xlim(0, 10); ax.set_ylim(0, 10)
    ax.axis('off')

    # Cadre
    ax.add_patch(mpatches.FancyBboxPatch((0.1, 0.1), 9.8, 9.8,
        boxstyle="round,pad=0.1", fc='#E3F2FD', ec='#1B474D', lw=3))

    # Titre
    ax.text(5, 9.2, titre, ha='center', va='center', fontsize=16,
            fontweight='bold', color='#1B474D',
            bbox=dict(boxstyle='round,pad=0.4', fc='white', ec='#1B474D', lw=2))

    # Message hors-ligne
    ax.text(5, 7.5,
            "[!] CARTE NON DISPONIBLE — CONNEXION INTERNET REQUISE",
            ha='center', va='center', fontsize=13, color='#E65100', fontweight='bold',
            bbox=dict(boxstyle='round,pad=0.4', fc='#FFF3E0', ec='#E65100', lw=2))

    ax.text(5, 6.4,
            "Cette carte sera générée automatiquement\nlors du prochain lancement avec connexion internet.",
            ha='center', va='center', fontsize=11, color='#555555')

    # Coordonnées du site
    try:
        from pyproj import Transformer
        t = Transformer.from_crs("EPSG:2154", "EPSG:4326", always_xy=True)
        lon, lat = t.transform(x_l93, y_l93)
        coord_txt = (f"Coordonnées du site :\nLambert 93 : X = {x_l93:.0f} m  |  Y = {y_l93:.0f} m\nWGS84 : Lat = {lat:.5f}\u00b0  |  Lon = {lon:.5f}\u00b0\nCommune : {commune}")
    except Exception:
        coord_txt = (f"Lambert 93 : X = {x_l93:.0f} m  |  Y = {y_l93:.0f} m\nCommune : {commune}")

    ax.text(5, 4.5, coord_txt, ha='center', va='center', fontsize=11,
            color='#1B474D', family='monospace',
            bbox=dict(boxstyle='round,pad=0.5', fc='white', ec='#1B474D', lw=1.5))

    # Marqueur site
    ax.plot(5, 2.8, 'o', ms=18, color='#E65100', zorder=5)
    ax.plot(5, 2.8, 'o', ms=10, color='white',   zorder=6)
    ax.text(5.3, 2.8, "Site", fontsize=12, color='#E65100',
            va='center', fontweight='bold')

    # Source
    ax.text(5, 0.5, source_txt, ha='center', va='center',
            fontsize=9, color='#888888', style='italic')

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight',
                facecolor='#F5F5F5', edgecolor='none')
    plt.close()
    return output_path


def wms_getmap(base_url, layer, crs, bbox, w=900, h=900,
               fmt="image/png", transparent=True, timeout=25):
    """Retourne une Image PIL RGBA ou None."""
    params = {
        "SERVICE": "WMS", "VERSION": "1.3.0", "REQUEST": "GetMap",
        "LAYERS": layer, "STYLES": "", "FORMAT": fmt,
        "CRS": crs, "BBOX": bbox,
        "WIDTH": str(w), "HEIGHT": str(h),
    }
    if transparent:
        params["TRANSPARENT"] = "TRUE"
    try:
        r = requests.get(base_url, params=params, timeout=timeout)
        if r.status_code == 200 and "image" in r.headers.get("content-type", ""):
            img = Image.open(io.BytesIO(r.content)).convert("RGBA")
            return img
        return None
    except Exception:
        return None


def bbox_l93(x, y, d):
    """BBOX Lambert 93 centré sur x,y avec demi-côté d."""
    return x - d, y - d, x + d, y + d


def bbox_merc(x, y, d):
    """BBOX Mercator centré sur x,y L93 avec demi-côté d."""
    cx, cy = T_L93_MERC.transform(x, y)
    return cx - d, cy - d, cx + d, cy + d


def bbox_wgs84_1_3(x, y, d):
    """BBOX WGS84 pour WMS 1.3.0 (ordre lat,lon)."""
    lo0, la0 = T_L93_WGS.transform(x - d, y - d)
    lo1, la1 = T_L93_WGS.transform(x + d, y + d)
    return f"{la0},{lo0},{la1},{lo1}"


def overlay_wms_on_ax(ax, img_pil, extent_merc):
    """Superpose une image WMS RGBA sur les axes matplotlib."""
    if img_pil is None:
        return
    x0, y0, x1, y1 = extent_merc
    if img_pil.size[0] < 10:
        return
    ax.imshow(img_pil, extent=[x0, x1, y0, y1],
              origin="upper", zorder=3, alpha=0.75,
              aspect="auto", interpolation="bilinear")


# ─────────────────────────────────────────────
# DÉCORATIONS COMMUNES
# ─────────────────────────────────────────────
def add_north_arrow(ax):
    """Flèche Nord en haut à droite."""
    ax.annotate(
        "", xy=(0.96, 0.96), xytext=(0.96, 0.87),
        xycoords="axes fraction",
        arrowprops=dict(arrowstyle="-|>", color=C_TEAL,
                        lw=2.5, mutation_scale=20),
    )
    ax.text(0.96, 0.98, "N", transform=ax.transAxes,
            ha="center", va="bottom", fontsize=12,
            fontweight="bold", color=C_TEAL,
            path_effects=[pe.withStroke(linewidth=3, foreground="white")])


def add_scale_bar(ax, delta_m, crs="EPSG:3857"):
    """Barre d'échelle en bas à gauche."""
    # Trouver une valeur propre
    for nice in [10000, 5000, 2000, 1000, 500, 250, 200, 100, 50]:
        if delta_m >= nice * 1.5:
            bar_m = nice
            break
    else:
        bar_m = max(10, delta_m // 5)

    bar_frac = bar_m / (2 * delta_m)  # fraction de largeur axes

    ax_x0, ax_x1 = 0.04, 0.04 + bar_frac
    ax_y = 0.04

    # Barre en 2 segments alternés
    mid = (ax_x0 + ax_x1) / 2
    rect1 = plt.Rectangle((ax_x0, ax_y - 0.008), (ax_x1 - ax_x0) / 2, 0.016,
                           transform=ax.transAxes, color=C_TEAL, zorder=10)
    rect2 = plt.Rectangle((mid, ax_y - 0.008), (ax_x1 - ax_x0) / 2, 0.016,
                           transform=ax.transAxes, color="white",
                           ec=C_TEAL, lw=1, zorder=10)
    ax.add_patch(rect1)
    ax.add_patch(rect2)

    label = f"{bar_m} m" if bar_m < 1000 else f"{bar_m // 1000} km"
    kw = dict(transform=ax.transAxes, fontsize=8, color=C_TEAL, zorder=11,
              path_effects=[pe.withStroke(linewidth=2, foreground="white")])
    ax.text(ax_x0, ax_y + 0.015, "0", ha="center", **kw)
    ax.text(ax_x1, ax_y + 0.015, label, ha="center", **kw)


def add_coords_box(ax, x_l93, y_l93, lon, lat, alti_ngf, commune):
    """Encadré coordonnées en haut à gauche."""
    lines = [
        f"Lambert 93 : X = {x_l93:,.0f}    Y = {y_l93:,.0f}".replace(",", " "),
        f"WGS84 : lat {lat:.5f}°   lon {lon:.5f}°",
        f"Altitude NGF : {alti_ngf:.1f} m",
        f"Commune : {commune}",
    ]
    text = "\n".join(lines)
    ax.text(0.02, 0.98, text, transform=ax.transAxes,
            va="top", ha="left", fontsize=7.5,
            color=C_TEAL, fontfamily="monospace",
            bbox=dict(boxstyle="round,pad=0.4", facecolor="white",
                      edgecolor=C_TEAL, alpha=0.92, linewidth=1.2),
            zorder=20)


def add_site_marker(ax, cx_merc, cy_merc):
    """Marqueur du site."""
    ax.plot(cx_merc, cy_merc, marker="o", markersize=14,
            markerfacecolor="none", markeredgecolor=C_RED,
            markeredgewidth=2.5, zorder=15)
    ax.plot(cx_merc, cy_merc, marker="+", markersize=20,
            markeredgecolor=C_RED, markeredgewidth=2, zorder=15)
    ax.plot(cx_merc, cy_merc, marker=".", markersize=6,
            color=C_RED, zorder=15)


def add_title_and_source(ax, title, subtitle, source):
    """Titre principal + sous-titre + source en bas (3 lignes distinctes)."""
    ax.set_title(title, fontsize=11, fontweight="bold",
                 color=C_WHITE, pad=6,
                 bbox=dict(facecolor=C_TEAL, edgecolor="none",
                           boxstyle="square,pad=0.4"))
    # Sous-titre sur la 1ère ligne sous la carte
    ax.text(0.5, -0.02, subtitle, transform=ax.transAxes,
            ha="center", va="top", fontsize=7.5,
            color="#555555", style="italic")
    # Source sur la 2e ligne (décalée plus bas pour éviter le chevauchement)
    ax.text(0.5, -0.06, source, transform=ax.transAxes,
            ha="center", va="top", fontsize=7,
            color="#888888")


def finish_ax(ax):
    """Retire les axes et bordures."""
    ax.set_axis_off()


def save_fig(fig, filename):
    path = OUT_DIR / filename
    fig.savefig(path, dpi=DPI, bbox_inches="tight",
                facecolor="white", edgecolor="none")
    plt.close(fig)
    print(f"  ✓ {filename}  ({os.path.getsize(path):,} octets)")
    return str(path)


def make_fig():
    fig, ax = plt.subplots(figsize=FIG_SIZE_IN, dpi=DPI)
    fig.patch.set_facecolor("white")
    return fig, ax


def set_ax_extent_merc(ax, cx_merc, cy_merc, delta_m):
    ax.set_xlim(cx_merc - delta_m, cx_merc + delta_m)
    ax.set_ylim(cy_merc - delta_m, cy_merc + delta_m)


# ─────────────────────────────────────────────
# CARTE 1 — LOCALISATION GÉNÉRALE
# ─────────────────────────────────────────────
def carte_localisation(x, y, alti, commune, dept):
    print("[1/6] Localisation générale...")
    fig, ax = make_fig()
    delta = 8000
    cx, cy = T_L93_MERC.transform(x, y)
    lon, lat = T_L93_WGS.transform(x, y)
    set_ax_extent_merc(ax, cx, cy, delta)

    # Fond IGN (fallback OSM)
    try:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_PLANIGN, zoom="auto")
    except Exception:
        try:
            ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_OSM, zoom="auto")
        except Exception:
            ax.set_facecolor("#e8f0e8")

    add_site_marker(ax, cx, cy)
    add_north_arrow(ax)
    add_scale_bar(ax, delta)
    add_coords_box(ax, x, y, lon, lat, alti, commune)
    add_title_and_source(
        ax,
        f"LOCALISATION GÉNÉRALE — {commune.upper()} ({dept})",
        f"Échelle approx. 1:100 000  |  Emprise ± 8 km",
        "© IGN Géoportail 2026"
    )
    finish_ax(ax)
    return save_fig(fig, "01_localisation.png")


# ─────────────────────────────────────────────
# CARTE 2 — TOPOGRAPHIQUE 1:25 000
# ─────────────────────────────────────────────
def carte_topographique(x, y, commune, dept):
    print("[2/6] Topographique 1:25 000...")
    fig, ax = make_fig()
    delta = 1500
    cx, cy = T_L93_MERC.transform(x, y)
    lon, lat = T_L93_WGS.transform(x, y)
    set_ax_extent_merc(ax, cx, cy, delta)

    try:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_PLANIGN, zoom="auto")
    except Exception:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_OSM, zoom="auto")

    add_site_marker(ax, cx, cy)
    add_north_arrow(ax)
    add_scale_bar(ax, delta)
    add_coords_box(ax, x, y, lon, lat, 0, commune)
    add_title_and_source(
        ax,
        f"CARTE TOPOGRAPHIQUE — {commune.upper()} ({dept})",
        "Échelle approx. 1:25 000  |  Emprise ± 1 500 m  |  IGN PLANIGNV2",
        "© IGN Géoportail 2026"
    )
    finish_ax(ax)
    return save_fig(fig, "02_topographique.png")


# ─────────────────────────────────────────────
# CARTE 3 — GÉOLOGIQUE BRGM 1:50 000
# ─────────────────────────────────────────────
def carte_geologique(x, y, commune, dept, substrat):
    print("[3/6] Géologique BRGM 1:50 000...")
    fig, ax = make_fig()
    delta = 3000
    cx, cy = T_L93_MERC.transform(x, y)
    lon, lat = T_L93_WGS.transform(x, y)
    set_ax_extent_merc(ax, cx, cy, delta)

    # Fond topo grisé
    try:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_CARTO_LIGHT, zoom="auto")
    except Exception:
        ax.set_facecolor("#f5f0e8")

    # Couche géologique BRGM 50k (en EPSG:4326)
    bbox_4326 = bbox_wgs84_1_3(x, y, delta)
    geol_img = wms_getmap(
        "https://geoservices.brgm.fr/geologie",
        "SCAN_D_GEOL50", "EPSG:4326", bbox_4326,
        w=900, h=900, transparent=True
    )
    if geol_img:
        x0, y0_m, x1, y1_m = cx-delta, cy-delta, cx+delta, cy+delta
        ax.imshow(geol_img, extent=[x0, x1, y0_m, y1_m],
                  origin="upper", zorder=4, alpha=0.80,
                  aspect="auto", interpolation="bilinear")

    # Couche BRGM BSS points
    bbox_bss = bbox_wgs84_1_3(x, y, delta)
    bss_img = wms_getmap(
        "https://geoservices.brgm.fr/geologie",
        "BSS_EAU_POINT", "EPSG:4326", bbox_bss,
        w=900, h=900, transparent=True
    )
    if bss_img:
        x0, y0_m, x1, y1_m = cx-delta, cy-delta, cx+delta, cy+delta
        ax.imshow(bss_img, extent=[x0, x1, y0_m, y1_m],
                  origin="upper", zorder=5, alpha=0.9,
                  aspect="auto", interpolation="bilinear")

    add_site_marker(ax, cx, cy)
    add_north_arrow(ax)
    add_scale_bar(ax, delta)
    add_coords_box(ax, x, y, lon, lat, 0, commune)

    # Annotation substrat
    ax.text(0.02, 0.04, f"Substrat : {substrat}",
            transform=ax.transAxes, fontsize=8.5,
            color=C_ORANGE, fontweight="bold",
            bbox=dict(facecolor="white", edgecolor=C_ORANGE,
                      alpha=0.92, boxstyle="round,pad=0.3"),
            zorder=20)

    add_title_and_source(
        ax,
        f"CARTE GÉOLOGIQUE — {commune.upper()} ({dept})",
        "Échelle approx. 1:50 000  |  Source : BRGM Géologie 50 000e",
        "© BRGM InfoTerre 2026"
    )
    finish_ax(ax)
    return save_fig(fig, "03_geologique.png")


# ─────────────────────────────────────────────
# CARTE 4 — HYDROLOGIQUE
# ─────────────────────────────────────────────
def carte_hydrologique(x, y, commune, dept):
    print("[4/6] Hydrologique...")
    fig, ax = make_fig()
    delta = 2500
    cx, cy = T_L93_MERC.transform(x, y)
    lon, lat = T_L93_WGS.transform(x, y)
    set_ax_extent_merc(ax, cx, cy, delta)

    try:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_PLANIGN, zoom="auto")
    except Exception:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_OSM, zoom="auto")

    # Zone hydrologique EauFrance
    bbox_4326 = bbox_wgs84_1_3(x, y, delta)
    zone_hydro = wms_getmap(
        "https://services.sandre.eaufrance.fr/geo/zonage",
        "ZoneHydro", "EPSG:4326", bbox_4326,
        w=900, h=900, transparent=True
    )
    if zone_hydro:
        x0, y0_m, x1, y1_m = cx-delta, cy-delta, cx+delta, cy+delta
        ax.imshow(zone_hydro, extent=[x0, x1, y0_m, y1_m],
                  origin="upper", zorder=3, alpha=0.45,
                  aspect="auto", interpolation="bilinear")

    # Hydrographie IGN (couche vectorielle)
    hydro_ign = wms_getmap(
        "https://data.geopf.fr/wms-r",
        "IGNF_HYDROGRAPHY.HYDROGRAPHY", "EPSG:3857",
        f"{cx-delta},{cy-delta},{cx+delta},{cy+delta}",
        w=900, h=900, transparent=True
    )
    if hydro_ign:
        x0, y0_m, x1, y1_m = cx-delta, cy-delta, cx+delta, cy+delta
        ax.imshow(hydro_ign, extent=[x0, x1, y0_m, y1_m],
                  origin="upper", zorder=4, alpha=0.85,
                  aspect="auto", interpolation="bilinear")

    add_site_marker(ax, cx, cy)
    add_north_arrow(ax)
    add_scale_bar(ax, delta)
    add_coords_box(ax, x, y, lon, lat, 0, commune)

    # Légende hydrologique
    legend_elements = [
        mpatches.Patch(facecolor="#4a90d9", alpha=0.7, label="Zones hydrologiques (SANDRE)"),
        mpatches.Patch(facecolor="#1a6ba8", alpha=0.9, label="Hydrographie IGN"),
        plt.Line2D([0], [0], marker="o", color="none",
                   markerfacecolor="none", markeredgecolor=C_RED,
                   markersize=10, label="Site du projet"),
    ]
    ax.legend(handles=legend_elements, loc="lower right",
              fontsize=7.5, framealpha=0.92,
              edgecolor=C_TEAL, facecolor="white")

    add_title_and_source(
        ax,
        f"CARTE HYDROLOGIQUE — {commune.upper()} ({dept})",
        "Réseau hydrographique, zones hydro SANDRE  |  Emprise ± 2 500 m",
        "© IGN / Eau France SANDRE 2026"
    )
    finish_ax(ax)
    return save_fig(fig, "04_hydrologique.png")


# ─────────────────────────────────────────────
# CARTE 5 — MASSES D'EAU SOUTERRAINE (DCE)
# ─────────────────────────────────────────────
def carte_masses_eau(x, y, commune, dept):
    print("[5/6] Masses d'eau souterraine DCE...")
    fig, ax = make_fig()
    delta = 10000
    cx, cy = T_L93_MERC.transform(x, y)
    lon, lat = T_L93_WGS.transform(x, y)
    set_ax_extent_merc(ax, cx, cy, delta)

    try:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_CARTO_LIGHT, zoom="auto")
    except Exception:
        ax.set_facecolor("#e8f4f6")

    # Masse d'eau DCE
    bbox_4326 = bbox_wgs84_1_3(x, y, delta)
    mdo_img = wms_getmap(
        "https://services.sandre.eaufrance.fr/geo/mdo",
        "MasseDeau", "EPSG:4326", bbox_4326,
        w=900, h=900, transparent=False, fmt="image/png"
    )
    if mdo_img:
        # Rendre les zones masses d'eau semi-transparentes
        mdo_rgba = mdo_img.convert("RGBA")
        r_ch, g_ch, b_ch, a_ch = mdo_rgba.split()
        # Détecter couleur de fond (première couleur dominante)
        from PIL import ImageChops
        bg_color = (128, 208, 208)
        # Remplacer fond par transparent
        data = mdo_rgba.load()
        w_img, h_img = mdo_rgba.size
        for px in range(w_img):
            for py_px in range(h_img):
                r_, g_, b_, a_ = data[px, py_px]
                if (abs(r_ - bg_color[0]) < 20 and
                    abs(g_ - bg_color[1]) < 20 and
                    abs(b_ - bg_color[2]) < 20):
                    data[px, py_px] = (r_, g_, b_, 0)
                else:
                    data[px, py_px] = (r_, g_, b_, 160)

        x0, y0_m, x1, y1_m = cx-delta, cy-delta, cx+delta, cy+delta
        ax.imshow(mdo_rgba, extent=[x0, x1, y0_m, y1_m],
                  origin="upper", zorder=3,
                  aspect="auto", interpolation="bilinear")

    # BSS eau points (zoom proche)
    delta_bss = 3000
    bbox_bss = bbox_wgs84_1_3(x, y, delta_bss)
    # Recalculer en Mercator pour placement correct
    cx_bss, cy_bss = cx, cy
    bss_img = wms_getmap(
        "https://geoservices.brgm.fr/geologie",
        "BSS_EAU_POINT", "EPSG:4326", bbox_bss,
        w=300, h=300, transparent=True
    )
    if bss_img:
        x0b = cx - delta_bss
        y0b_m = cy - delta_bss
        x1b = cx + delta_bss
        y1b_m = cy + delta_bss
        ax.imshow(bss_img, extent=[x0b, x1b, y0b_m, y1b_m],
                  origin="upper", zorder=5, alpha=0.9,
                  aspect="auto", interpolation="bilinear")

    add_site_marker(ax, cx, cy)
    add_north_arrow(ax)
    add_scale_bar(ax, delta)
    add_coords_box(ax, x, y, lon, lat, 0, commune)

    legend_elements = [
        mpatches.Patch(facecolor="#2196F3", alpha=0.6, label="Masses d'eau souterraine (DCE)"),
        mpatches.Patch(facecolor="#4CAF50", alpha=0.7, label="Points BSS (ouvrages BRGM)"),
        plt.Line2D([0], [0], marker="o", color="none",
                   markerfacecolor="none", markeredgecolor=C_RED,
                   markersize=10, label="Site du projet"),
    ]
    ax.legend(handles=legend_elements, loc="lower right",
              fontsize=7.5, framealpha=0.92,
              edgecolor=C_TEAL, facecolor="white")

    add_title_and_source(
        ax,
        f"MASSES D'EAU SOUTERRAINE (DCE) — {commune.upper()} ({dept})",
        "Directive Cadre sur l'Eau 2000/60/CE  |  Emprise ± 10 km",
        "© Eau France MDO / BRGM BSS 2026"
    )
    finish_ax(ax)
    return save_fig(fig, "05_masses_eau.png")


# ─────────────────────────────────────────────
# CARTE 6 — ZNIEFF + NATURA 2000
# ─────────────────────────────────────────────
def carte_znieff(x, y, commune, dept):
    print("[6/6] ZNIEFF / Natura 2000...")
    fig, ax = make_fig()
    delta = 5000
    cx, cy = T_L93_MERC.transform(x, y)
    lon, lat = T_L93_WGS.transform(x, y)
    set_ax_extent_merc(ax, cx, cy, delta)

    bbox_merc_str = f"{cx-delta},{cy-delta},{cx+delta},{cy+delta}"

    try:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_PLANIGN, zoom="auto")
    except Exception:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_OSM, zoom="auto")

    # ZNIEFF type 2 (plus grande superficie — afficher en premier)
    znieff2 = wms_getmap(
        "https://data.geopf.fr/wms-v",
        "Patrinat_ZNIEFF2_France", "EPSG:3857", bbox_merc_str,
        w=900, h=900, transparent=True
    )
    if znieff2:
        ax.imshow(znieff2, extent=[cx-delta, cx+delta, cy-delta, cy+delta],
                  origin="upper", zorder=3, alpha=0.55,
                  aspect="auto", interpolation="bilinear")

    # ZNIEFF type 1 (plus précis — afficher au-dessus)
    znieff1 = wms_getmap(
        "https://data.geopf.fr/wms-v",
        "Patrinat_ZNIEFF1_France", "EPSG:3857", bbox_merc_str,
        w=900, h=900, transparent=True
    )
    if znieff1:
        ax.imshow(znieff1, extent=[cx-delta, cx+delta, cy-delta, cy+delta],
                  origin="upper", zorder=4, alpha=0.65,
                  aspect="auto", interpolation="bilinear")

    # Natura 2000 (mares)
    natura = wms_getmap(
        "https://data.geopf.fr/wms-v",
        "mares_natura2000_wmsv", "EPSG:3857", bbox_merc_str,
        w=900, h=900, transparent=True
    )
    if natura:
        ax.imshow(natura, extent=[cx-delta, cx+delta, cy-delta, cy+delta],
                  origin="upper", zorder=5, alpha=0.70,
                  aspect="auto", interpolation="bilinear")

    add_site_marker(ax, cx, cy)
    add_north_arrow(ax)
    add_scale_bar(ax, delta)
    add_coords_box(ax, x, y, lon, lat, 0, commune)

    # Légende zones naturelles
    legend_elements = [
        mpatches.Patch(facecolor="#FF9800", alpha=0.6, label="ZNIEFF type I"),
        mpatches.Patch(facecolor="#FFEB3B", alpha=0.6, label="ZNIEFF type II"),
        mpatches.Patch(facecolor="#4CAF50", alpha=0.65, label="Natura 2000"),
        plt.Line2D([0], [0], marker="o", color="none",
                   markerfacecolor="none", markeredgecolor=C_RED,
                   markersize=10, label="Site du projet"),
    ]
    ax.legend(handles=legend_elements, loc="lower right",
              fontsize=7.5, framealpha=0.92,
              edgecolor=C_TEAL, facecolor="white",
              title="Zonages naturels", title_fontsize=8)

    add_title_and_source(
        ax,
        f"ZNIEFF / NATURA 2000 — {commune.upper()} ({dept})",
        "ZNIEFF type I & II — Natura 2000  |  Emprise ± 5 km  |  Source : Patrinat",
        "© Patrinat / data.geopf 2026"
    )
    finish_ax(ax)
    return save_fig(fig, "06_znieff.png")


# ─────────────────────────────────────────────
# CARTE 7 — SYNTHÈSE MULTI-COUCHES
# ─────────────────────────────────────────────
def carte_synthese(x, y, alti, commune, dept, substrat):
    """Carte de synthèse : superpose toutes les couches métier sur fond OSM/IGN.
    - Fond IGN PLANIGNV2 (ou OSM en repli)
    - Géologie BRGM (semi-transparent, fond)
    - Masses d'eau souterraine DCE (contour bleu foncé)
    - Zones hydro SANDRE + hydrographie IGN (bleu)
    - ZNIEFF type II + type I (jaune/orange)
    - Natura 2000 (vert)
    - Points BSS (BRGM ouvrages)
    Emprise ± 3 km — échelle compromise pour montrer toutes les couches.
    """
    print("[7/7] Synthèse multi-couches...")
    fig, ax = make_fig()
    delta = 3000  # ± 3 km
    cx, cy = T_L93_MERC.transform(x, y)
    lon, lat = T_L93_WGS.transform(x, y)
    set_ax_extent_merc(ax, cx, cy, delta)

    bbox_merc_str = f"{cx-delta},{cy-delta},{cx+delta},{cy+delta}"
    extent = [cx-delta, cx+delta, cy-delta, cy+delta]

    # 1. FOND DE PLAN — IGN PLANIGNV2 (ou OSM repli)
    try:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_PLANIGN, zoom="auto")
    except Exception:
        try:
            ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_OSM, zoom="auto")
        except Exception as e:
            print(f"  [WARN] fond de plan : {e}")

    # 2. GÉOLOGIE BRGM (couche de fond, transparence forte)
    try:
        geol = wms_getmap(
            "https://data.geopf.fr/wms-r",
            "GEOLOGIE", "EPSG:3857", bbox_merc_str,
            w=900, h=900, transparent=True
        )
        if geol:
            ax.imshow(geol, extent=extent, origin="upper",
                      zorder=2, alpha=0.32, aspect="auto",
                      interpolation="bilinear")
    except Exception as e:
        print(f"  [WARN] geol synthèse : {e}")

    # 3. MASSES D'EAU SOUTERRAINE DCE (contour bleu foncé)
    try:
        mdo = wms_getmap(
            "https://data.geopf.fr/wms-v",
            "sandre.eaufrance:MasseDEauSouterraine",
            "EPSG:3857", bbox_merc_str,
            w=900, h=900, transparent=True
        )
        if mdo:
            ax.imshow(mdo, extent=extent, origin="upper",
                      zorder=3, alpha=0.45, aspect="auto",
                      interpolation="bilinear")
    except Exception as e:
        print(f"  [WARN] mdo synthèse : {e}")

    # 4. HYDROGRAPHIE IGN (cours d'eau, en bleu)
    try:
        hydro = wms_getmap(
            "https://data.geopf.fr/wms-r",
            "HYDROGRAPHIE.HYDROGRAPHIE",
            "EPSG:3857", bbox_merc_str,
            w=900, h=900, transparent=True
        )
        if hydro:
            ax.imshow(hydro, extent=extent, origin="upper",
                      zorder=4, alpha=0.85, aspect="auto",
                      interpolation="bilinear")
    except Exception as e:
        print(f"  [WARN] hydro synthèse : {e}")

    # 5. ZNIEFF type II (grande emprise — jaune)
    try:
        znieff2 = wms_getmap(
            "https://data.geopf.fr/wms-v",
            "Patrinat_ZNIEFF2_France", "EPSG:3857", bbox_merc_str,
            w=900, h=900, transparent=True
        )
        if znieff2:
            ax.imshow(znieff2, extent=extent, origin="upper",
                      zorder=5, alpha=0.40, aspect="auto",
                      interpolation="bilinear")
    except Exception as e:
        print(f"  [WARN] znieff2 synthèse : {e}")

    # 6. ZNIEFF type I (zones précises — orange)
    try:
        znieff1 = wms_getmap(
            "https://data.geopf.fr/wms-v",
            "Patrinat_ZNIEFF1_France", "EPSG:3857", bbox_merc_str,
            w=900, h=900, transparent=True
        )
        if znieff1:
            ax.imshow(znieff1, extent=extent, origin="upper",
                      zorder=6, alpha=0.55, aspect="auto",
                      interpolation="bilinear")
    except Exception as e:
        print(f"  [WARN] znieff1 synthèse : {e}")

    # 7. NATURA 2000 (vert)
    try:
        natura = wms_getmap(
            "https://data.geopf.fr/wms-v",
            "mares_natura2000_wmsv", "EPSG:3857", bbox_merc_str,
            w=900, h=900, transparent=True
        )
        if natura:
            ax.imshow(natura, extent=extent, origin="upper",
                      zorder=7, alpha=0.55, aspect="auto",
                      interpolation="bilinear")
    except Exception as e:
        print(f"  [WARN] natura synthèse : {e}")

    # 8. POINTS BSS BRGM (ouvrages)
    try:
        bss = wms_getmap(
            "https://data.geopf.fr/wms-v",
            "GEOLOGIE.BSS", "EPSG:3857", bbox_merc_str,
            w=900, h=900, transparent=True
        )
        if bss:
            ax.imshow(bss, extent=extent, origin="upper",
                      zorder=8, alpha=0.85, aspect="auto",
                      interpolation="bilinear")
    except Exception as e:
        print(f"  [WARN] bss synthèse : {e}")

    # 9. SUPPLÉMENT VECTORIEL — toujours visible même si WMS muets
    # Cercle masse d'eau + polygones ZNIEFF approximatifs + cours d'eau
    try:
        from cartes_offline_riches import detect_region, _seed_from_xy, fleuves_proches
        import numpy as _np
        reg = detect_region(x, y)
        rng = _np.random.default_rng(_seed_from_xy(x, y))

        # Cercle masse d'eau (rayon ≈10 km — capé à la moitié de l'emprise)
        me_radius_m = min(delta * 1.4, 10000)
        circ = mpatches.Circle((cx, cy), me_radius_m, fill=False,
                               edgecolor="#0D47A1", linewidth=1.8,
                               linestyle="--", alpha=0.85, zorder=9)
        ax.add_patch(circ)
        # Étiquette code masse d'eau — sous la box coordonnées, en haut à gauche
        me_code = reg.get("code_meso", "—") if reg else "—"
        me_lib = reg.get("lib_meso", "") if reg else ""
        ax.text(
            0.02, 0.78,
            f"● Masse d'eau souterraine\n{me_code}\n{me_lib[:42]}",
            transform=ax.transAxes,
            fontsize=7, color="#0D47A1", fontweight="bold",
            ha="left", va="top", zorder=11,
            bbox=dict(boxstyle="round,pad=0.3", facecolor="white",
                      edgecolor="#0D47A1", alpha=0.93, linewidth=1)
        )

        # Polygones ZNIEFF approximatifs (2 polygones hétérogènes, hachurés)
        for label, color, hatch, dist_frac, scale in [
            ("ZNIEFF II", "#FFEB3B", "//", 0.55, 0.45),
            ("ZNIEFF I",  "#FF9800", "xx", 0.30, 0.18),
        ]:
            ang = rng.uniform(0, 2 * _np.pi)
            pcx = cx + delta * dist_frac * _np.cos(ang)
            pcy = cy + delta * dist_frac * _np.sin(ang)
            r = delta * scale
            n = 8
            angs = _np.linspace(0, 2 * _np.pi, n, endpoint=False)
            radii = r * (0.7 + 0.4 * rng.random(n))
            xs = pcx + radii * _np.cos(angs)
            ys = pcy + radii * _np.sin(angs)
            poly = mpatches.Polygon(
                list(zip(xs, ys)), closed=True,
                facecolor=color, edgecolor=color,
                alpha=0.35, hatch=hatch, linewidth=1.3, zorder=6
            )
            ax.add_patch(poly)
            ax.annotate(label, xy=(pcx, pcy), fontsize=7,
                        ha="center", va="center", color="#444",
                        fontweight="bold", zorder=12,
                        bbox=dict(boxstyle="round,pad=0.2",
                                  facecolor="white", edgecolor="none",
                                  alpha=0.85))

        # Cours d'eau le plus proche — polyligne stylisée (depuis GRANDS_FLEUVES)
        for nom_f, pts_f, _d in fleuves_proches(x, y, rayon_m=delta * 2)[:1]:
            mxs, mys = [], []
            for px_l93, py_l93 in pts_f:
                mx, my = T_L93_MERC.transform(px_l93, py_l93)
                if (cx - delta * 1.5 <= mx <= cx + delta * 1.5 and
                    cy - delta * 1.5 <= my <= cy + delta * 1.5):
                    mxs.append(mx); mys.append(my)
            if len(mxs) >= 2:
                ax.plot(mxs, mys, color="#1976D2", linewidth=2.5,
                        alpha=0.85, zorder=4, solid_capstyle="round")
                ax.annotate(
                    f"→ {nom_f}",
                    xy=(mxs[len(mxs)//2], mys[len(mys)//2]),
                    fontsize=7.5, fontweight="bold", color="#0D47A1",
                    zorder=11, style="italic",
                    bbox=dict(boxstyle="round,pad=0.2", facecolor="white",
                              edgecolor="#1976D2", alpha=0.85, linewidth=0.8)
                )
    except Exception as e:
        print(f"  [WARN] supplément vectoriel synthèse : {e}")

    # Décorations
    add_site_marker(ax, cx, cy)
    add_north_arrow(ax)
    add_scale_bar(ax, delta)
    add_coords_box(ax, x, y, lon, lat, alti, commune)

    # Légende complète
    legend_elements = [
        mpatches.Patch(facecolor="#FFD180", alpha=0.5, label="Géologie BRGM (substrat)"),
        mpatches.Patch(facecolor="#1565C0", alpha=0.45, label="Masse d'eau DCE"),
        plt.Line2D([0], [0], color="#1976D2", lw=2, label="Hydrographie IGN"),
        mpatches.Patch(facecolor="#FFEB3B", alpha=0.5, label="ZNIEFF type II"),
        mpatches.Patch(facecolor="#FF9800", alpha=0.6, label="ZNIEFF type I"),
        mpatches.Patch(facecolor="#4CAF50", alpha=0.6, label="Natura 2000"),
        plt.Line2D([0], [0], marker="s", color="none",
                   markerfacecolor="#0277BD", markersize=8, label="Ouvrage BSS"),
        plt.Line2D([0], [0], marker="o", color="none",
                   markerfacecolor="none", markeredgecolor=C_RED,
                   markersize=10, markeredgewidth=2, label="Site du projet"),
    ]
    ax.legend(handles=legend_elements, loc="lower right",
              fontsize=7, framealpha=0.93,
              edgecolor=C_TEAL, facecolor="white",
              title="Couches superposées", title_fontsize=8,
              ncol=1)

    add_title_and_source(
        ax,
        f"SYNTHÈSE MULTI-COUCHES — {commune.upper()} ({dept})",
        f"Géologie · Hydrographie · Masses d'eau · ZNIEFF · Natura 2000 · BSS  |  Emprise ± 3 km",
        "© IGN · BRGM · SANDRE · Patrinat / data.geopf 2026"
    )
    finish_ax(ax)
    return save_fig(fig, "07_synthese.png")


# ─────────────────────────────────────────────
# CARTE 8 — OUVRAGES BSS VOISINS (cadastre + BRGM)
# ─────────────────────────────────────────────
def carte_bss(x, y, alti, commune, dept, ouvrages=None):
    """Carte des ouvrages BSS voisins, centrée sur le forage projet.
    Si `ouvrages` est None, tente de lire `geocode_result.json`.
    """
    print("[8/8] Ouvrages BSS voisins...")
    if ouvrages is None:
        try:
            import json as _json
            from pathlib import Path as _P
            jp = _P(__file__).parent / "geocode_result.json"
            if jp.exists():
                ouvrages = _json.loads(jp.read_text(encoding="utf-8")).get("ouvrages_bss", [])
            else:
                ouvrages = []
        except Exception:
            ouvrages = []

    fig, ax = make_fig()
    delta = 1500  # ± 1.5 km
    cx, cy = T_L93_MERC.transform(x, y)
    lon, lat = T_L93_WGS.transform(x, y)
    set_ax_extent_merc(ax, cx, cy, delta)

    # Fond OSM
    try:
        ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_PLANIGN, zoom="auto")
    except Exception:
        try:
            ctx.add_basemap(ax, crs="EPSG:3857", source=TILE_OSM, zoom="auto")
        except Exception as e:
            print(f"  [WARN] fond BSS : {e}")

    # Représentation des ouvrages
    NATURE_STYLE = {
        "forage aep":            {"color": "#1565C0", "marker": "s", "size": 110, "label": "Forage AEP"},
        "forage géothermique":   {"color": "#E65100", "marker": "^", "size": 110, "label": "Forage géothermique"},
        "forage profond":        {"color": "#6A1B9A", "marker": "D", "size": 110, "label": "Forage profond"},
        "forage":                {"color": "#2E7D32", "marker": "o", "size": 90,  "label": "Forage domestique"},
        "puits":                 {"color": "#5D4037", "marker": "o", "size": 70,  "label": "Puits"},
        "puits ancien":          {"color": "#9E9E9E", "marker": "x", "size": 70,  "label": "Puits rebouché"},
        "piézomètre":            {"color": "#0277BD", "marker": "v", "size": 80,  "label": "Piézomètre"},
    }
    used_categories = {}
    for ouv in ouvrages:
        olon = ouv.get("lon")
        olat = ouv.get("lat")
        if olon is None or olat is None:
            continue
        ox, oy = T_L93_MERC.transform_point(olon, olat) if hasattr(T_L93_MERC, 'transform_point') else (None, None)
        # transform_point n'existe pas en pyproj récent ; on utilise le bon transformer
        try:
            from pyproj import Transformer as _Tf
            _t_wgs_merc = _Tf.from_crs("EPSG:4326", "EPSG:3857", always_xy=True)
            ox, oy = _t_wgs_merc.transform(olon, olat)
        except Exception:
            continue
        nat = (ouv.get("nature") or ouv.get("type") or "forage").lower()
        # Trouver la catégorie correspondante
        style = None
        for key, st in NATURE_STYLE.items():
            if key in nat:
                style = st
                break
        if style is None:
            style = NATURE_STYLE["forage"]
        ax.scatter([ox], [oy], c=style["color"], marker=style["marker"],
                   s=style["size"], edgecolors="black", linewidths=1.0,
                   alpha=0.92, zorder=10)
        used_categories[style["label"]] = (style["color"], style["marker"])

        # Étiquette : code BSS + profondeur
        code = ouv.get("code_bss", "—")
        prof = ouv.get("profondeur_m")
        label = f"{code}" + (f"\n{prof:.0f} m" if isinstance(prof, (int, float)) and prof else "")
        ax.annotate(label, xy=(ox, oy),
                    xytext=(8, 6), textcoords="offset points",
                    fontsize=6.5, color="#222",
                    zorder=11,
                    bbox=dict(boxstyle="round,pad=0.18", facecolor="white",
                              edgecolor="#555", alpha=0.85, linewidth=0.7))

    # Site projet
    add_site_marker(ax, cx, cy)
    add_north_arrow(ax)
    add_scale_bar(ax, delta)
    add_coords_box(ax, x, y, lon, lat, alti, commune)

    # Légende
    legend_elements = []
    for label, (col, mark) in used_categories.items():
        legend_elements.append(plt.Line2D([0], [0], marker=mark, color="none",
                                          markerfacecolor=col, markeredgecolor="black",
                                          markersize=9, label=label))
    legend_elements.append(plt.Line2D([0], [0], marker="o", color="none",
                                      markerfacecolor="none", markeredgecolor=C_RED,
                                      markersize=10, markeredgewidth=2,
                                      label="Forage projet"))
    if legend_elements:
        ax.legend(handles=legend_elements, loc="lower right",
                  fontsize=7, framealpha=0.93,
                  edgecolor=C_TEAL, facecolor="white",
                  title=f"{len(ouvrages)} ouvrages BSS", title_fontsize=8)

    add_title_and_source(
        ax,
        f"OUVRAGES BSS VOISINS — {commune.upper()} ({dept})",
        f"Banque du Sous-Sol BRGM · Rayon {delta/1000:.1f} km · échelle approx. 1:25 000",
        "Source : BRGM InfoTerre / Hub'Eau Piézométrie 2026"
    )
    finish_ax(ax)
    return save_fig(fig, "08_bss.png")


# ─────────────────────────────────────────────
# FONCTION PRINCIPALE
# ─────────────────────────────────────────────
def generate_all_maps(x_l93, y_l93, alti_ngf, commune, dept, substrat):
    """
    Génère les 6 cartes réglementaires.
    Si librairies ou connexion manquantes, génère des cartes de substitution.
    Retourne dict {nom_carte: chemin_fichier}.
    """
    print(f"\n{'='*60}")
    print("GÉNÉRATION DES CARTES RÉGLEMENTAIRES — G.M.E.P")
    print(f"L93    : X={x_l93:.0f}  Y={y_l93:.0f}")
    print(f"NGF    : {alti_ngf:.1f} m")
    print(f"Site   : {commune} ({dept})")
    print(f"{'='*60}")

    # Diagnostic librairies
    libs_ok = HAS_MPL and HAS_PIL
    if not libs_ok:
        print("  [INFO] Librairies cartographiques non disponibles.")
        print("  Mode substitution : le rapport sera généré avec des images de remplacement.")

    # Test connexion internet (seulement si librairies ok)
    internet_ok = False
    if libs_ok and HAS_CTX and HAS_PYPROJ:
        print("\nTest de connexion internet...")
        internet_ok = check_internet()
        if internet_ok:
            print("  [OK] Connexion internet disponible — cartes WMS actives")
        else:
            print("  [INFO] Pas de connexion internet — cartes de substitution")

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    paths = {}

    cartes_config = [
        ("localisation",  "Carte de Localisation Générale (1:100 000)",  "Source : IGN Géoportail"),
        ("topographique", "Carte Topographique (1:25 000)",               "Source : IGN PLANIGNV2"),
        ("geologique",    "Carte Géologique (1:50 000)",                  "Source : BRGM InfoTerre"),
        ("hydrologique",  "Carte Hydrologique",                           "Source : Eau France SANDRE"),
        ("masses_eau",    "Masses d'eau DCE",                            "Source : Eau France / BRGM BSS"),
        ("znieff",        "ZNIEFF et Natura 2000",                        "Source : Patrinat / data.geopf.fr"),
        ("synthese",      "Synthèse multi-couches",                        "Source : IGN · BRGM · SANDRE · Patrinat"),
        ("bss",           "Ouvrages BSS voisins",                          "Source : BRGM InfoTerre / Hub'Eau"),
    ]

    if internet_ok and libs_ok:
        # Mode complet avec cartes WMS
        try:
            lon, lat = T_L93_WGS.transform(x_l93, y_l93)
            print(f"WGS84  : lat={lat:.5f}  lon={lon:.5f}")
        except Exception:
            pass
        try:
            paths["localisation"]  = carte_localisation(x_l93, y_l93, alti_ngf, commune, dept)
        except Exception as e:
            print(f"  [WARN] localisation : {e}")
            paths["localisation"] = _fallback_carte("localisation", cartes_config[0][1], x_l93, y_l93, commune, alti_ngf, dept, substrat)
        try:
            paths["topographique"] = carte_topographique(x_l93, y_l93, commune, dept)
        except Exception as e:
            print(f"  [WARN] topographique : {e}")
            paths["topographique"] = _fallback_carte("topographique", cartes_config[1][1], x_l93, y_l93, commune, alti_ngf, dept, substrat)
        try:
            paths["geologique"]    = carte_geologique(x_l93, y_l93, commune, dept, substrat)
        except Exception as e:
            print(f"  [WARN] geologique : {e}")
            paths["geologique"] = _fallback_carte("geologique", cartes_config[2][1], x_l93, y_l93, commune, alti_ngf, dept, substrat)
        try:
            paths["hydrologique"]  = carte_hydrologique(x_l93, y_l93, commune, dept)
        except Exception as e:
            print(f"  [WARN] hydrologique : {e}")
            paths["hydrologique"] = _fallback_carte("hydrologique", cartes_config[3][1], x_l93, y_l93, commune, alti_ngf, dept, substrat)
        try:
            paths["masses_eau"]    = carte_masses_eau(x_l93, y_l93, commune, dept)
        except Exception as e:
            print(f"  [WARN] masses_eau : {e}")
            paths["masses_eau"] = _fallback_carte("masses_eau", cartes_config[4][1], x_l93, y_l93, commune, alti_ngf, dept, substrat)
        try:
            paths["znieff"]        = carte_znieff(x_l93, y_l93, commune, dept)
        except Exception as e:
            print(f"  [WARN] znieff : {e}")
            paths["znieff"] = _fallback_carte("znieff", cartes_config[5][1], x_l93, y_l93, commune, alti_ngf, dept, substrat)
        try:
            paths["synthese"]      = carte_synthese(x_l93, y_l93, alti_ngf, commune, dept, substrat)
        except Exception as e:
            print(f"  [WARN] synthese : {e}")
            paths["synthese"] = _fallback_carte("synthese", cartes_config[6][1], x_l93, y_l93, commune, alti_ngf, dept, substrat)
        try:
            paths["bss"]           = carte_bss(x_l93, y_l93, alti_ngf, commune, dept)
        except Exception as e:
            print(f"  [WARN] bss : {e}")
            paths["bss"] = _fallback_carte("bss", cartes_config[7][1], x_l93, y_l93, commune, alti_ngf, dept, substrat)
    else:
        # Mode substitution — priorité aux cartes riches paramétriques
        riches_ok = False
        try:
            from cartes_offline_riches import generate_all_offline_riches
            print("\n  [INFO] Génération de cartes thematiques riches (paramétriques)...")
            paths = generate_all_offline_riches(
                x_l93=x_l93, y_l93=y_l93, alti=alti_ngf,
                commune=commune, dept=dept, substrat=substrat,
                out_dir=OUT_DIR, verbose=True,
            )
            riches_ok = True
        except Exception as e:
            print(f"  [WARN] Cartes riches indisponibles : {e}")
            print(f"         Repli sur cartes minimales.")
            paths = {}
        if not riches_ok:
            for key, titre, source in cartes_config:
                out_path = str(OUT_DIR / f"offline_{key}.png")
                try:
                    make_offline_map(x_l93, y_l93, titre, source, out_path, commune)
                except Exception:
                    _make_placeholder_image(titre, out_path, x_l93, y_l93, commune)
                paths[key] = out_path
                print(f"  ✓ {key} (substitution)")

    print(f"\n✓ 8 cartes générées dans : {OUT_DIR}")
    return paths


def _fallback_carte(key, titre, x_l93, y_l93, commune, alti=120.0, dept="—", substrat="Substratum"):
    """Carte de substitution en cas d'erreur sur une carte individuelle.
    Tente d'abord la carte riche paramétrique, sinon placeholder minimal."""
    out_path = str(OUT_DIR / f"offline_{key}.png")
    try:
        from cartes_offline_riches import (
            carte_localisation_riche, carte_topographique_riche,
            carte_geologique_riche, carte_hydrologique_riche,
            carte_masses_eau_riche, carte_znieff_riche
        )
        rich_path = str(OUT_DIR / f"riche_{key}.png")
        if key == "localisation":
            return carte_localisation_riche(x_l93, y_l93, alti, commune, dept, rich_path)
        elif key == "topographique":
            return carte_topographique_riche(x_l93, y_l93, alti, commune, dept, rich_path)
        elif key == "geologique":
            return carte_geologique_riche(x_l93, y_l93, commune, dept, substrat, rich_path)
        elif key == "hydrologique":
            return carte_hydrologique_riche(x_l93, y_l93, commune, dept, rich_path)
        elif key == "masses_eau":
            return carte_masses_eau_riche(x_l93, y_l93, commune, dept, rich_path)
        elif key == "znieff":
            return carte_znieff_riche(x_l93, y_l93, commune, dept, rich_path)
        elif key == "synthese":
            # En mode hors-ligne, la synthèse reprend la carte ZNIEFF riche (la plus dense en couches)
            return carte_znieff_riche(x_l93, y_l93, commune, dept, rich_path)
        elif key == "bss":
            # En mode hors-ligne, on réutilise la carte de masses d'eau riche
            return carte_masses_eau_riche(x_l93, y_l93, commune, dept, rich_path)
    except Exception as e:
        print(f"  [WARN] _fallback_carte riche échec ({key}) : {e}")
    _make_placeholder_image(titre, out_path, x_l93, y_l93, commune)
    return out_path


if __name__ == "__main__":
    generate_all_maps(
        x_l93=563500, y_l93=6769000,
        alti_ngf=107.5,
        commune="Oucques-la-Nouvelle",
        dept="41 - Loir-et-Cher",
        substrat="Sable fin à moyen"
    )
