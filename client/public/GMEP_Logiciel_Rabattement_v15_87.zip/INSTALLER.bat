@echo off
chcp 65001 >nul
title GMEP - Installation automatique
color 0A
setlocal EnableDelayedExpansion

REM === Recuperation du dossier courant (compatible apostrophes & accents) ===
set "DOSSIER=%~dp0"
set "DOSSIER_NS=%DOSSIER:~0,-1%"
set "XLSX=%DOSSIER%Modelisation_Rabattement_TSN_GMEP.xlsm"

REM === Passage via variables d'environnement = pas de probleme d'apostrophes ===
set "GMEP_FOLDER=%DOSSIER_NS%"
set "GMEP_XLSX=%XLSX%"

echo.
echo =====================================================================
echo   GMEP - INSTALLATION DU LOGICIEL DE RABATTEMENT
echo =====================================================================
echo.

REM === Ferme Excel automatiquement ===
taskkill /IM EXCEL.EXE /F >nul 2>&1
timeout /t 1 /nobreak >nul

REM === Une seule commande PowerShell, chemins lus via $env: (apostrophe-safe) ===
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ErrorActionPreference='SilentlyContinue';" ^
  "$folder=$env:GMEP_FOLDER;" ^
  "$xlsx=$env:GMEP_XLSX;" ^
  "Write-Host '';" ^
  "Write-Host '[1/4] Deblocage de tous les fichiers (Mark of the Web)...' -ForegroundColor Cyan;" ^
  "Get-ChildItem -LiteralPath $folder -Recurse -File | ForEach-Object {" ^
    "Unblock-File -LiteralPath $_.FullName;" ^
    "Remove-Item -LiteralPath ($_.FullName+':Zone.Identifier') -Force" ^
  "};" ^
  "Write-Host '      OK' -ForegroundColor Green;" ^
  "Write-Host '';" ^
  "Write-Host '[2/4] Emplacement approuve Excel...' -ForegroundColor Cyan;" ^
  "foreach ($v in @('16.0','15.0','14.0')) {" ^
    "if (Test-Path \"HKCU:\Software\Microsoft\Office\$v\Excel\") {" ^
      "$tl=\"HKCU:\Software\Microsoft\Office\$v\Excel\Security\Trusted Locations\";" ^
      "New-Item -Path $tl -Force | Out-Null;" ^
      "$key=$tl+'\LocationGMEP';" ^
      "New-Item -Path $key -Force | Out-Null;" ^
      "New-ItemProperty -Path $key -Name 'Path' -Value $folder -PropertyType String -Force | Out-Null;" ^
      "New-ItemProperty -Path $key -Name 'AllowSubFolders' -Value 1 -PropertyType DWord -Force | Out-Null;" ^
      "New-ItemProperty -Path $key -Name 'Description' -Value 'GMEP' -PropertyType String -Force | Out-Null;" ^
      "New-ItemProperty -Path $tl -Name 'AllowNetworkLocations' -Value 1 -PropertyType DWord -Force | Out-Null;" ^
      "Write-Host ('      Excel '+$v+' : OK') -ForegroundColor Green" ^
    "}" ^
  "};" ^
  "Write-Host '';" ^
  "Write-Host '[3/4] Verification du tableur...' -ForegroundColor Cyan;" ^
  "if (-not (Test-Path -LiteralPath $xlsx)) { Write-Host '      ERREUR : tableur introuvable' -ForegroundColor Red; exit 1 };" ^
  "Unblock-File -LiteralPath $xlsx;" ^
  "Remove-Item -LiteralPath ($xlsx+':Zone.Identifier') -Force;" ^
  "Write-Host '      OK' -ForegroundColor Green;" ^
  "Write-Host '';" ^
  "Write-Host '[4/4] Ouverture du tableur dans Excel...' -ForegroundColor Cyan;" ^
  "Start-Process -FilePath $xlsx;" ^
  "Write-Host '      OK' -ForegroundColor Green;" ^
  "Write-Host '';"

echo.
echo =====================================================================
echo   INSTALLATION TERMINEE
echo =====================================================================
echo.
echo   Pour les prochaines utilisations :
echo     Double-cliquer directement sur Modelisation_Rabattement_TSN_GMEP.xlsm
echo.
timeout /t 5 /nobreak >nul
exit /b 0
