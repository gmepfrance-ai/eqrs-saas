' ================================================================
' G.M.E.P -- Diagnostic Python -- v1
' Lance python.exe directement avec WshShell.Exec pour capturer
' la vraie erreur de demarrage Python
' ================================================================
Option Explicit

Dim WshShell, FSO
Set WshShell = CreateObject("WScript.Shell")
Set FSO      = CreateObject("Scripting.FileSystemObject")

Dim PythonExe, LogFile, ScriptFolder
ScriptFolder = FSO.GetParentFolderName(WScript.ScriptFullName)
LogFile      = ScriptFolder & "\gmep_diag.txt"

' Python313 en chemin fixe
PythonExe = WshShell.ExpandEnvironmentStrings( _
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe")

' Creer le log
Dim fLog
Set fLog = FSO.CreateTextFile(LogFile, True, True)
fLog.WriteLine "=== DIAGNOSTIC PYTHON GMEP ==="
fLog.WriteLine "Date : " & Now()
fLog.WriteLine "Python : " & PythonExe
fLog.WriteLine "Existe : " & FSO.FileExists(PythonExe)
fLog.WriteLine ""

If Not FSO.FileExists(PythonExe) Then
    fLog.WriteLine "[ERREUR] python.exe introuvable"
    fLog.Close
    WshShell.Run "notepad """ & LogFile & """"
    WScript.Quit 1
End If

' ── Test 1 : python --version via Exec (capture stdout+stderr) ──
fLog.WriteLine "--- TEST 1 : python --version ---"
Dim oExec1, out1, err1
On Error Resume Next
Set oExec1 = WshShell.Exec("""" & PythonExe & """ --version")
If Err.Number <> 0 Then
    fLog.WriteLine "Exec echoue : " & Err.Description
    Err.Clear
Else
    out1 = oExec1.StdOut.ReadAll()
    err1 = oExec1.StdErr.ReadAll()
    fLog.WriteLine "StdOut : " & out1
    fLog.WriteLine "StdErr : " & err1
    fLog.WriteLine "ExitCode : " & oExec1.ExitCode
End If
On Error GoTo 0

' ── Test 2 : python -c "import sys; print(sys.version)" ──
fLog.WriteLine ""
fLog.WriteLine "--- TEST 2 : import sys ---"
Dim oExec2, out2, err2
On Error Resume Next
Set oExec2 = WshShell.Exec("""" & PythonExe & """ -c ""import sys; print(sys.version)""")
If Err.Number <> 0 Then
    fLog.WriteLine "Exec echoue : " & Err.Description
    Err.Clear
Else
    Dim t2start
    t2start = Timer
    ' Attendre max 10 secondes
    Do While oExec2.Status = 0 And (Timer - t2start) < 10
        WScript.Sleep 200
    Loop
    out2 = oExec2.StdOut.ReadAll()
    err2 = oExec2.StdErr.ReadAll()
    fLog.WriteLine "StdOut : " & out2
    fLog.WriteLine "StdErr : " & err2
    fLog.WriteLine "ExitCode : " & oExec2.ExitCode
    fLog.WriteLine "Status (0=running,1=done) : " & oExec2.Status
End If
On Error GoTo 0

' ── Test 3 : verifier si python.exe est bloque par AV ──
fLog.WriteLine ""
fLog.WriteLine "--- TEST 3 : taille python.exe ---"
Dim fPy
On Error Resume Next
Set fPy = FSO.GetFile(PythonExe)
If Err.Number = 0 Then
    fLog.WriteLine "Taille : " & fPy.Size & " octets"
    fLog.WriteLine "DateModif : " & fPy.DateLastModified
Else
    fLog.WriteLine "Impossible de lire le fichier : " & Err.Description
End If
On Error GoTo 0

fLog.Close

' Afficher le diagnostic
MsgBox "Diagnostic termine." & vbCrLf & vbCrLf & _
       "Le fichier gmep_diag.txt va s'ouvrir." & vbCrLf & _
       "Transmettez son contenu pour resolution.", _
       vbInformation, "G.M.E.P Diagnostic"

WshShell.Run "notepad """ & LogFile & """"

Set WshShell = Nothing
Set FSO = Nothing
