"""Met à jour le bloc « RÉSOLUTION GÉOGRAPHIQUE AUTOMATIQUE » du tableur Excel
à partir des coordonnées X/Y Lambert 93 saisies en C33/C34.

Usage :
    python update_excel_geo.py [chemin_fichier_excel]

Si le chemin est omis, utilise le tableur par défaut :
    Modelisation_Rabattement_TSN_GMEP.xlsx

Ce script est appelé automatiquement par le générateur PDF, mais peut aussi
être exécuté manuellement après modification des coordonnées dans Excel pour
mettre à jour le bloc d'affichage en lignes 109-128 (commune, INSEE, ZRE, masse d'eau).
"""
import os
import sys
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, SCRIPT_DIR)
import geo_resolver as g_mod  # noqa: E402

DEFAULT_XLSX = os.path.join(SCRIPT_DIR, "Modelisation_Rabattement_TSN_GMEP.xlsx")
START_ROW = 109  # Ligne de départ du bloc géo dans la feuille « Données d'Entrée »

# Styles partagés
HEADER_FILL = PatternFill(start_color="01696F", end_color="01696F", fill_type="solid")
HEADER_FONT = Font(bold=True, color="FFFFFF", size=10)
SUB_HEAD_FILL = PatternFill(start_color="0C4E54", end_color="0C4E54", fill_type="solid")
LABEL_FONT  = Font(bold=True, size=9, color="0C4E54")
VALUE_FONT  = Font(size=9, color="28251D")
DESC_FONT   = Font(italic=True, size=8, color="7A7974")
INFO_FILL   = PatternFill(start_color="EAF4F5", end_color="EAF4F5", fill_type="solid")
WARN_FILL   = PatternFill(start_color="FBEDF3", end_color="FBEDF3", fill_type="solid")
OK_FILL     = PatternFill(start_color="E8F4E8", end_color="E8F4E8", fill_type="solid")
NEUTRAL_FILL= PatternFill(fill_type=None)
THIN = Side(style="thin", color="B5D6D8")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def update_geo_block(xlsx_path: str = DEFAULT_XLSX) -> dict:
    """Met à jour le bloc géo lignes 109-128 et retourne le dict de résolution."""
    wb = openpyxl.load_workbook(xlsx_path)
    sheet_name = "Données d'Entrée" if "Données d'Entrée" in wb.sheetnames else wb.active.title
    ws = wb[sheet_name]

    xv = ws["C33"].value
    yv = ws["C34"].value
    if xv is None or yv is None:
        print(f"[!] X/Y manquants en C33/C34 — bloc géo non mis à jour")
        return {}

    try:
        x = float(xv); y = float(yv)
    except (TypeError, ValueError):
        print(f"[!] X/Y non numériques (C33={xv!r}, C34={yv!r}) — bloc géo non mis à jour")
        return {}

    print(f"[geo] X={x:.2f}  Y={y:.2f} → résolution en cours…")
    gd = g_mod.resolve_geo(x, y, use_cache=True)
    print(f"[geo] {gd.get('commune_nom')} (INSEE {gd.get('code_insee')}) — "
          f"ZRE: {gd.get('zre_statut')} — MESO: {gd.get('meso_code')}")

    # En-tête principal
    cell = ws.cell(row=START_ROW, column=2,
                   value="RÉSOLUTION GÉOGRAPHIQUE AUTOMATIQUE — X/Y Lambert 93 → contexte réglementaire")
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[START_ROW].height = 22
    try:
        ws.merge_cells(start_row=START_ROW, start_column=2, end_row=START_ROW, end_column=5)
    except Exception:
        pass  # déjà fusionné

    # Note explicative
    ws.cell(row=START_ROW + 1, column=2,
            value=("ℹ  Ces cellules sont régénérées automatiquement à chaque génération du PDF "
                   "à partir des coordonnées X/Y (C33-C34) — APIs SANDRE / Hub'Eau / "
                   "geo.api.gouv.fr / référentiel ZRE.")
            ).font = DESC_FONT
    try:
        ws.merge_cells(start_row=START_ROW + 1, start_column=2,
                       end_row=START_ROW + 1, end_column=5)
    except Exception:
        pass

    # En-têtes colonnes
    hdr_row = START_ROW + 2
    for col, label in zip([2, 3, 4, 5],
                          ["Paramètre", "Valeur résolue", "Unité / Type", "Source"]):
        c = ws.cell(row=hdr_row, column=col, value=label)
        c.font = Font(bold=True, color="FFFFFF", size=9)
        c.fill = SUB_HEAD_FILL
        c.alignment = Alignment(horizontal="center", vertical="center")
        c.border = BORDER

    zre_statut = gd.get("zre_statut", "—")
    if zre_statut == "CONFIRMÉ":
        zre_fill = OK_FILL
    elif "PRÉSOMPTION" in zre_statut:
        zre_fill = WARN_FILL
    else:
        zre_fill = None

    rows_data = [
        ("Commune (résolue auto)",    gd.get("commune_nom", "—"),         "—",         "geo.api.gouv.fr"),
        ("Code INSEE",                gd.get("code_insee", "—"),          "—",         "INSEE / geo.api.gouv.fr"),
        ("Code département",          gd.get("code_dpt", "—"),            "—",         "INSEE"),
        ("Code région",               gd.get("code_region", "—"),         "—",         "INSEE"),
        ("Longitude WGS84",           round(gd.get("lon_wgs84", 0), 6),   "° décimal", "Conversion L93 (pyproj)"),
        ("Latitude WGS84",            round(gd.get("lat_wgs84", 0), 6),   "° décimal", "Conversion L93 (pyproj)"),
        ("Bassin DCE",                gd.get("bassin_dce", "—"),          "—",         "Hub'Eau / SANDRE"),
        ("Agence de l'Eau",           gd.get("agence_eau", "—"),          "—",         "Référentiel SDAGE"),
        ("SDAGE applicable",          gd.get("sdage", "—"),               "—",         "Référentiel SDAGE"),
        ("SAGE applicable",           gd.get("sage", "—") or "—",         "—",         "GestEau / SANDRE"),
        ("Code masse d'eau (SANDRE)", gd.get("meso_code", "—"),           "Code FR…",  "Hub'Eau qualité_nappes"),
        ("Libellé masse d'eau",       gd.get("meso_libelle", "—"),        "—",         "Référentiel SANDRE"),
        ("Statut ZRE",                zre_statut,                         "—",         "Registre officiel ZRE"),
        ("Nappe ZRE concernée",       gd.get("zre_nappe", "—") or "—",    "—",         "Référentiel ZRE"),
        ("Arrêté préfectoral ZRE",    gd.get("zre_arrete", "—") or "—",   "—",         "Recueil actes administratifs"),
        ("Mise à jour ZRE",           gd.get("zre_date_maj", "—") or "—", "Date",      "Source ZRE"),
        ("Régime IOTA déclenché",
            ("AUTORISATION 1.1.1.0+1.1.2.0+1.3.1.0" if zre_statut == "CONFIRMÉ"
             else ("DÉCLARATION/AUTORISATION selon Q"
                   if "PRÉSOMPTION" in zre_statut
                   else "DÉCLARATION 1.1.1.0+1.1.2.0")),
            "—", "Calcul auto à partir Q et statut ZRE"),
    ]

    for i, (lab, val, unit, src) in enumerate(rows_data, start=hdr_row + 1):
        c_lab = ws.cell(row=i, column=2, value=lab)
        c_lab.font = LABEL_FONT; c_lab.border = BORDER
        c_val = ws.cell(row=i, column=3, value=val)
        c_val.font = VALUE_FONT; c_val.border = BORDER
        c_val.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        c_unit = ws.cell(row=i, column=4, value=unit)
        c_unit.font = DESC_FONT; c_unit.border = BORDER
        c_unit.alignment = Alignment(horizontal="center", vertical="center")
        c_src = ws.cell(row=i, column=5, value=src)
        c_src.font = DESC_FONT; c_src.border = BORDER
        c_src.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
        # Coloration des lignes ZRE selon statut
        if "ZRE" in lab and zre_fill is not None:
            for col in range(2, 6):
                ws.cell(row=i, column=col).fill = zre_fill
        elif i % 2 == 0:
            for col in range(2, 6):
                ws.cell(row=i, column=col).fill = INFO_FILL
        else:
            for col in range(2, 6):
                ws.cell(row=i, column=col).fill = NEUTRAL_FILL

    # Largeurs des colonnes
    ws.column_dimensions["B"].width = 42
    ws.column_dimensions["C"].width = 50
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 32

    wb.save(xlsx_path)
    print(f"[ok]  Tableur mis à jour : {xlsx_path}")
    return gd


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_XLSX
    update_geo_block(path)
